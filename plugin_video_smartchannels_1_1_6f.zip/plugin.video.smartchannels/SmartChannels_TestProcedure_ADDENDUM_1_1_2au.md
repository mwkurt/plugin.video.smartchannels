# plugin.video.smartchannels
# TEST PROCEDURE ADDENDUM — Version 1.1.2au
# Covers ONLY: the service.py / channel_manager.py advance_state →
#              advance_show duplication fix
# Base document: SmartChannels_COMPREHENSIVE_TestProcedure_1_1_2aq.md

---

## SCOPE OF THIS ADDENDUM

1.1.2au deleted `service.py`'s module-level `advance_state()` and
`get_episodes()` entirely. All TV and serial state advancement now goes
through `channel_manager.advance_show()` (called from two sites in
`service.py`: natural episode end in `PlaybackMonitor._handle_end`, and
skip-detected advancement in `SmartChannelsService`).

**Not touched this session, do NOT retest:** queue building, top-up /
join-boundary logic (`_topup_queue`, `_build_fresh_queue`, tail marker,
`last_slot_files`, `start_after`), interleave (silent or non-silent),
Coming Up Next, resume system, movie channel state (`advance_movie_state`
is a separate, untouched function), folder channels, episode filters,
settings, channel CRUD, backup/restore, artwork. All of Sections 1, 2,
9, 11–18 of the base test procedure are unaffected by this change and do
not need to be repeated.

**Also out of scope: verifying the queue never runs dry.** That is a
top-up invariant (`_topup_queue` firing at the replenishment threshold),
not something this session touched. The only legitimate place a queue
genuinely runs dry is a channel's true final episode with recycle=False
— every test case below that exercises a recycle=False channel's true
end checks for that, and only that. No test case here asks you to
verify or watch for dry-queue behavior on a recycle=True channel or
before a channel's actual final episode — if you observe it there,
that's a top-up bug, not something this addendum is designed to catch.

**In scope:** any test case in Sections 3–8 and 10 of the base procedure
that exercises an episode finishing naturally or being skipped, for TV
and serial channels only. Movie channels are excluded — `advance_show`
is never called for movies.

---

## TC-AU.1: TV sequential, single-show — mid-rotation advance (fast path)

**Maps to:** TC-3.3 (Sequential advancement), regression-focused.

**Setup:** TV channel, 1 show, sequential, recycle=True (as TC-3.1).

**Steps:**
1. Clear kodi.log.
2. Play 3 episodes to natural completion.

**Expected:**
- [ ] Episodes play in order E01 → E02 → E03, no skips, no repeats
- [ ] Log shows `[ChannelManager] advance_show: fast-path show=<id>
      next_ep=<id> S1E2` (or similar) after each episode — confirms the
      fast path fired, not a DB roundtrip
- [ ] No new/extra `GetEpisodes` JSON-RPC log entries appear between
      episodes (confirms the "no DB roundtrip" optimization is preserved)

---

## TC-AU.2: TV sequential, single-show — end-of-library stop (recycle=False)

**Maps to:** TC-8.1 (Sequential channel exhaustion), regression-focused.

**Setup:** Small test show, sequential, recycle=False.

**Steps:**
1. Play all episodes to natural completion.

**Expected:**
- [ ] After the last episode: exhaustion dialog appears (Delete channel
      / Reset to start / Do nothing)
- [ ] Log shows `[ChannelManager] _advance_sequential: show <id>
      exhausted, recycle=False`
- [ ] All three exhaustion dialog options still behave correctly
      (this confirms `next_episode_id=None` is actually being written —
      this specific write was added to `_advance_sequential` in this
      session; previously it only existed in the deleted
      `service.py` function)

---

## TC-AU.3: TV two-show Round Robin — rotation order preserved

**Maps to:** TC-5.1 (Round Robin rotation order), TC-5.2 (preserved
across stop/restart) — regression-focused, single pass is sufficient.

**Setup:** 2-show TV channel, sequential Round Robin (as TC-5.1).

**Steps:**
1. Play 6 episodes, noting which show each comes from.
2. Stop after episode 3, reopen the channel.

**Expected:**
- [ ] Strict A → B → A → B → A → B alternation
- [ ] After stop/reopen, rotation resumes from the correct show (not
      restarted)

---

## TC-AU.4: TV mixed sequential/random — per-show randomize still resolved correctly

**Maps to:** TC-6.1 (Per-show randomize).

**Setup:** 2-show channel, Show A sequential, Show B per-show random
(as TC-6.1).

**Steps:**
1. Play 10 episodes.

**Expected:**
- [ ] Show A plays in strict sequential order every time
- [ ] Show B plays in random order
- [ ] Rotation still strictly alternates A → B → A → B
- [ ] (This specifically verifies `advance_show`'s per-show `shows[]`
      entry lookup — the randomize-override resolution — still works
      after the refactor.)

---

## TC-AU.5: TV random, single-show, recycle=True — full-cycle reset

**Maps to:** TC-4.1 (Random mode — no repeats until full cycle).

**Setup:** Small test show (5–6 episodes), random, recycle=True.

**Steps:**
1. Clear kodi.log.
2. Play through enough episodes to complete one full cycle (every
   episode played once) and into the start of a second cycle.

**Expected:**
- [ ] No episode repeats until all episodes have played once
- [ ] After the full cycle, episodes begin repeating in a new random
      order (not blocked)
- [ ] Log shows `actually_played_ids` being tracked and reset after the
      full cycle (search log for `advance_show: fast-path` lines and
      confirm the field isn't growing without bound)

---

## TC-AU.6: TV random, single-show, recycle=False — exhaustion

**Maps to:** TC-4.3 (Recycle=False — exhaustion).

**Setup:** Small test show, random, recycle=False.

**Steps:**
1. Play until all episodes have played once.

**Expected:**
- [ ] Exhaustion dialog appears once the full episode pool has played
- [ ] Delete / Reset / Do nothing options work correctly

---

## TC-AU.7: Serial, single-show — ordinary in-show advancement does NOT reset the show

**Maps to:** TC-10.1 (Single-show serial — strict order). **This is the
highest-priority new check** — the refactor introduced a new code path
(`_advance_serial`) that must distinguish an ordinary in-show step from
a real show-boundary, and a 1-show serial channel only ever has
in-show steps until the very last episode.

**Setup:** Serial channel, 1 show, 6+ episodes.

**Steps:**
1. Clear kodi.log.
2. Play episodes 1 through 4 (do NOT reach the end of the show).

**Expected:**
- [ ] Strict order E01 → E02 → E03 → E04, no deviation
- [ ] Log shows `_advance_serial: fast-path show=<id> next_ep=<id>` for
      each transition
- [ ] Log does **NOT** show `_advance_serial: show boundary` at any
      point during this run — if it appears mid-show, the show was
      incorrectly reset

---

## TC-AU.8: Serial, two-show — boundary crossing fires exactly once, at the right point

**Maps to:** TC-10.2 (Two-show serial — show advancement).

**Setup:** Serial channel, Show A (5 episodes) + Show B (5 episodes).

**Steps:**
1. Clear kodi.log.
2. Play through Show A completely (all 5 episodes) and into Show B's
   first episode.

**Expected:**
- [ ] After Show A E05 completes, Show B E01 begins immediately —
      no skipped or repeated episode at the join
- [ ] Log shows exactly ONE `_advance_serial: show boundary <A_id> ->
      <B_id>` line, occurring right after Show A's last episode
- [ ] No boundary-crossing log lines appear during Show A episodes 1–4

---

## TC-AU.9: Serial, two-show, recycle=True — wraps to Show A after Show B

**Maps to:** TC-10.3.

**Steps:**
1. Continue TC-AU.8 through Show B's final episode.

**Expected:**
- [ ] After Show B's last episode, Show A E01 begins again
- [ ] Log shows a second `_advance_serial: show boundary` line
      (B → A, wrapping back to index 0)

---

## TC-AU.10: Serial, two-show, recycle=False — exhaustion after both shows complete

**Maps to:** TC-10.4.

**Setup:** 2-show serial, recycle=False.

**Steps:**
1. Play through both shows completely.

**Expected:**
- [ ] Exhaustion dialog appears after Show B's final episode — no
      restart of Show A
- [ ] Log shows `_advance_serial: queue dry for show=<id> — treating as
      show boundary` exactly once, on the channel's final episode only
      — this is the no-next-ep-id queue-dry path, distinct from the
      next_ep_id-present boundary path in TC-AU.8, and it is the one
      legitimate case in this addendum where "queue dry" is expected

---

## TC-AU.11: Serial resume — unaffected by the refactor

**Maps to:** TC-10.5. Regression-only — `advance_show` is not involved
in resume logic, but confirm the two systems still interact correctly.

**Steps:**
1. Play a serial episode past 60s.
2. Stop mid-episode.
3. Reopen the serial channel.

**Expected:**
- [ ] Resume dialog appears for the correct episode
- [ ] After resuming and finishing that episode, serial advancement
      continues normally (in-show or boundary, as appropriate)

---

## TC-AU.12: Skip-detection path — TV and serial, both call sites exercised

**No direct equivalent in base procedure** — this specifically tests
the SECOND `advance_show` call site (`SmartChannelsService`'s
skip-detection path), which TC-AU.1 through TC-AU.10 do NOT cover
(those all go through natural episode end / `_handle_end`).

**Setup:** Any TV sequential channel, and separately a 2-show serial
channel.

**Steps:**
1. Play a TV episode, then press skip-forward past the end of the
   current episode (triggers skip detection, not natural completion).
2. Repeat on the serial channel, skipping forward across a show
   boundary (e.g. skip from Show A's last episode into Show B).

**Expected:**
- [ ] TV: state advances correctly to the next episode, same as natural
      end (log shows `advance_show: fast-path` from the skip code path)
- [ ] Serial: skipping across a show boundary correctly resets the
      finished show and advances to the next show (log shows
      `_advance_serial: show boundary` triggered from the skip path)
- [ ] No duplicate or skipped episodes in either case

---

## SIGN-OFF TABLE — ADDENDUM 1.1.2au

| TC | Description | Pass | Fail | Skip |
|----|--------------|------|------|------|
| AU.1 | TV sequential — fast-path mid-rotation | | | |
| AU.2 | TV sequential — end-of-library stop (recycle=False) | | | |
| AU.3 | TV two-show Round Robin order preserved | | | |
| AU.4 | TV mixed sequential/random per-show resolution | | | |
| AU.5 | TV random recycle=True — full-cycle reset | | | |
| AU.6 | TV random recycle=False — exhaustion | | | |
| AU.7 | Serial single-show — in-show steps don't reset | | | |
| AU.8 | Serial two-show — boundary crossing | | | |
| AU.9 | Serial two-show recycle=True — wraps | | | |
| AU.10 | Serial two-show recycle=False — exhaustion | | | |
| AU.11 | Serial resume — unaffected | | | |
| AU.12 | Skip-detection path — both call sites | | | |
| **TOTAL** | | **12** | | |

**A pass on every row above is required before 1.1.2au can be
considered confirmed working** and used as a rollback target.
