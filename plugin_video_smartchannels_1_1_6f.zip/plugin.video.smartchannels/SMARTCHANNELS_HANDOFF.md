# plugin.video.smartchannels — Project Handoff

## Overview

Custom Kodi 21 (Omega / Python 3) addon that creates smart TV-style channels
playing TV episodes and movies in configurable rotation with persistent
queue/state management and auto top-up.

- **Owner/Developer:** Mark
- **Primary test machine:** Windows 10 PC. Shield is primary playback device.
- **Confirmed working baseline:** `1.1.6f` ✅ CONFIRMED STABLE
- **Last confirmed zip:** `plugin_video_smartchannels_1_1_6f.zip`
- **addon.xml version:** `1.1.6f`
- **Current build:** `1.1.6f` — Settings action button fix (create_channel, auto_create)
- **Goal:** Eventual submission to the official Kodi addon repository
- **Working directory:** `/home/claude/plugin_work/build_out/plugin.video.smartchannels/`
- **Output zips:** `/mnt/user-data/outputs/` — uncompressed (`-0` flag),
  exclude `*.pyc` and `__pycache__`
- **strings.po last used ID:** `#32660`
- **strings.po total strings:** 457 (zero duplicates, zero broken)
- **Pre-existing orphaned strings (harmless):** #32183–32191, #32222, #32231,
  #32256, #32281, #32286, #32441, #32443, #32444, #32497, #32512, #32517
- **Next free string ID:** `#32661`
- **addon.xml version must match zip filename on every build**

---

## Current Build — 1.1.6f

Settings action button fix. Auto-Create and Create New Channel now work
correctly from Settings. Overnight carousel log reviewed: 11h 56m, 33
pops, 0 errors. `_strip_leading_silents` fired once correctly.

---

## Architecture Rules — NEVER VIOLATE

1. `service.py` owns ALL playback callbacks, state advancement, resume,
   top-up, playlist management
2. `player.py` owns ONLY `start_channel()` and `_write_now_playing()`
3. `channel_manager.py` owns queue building, state read/write, library access
4. NO duplicate code between files — check before every change
5. NO playback event handlers outside `service.py`
6. **NO hardcoded user-visible strings** — all through strings.po via `_s()`
   - Log lines to kodi.log are exempt (developer-facing)
   - Every dialog title, body text, button label, setting label → strings.po
7. All code written for Kodi official repo submission standards
8. All file I/O through `xbmcvfs`
9. MANDATORY before/after code audit on every change: read the full method
   before editing, verify in context after, check all callers unaffected,
   syntax-check all modified files
10. One feature or fix at a time
11. Never break working functionality
12. **FAILED FIX PROTOCOL:** Before touching any code after a failed fix,
    explicitly state "Roll Back" or "Build On Top" and why (1–2 sentences).
    If this declaration is missing, push back before writing any code.
13. **CHANGELOG:** Every new build gets a `CHANGELOG.md` entry before packaging
14. **STRINGS:** Run audit script before AND after every session involving strings
15. **Read this handoff fully at the start of every session**

---

## Key Files

| File | Responsibility |
|------|---------------|
| `service.py` | Background service: playback events, skip detection, resume, top-up, exhaustion, CUN, carousel tick |
| `player.py` | `start_channel()`, `_write_now_playing()` only |
| `resources/lib/channel_manager.py` | Queue building, state I/O, library access, interleave |
| `resources/lib/carousel.py` | Carousel channel manager — owns ALL carousel logic |
| `resources/lib/channels/serial.py` | Serial queue builder |
| `resources/lib/channels/interleave.py` | Interleave weaving logic |
| `resources/lib/ui/channels.py` | Channel wizard including carousel step (TV+Movie only) |
| `resources/language/resource.language.en_gb/strings.po` | All UI strings — last ID #32660, 458 total, next free #32661 |
| `CHANGELOG.md` | Version history — write entry BEFORE packaging |

---

## Channel Types

| Type | Description |
|------|-------------|
| `tv` | Round Robin or Random TV show rotation with per-show episode filters and exclusions |
| `movies` | Movie channel with optional filters and exclusions |
| `serial` | Single or multiple shows in strict serial order |
| `folder` | Media files from a directory path (no Kodi library needed) |
| `audio` | Music channel from Kodi music library — queued for future revision |

Both TV and Movie channels support carousel. Serial, Folder, and Audio do not.

---

## Carousel Feature — Confirmed in 1.1.4o

Per-channel setting for TV and Movie channels. While nobody is watching,
every N minutes, M real items are removed from the front of the queue
file using Option A trailing sweep — silent interleaved items are swept
for free and do not count against pop_count. After every pop the queue
is immediately topped up to full depth via `_topup_queue`. When the user
opens the channel they pick up wherever the queue currently sits.

### Architecture
- `carousel.py` — owns ALL carousel logic
- `service.py` — two additions only:
  - Startup catch-up: `CarouselManager.check_all()` before run loop
  - `if tick % 60 == 0:` carousel check in run loop
- `channel_manager.py` — carousel fields in create/update whitelists;
  `_no_queue_change` guard in `update_channel`
- `ui/channels.py` — wizard Step 8 for TV and Movie channels only

### State key
`{channel_id}:__carousel__` → `{"last_pop_time": <float unix timestamp>}`

### Channel fields
| Field | Type | Default | Meaning |
|---|---|---|---|
| `carousel_enabled` | bool | False | Whether carousel is active |
| `carousel_interval` | int | 60 | Minutes between pops |
| `carousel_pop_count` | int | 1 | Real items removed per pop |

### Constants (carousel.py)
- `CAROUSEL_MIN_INTERVAL = 20` — enforced by wizard
- `CAROUSEL_QUEUE_FLOOR = 2` — last-resort safety constant (superseded
  by dynamic refill_threshold guard as primary clamp)

### Silent item sweep (Option A — 1.1.4o)
Silent interleaved items (`_silent=True`) are swept for free. The pop
walks forward counting only real items. After the last counted real item,
any immediately-following silents are also swept. The queue front is
always a real program after every pop.

### Pop guard
`pop_count` is clamped so at least `get_replenishment_threshold()` real
items remain after the pop (20% of queue_size, minimum 5).

### Resume behaviour
Resume cleared on pop via `clear_resume_position()`. Key also removed
from `self._state` and added to `_deleted_state_keys` to prevent
resurrection via `_save_state` merge (fixed in 1.1.4l).

---

## _no_queue_change Guard — update_channel

`update_channel` in `channel_manager.py` skips `_pregenerate_queue_safe`
when none of these fields changed: `name`, `shows`, `movies`,
`queue_size`, `interleave`, `filters`, `excluded_movies`, `mode`.
Carousel field changes and no-op edits both correctly skip the rebuild,
preserving the carousel's popped position.

---

## strings.po Audit Script

```python
import re, glob
from collections import Counter
base = "/home/claude/plugin_work/build_out/plugin.video.smartchannels"
with open(base + "/resources/language/resource.language.en_gb/strings.po") as f:
    po = f.read()
all_ids = re.findall(r'msgctxt "#(\d+)"', po)
defined = set(int(x) for x in all_ids)
dupes = {k: v for k, v in Counter(all_ids).items() if v > 1}
code_ids = set()
for fpath in glob.glob(base + "/**/*.py", recursive=True):
    with open(fpath) as f: src = f.read()
    joined = src.replace("\n", " ")
    for m in re.findall(r'(?:getLocalizedString|_s)\s*\(\s*(\d{5})\b', joined):
        code_ids.add(int(m))
with open(base + "/resources/settings.xml") as f: xml = f.read()
xml_ids = set(int(x) for x in re.findall(r'label="(\d+)"', xml))
xml_ids |= set(int(x) for x in re.findall(r'values="(\d+)"', xml))
all_used = code_ids | xml_ids
broken = sorted(all_used - defined)
orphaned = sorted(defined - all_used)
print("Duplicates:", dupes or "NONE")
print("Broken:", broken or "NONE")
print("Orphaned:", orphaned or "NONE")
print("Highest ID: #{}".format(max(defined)))
print("Total strings:", len(defined))
```

---

## Feature Queue

### Next confirmed feature
**Auto-Channel Creation** — COMPLETE in 1.1.5a.
- `resources/lib/ui/auto_channels.py` — full 9-screen wizard
- Wired into main screen, router.py, addon.py dispatch table
- Strings #32591–#32645 (55 strings)

### Completed features (for reference)

**Auto-Channel Creation** — COMPLETE in 1.1.5a.
- Genre-based auto-generation wizard (9 screens)
- `resources/lib/ui/auto_channels.py`
- Wired into main screen, router.py, addon.py

**Channel Side Panel** — COMPLETE in 1.1.6f.
- Custom `xbmcgui.WindowXML` panel replacing channel list directory view
- Left pane: channel list; right pane: scrollable upcoming queue
- Play from front or jump to any queue item
- Full context menu: Channel Info, Play, Reset, Edit, Delete,
  Toggle Visibility, Manage Interleave, View Exclusions
- Show Hidden Channels toggle
- Silent interleave items filtered from right pane
- `resources/lib/ui/side_panel.py` + skin XML for Estuary/Default/Confluence

**Carousel (Pseudo Live)** — COMPLETE in 1.1.4o.
- Wall-clock-driven channel advancement — pops episodes on a timer so
  viewers always pick up at the current clock position. This is the
  addon's implementation of pseudo-live / simulated broadcast.

### Possible future features (in dependency order)

**Duration Cache** — prerequisite for Scheduled Programming only.
Library items first; ffprobe extension for Windows phase 2. Only needed
if Scheduled Programming is confirmed wanted.

**Scheduled Programming** — requires Duration Cache. User creates a
hidden movie/TV channel as the content source and a schedule entry
defining: source channel, target channel, item count, date/time. The
service rebuilds the target channel's queue ahead of the scheduled time,
inserting the scheduled item at the position nearest the target time
(calculated from item durations). No mid-episode cuts — always starts
and ends at natural item boundaries. Approximate timing is acceptable.
Shelved until Duration Cache is built.

---

## Known Open Bugs

### Double-silent at top-up join boundary (interleaved folder channels)
**Symptom:** When two top-ups fire in rapid succession on a channel with
silent folder interleave, two silent items can appear back-to-back at the
join boundary between the two top-up blocks. This occurs when the offset
math places a silent item at the end of one top-up block AND `offset=0`
on the next block places a silent at the very start of the new block.
`_strip_leading_silents` catches the leading silent of the new block but
the trailing silent of the previous block is already committed to the queue.
**Impact:** Two back-to-back bumpers visible (silently) instead of one.
Playback unaffected. Users on non-silent interleave would see two bumpers
play consecutively.
**Fix:** Top-up weaver needs to track the real-episode count at the tail
of the previous block and carry it as the offset seed for the next block,
so the interleave rhythm is continuous across top-up joins.
**When:** Next session that touches `_topup_queue` / interleave weaving.

---

### Redundant top-up on recycle=False exhausting channels
**Symptom:** For a recycle=False channel where the show has fewer
episodes than queue_size, `_topup_queue` fires on every episode
transition once the queue drops below threshold, returns 0 items each
time, and rewrites the tail marker unnecessarily.
**Impact:** Log noise and redundant disk writes only. Playback unaffected.
**Fix:** Add early-exit in `_topup_queue` when recycle=False and all
shows are exhausted.
**When:** Next session that touches `_topup_queue`.

---

## Lower Priority Feature Queue (no committed build date)

### Channel Logos — 1.1.6b
**Target revision:** 1.1.6g — implement after 1.1.6f is confirmed stable.

**Summary:** Allow the user to assign a custom PNG/JPG logo to any channel.
The logo displays in both the side panel channel list (left pane) and the
standard directory-listing channel list. No logo = existing generic icon,
exactly as today.

**Storage convention:** No new field in `channels.json`. Logos live in a
dedicated subfolder of the addon profile:
```
userdata/addon_data/plugin.video.smartchannels/logos/<channel_id>.png
```
The channel UUID is the filename. The folder is created automatically on
first use.

**Art resolution logic (both side_panel.py and ui/channels.py):**
```python
logo_path = os.path.join(profile, "logos", "{}.png".format(ch["id"]))
icon = logo_path if xbmcvfs.exists(logo_path) else "DefaultVideoPlaylists.png"
li.setArt({"icon": icon})
```
Both `.png` and `.jpg` should be checked (try `.png` first, then `.jpg`).

**New context menu action: "Set Channel Logo"**
- Added to the context menu in `ui/channels.py` `_add_channel_item()`.
- Opens a `xbmcgui.Dialog().browseSingle()` file browser filtered to
  image files.
- Copies the chosen file to `logos/<channel_id>.png` (always normalise
  to .png filename regardless of source extension — Kodi handles the
  actual image format from the file bytes).
- Shows a success notification.
- Fires `Container.Refresh`.

**New context menu action: "Clear Channel Logo"**
- Only shown when a logo file already exists for that channel.
- Deletes `logos/<channel_id>.png` (and `.jpg` if present).
- Shows a notification confirming removal.
- Fires `Container.Refresh`.

**Auto-Create channels:** No automatic logo assignment. User sets logos
manually after channel creation.

**Delete channel:** `channel_manager.delete_channel()` should also delete
`logos/<channel_id>.png` and `.jpg` if they exist. Add cleanup there.

**Files changed:**
- `resources/lib/ui/channels.py` — `_add_channel_item()`: logo art
  resolution + two new context menu entries.
- `resources/lib/ui/side_panel.py` — `_populate_channel_list()`: same
  logo art resolution logic.
- `resources/lib/channel_manager.py` — `delete_channel()`: add logo
  file cleanup.
- `strings.po` — 4 new strings (Set Logo label, Clear Logo label,
  logo set notification, logo cleared notification).
  Next free ID at time of writing: **#32661** (audit before use).

**No changes to:** `channels.json` schema, `state.json`, queue files,
service.py, player.py, carousel.py, router.py (context menu is built
in `ui/channels.py` via `RunPlugin` URLs — the router action for
`set_channel_logo` and `clear_channel_logo` must also be added to
`router.py` and `addon.py`).

**Strings needed (starting #32661 — audit before use):**
| ID | Text |
|----|------|
| #32661 | `Set Channel Logo` |
| #32662 | `Clear Channel Logo` |
| #32663 | `Channel logo updated` |
| #32664 | `Channel logo removed` |

**Complexity:** Low. ~60 lines of new code across 4 files. No
architectural concerns. One session.

---

### Movie Channel Filter Persistence & Display
**Problem:** When a movie channel is created using a genre or year filter,
the filter criteria (type and value) are immediately discarded after the
matching movie list is resolved. Only the resulting list of movie IDs is
stored in `channels.json`. The `filters` field is left empty `[]`.
Consequences:
- Channel Info shows no filter information whatsoever.
- The genre/year wizard cannot pre-highlight the previously chosen value
  when the channel is edited.
- There is no way for the user to know after creation how the channel was
  originally filtered.

**Confirmed via `channels.json` inspection:** `CH-MOV-EXCL` (created by
year) has `"filters": []` — zero filter metadata stored.

**Fix — three coordinated changes:**
1. **`ui/channels.py` — wizard:** After resolving the filtered movie list,
   store `"filter_type"` (`"genre"`, `"year"`, or `"manual"`) and
   `"filter_value"` (the genre string or year integer) in the channel
   definition alongside the movie list. Manual selection stores
   `filter_type: "manual"`, `filter_value: null`.
2. **`ui/channels.py` — `channel_info()`:** Read `filter_type` and
   `filter_value` and display a meaningful line, e.g.
   `"Filter: By Year — 2025"` or `"Filter: By Genre — Comedy"` or
   `"Filter: Manual selection"`. Replace the current `"Filters: Yes"`
   string (#32393) or augment it.
3. **`ui/channels.py` — edit wizard:** When re-entering the movie filter
   step, pre-select the correct filter_type option and pre-highlight the
   matching genre/year in the selection dialog using the stored value.

**strings.po:** New string IDs needed for filter type labels in Channel
Info display. Audit before writing any new IDs.

**`_no_queue_change` guard:** `filter_type` and `filter_value` are
metadata only — they must NOT be included in the queue-change comparison
in `update_channel`. Only the resolved `movies` list matters for queue
rebuilds.

**When:** Next session that touches movie channel creation/editing. This
also closes two of the three existing non-blocking open items (filter
display label and genre wizard pre-highlight).

---

### Per-Show Expire in Round Robin
A per-show toggle for sequential (non-random) Round Robin TV channels.
When enabled on a specific show, that show plays through all its episodes
once and then permanently drops out of the rotation. The channel's other
shows continue cycling normally forever.

**Example:** Channel has Seinfeld, 3rd Rock, and Frasier. Frasier is
flagged expire_on_complete. Once Frasier's last episode plays it is gone
from the rotation permanently. Seinfeld and 3rd Rock keep cycling.

**Use case:** Watching a limited series or miniseries once as part of a
channel without having to remember to remove it manually afterward.

**Config:** New per-show key `shows[].expire_on_complete: true` (default
`false`). Set only in the creation wizard — not editable after creation.

**Architecture:** Mirrors the existing per-show `randomize` override
pattern. `_advance_sequential` already writes the exhaustion marker
(`next_episode_id: None`) on a show's last episode for recycle=False
channels — this feature gates that same write per-show instead of
channel-wide. The existing `_topup_queue` round-robin loop already
tracks a per-show `exhausted` set and skips exhausted shows.

**Before building:** Verify that `_topup_queue`'s round-robin loop
correctly continues indefinitely with a shrinking subset of active shows,
and that `episodes_per_slot` timing and `show_index` cycling are not
thrown off as shows drop out.

**Out of scope:** Serial channels (concept doesn't apply) and
channel-level `recycle=False` (all shows already behave this way).

---

### Notify on New Episodes
Per-show toggle on TV channels. When the library cache rebuilds after a
Kodi library scan (`VideoLibrary.OnScanFinished` → `_rebuild_library_cache`
already hooked in `service.py`), check `get_recently_added_episodes()`
against the `tvshowid` sets of all channels where any show has
`notify_new_episodes: true`. Fire a Kodi toast notification for each match:
"Smart Channels — New episode: The Office S09E23 - Finale."

To avoid repeat notifications across restarts, store a pruned set of
already-notified episode IDs in state.json under a dedicated key.

**Infrastructure already in place:**
- `onNotification` → `_rebuild_library_cache` hook in `service.py`
- `get_recently_added_episodes()` in `library.py`
- Toast notification pattern already used elsewhere in service.py

**New work needed:** per-show wizard toggle, post-rebuild comparison method
in `channel_manager.py`, notified-IDs state key.

---

### Duration Cache — Spec 4 (prerequisite for Scheduled Programming and side panel timing)
**Target revision:** 1.1.7a — implement after 1.1.6 line is confirmed stable.

**Reference:** SmartChannels_FeatureSpecs.md — Spec 4.

**Summary:** Stamps accurate duration (seconds) onto every queue item at
build/top-up time. Three media types handled differently:

| Type | Source | Method |
|------|--------|--------|
| TV episodes | Sidecar `.nfo` file | Read at queue build/top-up |
| Movies | Library cache `runtime` field | Already in `local_library.json` |
| Folder items | Organic capture from playback | `getTotalTime()` in `onPlayBackEnded` |

Kodi JSON-RPC `runtime` for TV episodes is NOT used — long-standing Kodi
bug makes it unreliable. NFO files are the only reliable TV episode
source. Users must run **Kodi → Videos → Export → Separate files** to
ensure NFO files exist and contain current data for all episodes.

**Skip behaviour (confirmed by Mark):** TV episodes without a valid NFO
duration are skipped entirely from the queue — not queued, not played.
No guessing, no defaults for TV episodes. The user is informed via a
dedicated missing-durations log file (see below). Movie and folder items
are never skipped.

**Existing queue items:** No forced rebuild when the feature is installed.
Items already in queue files play normally without a `duration` field —
they are treated as unknown duration (no timing display, no scheduling).
To add durations to an existing channel's queue the user edits the
channel and changes any queue-affecting field (e.g. queue size +1 then
back) to trigger a rebuild. A dedicated **"Rebuild Queue (stamp
durations)"** context menu action should be added to make this explicit
and user-friendly — avoids the queue size workaround and does NOT reset
show positions to S01E01.

**Important — `_no_queue_change` guard:** Changing the channel name and
back does NOT trigger a queue rebuild. The `name` field is included in
the `_no_queue_change` comparison in `update_channel()` at line 423 of
`channel_manager.py`. The queue size trick (change size +1 then back)
does work but is unintuitive. The dedicated context menu action is the
right solution.

---

#### NFO parsing — `read_nfo_duration(file_path)`

NFO path derived by replacing the video file extension with `.nfo`:
```
smb://Server/TV/Show/Season 1/Show - S01E01.mkv
→ smb://Server/TV/Show/Season 1/Show - S01E01.nfo
```
Read via `xbmcvfs.File()` — works on SMB, NFS, and local paths.

Tag priority (both TV `<episodedetails>` and movie `<movie>` roots):
1. `<durationinseconds>NNN</durationinseconds>` — exact seconds (Kodi 19+, Sonarr/Radarr)
2. `<runtime>NN</runtime>` — minutes, multiply × 60
3. Neither present or both zero → return `None` → episode skipped

`tvshow.nfo` (show-level) is ignored — contains average runtime only,
not per-episode data.

---

#### Missing durations log — `missing_durations.json`

New file in the shared data directory. Written at queue build/top-up
time whenever an episode is skipped due to missing NFO duration. Never
shown as a toast — log-only so as not to disrupt playback.

```json
[
  {
    "channel_id": "uuid",
    "channel_name": "Comedy TV",
    "show": "'Til Death",
    "season": 1,
    "episode": 3,
    "title": "The Ring",
    "file": "smb://Server/TV/...",
    "recorded_at": 1783282889.8
  }
]
```

Capped at 500 entries (oldest pruned). User reads the file to identify
which episodes need NFO files. A future Channel Info enhancement could
surface the count for a specific channel ("N episodes skipped — see
missing_durations.json").

---

#### Movies — library cache

`local_library.json` already contains `runtime` (seconds) for every
movie from the `GetMovies` JSONRPC call. At movie queue build time,
look up `movieid` in the library cache and stamp `duration` directly.
`runtime = 0` → `duration = 0` on the queue item (not skipped —
movie plays, just has no timing contribution).

No NFO read for movies. Library cache is reliable for movies.

---

#### Folder items — organic capture

In `service.py` `onPlayBackEnded`, for folder channel items only:
```python
if ch_type == "folder":
    d = int(self.player.getTotalTime())
    if d > 0:
        mgr.record_folder_duration(item["file"], d)
```
Written to `folder_durations.json` keyed by MD5 of file path.
Non-blocking, wrapped in try/except — any failure logged and ignored.
Replaces existing entry if file re-encoded (last-write-wins).

New field in Folder channel wizard: "Approximate duration of items in
this folder (minutes) [default: 2]". Stored as
`folder_default_duration_secs` on the channel definition. Used as
fallback for uncaptured items in scheduling calculations.

Channel Info for folder channels shows:
```
Duration coverage: 47 of 50 items captured
```

---

#### New file: `resources/lib/utils/duration_cache.py`

```python
def read_nfo_duration(file_path: str) -> int | None
def get_movie_duration(movieid: int, library_cache: dict) -> int
def record_folder_duration(file_path: str, duration_secs: int) -> None
def get_folder_duration(file_path: str) -> int | None
def get_folder_coverage(queue: list) -> tuple[int, int]
def log_missing_duration(channel_id, channel_name, item) -> None
```

`folder_durations.json` and `missing_durations.json` live in the
shared data directory alongside `channels.json` and `state.json`.

---

#### New context menu action: "Rebuild Queue (stamp durations)"

Added to channel context menu in `ui/channels.py`. Fires
`router.rebuild_queue_with_durations(channel_id)` which calls
`channel_manager.regenerate_queue(channel)` — same as the existing
regenerate path, which preserves current show positions and does NOT
reset to S01E01. The rebuilt queue gets fresh `duration` fields on
all items.

Only shown when the duration cache feature is active (i.e. always, once
the feature is in the build — no separate toggle needed).

---

#### Files changed

| File | Change |
|------|--------|
| `resources/lib/utils/duration_cache.py` | New file — all duration functions |
| `resources/lib/channel_manager.py` | Duration stamping in queue builder + top-up; `record_folder_duration()`; `get_folder_coverage()`; `rebuild_queue_with_durations()` |
| `resources/lib/ui/channels.py` | "Rebuild Queue" context menu entry; folder wizard default duration field; folder channel info coverage line |
| `resources/lib/router.py` | `rebuild_queue_with_durations` action |
| `addon.py` | Dispatch entry for new action |
| `service.py` | Folder duration capture in `onPlayBackEnded` |
| `strings.po` | 5–6 new strings — **audit before assigning IDs** (logos will use #32661–#32664; Duration Cache IDs TBD) |
| `folder_durations.json` | New data file (created on first capture) |
| `missing_durations.json` | New data file (created on first skip) |

---

#### Strings needed (IDs TBD — audit before use; logos consume #32661–#32664)

| Text |
|------|
| `Rebuild Queue (stamp durations)` |
| `Episode skipped — no NFO duration: {0}` |
| `Approximate duration of items in this folder (minutes)` |
| `Duration coverage: {0} of {1} items captured` |
| `All item durations captured` |

---

#### Performance

NFO reads over SMB: ~20–50ms each. Queue build of 30 episodes: ~1.5s
added. Top-up of 6 episodes: ~300ms. Both run in background threads —
no playback impact. Folder capture in `onPlayBackEnded` is a dict
lookup + JSON write — negligible.

---

#### Complexity: Medium. Estimate 1–2 sessions.
**Hard prerequisite for:** Scheduled Programming (Spec 5) and side panel
timing display.

---

### Audio Channel — Library Music Playback
**Target revision:** Future (after 1.1.6 line confirmed stable).
**Complexity:** Medium. Estimate 3–4 sessions.

**Summary:** A new channel type (`audio`) that plays songs from the Kodi
music library in channel-mode — continuous playback with shuffle/sequential
order, recycle, queue top-up, and carousel support disabled. Operates
identically to TV/Movie channels in terms of state management — the only
differences are the data source (music library vs video library) and the
Kodi playlist type used for playback.

**Architecture — no existing files broken:**
- `channels/audio.py` — new queue builder, same pattern as `channels/movies.py`
- `resources/lib/library.py` — new `get_songs()` method using
  `AudioLibrary.GetSongs` JSONRPC, same caching pattern as TV/movies.
  Cache stored in `local_library.json` under a new `"music"` key.
- `resources/lib/ui/channels.py` — new audio wizard path:
  Name → Source (All / By Artist / By Album / By Genre) → Shuffle or
  Sequential → Recycle → Queue Size → Visibility
- `resources/lib/player.py` — detect `channel_type == "audio"` and use
  `xbmc.PLAYLIST_MUSIC` instead of `xbmc.PLAYLIST_VIDEO`
- `service.py` — new branch in `onPlayBackEnded` state advancement for
  audio items. Coming Up Next suppressed for audio channels.
- `strings.po` — ~10 new strings. Audit before assigning IDs.

**Queue item format:**
```json
{
  "channel_id": "...",
  "songid": 1234,
  "title": "Song Title",
  "artist": "Artist Name",
  "album": "Album Name",
  "year": 2005,
  "file": "smb://...",
  "art": {
    "thumb": "image://...",
    "artist.thumb": "image://...",
    "fanart": "image://..."
  }
}
```

**No carousel support** — audio channels are always sequential or shuffle,
no wall-clock advancement needed. May be added later.

**No interleave support** in the initial revision — audio channels play
music only. Interleaving video bumpers into a music channel is a future
enhancement if ever wanted.

---

### Audio Channel — Artist Artwork Display (Option A)
**Target revision:** Same session as Audio Channel above — implement as
part of the initial audio channel build, not a separate revision.
**Complexity:** Low. ~30 lines additional in player.py.

**Summary:** When an audio channel plays a song, display the artist's
artwork (photo/thumbnail and fanart) on the Kodi now-playing screen using
the art properties already available from the Kodi music library. This
requires no scraper, no network calls, and no new data files — it uses
only what Kodi has already scraped and cached locally.

**What Kodi provides per song (from `AudioLibrary.GetSongs` with `art`
property):**
- `art.thumb` — album cover art
- `art.artist.thumb` — artist photo/thumbnail
- `art.fanart` — artist fanart (wide background image)

**Implementation:**
In `player.py` `_make_listitem()`, detect audio queue items and set art
properties on the ListItem:
```python
if item.get("channel_type") == "audio":
    art = item.get("art", {})
    li.setArt({
        "thumb":  art.get("artist.thumb") or art.get("thumb", ""),
        "fanart": art.get("fanart", ""),
        "icon":   art.get("thumb", ""),
    })
```

Kodi's Estuary skin then uses `thumb` for the main now-playing image and
`fanart` for the background — the artist photo fills the screen while
music plays with no extra code required.

**Fallback:** If `artist.thumb` is empty (artist not scraped), falls back
to album `thumb`. If both empty, Kodi shows its default music icon.

**No slideshow** — Kodi stores typically one `thumb` and one `fanart` per
artist from its scraper. Multiple-image cycling would require a network
scraper (Last.fm / fanart.tv) which is NOT being built at this time.

**No new strings needed.** No new files. Single method change in
`player.py` only.

---

### Queue File Write Lock
A file-level mutex in `utils/paths.py` to prevent silent data corruption
from concurrent queue file writes. Currently `_write_queue_file` has no
lock — carousel pop, playback top-up, and `onPlayBackEnded` all call
`save_json` directly with no mutual exclusion.

**Real risk:** Carousel pop vs `onPlayBackEnded` race — the carousel tick
and a natural episode end can both attempt to write the same queue file
in the brief window between one episode ending and the next starting.
Last write wins silently. No crash, but wrong queue state possible.

**Fix:** A `threading.Lock()` keyed by file path in a module-level dict
in `utils/paths.py`. Acquired before any write, released after. All queue
file writes become mutually exclusive regardless of calling thread.
Single-file change — `utils/paths.py` only.

**Priority note:** The carousel's architectural guard (skips currently-
playing channels) prevents the most common overlap. Risk is real but
infrequent given the 60-second tick interval. NAS/SMB shared storage
raises the risk slightly due to the write-to-temp-then-copy pattern.

---

## Maybe — Low priority, no committed build date

### Compact JSON Lists
A custom JSON serialiser in `utils/paths.py` replacing `json.dumps(data, indent=2)`
with a renderer that keeps flat lists of numbers/strings on a single line while
keeping objects and nested structures normally indented. Purely cosmetic — the
addon reads either format identically. Reduces state.json and queue files
significantly when `played_ids` or `interleave_order` contain many entries.
Single-file change, needs careful testing for all data types the addon writes.

---

## Removed from Queue (Mark's decision)
- End of Queue Warning
- Smart Playlist Channel
- Binge Mode / Auto-skip Credits
- Multiple Interleave Sources (superseded by existing multi-source interleave)

---

## Test Procedure Status

**CONFIRMED PASSING (comprehensive):** TC-1.x through TC-17.1, TC-EXC.1–16,
TC-UI.1–3, TC-RR.1–2, TC-EPS.1, TC-9.x through TC-13.x, TC-CAR.1–12e,
TC-CAR.SIL.1–10, TC-INFO.1–7 (all passed in 1.1.5r baseline run)

**ALL PASSING — 1.1.6f CONFIRMED STABLE:**
- 1.1.5r targeted regression tests: TC-7.2, TC-10.2, TC-10.3, TC-3.1,
  TC-13.1, TC-8.1, TC-12.3 — ALL PASS ✅
- 1.1.6f test checklist (33 items, Sections 1–3) — ALL PASS ✅

**Overnight carousel log (1.1.6f):**
- Duration: 11h 56m, two channels
- Pops: 33
- Errors: 0
- `_strip_leading_silents` fired once — correct ✅

**Full 1.1.6f test session confirmed working:**
- Carousel with silent interleave — 11h 56m clean overnight run ✅
- `_strip_leading_silents` fix — confirmed working in production ✅
- Settings → Create New Channel — working ✅
- Settings → Auto-Create Channels — working ✅
- Side Panel (Section 2, all 33 items) — PASS ✅
- Core feature spot checks (Section 3, all 8 items) — PASS ✅
- Queue top-up — fires correctly at threshold, interleave woven correctly ✅
- Silent interleave — suppressed correctly from upcoming list and OSD ✅
- Resume — save, offer, accept, start-over all confirmed ✅
- Coming Up Next — fires correctly, suppressed when no next episode ✅
- Serial channel exhaustion (recycle=False) — resets and auto-deletes correctly ✅
- Context menu in side panel — all actions confirmed ✅
- Edit channel — queue rebuild fires only when queue-affecting fields change ✅

**Next session priority:**
Move to 1.1.6g — Channel Logos. See Lower Priority Feature Queue for full spec.
1.1.6f is the confirmed stable baseline.

**Test procedure documents:**
- `SmartChannels_ComprehensiveTestProcedure_1_1_5r.md` — full suite
- `SmartChannels_TestProcedure_1_1_4a_thru_1_1_4l.md` — TC-CAR.1–12e, TC-INFO.1–7
- `SmartChannels_TestProcedure_TC-CAR-SIL_1_1_4o.md` — TC-CAR.SIL.1–10

---

## Version History — 1.1.4 Series

| Version | Change |
|---------|--------|
| 1.1.4a | Feature: Carousel Channel (carousel.py, wizard step, service hooks) |
| 1.1.4b | Fix: Carousel fields not persisted (missing from whitelists) |
| 1.1.4c | Improvement: Carousel channels support resume; resume cleared on pop |
| 1.1.4d | Improvement: Carousel minimum interval reduced from 30 to 20 minutes |
| 1.1.4e | Fix: Hardcoded minimum interval in wizard (now uses CAROUSEL_MIN_INTERVAL) |
| 1.1.4f | Fix: Popped episodes reappear after channel edit (attempted, two-bug root cause) |
| 1.1.4g | Fix: _only_carousel_changed — old_carousel_* snapshotted after update; no-op edit triggered rebuild |
| 1.1.4h | Fix: filters and excluded_movies not checked in _no_queue_change guard |
| 1.1.4i | Feature: Channel Info shows carousel status and exclusion counts; View Exclusions context menu |
| 1.1.4j | Fix: _channel_id not cleared on stop — carousel permanently skipped channel after first play |
| 1.1.4k | Fix: Queue deleted on Kodi shutdown — _channel_id now only cleared when not abortRequested() |
| 1.1.4l | Fix: Resume resurrected after carousel pop — clear_resume_position now removes from self._state and _deleted_state_keys |
| 1.1.4m | Fix: Carousel queue not topped up after pop while idle |
| 1.1.4n | Fix: Post-pop top-up added 3× too many items (refill_queue threshold misuse — now uses _topup_queue directly) |
| 1.1.4o | Feature: Silent-item-aware pop (Option A trailing sweep); pop guard uses refill_threshold |

---

## Coding Standards

- Uncompressed zips only (`zip -0`)
- Exclude `*.pyc` and `__pycache__/`
- Label zip with version: `plugin_video_smartchannels_1_1_6f.zip`
- addon.xml version must match zip filename
- Bug fix letters: 1.1.6g, 1.1.6h...
- Feature releases: 1.1.7a etc.
- Read entire method before editing
- After any change: syntax check, verify in context, check all callers
- CHANGELOG.md entry written BEFORE zip is packaged
- All user-visible strings through strings.po — no exceptions
- Log lines (kodi.log) may be hardcoded — developer-facing
