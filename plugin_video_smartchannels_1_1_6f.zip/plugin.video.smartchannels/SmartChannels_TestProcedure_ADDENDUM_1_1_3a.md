# plugin.video.smartchannels
# TEST PROCEDURE ADDENDUM — Version 1.1.3a
# Covers ONLY: Episode / Movie / Serial Exclusions
# Base document: SmartChannels_COMPREHENSIVE_TestProcedure_1_1_2aq.md

---

## SCOPE OF THIS ADDENDUM

1.1.3a adds per-channel exclusion lists (`excluded_episodes` per show
for TV/Serial, `excluded_movies` on the channel for Movie) so specific
episodes/movies can be removed from one channel's rotation without
affecting other channels using the same show/movie.

This touched every place that decides a show's playable episode pool
(`_build_fresh_queue`, `_topup_queue`, `_apply_starting_points`,
`advance_show` and its fallback path, `_channel_exhausted`'s random
branch, `get_next_episode_for_show`, `_recalculate_tail`,
`reset_show_to_start`, all 5 episode-fetch sites in
`channels/serial.py`), plus the single choke point for movies
(`_build_movie_queue`), plus three new wizard steps and a new picker.

**Not touched this session, do NOT retest:** `service.py` (confirmed
byte-identical to 1.1.2aw), interleave logic, Coming Up Next, resume
system, folder channels, settings, backup/restore, artwork. Sections 1,
11, 13, 14, 15, 18 of the base procedure are unaffected.

**Full regression required, not spot-check-only, for:** Sections 3, 4,
5, 6, 7, 9, 10 (every channel type whose episode/movie pool logic was
touched), plus TC-2.2, TC-2.6, TC-2.7 (edit/reset paths). Section 12
(Interleave) needs only a spot-check — same builders underneath, no new
code path for interleave itself.

---

## NEW TEST CASES

### TC-EXC.1: TV — basic exclusion, queue reflects it
**Setup:** TV channel, 1 show, sequential, recycle=True.
**Steps:**
1. Edit the channel → per-show exclusion prompt → Yes → pick 2 episodes
   from Season 1 to exclude → Done → save channel
2. Read the queue file directly (no need to play)

**Expected:**
- [ ] Neither excluded episode appears anywhere in the rebuilt queue
- [ ] Remaining episodes still in correct sequential order

---

### TC-EXC.2: TV — exclusion prompt always asks, never auto-enters
**Steps:**
1. Set an exclusion on a show, save
2. Edit the same channel again, reach the exclusion step

**Expected:**
- [ ] Prompted "Manage Exclusions? Yes/No" again — does NOT auto-enter
      the picker the way the episode-filters step does when filters
      already exist
- [ ] Choosing No preserves the existing exclusion list unchanged

---

### TC-EXC.3: TV — excluding the CURRENT next_episode_id pointer
**Setup:** Sequential TV channel, play 2–3 episodes so `next_episode_id`
in state.json points at a specific mid-season episode.
**Steps:**
1. Edit the channel, exclude exactly that episode, save
2. Read the rebuilt queue file

**Expected:**
- [ ] Queue's first item is the NEXT episode after the excluded one —
      NOT the excluded episode, and NOT a restart at S01E01
- [ ] Play the channel — confirm it actually starts there

**This is the highest-risk test case in this addendum** — it's the one
exercising `_resolve_pointer_index()`, the only genuinely new algorithm
in this feature (as opposed to additive filtering).

---

### TC-EXC.4: TV — excluding an entire remaining season
**Setup:** Sequential TV channel, show with 2+ seasons.
**Steps:**
1. Exclude every episode in the season the channel is currently
   partway through, leaving later seasons untouched

**Expected:**
- [ ] Queue skips forward to the next season correctly
- [ ] No crash, no infinite loop, no reset to S01E01

---

### TC-EXC.5: TV — excluding an entire show (recycle=True)
**Steps:**
1. In a Round Robin channel with 2+ shows, exclude every episode of one
   show

**Expected:**
- [ ] That show contributes nothing to the queue
- [ ] Other show(s) continue rotating normally
- [ ] No crash — `get_available_episodes()` returning `[]` for that show
      is handled gracefully everywhere it's checked

---

### TC-EXC.6: TV — recycle=False exhaustion with an exclusion present
**Setup:** Random, recycle=False, single show, small episode pool (e.g.
5 episodes), exclude 1 of them.
**Steps:**
1. Play all 4 remaining (non-excluded) episodes to completion

**Expected:**
- [ ] Exhaustion dialog appears after the 4th — channel does NOT wait
      forever for the excluded 5th episode to be "watched"
- [ ] This is the `_channel_exhausted` random-branch fix — confirm it
      actually fires, not just that nothing crashes

---

### TC-EXC.7: TV — Surprise Me / manual starting point cannot pick an excluded episode
**Steps:**
1. Exclude several episodes on a show
2. Edit the channel again → Starting Point → Surprise Me — repeat several
   times
3. Also try manual starting point selection on the same show

**Expected:**
- [ ] Surprise Me never lands on an excluded episode across repeated
      re-rolls
- [ ] Manual season/episode picker doesn't list excluded episodes at all

---

### TC-EXC.8: Serial — exclusion skips silently, sequence continues
**Setup:** Serial channel, 1 show, exclude 1 mid-sequence episode.
**Steps:**
1. Play through that point in the sequence

**Expected:**
- [ ] Excluded episode is skipped with no gap, no error dialog, no
      duplicate play of the episode before/after it
- [ ] Show boundary crossing to the next show (if applicable) still
      works correctly afterward

---

### TC-EXC.9: Serial — per-show exclusion prompt placement
**Steps:**
1. Create/edit a serial channel with 2 shows, walk the wizard

**Expected:**
- [ ] Exclusion prompt appears once per show, after show ordering and
      before Recycle — not before, not after

---

### TC-EXC.10: Movie — basic exclusion
**Steps:**
1. Movie channel, exclude 2–3 movies via the multiselect, save
2. Read queue file directly

**Expected:**
- [ ] Excluded movies never appear in the rebuilt queue
- [ ] Movie exclusion prompt appears between Recycle and Queue Size

---

### TC-EXC.11: Movie — recycle=False exhaustion with exclusions
**Setup:** Small movie channel (4 movies), recycle=False, exclude 1.
**Steps:**
1. Play the remaining 3 to completion

**Expected:**
- [ ] Exhaustion dialog fires after the 3rd — movie exhaustion is
      derived from the same already-exclusion-filtered pool built in
      `_build_movie_queue`, so this should work without any dedicated
      fix, but confirm it

---

### TC-EXC.12: Edit-time queue scrub (no dedicated code — verify the side effect)
**Setup:** Any TV channel, already has a full queue file with several
unplayed episodes queued ahead.
**Steps:**
1. Note 2 episode titles currently sitting a few slots ahead in the
   queue file (not the currently-playing one)
2. Edit the channel, exclude one of those 2 episodes, save
3. Read the queue file again immediately (no playback needed)

**Expected:**
- [ ] The newly-excluded episode is gone from the queue file
- [ ] The OTHER noted episode (not excluded) is still present
- [ ] If a channel was actively playing during the edit, confirm
      playback was NOT interrupted — this scrub happens via
      `_pregenerate_queue_safe`'s full rebuild, not an in-place edit, and
      only affects the on-disk file, not Kodi's already-loaded playlist

---

### TC-EXC.13: Reset Show respects exclusions
**Setup:** TV channel, play a show partway through, exclude its first
2 episodes.
**Steps:**
1. Long-press → Reset Show → select that show

**Expected:**
- [ ] Show restarts at the first NON-excluded episode, not literal
      S01E01
- [ ] This exercises the `reset_show_to_start()` / `router.py`
      pre-check fix found during this session's completeness sweep

---

### TC-EXC.14: Channel Info still shows excluded items in the roster
**Steps:**
1. Movie channel with some movies excluded → Channel Info

**Expected:**
- [ ] Excluded movies still appear in the informational movie list
      (this is intentional — Channel Info displays configuration, not
      what will play; excluding a movie doesn't remove it from the
      channel's selected roster, only from what gets queued)

---

### TC-EXC.15: Existing channels with no exclusions — zero behavior change
**Steps:**
1. Run TC-3.1–3.6, TC-4.1–4.3, TC-5.1–5.5, TC-9.1–9.5, TC-10.1–10.5 from
   the base procedure exactly as written, on channels that have never
   had an exclusion set

**Expected:**
- [ ] All pass identically to their 1.1.2aw results — every exclusion
      check in this release defaults to an empty list and is a no-op
      when unset. This is the regression backstop for the whole feature.

---

### TC-EXC.16: Interleave counter survives an edit that adds exclusions
**Why this exists:** interleave counters (`state.json` key
`"{channel_id}:interleave_counters"`) and exclusion filtering are both
"queue building" concerns but live in genuinely separate state — this
confirms editing a channel to add exclusions doesn't disturb an
in-progress interleave cycle, and that create vs. edit
(`_apply_starting_points(force=False)` vs. `force=True`) don't produce
different queue-building behavior once past that starting-point step.

**Setup:** TV channel, Round Robin, 2 shows, interleave source added
(another channel), frequency=3.
**Steps:**
1. Play ~9-10 items, confirm interleave fires every 3rd main item
2. Stop the channel (do not edit while playing — see README)
3. Note the current value of `state.json`'s
   `"{channel_id}:interleave_counters"` key
4. Edit the channel: exclude 2-3 episodes from one show, save
5. Read the rebuilt queue file — confirm excluded episodes are gone
6. Check the `interleave_counters` key again — confirm it's UNCHANGED
   from step 3
7. Reopen and play — confirm interleave fires at the correct REMAINING
   distance (e.g. counter at 2-of-3 before the edit means it should
   fire after 1 more main item, not reset to needing 3)

**Expected:**
- [ ] Excluded episodes never appear
- [ ] Interleave counter value identical before/after the edit
- [ ] Interleave fires at the correct remaining distance post-edit, not
      reset to a fresh cycle
- [ ] Interleave items' exact slot position in the rebuilt queue may
      differ from the pre-edit queue — expected (full rebuild, not a
      patch), not a regression, as long as frequency/timing is correct

---

## REDUNDANCY NOTES

TC-EXC.1, TC-EXC.10 (basic exclusion, TV and Movie) cover the same
filtering code shape as TC-EXC.8 (Serial) — if TC-EXC.1 passes cleanly,
TC-EXC.8 is very likely to also pass; still worth the one dedicated run
since serial's 5 call sites were touched independently.

TC-EXC.3 (stale pointer resolution) has no redundant sibling — it is the
one new algorithm in this feature and should not be spot-checked or
skipped.
