My recommendation: Don't redo the full 1.1.5r procedure. Instead run just these targeted spot checks from it:
From 1.1.5r								Why
TC-7.2 Queue top-up						Exercises _update_queue_file — the silent strip now runs here
TC-10.2 Interleave during playback		Confirms interleave + _update_queue_file still work together	
TC-10.3 Silent interleave				Directly exercises the new strip logic
TC-3.1 Create TV channel				Confirms wizard still works from the channel list
TC-13.1 Auto-Create						Confirms auto-create still works
TC-8.1 Resume offered					Confirms resume save/load unaffected
TC-12.3 Carousel pop					Confirms carousel unaffected
That's 7 targeted tests covering every code path that actually changed, rather than 80+ tests covering things that didn't. 
If those 7 pass, combined with the 1.1.6f checklist passing, you have full confidence the addon is working correctly end to end.




# Smart TV Channels — Test Checklist
## Version 1.1.6f | Both Display Modes
### Date: July 2026

---

## HOW TO USE THIS CHECKLIST

Work through each section in order. Mark each item:
- ✅ PASS
- ❌ FAIL — note what you saw

Run **Section 1 first** with the side panel OFF, then **Section 2** with it ON.
Section 3 applies to both modes and only needs to be run once.

**Side panel toggle:** Settings → Advanced → Use Side Panel (experimental)

---

## SECTION 1 — STANDARD CHANNEL LIST (Side Panel OFF)

### Settings

| # | Test | Result |
|---|------|--------|
| 1.1 | Open addon — channel list shows channels only, no management items at the bottom | |
| 1.2 | Right-click addon → Settings — 7 categories visible: Channels, Playback, Cache, Network, Resume, Advanced, Backup & Restore, Coming Up Next | |
| 1.3 | Settings → Channels → Create New Channel — wizard opens | |
| 1.4 | Settings → Channels → Auto-Create Channels — wizard opens | |
| 1.5 | Settings → Channels → Open Smart Channels — channel list opens, no alert beep | |
| 1.6 | Settings → Cache → Library cache age field shows a value (e.g. "0 days old"), greyed out | |
| 1.7 | Settings → Cache → Refresh Library Cache — cache rebuilds, notification appears | |
| 1.8 | Settings → Advanced → Delete All Addon Data — confirmation dialog appears, select NO, nothing deleted | |
| 1.9 | Settings → Backup & Restore → Backup Addon Data — backup zip created successfully | |
| 1.10 | Settings → Backup & Restore → Restore Addon Data — restore dialog opens, shows backup file | |

### Channel List Context Menu

| # | Test | Result |
|---|------|--------|
| 1.11 | Right-click a channel → Channel Info — dialog shows channel details | |
| 1.12 | Right-click a channel → Edit Channel — wizard opens, make a change, complete — channel updates | |
| 1.13 | Right-click a channel → Edit Channel — cancel partway through — no change made | |
| 1.14 | Right-click a channel → Reset Channel — confirmation dialog, confirm — channel resets to S01E01 | |
| 1.15 | Right-click a channel → Delete Channel — confirmation dialog, select NO — channel not deleted | |
| 1.16 | Right-click a channel → Delete Channel — confirm — channel removed from list | |
| 1.17 | Right-click a TV channel → Manage Interleave — interleave dialog opens | |
| 1.18 | Right-click a movie channel → View Exclusions — exclusions dialog opens | |
| 1.19 | Right-click a channel → Toggle Visibility — channel hidden/shown correctly | |

### Playback

| # | Test | Result |
|---|------|--------|
| 1.20 | Play a TV channel — correct episode plays from queue front | |
| 1.21 | Let an episode finish — next episode advances correctly | |
| 1.22 | Stop mid-episode — play again — resume dialog offered | |
| 1.23 | Accept resume — playback seeks to saved position | |
| 1.24 | Play channel with silent interleave — first item is a real episode, not a bumper | |
| 1.25 | Play a movie channel — movie plays correctly | |
| 1.26 | Episodes Per Slot wizard — "No, keep 1 each" is first/default option | |

---

## SECTION 2 — SIDE PANEL (Side Panel ON)

### Opening the Panel

| # | Test | Result |
|---|------|--------|
| 2.1 | Open addon — side panel opens with no flash of the Kodi Videos hub | |
| 2.2 | Left pane shows channel names only — no queue count subtitle beneath each name | |
| 2.3 | Right pane shows upcoming items for the first channel | |
| 2.4 | Settings → Channels → Open Smart Channels — panel opens, no alert beep | |

### Navigation

| # | Test | Result |
|---|------|--------|
| 2.5 | Up/Down in left pane — right pane updates to show selected channel's upcoming items | |
| 2.6 | Right arrow — focus moves to right pane | |
| 2.7 | Up/Down in right pane — scrolls through upcoming items | |
| 2.8 | Left arrow from right pane — focus returns to left pane | |
| 2.9 | Back/Escape — panel closes, Kodi returns to Home (not Videos hub) | |

### Playing Content

| # | Test | Result |
|---|------|--------|
| 2.10 | Press Enter on a channel in left pane — channel plays from queue front, no Videos hub flash | |
| 2.11 | Select ▶ Play Channel in right pane — plays from queue front | |
| 2.12 | Select a specific episode in right pane (not the first) — that episode plays, not the one before it | |
| 2.13 | Stop playback — Kodi returns to Home, not Videos hub | |
| 2.14 | Channel with silent interleave — no bumpers/commercials visible in right pane | |
| 2.15 | Channel with silent interleave — select a specific episode — correct episode plays, not a bumper | |
| 2.16 | Stop mid-episode — reopen panel — select a DIFFERENT episode — no resume offered for the previous episode | |

### Context Menu

| # | Test | Result |
|---|------|--------|
| 2.17 | Press C (or Menu button) on a channel — context menu appears | |
| 2.18 | Context menu → Channel Info — dialog opens, panel stays open behind it | |
| 2.19 | Context menu → Play Channel — channel plays correctly | |
| 2.20 | Context menu → Reset Channel — confirmation dialog, confirm — right pane immediately refreshes to S01E01, panel stays open | |
| 2.21 | Context menu → Reset Channel — cancel — no change, panel stays open | |
| 2.22 | Context menu → Edit Channel — wizard opens in front of panel, complete — panel refreshes with updated channel | |
| 2.23 | Context menu → Edit Channel — cancel — panel stays open unchanged | |
| 2.24 | Context menu → Delete Channel — confirmation in front of panel, confirm — channel removed, panel refreshes | |
| 2.25 | Context menu → Delete Channel — cancel — channel not deleted, panel unchanged | |
| 2.26 | Context menu → Toggle Visibility — channel hidden from left pane, focus moves to adjacent channel | |
| 2.27 | Context menu → Manage Interleave — dialog opens in front of panel, complete — panel refreshes | |
| 2.28 | Context menu → View Exclusions — dialog opens, panel stays open | |
| 2.29 | Serial channel context menu — Manage Interleave is NOT shown | |
| 2.30 | Folder channel context menu — View Exclusions is NOT shown | |

### Show Hidden Channels

| # | Test | Result |
|---|------|--------|
| 2.31 | Settings → Advanced → Show Hidden Channels OFF — hidden channels not visible in panel | |
| 2.32 | Settings → Advanced → Show Hidden Channels ON — hidden channels visible with [H] prefix | |

### Settings → Open Smart Channels

| # | Test | Result |
|---|------|--------|
| 2.33 | Right-click addon → Settings → Channels → Open Smart Channels — panel opens | |

---

## SECTION 3 — CORE FEATURE SPOT CHECKS (both modes)

Run these once regardless of which mode you're testing. These confirm the
core engine is unaffected by the 1.1.6 changes.

| # | Test | Result |
|---|------|--------|
| 3.1 | Carousel channel — pop fires after 20-minute interval, queue tops up | |
| 3.2 | Auto-Create Channels — completes and channel list refreshes | |
| 3.3 | Backup Data — zip file created in backup folder | |
| 3.4 | Restore Data — channels restored correctly | |
| 3.5 | Coming Up Next overlay — appears near end of episode | |
| 3.6 | Resume — offered after stopping mid-episode, seeks to correct position | |
| 3.7 | Queue top-up — fires automatically when queue drops below threshold | |
| 3.8 | Silent bumper never plays first when channel is opened or resumed | |

---

## KNOWN OPEN ITEMS (not blocking — do not fail for these)

| Item | Notes |
|------|-------|
| No episode thumbnails in side panel right pane | Generic icon shows instead — queued for future revision |
| Possible alert beep from Open Smart Channels on some setups | Environment-dependent |

---

*plugin.video.smartchannels v1.1.6f*
