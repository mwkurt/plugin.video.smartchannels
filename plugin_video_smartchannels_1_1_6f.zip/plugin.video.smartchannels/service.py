"""
service.py - Persistent background service for plugin.video.smartchannels.
Starts with Kodi and runs for its entire lifetime.
Watches now_playing.json written by the plugin and updates state.json
when episodes finish playing.
"""

import json
import os
import threading
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.utils.paths import load_json, save_json, resolve_path

ADDON    = xbmcaddon.Addon()
ADDON_ID = "plugin.video.smartchannels"
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}][service] {}".format(ADDON_ID, msg), level=level)


class PlaybackMonitor(xbmc.Player):
    """
    Long-lived xbmc.Player subclass.
    Tracks currently playing episode and writes state on episode end.
    Also handles exact resume: saves position on stop, seeks on AV start.
    """

    def __init__(self):
        super(PlaybackMonitor, self).__init__()
        self._lock        = threading.Lock()
        self._current_ep  = None
        self._channel_id  = None  # item's own channel id (used by _handle_end)
        self._primary_channel_id = None  # primary playing channel (used by Coming Up Next)
        self._show_id     = None
        self._channel     = None
        self._service_ref = None  # set by SmartChannelsService after init
        self._resume_sought = False
        self._poll_timer    = None
        self._pending_resume_save = None  # (ep, pos, total) set by timer, written by service loop
        self._last_polled_pos     = None  # most recent (ep, pos, total) — fallback when getTime() fails
        self._overlay_shown  = False  # True once Coming Up Next shown for current episode
        self._pending_overlay = None  # (current_ep, cun_settings) set by poll, shown by run()

        # Resume settings are read lazily in _load_resume_settings()
        # the first time set_now_playing() is called. Reading at __init__
        # time is unreliable because the service starts before Kodi has
        # finished loading addon settings, causing getSetting() to return
        # empty strings even when the settings file has correct values.
        self._resume_on_stop = True   # safe defaults until settings load
        self._poll_interval  = 300
        self._resume_ask     = True
        self._resume_settings_loaded = False

        log("PlaybackMonitor initialised")

    def _load_resume_settings(self):
        """Read resume settings. Retries with a fresh Addon() instance if
        the module-level ADDON returns default/empty values, which can happen
        when the service starts before Kodi finishes loading settings."""
        for attempt in range(3):
            try:
                _addon    = xbmcaddon.Addon() if attempt > 0 else ADDON
                _on_stop  = _addon.getSetting("resume_on_stop").lower()
                _interval = _addon.getSetting("resume_poll_interval").strip()
                _ask      = _addon.getSetting("resume_ask_user").lower()
                # If interval is empty, settings haven't initialised yet — retry
                if _interval == "" and attempt < 2:
                    xbmc.sleep(500)
                    continue
                self._resume_on_stop = (_on_stop == "true")
                self._poll_interval  = max(0, int(_interval or "5")) * 60
                self._resume_ask     = (_ask == "true")
                self._resume_settings_loaded = True
                log("Resume settings loaded (attempt {}): on_stop={} "
                    "interval={}s ask={}".format(
                        attempt + 1, self._resume_on_stop,
                        self._poll_interval, self._resume_ask))
                return
            except Exception as _e:
                log("_load_resume_settings error (attempt {}): {}".format(
                    attempt + 1, _e))
        log("_load_resume_settings: using defaults after retries")

    def set_now_playing(self, ep, channel_id, show_id, channel):
        # Load resume settings on first call — by now Kodi has fully
        # loaded addon settings so getSetting() returns correct values.
        if not self._resume_settings_loaded:
            self._load_resume_settings()
        # Capture the previous episode before overwriting _current_ep.
        # If we are transitioning to a new episode, the previous one
        # finished naturally so its resume entry should be cleared.
        with self._lock:
            prev_ep          = self._current_ep
            self._current_ep = ep
            self._channel_id = channel_id
            self._show_id    = show_id
            self._channel    = channel
            log("set_now_playing: show_id={} ep_id={} title={}".format(
                show_id,
                ep.get("episodeid"),
                ep.get("title")))

        # Clear resume entry for the episode that just finished naturally.
        # onPlayBackEnded only fires when the whole playlist ends, so this
        # is the reliable place to clear between-episode resume entries.
        # Use file path comparison (not episodeid) as the reliable unique
        # identifier — works for both TV episodes and movies.
        prev_file = prev_ep.get("file") if prev_ep else None
        curr_file = ep.get("file")
        log("set_now_playing: prev_file={} curr_file={}".format(
            prev_file, curr_file))
        if prev_ep and prev_file and prev_file != curr_file:
            try:
                svc = self._service_ref
                mgr = svc._get_manager() if svc else None
                if mgr:
                    mgr.clear_resume_position(prev_ep)
                    log("set_now_playing: cleared resume for prev ep={}".format(
                        prev_ep.get("episodeid") or prev_ep.get("movieid")))
                else:
                    log("set_now_playing: no manager, could not clear resume")
            except Exception as _e:
                log("set_now_playing: clear_resume error: {}".format(_e))
        elif not prev_ep:
            log("set_now_playing: no prev_ep to clear")
        elif prev_file == curr_file:
            log("set_now_playing: same file, no clear needed")

        # Start poll timer here as a guaranteed trigger point.
        # onAVStarted also starts it, but set_now_playing is called
        # from the service loop and is reliable on all Kodi versions.
        self._overlay_shown = False   # reset so overlay fires for this episode
        self._last_polled_pos = None  # clear stale position from previous episode —
                                      # if the new episode stops before the poll
                                      # timer fires, we must not resume at the
                                      # previous episode's poll position
        self._start_poll_timer()

        # Write a minimal state entry for this show if none exists yet.
        # This ensures that if playback is stopped mid-episode before
        # onPlayBackEnded fires, state.json still has an entry for this
        # show pointing to the current episode so resume works correctly.
        # Movies (show_id=0) use __movie_state__ - skip TV-style entry.
        is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
        if is_movie:
            return

        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})
        key        = "{}:{}".format(channel_id, show_id)
        if key not in state_all:
            state_all[key] = {
                "next_episode_id": ep.get("episodeid"),
                "season":          ep.get("season",  1),
                "episode":         ep.get("episode", 1),
                "played_ids":      [],
            }
            save_json(state_path, state_all)
            log("Created initial state entry for show {}".format(show_id))

    def onPlayBackStarted(self):
        log("onPlayBackStarted")
        self._resume_sought = False

    def onAVStarted(self):
        """Fires when AV data is available - safe to call seekTime here."""
        log("onAVStarted")
        if not self._resume_on_stop or self._resume_sought:
            return
        svc = self._service_ref
        if not svc:
            return
        # _current_ep is set by set_now_playing from the service loop.
        # onAVStarted fires almost instantly; the service loop may not have
        # run yet. Run the resume check in a background thread so we can
        # wait as long as needed without blocking the player callback.
        threading.Thread(target=self._do_resume_check, daemon=True).start()

    def _do_resume_check(self):
        """
        Background thread: look up resume entry for the currently playing
        file and seek to it if found.

        Does NOT wait for _current_ep — instead reads the queue file
        directly to find episode metadata for the playing file. This makes
        it resilient to the service loop not having ticked yet.
        """
        svc = self._service_ref
        if not svc:
            return

        # Capture playing file immediately — this is reliable even before
        # the service loop runs.
        try:
            playing_file = self.getPlayingFile()
        except Exception:
            log("_do_resume_check: not playing, aborting")
            return

        if not playing_file:
            return

        # Find the episode in the queue file that matches the playing file.
        # Use the active queue path the service already knows about.
        ep = None
        channel_id = None

        # First try _current_ep (may already be set if service loop was fast)
        with self._lock:
            ep_candidate = self._current_ep
        if ep_candidate and ep_candidate.get("file") == playing_file:
            ep = ep_candidate
            channel_id = (ep.get("_channel_id") or ep.get("channel_id"))

        # If not, scan the queue file directly
        if not ep:
            try:
                queue_path = svc._active_queue_path
                if queue_path and xbmcvfs.exists(queue_path):
                    with xbmcvfs.File(queue_path, "r") as _f:
                        _raw = _f.read()
                    if _raw:
                        import json as _json
                        _queue = _json.loads(_raw)
                        for _item in _queue:
                            if _item.get("file") == playing_file:
                                ep = _item
                                channel_id = (_item.get("_channel_id")
                                              or _item.get("channel_id"))
                                break
            except Exception as _e:
                log("_do_resume_check: queue scan error: {}".format(_e))

        if not ep or not channel_id:
            # Queue scan failed - episode may not be in queue (e.g. serial
            # channel rebuilds queue from current position, not episode 1).
            # Fall back to waiting for _current_ep from the service loop.
            log("_do_resume_check: not in queue, waiting for _current_ep")
            for _ in range(20):
                with self._lock:
                    ep_candidate = self._current_ep
                if ep_candidate and ep_candidate.get("file") == playing_file:
                    ep = ep_candidate
                    channel_id = (ep.get("_channel_id") or ep.get("channel_id"))
                    break
                xbmc.sleep(500)
            if not ep or not channel_id:
                log("_do_resume_check: could not identify playing episode")
                return

        if self._resume_sought:
            return

        mgr = svc._get_manager()
        if not mgr:
            return

        # Build the resume key directly so we read from shared state first,
        # then local backup — both may have valid entries.
        is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
        is_folder = ep.get("is_folder_item", False)
        item_id  = (ep.get("movieid", -1) if is_movie
                    else ep.get("episodeid", -1))
        # For folder items, item_id is -1 but resume uses file MD5 key —
        # get_resume_position handles this via _resume_key_for_item.
        # Only bail out for non-folder, non-movie items with no valid ID.
        if not is_folder and (not item_id or item_id < 0):
            return

        try:
            entry = mgr.get_resume_position(ep)
            log("_do_resume_check: get_resume_position returned: {}".format(
                entry is not None))
        except Exception as _e:
            log("_do_resume_check: get_resume_position error: {}".format(_e))
            return

        if not entry:
            log("_do_resume_check: no resume entry for ep={} channel={}".format(
                ep.get("episodeid"), channel_id))
            return

        position = entry.get("position", 0)
        title    = ep.get("title", "")
        ts       = "{:d}:{:02d}".format(int(position) // 60, int(position) % 60)
        log("_do_resume_check: found resume pos={:.0f}s title={}".format(
            position, title))

        # Pause immediately so the user doesn't see the beginning of the
        # episode play while the dialog is shown.
        try:
            self.pause()
            log("_do_resume_check: paused for resume dialog")
        except Exception as _e:
            log("_do_resume_check: pause error: {}".format(_e))

        do_seek = True
        if self._resume_ask:
            choice = xbmcgui.Dialog().yesno(
                ADDON.getLocalizedString(32289),
                ADDON.getLocalizedString(32371).format(title[:40], ts),
                nolabel=ADDON.getLocalizedString(32250),
                yeslabel=ADDON.getLocalizedString(32150))
            do_seek = choice
        self._resume_sought = True
        try:
            if do_seek:
                self.seekTime(position)
                log("_do_resume_check: sought to {:.0f}s for {}".format(
                    position, title))
            else:
                # User chose Start Over — seek to beginning and erase the
                # stored resume position. The key must be cleared here (not
                # deferred to the next poll save) because the user explicitly
                # declined to resume. If they stop again in the first 60s
                # before any poll fires, the old stale position must not be
                # offered to them again.
                self.seekTime(0)
                log("_do_resume_check: start over, seeking to 0")
                try:
                    mgr.clear_resume_position(ep)
                    log("_do_resume_check: start over, resume key cleared")
                except Exception as _ce:
                    log("_do_resume_check: start over clear error: {}".format(
                        _ce))
            # Give Kodi a moment to complete the seek, then explicitly
            # resume. We use xbmc.executebuiltin("PlayerControl(Play)")
            # rather than pause() toggle or isPaused() check because
            # seekTime() can reset the paused state internally, making
            # isPaused() unreliable immediately after a seek.
            xbmc.sleep(500)
            xbmc.executebuiltin("PlayerControl(Play)")
            log("_do_resume_check: resumed playback")
            # If _current_ep was cleared by onPlayBackStopped before we ran,
            # set it now from the ep we found in the queue — otherwise _poll_save
            # finds ep=None, never saves position, and _last_polled_pos stays None.
            with self._lock:
                if self._current_ep is None and ep:
                    self._current_ep = ep
                    log("_do_resume_check: restored _current_ep ep={}".format(
                        ep.get("episodeid") or ep.get("movieid")))
            # Restart the poll timer here. set_now_playing() only calls
            # _start_poll_timer when a NEW file is detected. After a resume
            # seek, the file is the same so set_now_playing never fires and
            # the poll timer stays dead. Starting it here is safe — the
            # comment about a "race" was incorrect; _start_poll_timer cancels
            # any existing timer before creating a new one.
            self._start_poll_timer()
            log("_do_resume_check: poll timer restarted after resume seek")
            # DO NOT clear the resume key here. Clearing immediately after
            # the seek leaves a window where stopping before the first poll
            # save (60s) results in no resume key in state.json at all.
            # The key is cleared by the service loop the first time a fresh
            # poll save is successfully written for this item — at that
            # point there is a valid replacement and it is safe to drop
            # the old one.
        except Exception as _e:
            log("_do_resume_check: seek/resume error: {}".format(_e))
        # Poll timer is started by set_now_playing() which fires from the
        # service loop on every new episode. Starting it here too causes a
        # race between threads producing two concurrent poll timers.

    def onPlayBackEnded(self):
        """
        Fires when an item in the playlist finishes naturally.
        Advance state and increment _queue_position so the skip
        detector in _check_now_playing does not double-count this
        as a skip when the next item starts.
        Clear any resume entry since item finished naturally.
        """
        log("onPlayBackEnded - advancing state")
        self._stop_poll_timer()
        # Clear resume entry - item finished naturally, no need to resume.
        # _current_ep may be None if onPlayBackStopped previously cleared it
        # (e.g. user stopped mid-episode, then replayed and let it finish).
        # Fall back to the queue item at _queue_position so the resume is
        # always cleared for whatever just ended naturally.
        svc = self._service_ref
        if svc:
            with self._lock:
                ep = self._current_ep
            # Fallback: if _current_ep is None, use the queue item at the
            # current position — that is the episode that just finished.
            if not ep and svc._queue:
                pos = svc._queue_position
                if pos < len(svc._queue):
                    ep = svc._queue[pos]
                    log("onPlayBackEnded: _current_ep was None, "
                        "using queue[{}] for resume clear".format(pos))
            if ep:
                try:
                    mgr = svc._get_manager()
                    if mgr:
                        mgr.clear_resume_position(ep)
                        log("onPlayBackEnded: cleared resume for ep={}".format(
                            ep.get("episodeid") or ep.get("movieid")))
                except Exception as _e:
                    log("onPlayBackEnded: clear_resume error: {}".format(_e))
            else:
                log("onPlayBackEnded: no ep available to clear resume")
        self._handle_end()
        self._resume_sought = False
        # Increment position so skip detector knows this end was natural
        if self._service_ref:
            self._service_ref._queue_position += 1
            log("onPlayBackEnded - queue_position advanced to {}".format(
                self._service_ref._queue_position))

        # Check if a recycle=False channel just exhausted via natural playback.
        # _update_queue_file is never called after the last episode ends
        # naturally (no new episode starts to trigger _check_now_playing),
        # so _pending_exhausted_channel would never be set via that path.
        # For TV channels: _handle_end above called channel_manager.advance_show
        # (via mgr.advance_show) which writes next_episode_id=None for the last
        # episode — _channel_exhausted() returns True.
        # For movie channels: _handle_end called advance_movie_state which
        # empties unplayed_ids when the last movie finishes — _channel_exhausted()
        # returns True for movies too. The prior movies exclusion here prevented
        # the dialog from ever firing after natural movie end.
        svc = self._service_ref
        if svc:
            with self._lock:
                ch_id  = self._channel_id
                ch     = self._channel
            if (ch and not ch.get("recycle", True)):
                try:
                    mgr = svc._get_manager()
                    if mgr and mgr.is_channel_exhausted(ch_id, ch):
                        log("onPlayBackEnded: channel exhausted naturally")
                        # Clear _current_ep so onPlayBackStopped (which fires
                        # after playlist ends) does not attempt to save a
                        # resume position for the finished episode.
                        with self._lock:
                            self._current_ep = None
                        # Delete the queue file so channel detail shows clean.
                        import xbmcvfs as _xv
                        _qp = resolve_path("queue_{}.json".format(ch_id))
                        if _xv.exists(_qp):
                            _xv.delete(_qp)
                        if svc._pending_exhausted_channel is None:
                            svc._pending_exhausted_channel = (
                                ch_id, ch.get("name", ""))
                except Exception as _ee:
                    log("onPlayBackEnded: exhaustion check error: {}".format(
                        _ee), xbmc.LOGWARNING)

    def onPlayBackStopped(self):
        """
        User stopped playback manually.  Save position NOW — do not rely
        on the poll timer having fired (it may not have if the episode was
        stopped before the poll interval elapsed).
        Do NOT advance state so the stopped episode remains current.
        """
        self._stop_poll_timer()
        with self._lock:
            ep = self._current_ep

        # Never save resume for recycle=False channels — they play once and stop.
        with self._lock:
            ch = self._channel
        _is_stop_channel = ch and not ch.get("recycle", True)

        # Never save resume for silent interleaved folder items.
        # Non-silent interleaved folder items ARE resumable — the user
        # can see them playing and would expect resume to work.
        _skip_folder_resume = False
        if ep and ep.get("is_folder_item"):
            if ep.get("_silent", False):
                _skip_folder_resume = True

        if self._resume_on_stop and not _is_stop_channel and not _skip_folder_resume:
            saved = False
            if ep:
                try:
                    pos   = self.getTime()
                    total = self.getTotalTime()
                    if pos > 10:
                        self._pending_resume_save = (ep, pos, total)
                        log("onPlayBackStopped: queued resume save at {:.0f}s "
                            "(poll timer had not fired)".format(pos))
                        saved = True
                    else:
                        log("onPlayBackStopped: position {:.0f}s too early "
                            "to save resume".format(pos))
                except Exception as _e:
                    log("onPlayBackStopped: error reading position: {}".format(_e))

            # Fallback: use last polled position when getTime() fails or
            # ep is None (can happen after resume seek when _current_ep
            # is cleared by a race with the player callback thread).
            if not saved:
                lp = self._last_polled_pos
                if lp and lp[1] > 10:
                    lp_ep, lp_pos, lp_total = lp
                    # Use the polled ep if current ep is missing
                    use_ep = ep if ep else lp_ep
                    if use_ep:
                        self._pending_resume_save = (use_ep, lp_pos, lp_total)
                        log("onPlayBackStopped: using last polled pos {:.0f}s "
                            "as fallback (ep={})".format(
                            lp_pos,
                            use_ep.get("episodeid") or use_ep.get("movieid")))
                    else:
                        log("onPlayBackStopped: no ep and no polled pos — "
                            "resume not saved")
                else:
                    log("onPlayBackStopped: resume_on_stop={} ep={} "
                        "no fallback available".format(
                        self._resume_on_stop, ep))
        else:
            log("onPlayBackStopped: resume_on_stop={} ep={} "
                "is_stop_channel={}".format(
                self._resume_on_stop, ep, _is_stop_channel))

        with self._lock:
            self._current_ep   = None
            self._current_file = None   # force re-registration if same file replays
            # Clear _channel_id so the carousel does not permanently skip
            # this channel after the user stops playback.  Guard against
            # Kodi shutdown: when abortRequested() is True, Kodi fires
            # onPlayBackStopped as part of its own teardown sequence — in
            # that case we must NOT clear _channel_id because onPlayBackEnded
            # may still need it for the exhaustion check that runs before
            # the service loop exits.
            _aborting = False
            svc = self._service_ref
            if svc:
                try:
                    _aborting = svc.abortRequested()
                except Exception:
                    pass
            if not _aborting:
                self._channel_id = None
        # Also clear the SERVICE-level _current_file so _check_now_playing does
        # not mistake the restarted episode for "already registered" and skip
        # calling set_now_playing — which would leave _current_ep = None and
        # cause _handle_end to fall back to the wrong queue position.
        if svc:
            svc._current_file = None
        self._last_polled_pos = None
        self._resume_sought   = False

    def onPlayBackError(self):
        log("onPlayBackError - advancing state")
        self._stop_poll_timer()
        self._handle_end()

    def _start_poll_timer(self):
        """Start background polling timer.
        The timer serves two purposes:
        1. Save resume position (only when resume_on_stop is enabled and
           channel is recycle=True).
        2. Trigger the Coming Up Next overlay (always, regardless of resume
           settings — the overlay and resume save are independent features).
        Timer always starts when a channel is playing so both can fire.
        Individual features gate themselves inside _poll_save."""
        self._stop_poll_timer()
        if self._poll_interval <= 0:
            return
        self._poll_timer = threading.Timer(
            self._poll_interval, self._poll_save)
        self._poll_timer.daemon = True
        self._poll_timer.start()
        log("Poll timer started ({:.0f}s interval)".format(self._poll_interval))

    def _stop_poll_timer(self):
        """Cancel the background poll timer if running."""
        if self._poll_timer:
            self._poll_timer.cancel()
            self._poll_timer = None

    def _poll_save(self):
        """Background poll: saves resume position and triggers Coming Up Next.
        These are two independent concerns — resume save is gated on user
        settings and channel type; the overlay fires regardless of both."""
        try:
            with self._lock:
                ep = self._current_ep
                ch = self._channel
            if ep:
                pos   = self.getTime()
                total = self.getTotalTime()

                # ── Resume save ───────────────────────────────────────────
                # Save when resume is enabled, regardless of recycle setting.
                # For folder items: only skip if the item is a silent
                # interleave — silent items play invisibly and resume makes
                # no sense. Non-silent interleaved folder items and standalone
                # folder channel items are all resumable.
                _allow_resume = self._resume_on_stop and pos > 10
                if _allow_resume and ep.get("is_folder_item"):
                    if ep.get("_silent", False):
                        _allow_resume = False
                if _allow_resume:
                    self._pending_resume_save = (ep, pos, total)
                    self._last_polled_pos     = (ep, pos, total)   # fallback for onPlayBackStopped
                    log("Poll save queued: {:.0f}s (will write on main thread)".format(pos))

                # ── Coming Up Next overlay trigger ────────────────────────
                # Fires once per episode when remaining time < lead window.
                # Completely independent of resume settings and channel type.
                # The overlay itself runs on the service main loop via
                # _pending_overlay so xbmcgui calls stay on the main thread.
                if (not self._overlay_shown
                        and total > 0
                        and pos > 0):
                    try:
                        from resources.lib.coming_up_next import load_settings
                        _cun = load_settings()
                        if _cun.get("enabled", False):
                            # Skip overlay for short items (e.g. bumpers).
                            # User-configured minimum duration in seconds.
                            try:
                                _min_dur = int(
                                    ADDON.getSetting("cun_min_duration") or "0")
                            except (ValueError, TypeError):
                                _min_dur = 0
                            if _min_dur > 0 and total < _min_dur:
                                pass  # item too short — skip overlay
                            elif ep.get("_silent") and ADDON.getSettingBool(
                                    "cun_suppress_silent"):
                                pass  # silent item + suppress enabled — skip
                            else:
                                # Lead window: user-configured minutes converted
                                # to seconds, plus display duration as buffer.
                                _lead = (_cun.get("lead_minutes", 2) * 60) + \
                                        _cun.get("duration", 8)
                                if total - pos <= _lead:
                                    self._overlay_shown = True
                                    self._pending_overlay = (ep, _cun)
                                    log("Coming Up Next queued (pos={:.0f}s "
                                        "total={:.0f}s)".format(pos, total))
                    except Exception as _ce:
                        log("Coming Up Next trigger error: {}".format(_ce))
        except Exception as _e:
            log("_poll_save error: {}".format(_e))
        self._start_poll_timer()

    def _handle_end(self):
        with self._lock:
            ep         = self._current_ep
            channel_id = self._channel_id
            show_id    = self._show_id
            channel    = self._channel

        if not ep and self._service_ref:
            # _current_ep was cleared (e.g. by a rapid stop+play).
            # Fall back to queue[_queue_position] which is the item
            # that just finished naturally.
            svc = self._service_ref
            pos = max(0, svc._queue_position - 1)
            if svc._queue and pos < len(svc._queue):
                fallback = svc._queue[pos]
                ep       = fallback
                show_id  = fallback.get("show_id", 0)
                if not channel_id:
                    channel_id = fallback.get("channel_id",
                                              fallback.get("_channel_id"))
                if not channel and channel_id:
                    channel = svc._get_channel(channel_id)
                log("_handle_end: used queue fallback ep={} show={}".format(
                    ep.get("episodeid"), show_id))

        if not ep or not channel_id or not channel:
            log("_handle_end: missing context - ep={} ch={} show={}".format(
                ep, channel_id, show_id), xbmc.LOGWARNING)
            return

        # Folder channel items: no library state to update, no show_id.
        # Record the played file path for recycle=False exhaustion tracking,
        # then let the queue advance naturally via _update_queue_file.
        if ep.get("is_folder_item"):
            log("_handle_end: folder item completed, queue advances naturally")
            file_path    = ep.get("file", "")
            channel_type = channel.get("channel_type", "")
            svc_ref = self._service_ref
            if file_path and channel_type == "folder" and svc_ref:
                # _get_manager is on SmartChannelsService, not PlaybackMonitor —
                # must use self._service_ref._get_manager(), not self._get_manager()
                mgr = svc_ref._get_manager()
                if mgr:
                    mgr.record_folder_file_played(channel_id, file_path)
            return

        # Movie channels: update movie state directly.
        # Interleaved movies (_interleaved=True) are from a foreign channel
        # and must NOT update that channel's played_ids when watched inside
        # the primary TV channel.
        if ep.get("is_movie") or ep.get("movieid", -1) > 0:
            # Always advance movie state for interleaved movies too,
            # so the foreign channel tracks which movies have been seen.
            service_ref = self._service_ref
            if service_ref:
                service_ref._advance_movie_state(channel_id, ep, channel)
                service_ref._reset_watched_if_enabled(
                    episodeid=-1, movieid=ep.get("movieid", -1))
            else:
                log("_handle_end: no service_ref, cannot advance movie state",
                    xbmc.LOGWARNING)
            return

        if not show_id:
            log("_handle_end: no show_id for TV episode", xbmc.LOGWARNING)
            return

        # Find the next episode in the queue to keep state in sync.
        # For serial channels: take the very next item regardless of show
        # so that show boundary crossings are detected correctly.
        # For TV/random channels: find the next episode of the SAME show
        # (round-robin interleaving means other shows appear between).
        next_ep_id   = None
        next_ep_info = None
        service_ref  = self._service_ref
        is_serial    = channel.get("channel_type") == "serial" if channel else False
        if service_ref:
            queue = service_ref._queue
            for i, q_ep in enumerate(queue):
                if q_ep.get("episodeid") == ep.get("episodeid"):
                    for future_ep in queue[i + 1:]:
                        if is_serial:
                            # Serial: take the very next item in the queue,
                            # regardless of which show it belongs to.
                            # Include _show_id so boundary detection can fire.
                            next_ep_id   = future_ep.get("episodeid")
                            next_ep_info = {
                                "season":   future_ep.get("season",  1),
                                "episode":  future_ep.get("episode", 1),
                                "_show_id": future_ep.get("_show_id")
                                            or future_ep.get("show_id"),
                            }
                            break
                        else:
                            # TV/random: find next episode of the same show
                            if future_ep.get("show_id") == show_id:
                                next_ep_id   = future_ep.get("episodeid")
                                next_ep_info = {
                                    "season":  future_ep.get("season",  1),
                                    "episode": future_ep.get("episode", 1),
                                }
                                break
                    break

        try:
            svc = self._service_ref
            mgr = svc._get_manager() if svc else None
            if mgr:
                mgr.advance_show(channel_id, show_id,
                                 ep.get("episodeid", -1),
                                 next_ep_id=next_ep_id,
                                 next_ep_info=next_ep_info)
            else:
                log("_handle_end: no manager, could not advance state",
                    xbmc.LOGWARNING)
        except Exception as _ae:
            log("_handle_end: advance_show error: {}".format(_ae),
                xbmc.LOGWARNING)

        # Reset watched status in Kodi library if setting is enabled.
        # Runs after state is advanced so it doesn't interfere with
        # next-episode logic. Errors are caught — never crash playback.
        _svc_rw = self._service_ref
        if _svc_rw:
            _svc_rw._reset_watched_if_enabled(
                episodeid=ep.get("episodeid", -1), movieid=-1)

        # Advance interleave counters for the primary channel.
        # Only fires for primary TV episodes (not interleaved foreign items,
        # not movies, not folder items — those exit earlier in _handle_end).
        # The _interleaved flag marks items from a foreign source; we must
        # not count those as primary items or the frequency drifts.
        #
        # IMPORTANT: use the PRIMARY channel (from _primary_channel_id), not
        # the item's own channel_id. For a multi-show TV channel, individual
        # queue items may have channel_id pointing to a foreign source channel
        # (e.g. when the interleave source is a TV show channel). The interleave
        # config lives on the primary channel only.
        if not ep.get("_interleaved"):
            try:
                _svc            = self._service_ref
                _primary_ch_id  = (self._primary_channel_id or channel_id)
                _primary_ch     = (_svc._get_channel(_primary_ch_id)
                                   if _svc else None) or channel
                from resources.lib.channel_manager import ChannelManager as _CM
                _mgr   = _CM(ADDON)
                _fired = _mgr.advance_interleave_counters(_primary_ch_id,
                                                          _primary_ch)
                if _fired:
                    log("_handle_end: interleave counters fired {} source(s) "
                        "for channel {}".format(len(_fired),
                                                _primary_ch_id[:8]))
            except Exception as _ce:
                log("_handle_end: advance_interleave_counters error: "
                    "{}".format(_ce), xbmc.LOGWARNING)


class SmartChannelsService(xbmc.Monitor):
    """Main service - runs for Kodi's lifetime."""

    def __init__(self):
        super(SmartChannelsService, self).__init__()
        self.player           = PlaybackMonitor()
        self.player._service_ref = self   # give player access to queue
        self.pointer_path     = resolve_path("now_playing.json")
        self.channels_path    = resolve_path("channels.json")
        self._active_queue_path = None    # path to current channel queue file
        self._last_file       = None
        self._current_file    = None
        self._queue           = []
        self._queue_position  = 0    # tracks current position for skip detection
        self._pending_exhausted_channel = None  # (channel_id, name) set when
                                                # recycle=False channel finishes;
                                                # checked in run() to show dialog
        log("Service started - profile={}".format(PROFILE))

        # Check if local library cache needs rebuilding
        # Do this in background so it doesn't block service startup
        self._start_cache_rebuild_if_needed()

        # Orphaned shared folder check:
        # If Kodi's 'Remove + delete data' wiped the local profile but
        # the shared folder setting survived (stored in Kodi's addon DB,
        # not in the profile), offer to clean the shared folder.
        threading.Thread(target=self._check_orphaned_shared_data,
                         daemon=True).start()

    def _get_channel(self, channel_id):
        channels = load_json(self.channels_path, [])
        for ch in channels:
            if ch["id"] == channel_id:
                return ch
        return None

    def _get_next_episode(self, current_ep, primary_channel_id=None):
        """
        Return the episode/movie immediately following current_ep in the
        active queue file, or None if not found or at end of queue.

        Called by the run() loop when displaying the Coming Up Next overlay.
        Reads the queue file directly — channel_manager.py is not involved
        because this is a pure read of already-built queue data.

        primary_channel_id: the channel actually playing (from
        self.player._channel_id). Must be passed by the caller so that
        interleaved episodes — whose channel_id/_ channel_id point to the
        foreign source channel — are looked up in the correct primary queue.
        Without this, Coming Up Next reads the foreign TV channel's own queue
        and returns the next TV episode, silently skipping any movie that
        appears between them in the actual playing interleaved queue.
        """
        try:
            # Use the primary channel id supplied by the caller.
            # Fall back to the episode's own channel_id only when no primary
            # id is available (non-interleaved channels, legacy callers).
            channel_id = (primary_channel_id
                          or current_ep.get("channel_id")
                          or current_ep.get("_channel_id", ""))
            if not channel_id:
                return None
            mgr = self._get_manager()
            if not mgr:
                return None
            queue_path = mgr._resolve_path(
                "queue_{}.json".format(channel_id))
            queue = load_json(queue_path, [])
            if not queue:
                return None
            current_file = current_ep.get("file", "")
            for i, item in enumerate(queue):
                if item.get("file") == current_file and i + 1 < len(queue):
                    # Skip any _silent items — they play invisibly and must
                    # not appear in Coming Up Next.
                    for next_item in queue[i + 1:]:
                        if not next_item.get("_silent"):
                            return next_item
                    return None
            return None
        except Exception as _e:
            log("_get_next_episode error: {}".format(_e), xbmc.LOGWARNING)
            return None

    def _get_manager(self):
        """Return a ChannelManager instance using the module-level ADDON.
        Using ADDON (created at module import on the main thread) ensures
        getSetting() works correctly regardless of which thread calls this.
        Creating a fresh xbmcaddon.Addon() on background threads may return
        an instance that cannot read settings on some Kodi/platform combos."""
        try:
            from resources.lib.channel_manager import ChannelManager
            return ChannelManager(ADDON)
        except Exception as _e:
            log("_get_manager error: {}".format(_e), xbmc.LOGWARNING)
            return None

    def _check_now_playing(self):
        """
        Read now_playing.json pointer to find the active channel queue file,
        then load the per-channel queue and match the currently playing file.

        Also handles SKIPPING: when the playing file changes, we find
        all episodes that were skipped over and advance their state pointers.
        """
        # Step 1: Read pointer file to find active channel queue.
        # Try shared path first; fall back to local profile copy
        # (player.py always writes both, so local is always current).
        pointer_raw = None
        for ptr_path in [self.pointer_path,
                         os.path.join(PROFILE, "now_playing.json")]:
            if not xbmcvfs.exists(ptr_path):
                continue
            try:
                with xbmcvfs.File(ptr_path, "r") as f:
                    pointer_raw = f.read()
                if pointer_raw:
                    break
            except Exception:
                continue

        if not pointer_raw:
            return

        try:
            pointer = json.loads(pointer_raw)
            queue_filename = pointer.get("queue_file", "")
            if not queue_filename:
                return
            queue_path = resolve_path(queue_filename)
        except Exception as e:
            log("Cannot parse now_playing pointer: {}".format(e),
                xbmc.LOGWARNING)
            return

        # Step 2: Load the per-channel queue file
        if not xbmcvfs.exists(queue_path):
            return

        try:
            with xbmcvfs.File(queue_path, "r") as f:
                raw = f.read()
        except Exception as e:
            log("Cannot read queue file: {}".format(e), xbmc.LOGWARNING)
            return

        if not raw:
            return

        # Reload queue if file changed OR if we switched to a different channel
        channel_switched = (queue_path != self._active_queue_path
                            and self._active_queue_path is not None)
        # Normalise line endings before comparing — xbmcvfs on Windows may
        # return \r\n while json.dumps produces \n, causing a spurious
        # content_changed on every tick which resets self._queue to the
        # trimmed disk content and destroys the cumulative queue fix.
        content_changed  = (raw.replace("\r\n", "\n") !=
                            (self._last_file or "").replace("\r\n", "\n"))

        if content_changed or channel_switched:
            if channel_switched:
                log("Channel switched - resetting queue state")
            elif content_changed:
                log("Queue file content changed - resetting position")

            # Always reset position and current file tracking when the
            # queue content changes. This covers:
            #   - Channel switch (different queue_path)
            #   - Same channel replayed (new random order written by
            #     _write_now_playing overwrites pregenerated queue)
            #   - Queue regenerated or refilled
            self._current_file   = None  # force re-registration
            self._queue_position = 0
            self._last_file         = raw
            self._active_queue_path = queue_path
            try:
                self._queue = json.loads(raw)
                log("Queue loaded from {}: {} items".format(
                    queue_filename, len(self._queue)))
                self._queue_position = self._find_resume_position(self._queue)
                log("Queue position seeded to {} on load".format(
                    self._queue_position))
            except Exception as e:
                log("Queue file parse error: {}".format(e), xbmc.LOGWARNING)
                return

        if not self.player.isPlaying():
            return

        # Get currently playing file path
        try:
            playing_file = self.player.getPlayingFile()
        except Exception as e:
            log("getPlayingFile error: {}".format(e), xbmc.LOGWARNING)
            return

        if playing_file == self._current_file:
            return  # Already registered this file - nothing to do

        log("File change detected: {}".format(playing_file))
        log("Current queue has {} items, last_position={}".format(
            len(self._queue), self._queue_position))

        # New file detected - find its position in the queue.
        #
        # A movie (or episode) may appear more than once in the queue
        # (e.g. a 13-movie channel with queue_size=20 repeats 7 movies).
        # We use Kodi's playlist position as the ground truth when available,
        # since file path matching alone cannot distinguish two identical files
        # at different queue positions (e.g. skip to occurrence 2 of a movie).
        last_position = self._queue_position
        new_position  = None

        def _file_matches(ep, playing_file):
            queue_file = ep.get("file", "")
            if queue_file == playing_file:
                return True
            if queue_file and playing_file:
                qf = queue_file.split("/")[-1].split("\\")[-1]
                pf = playing_file.split("/")[-1].split("\\")[-1]
                if qf and pf and qf == pf:
                    return True
            return False

        # Strategy 1: Use Kodi's playlist position directly.
        # xbmc.PlayList.getposition() returns the current cursor index.
        # This is the most reliable method and handles duplicate files.
        try:
            playlist    = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            kodi_pos    = playlist.getposition()
            if (kodi_pos >= 0 and kodi_pos < len(self._queue)
                    and _file_matches(self._queue[kodi_pos], playing_file)):
                new_position = kodi_pos
                log("Matched at queue[{}] via Kodi playlist position".format(
                    kodi_pos))
        except Exception as e:
            log("getposition() failed: {}".format(e), xbmc.LOGWARNING)

        # Strategy 2: Fallback - scan forward from last_position.
        # Used when Kodi position is unavailable or doesn't match
        # (e.g. queue was refilled and Kodi/internal positions diverged).
        if new_position is None:
            for i in range(last_position, len(self._queue)):
                if _file_matches(self._queue[i], playing_file):
                    new_position = i
                    log("Matched at queue[{}] (forward scan from {})".format(
                        i, last_position))
                    break

        # Strategy 3: Wrap-around scan from beginning.
        if new_position is None:
            for i in range(0, last_position):
                if _file_matches(self._queue[i], playing_file):
                    new_position = i
                    log("Matched at queue[{}] (wrap-around scan)".format(i))
                    break

        if new_position is None:
            log("Playing file not found in queue: {}".format(playing_file),
                xbmc.LOGWARNING)
            log("Queue files: {}".format(
                [ep.get("file","").split("/")[-1]
                 for ep in self._queue[:5]]))
            return

        log("New file at queue[{}]: {}".format(
            new_position, playing_file.split("/")[-1]))

        # SKIP DETECTION: if new_position > last_position + 1,
        # episodes were skipped. Advance state for each skipped episode
        # so state.json reflects the true watch position.
        # last_position already set during file matching above
        log("Skip check: new_position={} last_position={}".format(
            new_position, last_position))
        if new_position > last_position:
            skipped_count = new_position - last_position
            log("Detected {} skipped episode(s) - advancing state".format(
                skipped_count))
            for skip_idx in range(last_position, new_position):
                skipped_ep = self._queue[skip_idx]
                skip_channel_id = skipped_ep.get("channel_id", "")
                skip_show_id    = skipped_ep.get("show_id",    0)
                skip_channel    = self._get_channel(skip_channel_id)
                if skip_channel:
                    # Handle movie skips separately.
                    # Interleaved movies (_interleaved=True) belong to a
                    # foreign channel and must NOT update that channel's
                    # played_ids - they were not watched in their own channel.
                    if (skipped_ep.get("is_movie")
                            or skipped_ep.get("movieid", -1) > 0):
                        is_interleaved   = skipped_ep.get("_interleaved", False)
                        _skip_ch_recycle = skip_channel.get("recycle", True)
                        log("Skip loop movie: id={} title={} interleaved={} "
                            "recycle={}".format(
                            skipped_ep.get("movieid", -1),
                            skipped_ep.get("title", "?")[:20],
                            is_interleaved, _skip_ch_recycle))

                        # Always clear any saved resume for a skipped movie.
                        # The continue below bypasses the shared TV resume-clear
                        # block, so we must clear here explicitly — otherwise a
                        # stale resume entry survives and fires the next time
                        # this channel is opened.
                        try:
                            _mgr = self._get_manager()
                            if _mgr:
                                _mgr.clear_resume_position(skipped_ep)
                        except Exception as _cre:
                            log("Skip: clear_resume (movie) error: {}".format(
                                _cre))

                        # recycle=False only: call advance_movie_state so
                        # unplayed_ids shrinks as movies are skipped past.
                        # _channel_exhausted() checks unplayed_ids==[] to
                        # detect completion — without this call the pool never
                        # empties on skip, top-up keeps firing, and the
                        # exhaustion dialog never appears.
                        #
                        # recycle=True: do NOT call advance_movie_state.
                        # The builder (_build_movie_queue) manages
                        # played/unplayed itself during queue construction and
                        # persists the result. Calling advance here would
                        # double-update the pool (builder already handled it
                        # when queuing), causing premature recycling and
                        # repeat movies.
                        if not _skip_ch_recycle:
                            try:
                                _mgr = self._get_manager()
                                if _mgr:
                                    _mgr.advance_movie_state(
                                        skip_channel_id, skipped_ep,
                                        skip_channel)
                            except Exception as _mse:
                                log("Skip: advance_movie_state error: {}".format(
                                    _mse))
                        continue

                    log("Advancing skipped ep: queue[{}] show={} ep={}".format(
                        skip_idx, skip_show_id,
                        skipped_ep.get("episodeid")))

                    # Folder items: record skipped file as played for
                    # recycle=False exhaustion tracking, then continue —
                    # no advance_show call needed (no library state).
                    if skipped_ep.get("is_folder_item"):
                        _skip_fp = skipped_ep.get("file", "")
                        if (_skip_fp
                                and skip_channel
                                and skip_channel.get("channel_type") == "folder"
                                and not skip_channel.get("recycle", True)):
                            try:
                                _mgr = self._get_manager()
                                if _mgr:
                                    _mgr.record_folder_file_played(
                                        skip_channel_id, _skip_fp)
                            except Exception as _fse:
                                log("Skip: record_folder_file_played "
                                    "error: {}".format(_fse))
                        try:
                            _mgr = self._get_manager()
                            if _mgr:
                                _mgr.clear_resume_position(skipped_ep)
                        except Exception as _ce:
                            log("Skip: clear_resume (folder) error: {}".format(
                                _ce))
                        continue
                    # Clear any resume entry for the skipped episode so it
                    # doesn't incorrectly offer to resume next time it appears.
                    try:
                        _mgr = self._get_manager()
                        if _mgr:
                            _mgr.clear_resume_position(skipped_ep)
                    except Exception as _ce:
                        log("Skip: clear_resume error: {}".format(_ce))
                    next_ep_id   = None
                    next_ep_info = None
                    _skip_is_serial = (skip_channel.get("channel_type") == "serial"
                                       if skip_channel else False)
                    for future_idx in range(skip_idx + 1, len(self._queue)):
                        future_ep = self._queue[future_idx]
                        if _skip_is_serial:
                            # Serial: take the very next item so boundaries fire
                            next_ep_id   = future_ep.get("episodeid")
                            next_ep_info = {
                                "season":   future_ep.get("season",  1),
                                "episode":  future_ep.get("episode", 1),
                                "_show_id": future_ep.get("_show_id")
                                            or future_ep.get("show_id"),
                            }
                            break
                        else:
                            # TV/random: next episode of the same show
                            if future_ep.get("show_id") == skip_show_id:
                                next_ep_id   = future_ep.get("episodeid")
                                next_ep_info = {
                                    "season":  future_ep.get("season",  1),
                                    "episode": future_ep.get("episode", 1),
                                }
                                break
                    try:
                        _mgr2 = self._get_manager()
                        if _mgr2:
                            _mgr2.advance_show(
                                skip_channel_id, skip_show_id,
                                skipped_ep.get("episodeid", -1),
                                next_ep_id=next_ep_id,
                                next_ep_info=next_ep_info)
                        else:
                            log("Skip: no manager, could not advance state",
                                xbmc.LOGWARNING)
                    except Exception as _ase:
                        log("Skip: advance_show error: {}".format(_ase),
                            xbmc.LOGWARNING)

        # Update position and register the now-playing episode
        self._queue_position = new_position
        self._current_file   = playing_file

        ep = self._queue[new_position]

        # The item's channel_id may be a FOREIGN channel (interleaved item).
        # For state advancement we use the item's own channel_id.
        # For queue file management we ALWAYS use the PRIMARY channel id
        # (from the queue file we are currently tracking) so we never
        # accidentally overwrite the foreign channel's queue file.
        item_channel_id    = ep.get("channel_id", "")
        show_id            = ep.get("show_id",    0)
        item_channel       = self._get_channel(item_channel_id)

        # Derive primary channel id from the active queue file path
        # e.g. ".../queue_abc123.json" -> "abc123..."
        import re as _re
        primary_channel_id = item_channel_id  # fallback
        if self._active_queue_path:
            m = _re.search(r"queue_([^.]+)[.]json$", self._active_queue_path)
            if m:
                primary_channel_id = m.group(1)
        primary_channel = self._get_channel(primary_channel_id)

        if item_channel:
            self.player.set_now_playing(
                ep, item_channel_id, show_id, item_channel)
        # Always record the primary channel id separately so Coming Up Next
        # (_get_next_episode) reads the correct queue file. For interleaved
        # TV episodes, item_channel_id is the foreign TV channel — but the
        # queue we need to look up is the primary movie channel's queue.
        self.player._primary_channel_id = primary_channel_id

        if primary_channel:
            # Save show index using primary channel context
            shows    = primary_channel.get("shows", [])
            show_ids = [s["tvshowid"] for s in shows]
            if show_id in show_ids:
                idx = show_ids.index(show_id)
                self._save_show_index(primary_channel_id, idx)

            # Rewrite the queue file using the PRIMARY channel id
            # so interleaved items never corrupt the foreign channel's file
            self._update_queue_file(primary_channel_id, new_position)
        elif item_channel:
            # Primary channel not found but item channel is - use item channel
            # as last resort (shouldn't happen in normal operation)
            log("Primary channel not found, using item channel for queue update",
                xbmc.LOGWARNING)
            self._update_queue_file(item_channel_id, new_position)
        else:
            log("Channel {} not found in channels.json".format(
                item_channel_id), xbmc.LOGWARNING)

    def _advance_movie_state(self, channel_id, ep, channel):
        """
        Delegate to channel_manager.advance_movie_state().
        Called only on natural movie end (_handle_end path).
        State writes must go through CM, not service.py directly.
        """
        try:
            _mgr = self._get_manager()
            if _mgr:
                _mgr.advance_movie_state(channel_id, ep, channel)
        except Exception as _e:
            log("_advance_movie_state delegate error: {}".format(_e),
                xbmc.LOGWARNING)

    def _reset_watched_if_enabled(self, episodeid: int, movieid: int) -> None:
        """
        Reset the watched/playcount status of an episode or movie in the
        Kodi library if the 'reset_watched' setting is enabled.

        Called after natural completion of a TV episode or movie.
        Never called for folder items, skipped items, or errors.
        Errors are caught and logged — never crash playback.

        episodeid: the episode ID to reset, or -1 if not applicable
        movieid:   the movie ID to reset, or -1 if not applicable
        """
        try:
            if not ADDON.getSettingBool("reset_watched"):
                return
            from resources.lib.library import LibraryClient
            lib = LibraryClient(ADDON)
            if episodeid and episodeid > 0:
                lib.reset_watched_episode(episodeid)
            elif movieid and movieid > 0:
                lib.reset_watched_movie(movieid)
        except Exception as _e:
            log("_reset_watched_if_enabled error: {}".format(_e),
                xbmc.LOGWARNING)


    def _find_resume_position(self, queue):
        """
        Find the correct starting position in the queue.

        For movie queues: always return 0. Movie entries use episodeid=-1
        which is meaningless for position detection. The queue file is
        already written in the correct playback order by _write_now_playing
        or trimmed by _update_queue_file.

        For TV queues: the queue file is trimmed so position 0 is always
        correct in normal operation. We only need to scan if the queue
        was not trimmed (fresh channel, regenerated queue).
        """
        if not queue:
            return 0

        # Movie queues: episodeid=-1 for all entries - always start at 0
        if queue[0].get("is_movie") or queue[0].get("movieid", -1) > 0:
            log("_find_resume_position: movie queue - starting at 0")
            return 0

        # Folder channel queues: file-based items, no library state - start at 0
        if queue[0].get("is_folder_item"):
            log("_find_resume_position: folder queue - starting at 0")
            return 0

        # TV queues: use state.json to verify position
        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})

        all_played   = set()
        all_next_ids = set()
        for key, val in state_all.items():
            if isinstance(val, dict):
                if "played_ids" in val:
                    all_played.update(val.get("played_ids", []))
                nid = val.get("next_episode_id")
                if nid is not None and nid != -1:
                    all_next_ids.add(nid)

        first_ep_id = queue[0].get("episodeid")

        # Queue is correctly trimmed - start at 0
        if first_ep_id in all_next_ids or first_ep_id not in all_played:
            log("_find_resume_position: TV queue correctly trimmed, "
                "starting at 0 (ep={})".format(first_ep_id))
            return 0

        # Queue not trimmed - scan for first next_episode_id match
        if all_next_ids:
            for i, ep in enumerate(queue):
                if ep.get("episodeid") in all_next_ids:
                    log("_find_resume_position: found next_ep at "
                        "index {}".format(i))
                    return max(0, i - 1)

        # Final fallback: first unplayed episode
        for i, ep in enumerate(queue):
            if ep.get("episodeid") not in all_played:
                log("_find_resume_position: first unplayed at "
                    "index {}".format(i))
                return max(0, i - 1)

        return 0

    def _persist_queue(self):
        """
        Write the current in-memory queue to its queue file on disk.
        Called by onAVStarted so the queue file stays current after
        each skip or natural episode end.
        Always re-resolves the destination via resolve_path() so a
        shared-path change mid-session is picked up immediately.
        """
        if not self._active_queue_path or not self._queue:
            return
        try:
            import os as _os
            # Re-resolve filename through current shared path setting
            import re as _re2
            _m = _re2.search(r'(queue_[^/\\]+\.json)$',
                             self._active_queue_path)
            queue_filename = _m.group(1) if _m else \
                os.path.basename(self._active_queue_path)
            dest = resolve_path(queue_filename)
            # Update cached path so _update_queue_file stays in sync
            self._active_queue_path = dest
            json_str = json.dumps(self._queue, indent=2)
            is_shared = not dest.startswith(PROFILE)
            if not is_shared:
                with xbmcvfs.File(dest, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os.path.join(PROFILE, _os.path.basename(dest))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, dest):
                    if "://" not in dest:
                        with xbmcvfs.File(local_copy, "r") as _s, \
                             xbmcvfs.File(dest, "w") as _d:
                            _d.write(_s.read())
            log("_persist_queue: wrote {} items to {}".format(
                len(self._queue), self._active_queue_path))
        except Exception as e:
            log("_persist_queue error: {}".format(e), xbmc.LOGWARNING)

    def _update_queue_file(self, channel_id, current_position):
        """
        Rewrite the per-channel queue file starting from current_position.
        After trimming, checks if remaining items are below the replenishment
        threshold. If so, triggers a background top-up so playback never
        runs dry.
        """
        queue_path = resolve_path("queue_{}.json".format(channel_id))
        try:
            remaining = self._queue[current_position:]

            # Check replenishment threshold BEFORE writing.
            # Use len(remaining) - 1 because remaining[0] is the currently
            # playing item and is already consumed from the user's perspective.
            channel   = self._get_channel(channel_id)
            if channel:
                threshold    = self._get_threshold(channel)
                items_left   = max(0, len(remaining) - 1)
                # Allow top-up when queue is low AND the channel is not fully
                # exhausted. For recycle=True this is just the threshold check.
                # For recycle=False we allow top-up while unplayed episodes
                # remain; is_channel_exhausted() returns True only when every
                # show's unplayed pool is empty. service.py owns this decision.
                manager = self._get_manager()
                is_done = (manager.is_channel_exhausted(channel_id, channel)
                           if manager else False)
                # Also check how many items remain in Kodi's live
                # playlist from the current position onward. When the user
                # rapid-skips, the disk queue check fires correctly but the
                # Kodi playlist may already be nearly exhausted because
                # previous top-ups appended to a growing cumulative playlist.
                # We top-up whenever EITHER the disk queue OR the Kodi
                # playlist remaining count is low.
                try:
                    _playlist      = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    _pl_pos        = _playlist.getposition()
                    _pl_size       = _playlist.size()
                    _pl_remaining  = max(0, _pl_size - _pl_pos - 1)
                except Exception:
                    _pl_remaining  = items_left

                _need_topup = (items_left <= threshold or
                               _pl_remaining <= threshold)

                if _need_topup and not is_done:
                    log("Queue below threshold (disk={} pl={} threshold={}) "
                        "- triggering top-up for channel {}".format(
                        items_left, _pl_remaining, threshold,
                        channel_id[:8]))
                    new_remaining = self._topup_in_background(
                        channel, remaining)
                    if len(new_remaining) > len(remaining):
                        # Top-up added items. Extend self._queue in memory
                        # with the new items so Kodi's growing playlist
                        # stays in sync with our internal queue.
                        new_items = new_remaining[len(remaining):]
                        self._queue = self._queue + new_items
                    remaining = new_remaining
                    # Detect last-episode exhaustion for recycle=False channels.
                    # is_channel_exhausted() cannot detect this while the last
                    # episode is still playing (next_episode_id is not yet None).
                    # The reliable signal is: top-up added 0 new items AND only
                    # 1 item remains (the currently playing last episode).
                    # This happens when the user skips to the last episode via
                    # the Kodi playlist — without this check, _pending_exhausted_channel
                    # is never set and the run() loop restarts the channel.
                    if (not channel.get("recycle", True)
                            and len(remaining) <= 1
                            and len(new_remaining) == len(remaining)):
                        is_done = True

                # When the channel is fully exhausted (recycle=False, nothing
                # left to play), delete the queue file so the channel detail
                # view shows no stale "last episode" entry, and set the pending
                # flag so the run() loop can offer delete/reset after playback.
                if is_done and not channel.get("recycle", True):
                    log("Channel {} exhausted — deleting queue file".format(
                        channel_id[:8]))
                    if xbmcvfs.exists(queue_path):
                        xbmcvfs.delete(queue_path)
                    # Also delete local profile copy for shared-storage setups
                    import os as _os2
                    _local_q = _os2.path.join(
                        PROFILE, "queue_{}.json".format(channel_id))
                    if _local_q != queue_path and xbmcvfs.exists(_local_q):
                        xbmcvfs.delete(_local_q)
                    # Signal the run() loop to offer delete/reset dialog.
                    # Only set if not already pending (guard against firing
                    # multiple times on rapid successive ticks).
                    if self._pending_exhausted_channel is None:
                        self._pending_exhausted_channel = (
                            channel_id, channel.get("name", ""))
                    # Update _last_file to empty so _check_now_playing does
                    # not try to reload the deleted file and log a warning.
                    self._last_file = ""
                    self._active_queue_path = queue_path
                    self._queue_position    = current_position
                    return

            import os as _os
            # Ensure the queue never starts with a silent interleave item.
            # If a silent bumper sits at position 0 after trimming, the user
            # would see an invisible item play first on next channel open.
            # Strip leading silents to the tail before writing.
            from resources.lib.channel_manager import ChannelManager as _CM
            remaining = _CM._strip_leading_silents(remaining)

            # Write only the tail (remaining) to disk to keep file compact.
            json_str = json.dumps(remaining, indent=2)
            is_shared = not queue_path.startswith(PROFILE)
            if not is_shared:
                with xbmcvfs.File(queue_path, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os.path.join(PROFILE,
                                           _os.path.basename(queue_path))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, queue_path):
                    log("_update_queue_file copy failed {}, open() fallback".format(
                        queue_path), xbmc.LOGWARNING)
                    if "://" not in queue_path:
                        with xbmcvfs.File(local_copy, "r") as _s, \
                             xbmcvfs.File(queue_path, "w") as _d:
                            _d.write(_s.read())

            # Update in-memory state.
            # Do NOT reset self._queue — it is kept as the full cumulative
            # list matching Kodi's live playlist so position tracking works
            # correctly across multiple top-ups.
            # Do NOT reset self._queue_position to 0 — it stays at
            # current_position so Kodi's playlist index maps correctly.
            # self._last_file is set to json_str (the trimmed disk content)
            # so _check_now_playing does not detect a spurious content change
            # and reload the trimmed file, which would reset self._queue.
            self._queue_position    = current_position
            self._active_queue_path = queue_path
            self._last_file         = json_str
            log("Queue file updated for channel {}: {} items on disk, "
                "{} items in memory, position={}".format(
                channel_id[:8], len(remaining),
                len(self._queue), current_position))

        except Exception as e:
            log("_update_queue_file error: {}".format(e), xbmc.LOGWARNING)

    def _get_threshold(self, channel):
        """Return replenishment threshold from user setting."""
        try:
            threshold = max(1, int(
                ADDON.getSetting("refill_threshold") or "15"))
            queue_size = channel.get("queue_size",
                max(10, int(ADDON.getSetting(
                    "default_queue_size") or "30")))
            # Cap threshold at half queue_size so it doesn't fire
            # on every item when threshold >= queue_size
            if threshold >= queue_size:
                threshold = max(1, queue_size // 2)
            return threshold
        except Exception:
            return 15

    def _topup_in_background(self, channel, current_queue):
        """
        Top up the queue synchronously. Returns the extended queue.
        Uses refill_queue so interleave is applied to new tail items.
        Also appends new items to Kodi's active video playlist so
        playback continues without hitting 'can't find item to play'.
        """
        try:
            threshold = self._get_threshold(channel)

            from resources.lib.channel_manager import ChannelManager
            from resources.lib.player import _make_listitem
            import xbmcaddon
            addon   = xbmcaddon.Addon()
            manager = ChannelManager(addon)

            extended = manager.refill_queue(channel, current_queue, threshold)
            new_items = extended[len(current_queue):]

            # Append new items to Kodi's live video playlist so the player
            # doesn't run out of items before the top-up is visible.
            if new_items:
                try:
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    for ep in new_items:
                        li = _make_listitem(ep)
                        playlist.add(ep["file"], li)
                    log("Top-up: appended {} items to Kodi playlist "
                        "(playlist now {} items)".format(
                            len(new_items), playlist.size()))
                except Exception as pe:
                    log("Top-up playlist append error: {}".format(pe),
                        xbmc.LOGWARNING)

            log("Top-up complete: {} -> {} items".format(
                len(current_queue), len(extended)))
            return extended
        except Exception as e:
            log("_topup_in_background error: {}".format(e), xbmc.LOGWARNING)
            return current_queue

    def onSettingsChanged(self):
        """
        Called by Kodi when the user changes any addon setting.
        Reloads resume settings immediately and restarts the poll timer
        if it is currently running so the new interval takes effect at
        once — no Kodi restart and no need to wait for the next playback
        event.
        """
        try:
            # Reload settings immediately on the PlaybackMonitor instance
            with self.player._lock:
                self.player._resume_settings_loaded = False
            self.player._load_resume_settings()
            # If the poll timer is running, restart it with the new interval
            # so it picks up the new value right away rather than finishing
            # its current (old-interval) cycle first.
            with self.player._lock:
                _timer_running = self.player._poll_timer is not None
            if _timer_running:
                self.player._start_poll_timer()
                log("onSettingsChanged: poll timer restarted with new interval")
            log("onSettingsChanged: settings reloaded (interval={}s)".format(
                self.player._poll_interval))
        except Exception as _e:
            log("onSettingsChanged error: {}".format(_e))

    def onNotification(self, sender, method, data):
        """
        Listen for Kodi library scan completion to auto-rebuild cache.
        """
        if method == "VideoLibrary.OnScanFinished":
            log("VideoLibrary.OnScanFinished - rebuilding library cache")
            _msg = ADDON.getLocalizedString(32372)
            xbmc.executebuiltin(
                "Notification({},{},3000)".format(
                    ADDON.getLocalizedString(32289), _msg))
            threading.Thread(
                target=self._rebuild_library_cache,
                daemon=True).start()

    def _start_cache_rebuild_if_needed(self):
        """
        Start a background cache rebuild if the local cache is missing
        or older than the configured max age (default 7 days).
        Shows a toast notification so user knows what is happening.
        """
        try:
            import xbmcaddon as _xbmcaddon
            from resources.lib.library import LibraryClient
            addon   = _xbmcaddon.Addon()
            library = LibraryClient(addon)

            max_age = int(addon.getSetting("cache_max_age_days") or "7")
            age     = library.local_cache_age_days()

            # Keep the read-only cache age display in Settings current
            try:
                addon.setSetting(
                    "cache_age_display",
                    "{} day{} old".format(
                        int(age), "" if int(age) == 1 else "s"))
            except Exception:
                pass

            auto_rebuild = addon.getSetting(
                "cache_auto_rebuild") != "false"
            if age > max_age:
                if not library.local_cache_exists():
                    msg = ADDON.getLocalizedString(32373)
                    log("[Service] {}".format(msg))
                    xbmc.executebuiltin(
                        "Notification({},{},4000)".format(
                            ADDON.getLocalizedString(32289), msg))
                    threading.Thread(
                        target=self._rebuild_library_cache,
                        daemon=True).start()
                elif auto_rebuild:
                    msg = ADDON.getLocalizedString(32374).format(
                        int(age))
                    log("[Service] {}".format(msg))
                    xbmc.executebuiltin(
                        "Notification({},{},4000)".format(
                            ADDON.getLocalizedString(32289), msg))
                    threading.Thread(
                        target=self._rebuild_library_cache,
                        daemon=True).start()
                else:
                    log("[Service] Cache is {:.0f} days old but "
                        "auto-rebuild is disabled".format(age))
            else:
                log("[Service] Local cache is {:.1f} days old - OK".format(age))
        except Exception as e:
            log("[Service] Cache check error: {}".format(e))

    def _rebuild_library_cache(self):
        """
        Rebuild the local library cache in a background thread.
        Shows progress via Kodi notifications.
        """
        try:
            import xbmcaddon as _xbmcaddon
            from resources.lib.library import LibraryClient
            addon   = _xbmcaddon.Addon()
            library = LibraryClient(addon)

            log("[Service] Background cache rebuild started")

            def _on_progress(pct, msg):
                log("[Service] Cache rebuild {}%: {}".format(pct, msg))

            success = library.build_local_cache(
                progress_callback=_on_progress)

            if success:
                _msg = ADDON.getLocalizedString(32375)
                xbmc.executebuiltin(
                    "Notification({},{},3000)".format(
                        ADDON.getLocalizedString(32289), _msg))
                log("[Service] Cache rebuild complete")

                # Update the read-only cache age display in Settings
                try:
                    _age = library.local_cache_age_days()
                    addon.setSetting(
                        "cache_age_display",
                        "{} day{} old".format(
                            int(_age), "" if int(_age) == 1 else "s"))
                except Exception:
                    pass

                # Auto-rebuild duration cache if the user has enabled it.
                # Runs in this same background thread — library rebuild just
                # finished so local_library.json is fresh and ready.
                try:
                    auto_dc = addon.getSetting(
                        "duration_auto_rebuild") == "true"
                    if auto_dc:
                        log("[Service] Auto-rebuilding duration cache "
                            "after library refresh")
                        from resources.lib.utils.duration_cache import (
                            build_cache as _build_dc)
                        _build_dc(addon)
                        log("[Service] Duration cache auto-rebuild complete")
                except Exception as _dc_err:
                    log("[Service] Duration cache auto-rebuild error: "
                        "{}".format(_dc_err))
            else:
                _msg = ADDON.getLocalizedString(32341)
                xbmc.executebuiltin(
                    "Notification({},{},4000)".format(
                        ADDON.getLocalizedString(32289), _msg))
        except Exception as e:
            log("[Service] Cache rebuild error: {}".format(e))

    def _save_show_index(self, channel_id, show_index):
        """
        Delegate to channel_manager.save_show_index().
        State writes must go through CM, not service.py directly.
        """
        try:
            _mgr = self._get_manager()
            if _mgr:
                _mgr.save_show_index(channel_id, show_index)
        except Exception as _e:
            log("_save_show_index delegate error: {}".format(_e),
                xbmc.LOGWARNING)

    def _check_orphaned_shared_data(self):
        """
        Called at startup.  If the shared folder has addon data files
        but the local profile has NO channels.json, it likely means
        Kodi's built-in 'Remove addon + delete data' wiped the local
        profile but left the shared folder untouched.
        Show a notification so the user knows to use
        [Delete All Addon Data] before removing the addon.
        """
        try:
            raw = ADDON.getSetting("shared_storage_path").strip()
            if raw in ("", "smb://", "smb:/"):
                return  # no shared folder configured
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = raw.lstrip("\\/")
                raw = "smb://" + raw.replace("\\", "/")
            shared = raw.rstrip("/").rstrip("\\")
            if not shared:
                return

            # Check shared folder has data files
            if "://" in shared:
                shared_channels = shared + "/channels.json"
            else:
                shared_channels = os.path.join(shared, "channels.json")

            if not xbmcvfs.exists(shared_channels):
                return  # shared folder is already empty - nothing to warn about

            # Check local profile is missing channels.json
            local_channels = os.path.join(PROFILE, "channels.json")
            if xbmcvfs.exists(local_channels):
                return  # local profile intact - normal startup

            # If shared storage is configured and local channels.json is
            # missing, this is the expected state for a secondary client —
            # channels live on the shared path by design. Only the primary
            # client (the one that created the channels) has a local copy.
            # There is no orphan scenario here so we return silently.
            #
            # True orphan detection (local wiped without Delete All) would
            # require a separate marker file written locally — not worth the
            # complexity for a home multi-client setup.
            return
        except Exception as e:
            log("[Service] _check_orphaned_shared_data error: {}".format(e))

    def run(self):
        log("Service run loop started")
        consecutive_errors = 0
        tick = 0

        # Startup catch-up: check carousel channels immediately so any pops
        # that were due while Kodi was closed are applied before playback
        # starts.  Runs once, before the loop.
        try:
            from resources.lib.carousel import CarouselManager
            CarouselManager().check_all(
                self._get_manager(),
                self.player._channel_id)
        except Exception as _car_e:
            log("Carousel startup check error: {}".format(_car_e))

        while not self.abortRequested():
            try:
                # Flush any pending resume save from poll timer thread.
                # Written here on the main thread so xbmcvfs SMB works
                # correctly on all platforms including Android/Shield.
                pending = self.player._pending_resume_save
                if pending:
                    self.player._pending_resume_save = None
                    ep, pos, total = pending
                    try:
                        mgr = self._get_manager()
                        if mgr:
                            mgr.save_resume_position(ep, pos, total)
                            log("Poll save written: {:.0f}s".format(pos))
                            # If this is the first poll save after a resume
                            # seek, the old key and the new key are identical
                            # (same item, same channel) so save_resume_position
                            # has already overwritten it — nothing extra to do.
                            # The key is never left absent: the old value was
                            # in state.json until this write replaced it.
                    except Exception as _pe:
                        log("Poll save write error: {}".format(_pe))

                # Show Coming Up Next overlay if the poll timer queued one.
                # Runs here on the main service thread — xbmcgui WindowDialog
                # must be shown from the main thread on all Kodi platforms.
                _overlay_pending = self.player._pending_overlay
                if _overlay_pending:
                    self.player._pending_overlay = None
                    _cur_ep, _cun_settings = _overlay_pending
                    try:
                        _next_ep = self._get_next_episode(
                            _cur_ep,
                            primary_channel_id=self.player._primary_channel_id
                                               or self.player._channel_id)
                        if _next_ep:
                            from resources.lib.coming_up_next import show_overlay
                            show_overlay(_next_ep, _cun_settings)
                        else:
                            log("Coming Up Next: no next episode found, "
                                "skipping overlay")
                    except Exception as _oe:
                        log("Coming Up Next display error: {}".format(_oe),
                            xbmc.LOGWARNING)
                self._check_now_playing()

                # Check if a recycle=False channel just finished.
                # Show the delete/reset dialog only when the player has
                # stopped — never interrupt mid-playback.
                # The dialog runs here on the main service thread, which
                # is the only safe place to show Kodi dialogs.
                _exhausted = self._pending_exhausted_channel
                if _exhausted and not self.player.isPlaying():
                    self._pending_exhausted_channel = None
                    _ch_id, _ch_name = _exhausted
                    # Verify channel still exists — user may have deleted it
                    # via another route between the flag being set and now.
                    if self._get_channel(_ch_id):
                        try:
                            _choice = xbmcgui.Dialog().select(
                                ADDON.getLocalizedString(32292),
                                [
                                    ADDON.getLocalizedString(
                                        32293).format(_ch_name),
                                    ADDON.getLocalizedString(
                                        32294).format(_ch_name),
                                    ADDON.getLocalizedString(32295),
                                ])
                            if _choice == 0:
                                # Delete
                                mgr = self._get_manager()
                                if mgr:
                                    mgr.delete_channel(_ch_id)
                                    log("Exhausted channel '{}' "
                                        "deleted".format(_ch_name))
                                xbmcgui.Dialog().notification(
                                    ADDON.getLocalizedString(32292),
                                    ADDON.getLocalizedString(
                                        32296).format(_ch_name),
                                    xbmcgui.NOTIFICATION_INFO, 3000)
                                xbmc.executebuiltin("Container.Refresh")
                            elif _choice == 1:
                                # Reset to start
                                mgr = self._get_manager()
                                if mgr:
                                    mgr.reset_channel(_ch_id)
                                    log("Exhausted channel '{}' "
                                        "reset".format(_ch_name))
                                xbmcgui.Dialog().notification(
                                    ADDON.getLocalizedString(32292),
                                    ADDON.getLocalizedString(
                                        32297).format(_ch_name),
                                    xbmcgui.NOTIFICATION_INFO, 3000)
                                xbmc.executebuiltin("Container.Refresh")
                            # _choice == 2 or -1: Do Nothing — no action
                        except Exception as _de:
                            log("Exhausted channel dialog error: "
                                "{}".format(_de), xbmc.LOGWARNING)

                consecutive_errors = 0
            except Exception as e:
                consecutive_errors += 1
                log("Service loop error #{}: {} - continuing".format(
                    consecutive_errors, e), xbmc.LOGWARNING)
                import traceback
                log("Traceback: {}".format(traceback.format_exc()),
                    xbmc.LOGWARNING)
                # Back off slightly on persistent errors but never stop
                if consecutive_errors > 10:
                    if self.waitForAbort(5):
                        break
                    continue

            # Heartbeat every 5 minutes so we can confirm service is alive
            tick += 1
            if tick % 300 == 0:
                log("Service heartbeat: still running (tick={})".format(tick))

            # Carousel: check all carousel-enabled channels every 60 seconds.
            # Uses wall-clock timestamps — skips any channel currently playing.
            if tick % 60 == 0:
                try:
                    from resources.lib.carousel import CarouselManager
                    CarouselManager().check_all(
                        self._get_manager(),
                        self.player._channel_id)
                except Exception as _car_e:
                    log("Carousel tick check error: {}".format(_car_e))

            if self.waitForAbort(1):
                break
        log("Service stopped")


if __name__ == "__main__":
    service = SmartChannelsService()
    service.run()
