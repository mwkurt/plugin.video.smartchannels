# plugin.video.smartchannels
# TEST PROCEDURE ADDENDUM — Version 1.1.3g
# Covers: ALL changes in versions 1.1.3a through 1.1.3g
# Base document: SmartChannels_COMPREHENSIVE_TestProcedure_1_1_2aq.md

---

## WHAT CHANGED IN 1.1.3a–1.1.3g

| Version | Change |
|---------|--------|
| 1.1.3a  | Feature: Episode/Movie/Serial Exclusions |
| 1.1.3b  | Cleanup: exclusion helpers moved to channels/base.py |
| 1.1.3c  | Fix: excluded_episodes dropped from selected_shows merge on edit |
| 1.1.3d  | Fix: Round Robin queue rebuild always started from show[0] after edit |
| 1.1.3e  | UI: Show-picker flow for exclusions; "Exclude entire season"; "Keep current position" label |
| 1.1.3f  | Fix: eps_per_slot slots had wrong count at episode-list cycle boundary |
| 1.1.3g  | Fix: movie channel edit inherited stale cycle state, causing early repeats |

---

## TEST STATUS SUMMARY

Tests confirmed PASS during 1.1.3x session:

| Tests | Version | Status |
|-------|---------|--------|
| TC-EXC.1–TC-EXC.16 | 1.1.3a–d | ✅ ALL PASS |
| TC-5.3 (eps_per_slot) | 1.1.3f | ✅ PASS |
| TC-5.4, TC-5.5 | Base regression | ✅ PASS |
| TC-9.1–TC-9.5 | 1.1.3g + base regression | ✅ PASS |
| TC-10.1–TC-10.5 | Base regression | ✅ PASS |

**Remaining gaps — new tests in this addendum:**

| Test | What it covers | Version |
|------|---------------|---------|
| TC-UI.1 | "Exclude entire season" option | 1.1.3e |
| TC-UI.2 | "Keep current position" label during edit | 1.1.3e |
| TC-UI.3 | Show-picker loop with per-show exclusion counts | 1.1.3e |
| TC-RR.1 | Rotation seed when show[0] was the active show | 1.1.3d |
| TC-EPS.1 | eps_per_slot=2 cycle-wrap at top-up boundary | 1.1.3f |

These five are the only items not explicitly confirmed by a logged test
run during the 1.1.3x session. Everything else is confirmed PASS above.

---

## SECTION A — EXCLUSIONS UI (1.1.3e)

### TC-UI.1: "Exclude entire season" option
**Setup:** Any TV channel with 2+ seasons.
**Steps:**
1. Edit channel → "Exclude Episodes? Yes"
2. Pick a show → pick a season → select "Exclude entire Season X"
3. Save channel
4. Read queue file directly

**Expected:**
- [ ] "Exclude entire Season X / Select individual episodes" dialog appears
      after picking the season — not directly into the episode multiselect
- [ ] All episodes from that season are absent from the rebuilt queue
- [ ] Episodes from OTHER seasons are unaffected
- [ ] If you previously had individual episode exclusions within that
      season, they are replaced (not appended) by the full-season exclusion

---

### TC-UI.2: "Keep current position" label during channel edit
**Setup:** Any TV channel that has been played (so next_episode_id is set
past S01E01).
**Steps:**
1. Edit the channel — reach the Starting Point step

**Expected:**
- [ ] Option 0 reads **"Keep current position"** (not "Start from S01E01 (default)")
- [ ] Options 1 and 2 still read "Set Starting Points manually" and "Surprise Me!"
- [ ] Selecting option 0 leaves the channel continuing from exactly where
      it was (no episode pointer reset, no restart to S01E01)

**Contrast check:** Create a BRAND NEW channel of the same type and reach
the Starting Point step — option 0 should read "Start from S01E01 (default)"
(unchanged for creation).

---

### TC-UI.3: Show-picker loop with per-show exclusion counts
**Setup:** TV channel with 3+ shows, at least one show already has exclusions
set from a previous edit.
**Steps:**
1. Edit channel → "Exclude Episodes? Yes"
2. Observe the show list before selecting anything

**Expected:**
- [ ] Show list displays each show name with a count alongside it,
      e.g. "Til Death — 2 episode(s) excluded" or "1883 — no episodes excluded"
- [ ] "Done" option appears at the bottom of the list
- [ ] Picking Done exits the picker without changes
- [ ] Picking a show, making exclusion changes, then returning to the picker
      updates that show's count in the list immediately

---

## SECTION B — ROUND ROBIN ROTATION SEED (1.1.3d)

### TC-RR.1: Edit when show[0] was the active show — queue unchanged
**Why this matters:** TC-EXC.16 confirmed the fix for show[1] being active.
This confirms show[0] (the simple case) is not disrupted.

**Setup:** Two-show Round Robin channel. Make sure show[0] (the first show
in the channel's show list) was the most recently playing show before stopping.

**Steps:**
1. Play the channel until an episode of show[0] is playing
2. Stop
3. Edit channel (any minor change — add/remove an exclusion)
4. Read the rebuilt queue file

**Expected:**
- [ ] Queue starts with show[0] at position 0 — correct, unchanged
- [ ] Log: `update_channel: captured start_show_index=0` is NOT logged
      (start_show_index=0 is the default; the code skips the log for 0)
      OR: no "captured start_show_index" log line at all (same result)
- [ ] No rotation disruption — show[0] and show[1] alternate normally

**Note:** The `0 < start_show_index` guard in `_build_fresh_queue` means
show_index=0 uses the unchanged default path. This is correct — no
log line for it is expected.

---

## SECTION C — EPISODES PER SLOT CYCLE WRAP (1.1.3f)

### TC-EPS.1: eps_per_slot=2 cycle wrap in top-up
**Why this matters:** TC-5.3 confirmed the fresh build is correct. This
specifically targets the top-up boundary where the episode list wraps from
the last episode back to the first mid-slot.

**Setup:** TV channel, 1 show with exactly 10 episodes (e.g. 1883),
eps_per_slot=2, recycle=True.

**Steps:**
1. Play channel until a top-up fires (queue drops to threshold)
2. Immediately read the queue file after the top-up completes
3. Find the point in the queue where the show recycles (E10 followed by E01)

**Expected:**
- [ ] E09 and E10 appear as a PAIR (consecutive, no Til Death or other
      show between them) — confirming the end of the first cycle is correctly
      paired
- [ ] E10 and E01 appear as a PAIR — confirming the cycle-boundary slot
      is correctly filled (E10 as first of pair, E01 as second, no early
      rotation to the other show between them)
- [ ] The queue continues correctly: E01+E02 paired, E03+E04 paired, etc.
- [ ] Log: NO single-episode 1883 slots visible anywhere in the queue
      (read the raw file and verify each 1883 grouping has exactly 2)

**Quick verification from queue file:** Sort the items by position and
check that every pair of consecutive 1883 episodes is truly consecutive
with no other show between them. The bug would show as a single 1883
episode followed immediately by another show's episode.

---

## REGRESSION NOTES

The following base procedure sections are covered by the above tests and
the already-confirmed TC-EXC / TC-9 / TC-10 results. No further runs
needed unless a specific failure is suspected:

- **Section 3 (TV single-show sequential):** Covered by TC-EXC.3, TC-10.1
- **Section 5 (Two-show Round Robin):** Covered by TC-5.3–5.5, TC-EXC.16
- **Section 7 (Episode filters):** Unchanged by 1.1.3x; no new test needed
- **Section 8 (Recycle=False):** Covered by TC-EXC.6, TC-10.2/10.4
- **Section 9 (Movie channel):** Covered by TC-9.1–9.5
- **Section 10 (Serial channel):** Covered by TC-10.1–10.5
- **Section 14 (Coming Up Next):** service.py untouched; no new test needed
- **Section 15 (Resume):** Covered by TC-EXC.16, TC-10.5
- **Section 12/13 (Interleave):** Covered by TC-EXC.16

**service.py:** Confirmed byte-identical to 1.1.2aw throughout all 1.1.3x
versions. No playback callback or state-advancement code was touched.
Sections 15 and 16 of the base procedure require no re-run.

---

## SIGN-OFF TABLE — 1.1.3g ADDENDUM

| Test | Description | Status |
|------|-------------|--------|
| TC-EXC.1 | TV basic exclusion, queue reflects it | ✅ PASS |
| TC-EXC.2 | Exclusion prompt always asks, never auto-enters | ✅ PASS |
| TC-EXC.3 | Excluding the current next_episode_id pointer | ✅ PASS |
| TC-EXC.4 | Excluding an entire remaining season | ✅ PASS |
| TC-EXC.5 | Excluding an entire show (recycle=True) | ✅ PASS |
| TC-EXC.6 | recycle=False exhaustion with exclusion present | ✅ PASS |
| TC-EXC.7 | Surprise Me / manual start cannot pick excluded episode | ✅ PASS |
| TC-EXC.8 | Serial exclusion skips silently, sequence continues | ✅ PASS |
| TC-EXC.9 | Serial per-show exclusion prompt placement | ✅ PASS |
| TC-EXC.10 | Movie basic exclusion | ✅ PASS |
| TC-EXC.11 | Movie recycle=False exhaustion with exclusions | ✅ PASS |
| TC-EXC.12 | Edit-time queue scrub (side effect verification) | ✅ PASS |
| TC-EXC.13 | Reset Show respects exclusions | ✅ PASS |
| TC-EXC.14 | Channel Info still shows excluded items in roster | Waived |
| TC-EXC.15 | Existing channels — zero behavior change | ✅ PASS |
| TC-EXC.16 | Interleave counter survives edit that adds exclusions | ✅ PASS |
| TC-5.3 | eps_per_slot=2 fresh build — correct pairs | ✅ PASS |
| TC-5.4 | Starting point — manual selection after 1.1.3 | ✅ PASS |
| TC-5.5 | Starting point — Surprise Me after 1.1.3 | ✅ PASS |
| TC-9.1 | Movie channel creation, fresh distribution | ✅ PASS |
| TC-9.2 | Movie filter (genre) after edit — no early repeats | ✅ PASS |
| TC-9.3 | Movie channel recycle=True wraps correctly | ✅ PASS |
| TC-9.4 | Movie channel recycle=False exhaustion | ✅ PASS |
| TC-9.5 | Movie channel resume | ✅ PASS |
| TC-10.1 | Serial single-show strict order | ✅ PASS |
| TC-10.2 | Serial two-show advancement | ✅ PASS |
| TC-10.3 | Serial recycle=True wraps Show B → Show A | ✅ PASS |
| TC-10.4 | Serial recycle=False exhaustion | ✅ PASS |
| TC-10.5 | Serial resume | ✅ PASS |
| **TC-UI.1** | **"Exclude entire season" option** | **⬜ PENDING** |
| **TC-UI.2** | **"Keep current position" label during edit** | **⬜ PENDING** |
| **TC-UI.3** | **Show-picker loop with per-show counts** | **⬜ PENDING** |
| **TC-RR.1** | **Rotation seed when show[0] was active** | **⬜ PENDING** |
| **TC-EPS.1** | **eps_per_slot=2 cycle wrap at top-up boundary** | **⬜ PENDING** |
