"""
resources/lib/carousel.py
=========================
Carousel channel manager.

A carousel channel's queue advances automatically on a wall-clock timer
while nobody is watching.  Every N minutes, M items are silently removed
from the front of the queue file.  When a user opens the channel they
pick up wherever the queue currently sits — no catching up, no resume.

Architecture rules
------------------
- This module owns ALL carousel logic.  Nothing else owns it.
- channel_manager.py queue-file read/write methods are used for all
  file I/O — no bare open() calls here.
- service.py calls CarouselManager().check_all() in two places only:
    1. Once on startup (before the run loop) to catch missed pops.
    2. Every 60 ticks inside the run loop.
- service.py _do_resume_check skips resume when carousel_enabled=True.
- player.py, channel_manager.py, and all channel builders are untouched.

State key
---------
{channel_id}:__carousel__ -> {"last_pop_time": <float unix timestamp>}

Queue safety / silent-item sweep
--------------------------------
_maybe_pop uses Option A trailing-sweep logic.  Silent interleaved items
(_silent=True) are swept from the queue for free — they do not count
against pop_count.  The pop walks forward until pop_count real items are
consumed, then sweeps any trailing silent items so the queue always
starts with a real program.  A guard clamps pop_count so at least
get_replenishment_threshold() real items remain after the pop.
CAROUSEL_QUEUE_FLOOR is retained as a last-resort constant but is no
longer the primary guard.
"""

from __future__ import annotations

import time

from resources.lib.utils.logger import log

# Minimum interval enforced by the wizard (minutes).
CAROUSEL_MIN_INTERVAL = 20

# Absolute minimum items that must remain in the queue after a pop.
CAROUSEL_QUEUE_FLOOR = 2

_STATE_KEY = "{}:__carousel__"


class CarouselManager:
    """
    Checks all carousel-enabled channels and pops items whose interval
    has elapsed.  Instantiated fresh on each call from service.py so
    there is no shared mutable state between calls.
    """

    def check_all(self, channel_manager, now_playing_channel_id=None):
        """
        Iterate every channel.  For each TV or Movie channel that has
        carousel_enabled=True, check whether a pop is due and execute it.

        now_playing_channel_id: the channel currently being played
        (self.player._channel_id from service.py).  That channel is
        skipped — watching it IS the drift.  Pass None when nothing is
        playing.

        channel_manager may be None if the manager could not be obtained
        (e.g. very early startup).  Guard and return silently.
        """
        if channel_manager is None:
            return

        try:
            channels = channel_manager.get_all_channels()
        except Exception as e:
            log("[Carousel] check_all: could not load channels: {}".format(e))
            return

        if not channels:
            return

        now = time.time()
        for ch in channels:
            if not ch.get("carousel_enabled", False):
                continue
            ch_type = ch.get("channel_type", "tv")
            if ch_type not in ("tv", "movies"):
                continue
            ch_id = ch.get("id", "")
            if not ch_id:
                continue
            if ch_id == now_playing_channel_id:
                log("[Carousel] check_all: skipping '{}' — currently "
                    "playing".format(ch.get("name", ch_id)))
                continue
            try:
                self._maybe_pop(ch, channel_manager, now)
            except Exception as e:
                log("[Carousel] check_all: error processing channel "
                    "'{}': {}".format(ch.get("name", ch_id), e))

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _maybe_pop(self, channel, channel_manager, now):
        """
        Pop items from the front of the queue if the interval has elapsed.

        Reads last_pop_time from state.  On first use (key absent) writes
        now as last_pop_time and does nothing — the clock starts from the
        first time the addon runs with carousel enabled on this channel.
        """
        channel_id    = channel["id"]
        interval_mins = max(CAROUSEL_MIN_INTERVAL,
                            int(channel.get("carousel_interval", 60)))
        pop_count     = max(1, int(channel.get("carousel_pop_count", 1)))
        interval_secs = interval_mins * 60

        carousel_state = self._get_carousel_state(channel_id, channel_manager)
        last_pop = carousel_state.get("last_pop_time")

        if last_pop is None:
            # First run — initialise the clock, no pop yet.
            log("[Carousel] '{}': first run, initialising "
                "clock".format(channel.get("name", channel_id)))
            self._set_carousel_state(
                channel_id, {"last_pop_time": now}, channel_manager)
            return

        elapsed = now - last_pop
        if elapsed < interval_secs:
            log("[Carousel] '{}': {:.0f}s elapsed, {:.0f}s remaining — "
                "no pop needed".format(
                channel.get("name", channel_id),
                elapsed, interval_secs - elapsed))
            return

        # How many full intervals have elapsed?  Pop that many times.
        intervals_due = int(elapsed // interval_secs)
        total_to_pop  = pop_count * intervals_due

        log("[Carousel] '{}': {:.0f}s elapsed ({} interval(s) due), "
            "attempting to pop {} real item(s)".format(
            channel.get("name", channel_id),
            elapsed, intervals_due, total_to_pop))

        # Read queue file
        try:
            queue_path = channel_manager._queue_file_path(channel_id)
            queue = channel_manager._load_json(queue_path, [])
        except Exception as e:
            log("[Carousel] '{}': could not read queue: {}".format(
                channel.get("name", channel_id), e))
            return

        if not queue:
            log("[Carousel] '{}': queue is empty, skipping pop".format(
                channel.get("name", channel_id)))
            return

        # Guard: clamp pop_count so at least refill_threshold real
        # (non-silent) items remain after the pop.  This prevents a
        # misconfigured pop_count from draining the queue entirely
        # in the window before the top-up fires.
        real_items     = [it for it in queue if not it.get("_silent", False)]
        real_count     = len(real_items)
        refill_floor   = channel_manager.get_replenishment_threshold(channel)
        max_safe_pop   = max(0, real_count - refill_floor)

        if max_safe_pop == 0:
            log("[Carousel] '{}': not enough real items ({}) to pop "
                "{} (floor={}) — skipping".format(
                channel.get("name", channel_id),
                real_count, total_to_pop, refill_floor))
            self._set_carousel_state(
                channel_id,
                {"last_pop_time": last_pop + interval_secs * intervals_due},
                channel_manager)
            return

        if total_to_pop > max_safe_pop:
            log("[Carousel] '{}': clamping pop from {} to {} "
                "(real items={}, floor={})".format(
                channel.get("name", channel_id),
                total_to_pop, max_safe_pop, real_count, refill_floor))
            total_to_pop = max_safe_pop

        # Option A — Trailing sweep pop:
        # Walk the queue from position 0.  Silent items (_silent=True)
        # are swept for free without counting against total_to_pop.
        # Non-silent items count against the budget.  After consuming
        # the last counted item, continue sweeping any silent items that
        # immediately follow it so the new queue front is always a real
        # program.  Leading silent items (before the first non-silent
        # item) are also swept for free.
        popped    = []
        remaining = list(queue)
        counted   = 0

        while remaining and counted < total_to_pop:
            item = remaining[0]
            if item.get("_silent", False):
                # Silent item — sweep for free
                popped.append(remaining.pop(0))
            else:
                # Real item — counts against budget
                popped.append(remaining.pop(0))
                counted += 1

        # Trailing sweep: remove any silent items that immediately follow
        # the last counted item so the queue always starts with a real
        # program.
        while remaining and remaining[0].get("_silent", False):
            popped.append(remaining.pop(0))

        new_queue = remaining

        # Write updated queue file
        try:
            channel_manager._write_queue_file(channel_id, new_queue)
        except Exception as e:
            log("[Carousel] '{}': could not write queue: {}".format(
                channel.get("name", channel_id), e))
            return

        # Log each popped item and clear any stored resume position.
        # Distinguish real items (counted) from silent items (swept).
        real_popped   = [it for it in popped if not it.get("_silent", False)]
        silent_popped = [it for it in popped if it.get("_silent", False)]
        for item in popped:
            is_silent = item.get("_silent", False)
            title = (item.get("title") or item.get("tvshowtitle")
                     or item.get("label") or "unknown")
            log("[Carousel] '{}': {} '{}' ".format(
                channel.get("name", channel_id),
                "swept silent" if is_silent else "popped real  ",
                title))
            try:
                channel_manager.clear_resume_position(item)
            except Exception as _re:
                log("[Carousel] '{}': could not clear resume for '{}': "
                    "{}".format(channel.get("name", channel_id),
                                title, _re))

        log("[Carousel] '{}': queue {} -> {} items "
            "({} real popped, {} silent swept)".format(
            channel.get("name", channel_id),
            len(queue), len(new_queue),
            len(real_popped), len(silent_popped)))

        # Top up the queue if the pop left it below the pre-pop length.
        # The carousel operates while nobody is watching, so the normal
        # playback-driven top-up in service.py never fires.  Without this,
        # repeated pops can drain the queue to the safety floor (2 items)
        # where it sits indefinitely until the channel is next played.
        #
        # For interleaved channels the queue is larger than queue_size
        # (e.g. 45 items for a 30-item channel with 15 silent items woven
        # in at every 2nd slot).  Using queue_size (30) as the target
        # always evaluates False (45 > 30) and the top-up is never
        # triggered.  Instead use the pre-pop queue length as the target
        # so we restore exactly as many items as were removed.
        #
        # For interleaved channels we also need to re-weave silent items
        # into the new tail, which _topup_queue alone does not do.
        # refill_queue adds real items AND re-applies interleave, so use
        # it for interleaved channels.  Pass a shallow copy of channel
        # with queue_size overridden to pre_pop_real (real items only) so
        # refill_queue tops up to the correct real-item count; after
        # interleave re-weaving the total converges back to pre_pop_len.
        pre_pop_len = len(queue)   # captured before any items were removed
        # Count real (non-silent) items in the pre-pop queue.  For interleaved
        # channels the total queue length includes woven-in silent items.
        # We need to restore exactly pre_pop_real real items; after
        # re-weaving silents the total should converge back to pre_pop_len.
        pre_pop_real = sum(
            1 for it in queue if not it.get("_silent", False))

        if len(new_queue) < pre_pop_len:
            try:
                interleave_cfg = channel.get("interleave")
                if interleave_cfg:
                    # For interleaved channels we cannot use refill_queue
                    # because it compares queue_size against len(current_queue)
                    # which includes silents — causing it to return immediately
                    # when the post-pop queue (real+silent) already exceeds
                    # queue_size (real-only target).
                    # Instead: count real items remaining, top up real items
                    # explicitly, then re-weave silents into the new tail only.
                    real_remaining = sum(
                        1 for it in new_queue if not it.get("_silent", False))
                    real_needed = pre_pop_real - real_remaining
                    if real_needed > 0:
                        topped_up = channel_manager._topup_queue(
                            channel, new_queue, real_needed)
                        # Re-weave silents into the new tail only.
                        if len(topped_up) > len(new_queue):
                            new_tail = topped_up[len(new_queue):]
                            primary_offset = 0
                            for ep in reversed(new_queue):
                                if (ep.get("_interleaved")
                                        or ep.get("_silent", False)):
                                    break
                                primary_offset += 1
                            woven_tail = channel_manager._apply_interleave(
                                new_tail, interleave_cfg,
                                primary_offset=primary_offset,
                                channel_name=channel.get("name", ""))
                            topped_up = new_queue + woven_tail
                    else:
                        topped_up = new_queue
                else:
                    topup_size = pre_pop_len - len(new_queue)
                    topped_up = channel_manager._topup_queue(
                        channel, new_queue, topup_size)
                if len(topped_up) > len(new_queue):
                    channel_manager._write_queue_file(channel_id, topped_up)
                    log("[Carousel] '{}': topped up queue {} -> {} items".format(
                        channel.get("name", channel_id),
                        len(new_queue), len(topped_up)))
                    new_queue = topped_up
            except Exception as _tu:
                log("[Carousel] '{}': top-up after pop failed: {}".format(
                    channel.get("name", channel_id), _tu))

        # Advance last_pop_time by exactly the intervals that elapsed
        # (not to now) so drift does not accumulate from processing delay.
        new_last_pop = last_pop + interval_secs * intervals_due
        self._set_carousel_state(
            channel_id, {"last_pop_time": new_last_pop}, channel_manager)

    def _get_carousel_state(self, channel_id, channel_manager):
        """Read carousel state from state.json for this channel."""
        key = _STATE_KEY.format(channel_id)
        try:
            state_all = channel_manager._load_json(
                channel_manager._state_path, {})
            return state_all.get(key, {})
        except Exception as e:
            log("[Carousel] _get_carousel_state error: {}".format(e))
            return {}

    def _set_carousel_state(self, channel_id, value, channel_manager):
        """Write carousel state to state.json for this channel."""
        key = _STATE_KEY.format(channel_id)
        try:
            channel_manager._deleted_state_keys.discard(key)
            channel_manager._state[key] = value
            channel_manager._save_state()
        except Exception as e:
            log("[Carousel] _set_carousel_state error: {}".format(e))
