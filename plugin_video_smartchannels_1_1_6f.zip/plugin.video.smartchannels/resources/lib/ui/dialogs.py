# ui/dialogs.py
#
# OWNS:   Reusable Kodi dialog helpers extracted from ui/channels.py.
#         select(), yesno(), ok(), input(), multiselect() wrappers
#         that provide consistent error handling and return types.
#
# NEVER:  State reads/writes, library access, playback control, routing.
#         Channel-type-specific wizard logic (stays in ui/channels.py).
#
# CALLERS: ui/channels.py, router.py.

# Populated during Phase 4 / cleanup pass.
