"""
resources/lib/serial.py
========================
Compatibility shim — the canonical implementation has moved to
resources/lib/channels/serial.py as part of the 1.1.0 rewrite.

All imports of SerialQueueBuilder from this path continue to work.
"""
from resources.lib.channels.serial import SerialQueueBuilder  # noqa: F401
