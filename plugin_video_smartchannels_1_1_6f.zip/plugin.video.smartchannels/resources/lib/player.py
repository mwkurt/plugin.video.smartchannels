"""
resources/lib/player.py
========================
SmartPlayer builds the initial queue and starts playback.

Ownership is strictly divided:
  - player.py owns ONLY start_channel() — builds the xbmc.PlayList and
    calls xbmc.Player().play() to begin playback. Nothing else.
  - service.py owns ALL playback event callbacks (onPlayBackStarted,
    onPlayBackEnded, onPlayBackStopped, onAVStarted, onPlayBackError),
    all state advancement, all resume save/seek, all queue top-up, and
    all playlist appending after the initial play.

Do NOT add playback event handlers here. Do NOT write state here during
playback. The service runs as a persistent background thread and handles
everything after the initial play() call.
"""

from __future__ import annotations

import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.channel_manager import ChannelManager
from resources.lib.utils.logger     import log


class SmartPlayer:
    """High-level controller: builds the playlist and starts playback."""

    def __init__(self, addon, manager):
        self.addon   = addon
        self.manager = manager

    def start_channel(self, channel):
        log("[SmartPlayer] Starting channel '{}'".format(channel["name"]))

        # Warn user if refill threshold >= queue size
        try:
            _qs  = channel.get("queue_size", 30)
            _rt  = max(1, int(
                self.addon.getSetting("refill_threshold") or "15"))
            if _rt >= _qs:
                xbmcgui.Dialog().notification(
                    "Smart TV Channels",
                    "Warning: Refill threshold ({}) >= queue size ({}). "
                    "Threshold capped at {}. Adjust in Settings.".format(
                        _rt, _qs, max(1, _qs // 2)),
                    xbmcgui.NOTIFICATION_WARNING, 6000)
                log("[SmartPlayer] Warning: refill_threshold {} >= "
                    "queue_size {} - capped at {}".format(
                        _rt, _qs, max(1, _qs // 2)))
        except Exception:
            pass

        queue = self.manager.build_queue(channel)
        if not queue:
            # Return False so the caller (router.play_channel) can offer
            # to delete the channel.  We do not show a dialog here —
            # router handles all user interaction for the empty-queue case.
            log("[SmartPlayer] Empty queue for channel '{}' — "
                "returning False".format(channel["name"]))
            return False

        # Write queue file and pointer BEFORE building playlist so:
        # 1. Channel view shows correct episodes immediately
        # 2. Service can start monitoring the correct queue file
        self._write_now_playing(queue, channel["id"])

        first_titles = [ep.get("title", "?")[:20] for ep in queue[:3]]
        log("[SmartPlayer] Play queue first 3: {}".format(first_titles))

        # Build the xbmc.PlayList
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()

        for ep in queue:
            li = _make_listitem(ep)
            playlist.add(ep["file"], li)

        log("[SmartPlayer] Playlist built with {} items".format(len(queue)))

        # Start playback — service.py handles all events and state from here
        xbmc.Player().play(playlist)
        log("[SmartPlayer] Playback started")

    def _write_now_playing(self, queue, primary_channel_id=None):
        """
        Write a per-channel queue file: queue_{channel_id}.json
        and a now_playing.json pointer so service.py knows which
        channel is active.

        primary_channel_id must always be passed explicitly.
        Never derive from queue items — interleaved items carry the
        foreign channel's _channel_id giving the wrong filename.
        """
        import json, os
        import xbmcvfs
        profile = xbmcvfs.translatePath(
            self.addon.getAddonInfo("profile"))

        if not queue:
            return

        # Always use the explicitly passed primary channel ID
        first_ep   = queue[0]
        channel_id = (primary_channel_id
                      or first_ep.get("channel_id", "")
                      or first_ep.get("_channel_id", ""))

        # Normalize queue entries - minimal for TV, richer for movies
        data = []
        for ep in queue:
            cid      = ep.get("_channel_id") or ep.get("channel_id", "")
            sid      = ep.get("_show_id") if ep.get("_show_id") is not None \
                       else ep.get("show_id", 0)
            is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0

            if is_movie:
                # Movies keep metadata for playlist display.
                # _interleaved MUST be preserved so the service can
                # distinguish foreign interleaved movies from primary
                # channel movies when advancing state.
                genre = ep.get("genre", "")
                if isinstance(genre, list):
                    genre = ", ".join(genre)
                entry = {
                    "channel_id":  cid,
                    "_channel_id": cid,
                    "show_id":     0,
                    "_show_id":    0,
                    "movieid":     ep.get("movieid", -1),
                    "episodeid":   -1,
                    "title":       ep.get("title",   ""),
                    "season":      0,
                    "episode":     0,
                    "file":        ep.get("file",    ""),
                    "is_movie":    True,
                    "year":        ep.get("year",    0),
                    "genre":       genre,
                    "plot":        ep.get("plot",    ""),
                    "rating":      ep.get("rating",  0),
                    "mpaa":        ep.get("mpaa",    ""),
                    "runtime":     ep.get("runtime", 0),
                }
                if ep.get("_interleaved"):
                    entry["_interleaved"] = True
                if ep.get("_silent"):
                    entry["_silent"]       = True
                    entry["_channel_name"] = ep.get("_channel_name", "")
                data.append(entry)
            else:
                # TV episodes and folder items - minimal fields only
                entry = {
                    "channel_id":  cid,
                    "_channel_id": cid,
                    "show_id":     sid,
                    "_show_id":    sid,
                    "episodeid":   ep.get("episodeid", -1),
                    "tvshowtitle": ep.get("tvshowtitle", ""),
                    "title":       ep.get("title",   ""),
                    "season":      ep.get("season",  0),
                    "episode":     ep.get("episode", 0),
                    "file":        ep.get("file",    ""),
                }
                if ep.get("_interleaved"):
                    entry["_interleaved"] = True
                if ep.get("_silent"):
                    entry["_silent"]       = True
                    entry["_channel_name"] = ep.get("_channel_name", "")
                if ep.get("is_folder_item"):
                    entry["is_folder_item"] = True
                data.append(entry)

        # Write per-channel queue file
        queue_filename = "queue_{}.json".format(channel_id)
        queue_path     = self.manager._resolve_path(queue_filename)
        try:
            import os as _os2
            json_str = json.dumps(data, indent=2)
            is_shared = not queue_path.startswith(profile)
            if not is_shared:
                with xbmcvfs.File(queue_path, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os2.path.join(profile,
                                            _os2.path.basename(queue_path))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, queue_path):
                    if "://" not in queue_path:
                        with xbmcvfs.File(local_copy, "r") as _s, \
                             xbmcvfs.File(queue_path, "w") as _d:
                            _d.write(_s.read())
            log("[SmartPlayer] {} written ({} items)".format(
                queue_filename, len(data)))
        except Exception as e:
            log("[SmartPlayer] Failed to write queue file: {}".format(e))

        # Write now_playing.json pointer — local first, then shared
        pointer_path = self.manager._resolve_path("now_playing.json")
        try:
            import os as _os3
            _ptr_str = json.dumps({
                "active_channel_id": channel_id,
                "queue_file": queue_filename,
            }, indent=2)
            local_ptr = _os3.path.join(profile, "now_playing.json")
            with xbmcvfs.File(local_ptr, "w") as _f2:
                _f2.write(_ptr_str)
            log("[SmartPlayer] now_playing.json written (local)")
            if pointer_path != local_ptr:
                ok = xbmcvfs.copy(local_ptr, pointer_path)
                if ok:
                    log("[SmartPlayer] now_playing.json copied to shared")
                else:
                    log("[SmartPlayer] now_playing.json shared copy failed "
                        "- service will use local copy", level=1)
        except Exception as e:
            log("[SmartPlayer] Failed to write now_playing pointer: {}".format(e))


# -- List item builder ---------------------------------------------------------

def _make_listitem(ep):
    """
    Build an xbmcgui.ListItem from an episode or movie queue dict.
    NOTE: ListItem lives in xbmcgui, NOT xbmc.
    Handles both TV episodes and movies.
    Used by start_channel() for the initial playlist build, and by
    service.py _topup_in_background() when appending new items.
    """
    title      = ep.get("title", "Unknown")
    is_movie   = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
    # Silent interleave items display the primary channel name on the OSD
    # instead of the item's own title, so the viewer sees no label change.
    if ep.get("_silent") and ep.get("_channel_name"):
        label = ep["_channel_name"]
    elif not is_movie:
        show   = ep.get("tvshowtitle", "") or ep.get("showtitle", "")
        season = int(ep.get("season",  0) or 0)
        ep_num = int(ep.get("episode", 0) or 0)
        if show:
            label = "{} - S{:02d}E{:02d} - {}".format(
                show, season, ep_num, title)
        else:
            label = title
    else:
        label = title
    li = xbmcgui.ListItem(label=label)

    if is_movie:
        movie_id = int(ep.get("movieid", -1) or -1)

        year    = int(ep.get("year",    0) or 0)
        plot    = ep.get("plot",    "") or ""
        genre   = ep.get("genre",   "") or ""
        rating  = float(ep.get("rating", 0) or 0)
        mpaa    = ep.get("mpaa",    "") or ""
        runtime = int(ep.get("runtime", 0) or 0)

        if movie_id > 0 and not year:
            try:
                import xbmcaddon as _xbmcaddon
                _addon   = _xbmcaddon.Addon()
                from resources.lib.library import LibraryClient
                _lib     = LibraryClient(_addon)
                _movies  = _lib.get_all_movies()
                _m       = next((m for m in _movies
                                 if m.get("movieid") == movie_id), None)
                if _m:
                    year    = int(_m.get("year",   0) or 0)
                    plot    = (_m.get("plot",   "") or "")[:300]
                    genre   = _m.get("genre",  [])
                    if isinstance(genre, list):
                        genre = " / ".join(genre)
                    rating  = float(_m.get("rating", 0) or 0)
                    mpaa    = _m.get("mpaa",   "") or ""
                    runtime = int(_m.get("runtime", 0) or 0)
            except Exception as e:
                log("[SmartPlayer] Cache lookup failed: {}".format(e))

        if isinstance(genre, list):
            genre = " / ".join(genre)

        try:
            tag = li.getVideoInfoTag()
            tag.setMediaType("movie")
            tag.setDbId(movie_id)
            tag.setTitle(title)
            tag.setOriginalTitle(title)
            tag.setPlot(plot)
            tag.setPlotOutline(plot[:100] if plot else "")
            tag.setYear(year)
            tag.setGenres([g.strip() for g in genre.split("/") if g.strip()])
            tag.setRating(rating)
            tag.setMpaa(mpaa)
            tag.setDuration(runtime)
        except Exception:
            li.setInfo("video", {
                "mediatype": "movie", "dbid": movie_id,
                "title": title, "plot": plot, "year": year,
                "genre": genre, "rating": rating,
                "mpaa": mpaa, "duration": runtime,
            })
        li.setProperty("IsPlayable", "true")
    else:
        # Folder items and silent interleave items have no season/episode data.
        # Using mediatype "episode" with season=0/episode=0 causes Kodi to
        # display "0x" in the internal playlist. Use "video" for these items.
        is_folder = ep.get("is_folder_item") or ep.get("_silent")
        try:
            tag = li.getVideoInfoTag()
            if is_folder:
                tag.setMediaType("video")
                tag.setTitle(label)
            else:
                tag.setMediaType("episode")
                tag.setTitle(title)
                tag.setTvShowTitle(ep.get("tvshowtitle", "") or ep.get("showtitle", ""))
                tag.setSeason(int(ep.get("season",  0) or 0))
                tag.setEpisode(int(ep.get("episode", 0) or 0))
                tag.setPlot(ep.get("plot", ""))
                tag.setDuration(int(ep.get("runtime", 0) or 0))
        except Exception:
            if is_folder:
                li.setInfo("video", {"mediatype": "video", "title": label})
            else:
                li.setInfo("video", {
                    "mediatype":   "episode",
                    "title":       title,
                    "tvshowtitle": ep.get("tvshowtitle", "") or ep.get("showtitle", ""),
                    "season":      int(ep.get("season",  0) or 0),
                    "episode":     int(ep.get("episode", 0) or 0),
                    "plot":        ep.get("plot",    ""),
                    "duration":    int(ep.get("runtime", 0) or 0),
                })

    art   = ep.get("art", {})
    thumb = art.get("thumb") or ep.get("thumbnail", "")
    if thumb:
        li.setArt({"thumb": thumb, "icon": thumb})

    li.setProperty("IsPlayable", "true")
    return li
