# channels/movies.py
#
# OWNS:   Queue building logic for Movie channels only.
#         Extends BaseQueueBuilder from channels/base.py.
#
# NEVER:  State reads/writes (request via channel_manager.py).
#         Direct library access (request via channel_manager.py).
#         Playback control, UI rendering, routing.
#         Logic belonging to a different channel type.
#
# CALLERS: channel_manager.py only — via the build_queue() dispatch.
#
# STATUS 1.1.0: MovieQueueBuilder delegates to channel_manager._build_movie_queue
# and _topup_queue. Full logic extraction is post-1.1.0.

from __future__ import annotations

from resources.lib.channels.base import BaseQueueBuilder
from resources.lib.utils.logger  import log


class MovieQueueBuilder(BaseQueueBuilder):
    """
    Queue builder for Movie channels.
    Delegates to channel_manager's existing build infrastructure.
    """

    def build(self, channel: dict, target_size: int,
              current_queue=None) -> list:
        """
        Build or top-up a Movie channel queue.

        current_queue=None  → fresh build
        current_queue=list  → top-up
        """
        if current_queue is not None:
            log("[channels/movies] build: top-up mode, current={} target={}".format(
                len(current_queue), target_size))
            return self._cm._topup_queue(channel, current_queue, target_size)

        log("[channels/movies] build: fresh build, target={}".format(target_size))
        return self._cm._build_movie_queue(channel, target_size,
                                           for_interleave=False)
