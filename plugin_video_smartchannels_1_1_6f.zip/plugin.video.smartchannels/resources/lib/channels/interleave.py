# channels/interleave.py
#
# OWNS:   All Unified Interleave logic:
#         - Normalising the interleave config (single-dict -> list migration shim)
#         - get_sources()           : return the list of source configs for a channel
#         - apply_interleave_list() : weave ALL sources (silent and non-silent) into a queue
#         - get_all_foreign_ids()   : return every foreign channel_id referenced
#         - advance_counters()      : increment per-source counters, return fired sources
#
# NEVER:  State reads/writes (state.json -- that is channel_manager.py's job).
#         Library access.
#         Playback control or UI rendering.
#         Writing queue files.
#
# CALLERS: channel_manager.py only.
#
# DESIGN NOTE -- single-dict compatibility shim
# ---------------------------------------------
# Versions <= 1.1.1f stored interleave as a single dict:
#   {"channel_id": "...", "frequency": 4, ...}
# Unified Interleave stores it as a list:
#   [{"channel_id": "...", "frequency": 4, "silent": false}, ...]
#
# get_sources() normalises both forms transparently.
#
# SILENT FLAG
# -----------
# silent: true  -- items are woven into the queue like non-silent items, BUT:
#                  - Tagged _silent: True on the item dict (written to queue file)
#                  - Tagged _channel_name: <primary channel name> so the OSD
#                    shows the primary channel name instead of the item title
#                  - Coming Up Next skips them (handled in service.py)
#                  - Movie state still advances when they complete (correct)
# silent: false -- standard behaviour, items appear normally in queue and CUN

from __future__ import annotations

import random
from resources.lib.utils.logger import log


# ---------------------------------------------------------------------------
# Public: config normalisation
# ---------------------------------------------------------------------------

def get_sources(channel: dict) -> list:
    """
    Return the list of interleave source configs for *channel*.

    Handles both legacy single-dict format and new list format.
    Returns an empty list when no interleave is configured.
    Each source dict is guaranteed to have:
        channel_id  str
        frequency   int  >= 1
        jitter      int  >= 0
        count_per   int  >= 1
        silent      bool
    """
    raw = channel.get("interleave")
    if not raw:
        return []

    # Legacy single-dict -> wrap in list
    if isinstance(raw, dict):
        raw = [raw]

    sources = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        cid = entry.get("channel_id", "")
        if not cid:
            continue
        sources.append({
            "channel_id": cid,
            "frequency":  max(1, int(entry.get("frequency",  4))),
            "jitter":     max(0, int(entry.get("jitter",     0))),
            "count_per":  max(1, int(entry.get("count_per",  1))),
            "silent":     bool(entry.get("silent", False)),
        })
    return sources


def get_all_foreign_ids(channel: dict) -> list:
    """Return every foreign channel_id referenced by *channel*'s interleave."""
    return [s["channel_id"] for s in get_sources(channel)]


# ---------------------------------------------------------------------------
# Public: runtime counter advancement
# ---------------------------------------------------------------------------

def advance_counters(sources, counters):
    """
    Pure counter logic - no state I/O.

    Increments each source's counter by 1 (one primary item just completed).
    When a counter reaches its threshold (frequency +/- jitter) the source
    fires: its counter resets to 0 and it is added to the fired list.

    sources  : list of source config dicts (from get_sources())
    counters : dict {channel_id: int} -- current counter values from state.json

    Returns (updated_counters, fired_sources).
    """
    updated = dict(counters)
    fired   = []

    for source in sources:
        cid       = source["channel_id"]
        frequency = source["frequency"]
        jitter    = source["jitter"]

        current = updated.get(cid, 0) + 1

        if jitter == 0:
            threshold = frequency
        else:
            threshold = random.randint(max(1, frequency - jitter),
                                       frequency + jitter)

        if current >= threshold:
            fired.append(source)
            updated[cid] = 0
            log("[channels/interleave] counter fired: source='{}' "
                "count={} threshold={}".format(cid[:8], current, threshold))
        else:
            updated[cid] = current
            log("[channels/interleave] counter tick: source='{}' "
                "count={}/{} threshold={}".format(
                cid[:8], current, frequency, threshold))

    return updated, fired


# ---------------------------------------------------------------------------
# Public: queue weaving (all sources -- silent and non-silent)
# ---------------------------------------------------------------------------

def apply_interleave_list(queue, channel, get_foreign_items_fn,
                          get_channel_fn, primary_offset=0):
    """
    Weave items from ALL interleave sources into *queue*.

    Sources are processed in list order. Each source uses its own
    independent pass so their frequencies are independent of each other.

    get_foreign_items_fn(foreign_id, foreign_ch, needed) -> list
    get_channel_fn(channel_id)                           -> dict | None

    primary_offset: number of primary items already played/queued before
    this batch (used to align the first insertion point correctly on top-ups).

    Silent sources are woven in the same way as non-silent, but their items
    are tagged _silent: True and _channel_name: <primary channel name> so
    that Coming Up Next can skip them and the OSD can show the channel name.

    Returns the woven queue.
    """
    if not queue:
        return queue

    sources = get_sources(channel)
    if not sources:
        return queue

    channel_name = channel.get("name", "")
    result = queue
    for source in sources:
        result = _weave_single_source(
            result, source, get_foreign_items_fn, get_channel_fn,
            primary_offset, channel_name)

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _weave_single_source(queue, source, get_foreign_items_fn,
                         get_channel_fn, primary_offset=0,
                         channel_name=""):
    """
    Weave one source's items into *queue*.

    Silent sources get items tagged _silent: True and
    _channel_name: channel_name for OSD label suppression.
    """
    foreign_id = source["channel_id"]
    frequency  = source["frequency"]
    jitter     = source["jitter"]
    count_per  = source["count_per"]
    is_silent  = source["silent"]

    foreign_ch = get_channel_fn(foreign_id)
    if not foreign_ch:
        log("[channels/interleave] source channel {} not found -- "
            "skipping".format(foreign_id))
        return queue

    # Estimate how many foreign items we need
    min_gap  = max(1, frequency - jitter)
    _since   = primary_offset % frequency if frequency else 0
    needed   = 0
    for _ in queue:
        _since += 1
        if _since >= min_gap:
            needed += 1
            _since = 0
    if needed == 0:
        return queue
    needed *= count_per

    foreign_items = get_foreign_items_fn(foreign_id, foreign_ch, needed)
    if not foreign_items:
        log("[channels/interleave] no items from '{}' -- "
            "skipping".format(foreign_ch.get("name", foreign_id)))
        return queue

    # Tag items
    tagged = []
    for item in foreign_items:
        item = dict(item)
        item["_channel_id"]  = (item.get("_channel_id")
                                or item.get("channel_id", foreign_id))
        item["_show_id"]     = (item.get("_show_id")
                                or item.get("show_id", 0))
        item["_interleaved"] = True
        if is_silent:
            item["_silent"]       = True
            item["_channel_name"] = channel_name
        tagged.append(item)

    # Weave
    result        = []
    foreign_index = 0
    primary_since = primary_offset % frequency if frequency else 0

    if jitter == 0:
        next_gap = frequency
    else:
        next_gap = random.randint(max(1, frequency - jitter),
                                  frequency + jitter)

    for primary_item in queue:
        result.append(primary_item)
        primary_since += 1
        if primary_since >= next_gap and foreign_index < len(tagged):
            for _ in range(count_per):
                if foreign_index < len(tagged):
                    result.append(tagged[foreign_index])
                    foreign_index += 1
            primary_since = 0
            if jitter == 0:
                next_gap = frequency
            else:
                next_gap = random.randint(max(1, frequency - jitter),
                                          frequency + jitter)

    mode_str = (
        "every {}x{}{}".format(frequency, count_per,
                               " [silent]" if is_silent else "")
        if jitter == 0
        else "every {}+/-{}x{}{} (range {}-{})".format(
            frequency, jitter, count_per,
            " [silent]" if is_silent else "",
            max(1, frequency - jitter), frequency + jitter))
    log("[channels/interleave] wove {} items from '{}' "
        "({}, offset={})".format(
        foreign_index, foreign_ch.get("name", foreign_id),
        mode_str, primary_offset))

    return result
