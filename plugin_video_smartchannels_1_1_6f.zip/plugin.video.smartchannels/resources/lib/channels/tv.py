# channels/tv.py
#
# OWNS:   Queue building logic for TV channels only.
#         Extends BaseQueueBuilder from channels/base.py.
#
# NEVER:  State reads/writes (request via channel_manager.py).
#         Direct library access (request via channel_manager.py).
#         Playback control, UI rendering, routing.
#         Logic belonging to a different channel type.
#
# CALLERS: channel_manager.py only — via the build_queue() dispatch.
#
# STATUS 1.1.0: TVQueueBuilder delegates to channel_manager._build_fresh_queue
# and _topup_queue. The inner slot/EPS/rotation loop lives in channel_manager
# until a dedicated cleanup pass extracts it fully. The module boundary is
# correct; the full logic migration is post-1.1.0.

from __future__ import annotations

from resources.lib.channels.base import BaseQueueBuilder
from resources.lib.utils.logger  import log


class TVQueueBuilder(BaseQueueBuilder):
    """
    Queue builder for TV (round-robin / random) channels.
    Delegates to channel_manager's existing build infrastructure.
    """

    def build(self, channel: dict, target_size: int,
              current_queue=None, start_show_index=None) -> list:
        """
        Build or top-up a TV channel queue.

        current_queue=None  → fresh build via _build_fresh_queue
        current_queue=list  → top-up via _topup_queue
        """
        if current_queue is not None:
            log("[channels/tv] build: top-up mode, current={} target={}".format(
                len(current_queue), target_size))
            return self._cm._topup_queue(channel, current_queue, target_size)

        log("[channels/tv] build: fresh build, target={}".format(target_size))
        return self._cm._build_fresh_queue(channel, target_size,
                                           start_show_index=start_show_index)
