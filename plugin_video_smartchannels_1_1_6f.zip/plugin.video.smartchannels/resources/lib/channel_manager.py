from __future__ import annotations
"""
resources/lib/channel_manager.py
==================================
Central brain of the addon.

Responsibilities:
  - CRUD operations on channel definitions (stored as JSON).
  - Per-show / per-movie "next item" pointer management (persistent state).
  - Queue building: round-robin or randomized, with interleaving support.
  - Recycling logic (loop back to S01E01 when a show is exhausted).

Data files (stored in addon profile folder):
  channels.json   - list of channel definitions
  state.json      - per-channel, per-show playback pointers
"""

import json
import os
import random
import uuid
from typing import Any, Optional

import xbmcaddon
import xbmcvfs

from resources.lib.library      import LibraryClient
from resources.lib.utils.logger import log
from resources.lib.channels.base import (
    normalize_ep as _normalize_ep_fn,
    normalize_movie as _normalize_movie_fn,
    get_filtered_episodes as _get_filtered_episodes_fn,
    get_available_episodes as _get_available_episodes_fn,
    resolve_pointer_index as _resolve_pointer_index_fn,
)
from resources.lib.channels.interleave import (
    get_sources           as _interleave_get_sources,
    apply_interleave_list as _apply_interleave_list,
    get_all_foreign_ids   as _interleave_foreign_ids,
    advance_counters      as _interleave_advance_counters,
)
from resources.lib.utils.paths  import (load_json, save_json, resolve_path,
                                         shared_root, path_join)

# -- Type aliases --------------------------------------------------------------
ChannelDef = dict
EpisodeInfo = dict


class ChannelManager:
    """Manages channel definitions and playback state."""

    CHANNELS_FILE = "channels.json"
    STATE_FILE    = "state.json"

    def __init__(self, addon: xbmcaddon.Addon):
        self.addon   = addon
        self.profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self._ensure_profile_dir()

        # Paths resolved via _resolve_path so shared storage is used
        # automatically when 'shared_storage_path' setting is configured.
        self._channels_path = self._resolve_path(self.CHANNELS_FILE)
        self._state_path    = self._resolve_path(self.STATE_FILE)

        shared = self._shared_root()
        if shared:
            log("[ChannelManager] SHARED STORAGE ACTIVE: {}".format(shared))
            log("[ChannelManager] channels.json -> {}".format(
                self._channels_path))
            log("[ChannelManager] state.json    -> {}".format(
                self._state_path))
        else:
            log("[ChannelManager] LOCAL STORAGE: {}".format(self.profile))

        self._channels = self._load_json(self._channels_path, [])
        self._state    = self._load_json(self._state_path, {})
        log("[ChannelManager] Loaded {} channel(s) from {}".format(
            len(self._channels), self._channels_path))
        # Keys explicitly deleted in this session; stripped from disk
        # merge so deletions are not resurrected by _save_state.
        self._deleted_state_keys: set = set()

        self.library = LibraryClient(addon)

    def _default_queue_size(self) -> int:
        """Return the configured default queue size from settings."""
        try:
            return max(10, int(self.addon.getSetting(
                "default_queue_size") or "30"))
        except (ValueError, TypeError):
            return 30

    # -- Internal helpers ------------------------------------------------------

    def get_replenishment_threshold(self, channel):
        """
        Return the item count at which the queue should be topped up.
        Default: 20% of target queue size, minimum 5 items.
        """
        target = channel.get("queue_size", self._default_queue_size())
        return max(5, int(target * 0.20))

    def _ensure_profile_dir(self) -> None:
        if not xbmcvfs.exists(self.profile):
            xbmcvfs.mkdirs(self.profile)

    # -- Shared-storage path resolver ------------------------------------------

    def _shared_root(self) -> str:
        """Delegate to utils/paths.py — single source of truth."""
        return shared_root()

    def _is_network_path(self, path: str) -> bool:
        """Return True if path is a network protocol URL (smb://, nfs://, etc)."""
        return "://" in path

    def _path_join(self, root: str, filename: str) -> str:
        """Delegate to utils/paths.py — single source of truth."""
        return path_join(root, filename)

    def _resolve_path(self, filename: str) -> str:
        """Delegate to utils/paths.py — single source of truth."""
        return resolve_path(filename)

    # -- JSON I/O --------------------------------------------------------------

    def _load_json(self, path: str, default: Any) -> Any:
        """Delegate to utils/paths.py — single source of truth."""
        return load_json(path, default)

    def _save_json(self, path: str, data: Any) -> None:
        """Delegate to utils/paths.py — single source of truth."""
        save_json(path, data)

    def _save_channels(self) -> None:
        self._save_json(self._channels_path, self._channels)

    def _save_state(self) -> None:
        """
        Re-read-before-write merge for state.json.

        Reads the current file from disk, merges our in-memory changes on
        top, then writes atomically.  Explicitly deleted keys are stripped
        from the merged result so deletions survive the merge.
        """
        try:
            on_disk = self._load_json(self._state_path, {})
            # Merge: start with what's on disk, overlay our in-memory state
            merged = {**on_disk, **self._state}
            # Remove any keys that were explicitly deleted this session
            for k in self._deleted_state_keys:
                merged.pop(k, None)
            self._save_json(self._state_path, merged)
            # Keep in-memory copy consistent with what was written
            self._state = merged
        except Exception as exc:
            log("[ChannelManager] _save_state merge error: {}".format(exc),
                level=2)

    # -- Channel CRUD ----------------------------------------------------------

    def get_all_channels(self) -> list[ChannelDef]:
        """Return all channels (visible and hidden)."""
        return self._channels

    def get_visible_channels(self) -> list[ChannelDef]:
        """Return only channels marked visible."""
        return [c for c in self._channels if c.get("visible", True)]

    def get_channel(self, channel_id: str) -> Optional[ChannelDef]:
        """Find a channel by its ID."""
        for ch in self._channels:
            if ch["id"] == channel_id:
                return ch
        return None

    def create_channel(self, definition: dict) -> ChannelDef:
        """
        Create a new channel from the given definition dict.

        Required keys in definition:
          name        : str   - Display name
          shows       : list  - [{"tvshowid": int, "title": str}, ...]
          randomize   : bool  - Random order or round-robin
          recycle     : bool  - Loop back to S01E01 when exhausted
          queue_size  : int   - Target queue length
          visible     : bool  - Show in channel list
          filters     : list  - Optional [{type, value}, ...] e.g. genre/year
          interleave  : dict  - Optional {"channel_id": str, "frequency": int, "jitter": int}

        Returns the new channel dict (with generated id).
        """
        channel = {
            "id":             str(uuid.uuid4()),
            "name":           definition.get("name", "Unnamed Channel"),
            "channel_type":   definition.get("channel_type", "tv"),
            "shows":          definition.get("shows", []),
            "movies":         definition.get("movies", []),
            "folder_path":    definition.get("folder_path", ""),
            "randomize":      definition.get("randomize", False),
            "recycle":        definition.get("recycle", True),
            "queue_size":     int(definition.get("queue_size", self._default_queue_size())),
            "visible":        definition.get("visible", True),
            "filters":        definition.get("filters", []),
            "excluded_movies": definition.get("excluded_movies", []),
            "interleave":     definition.get("interleave", None),
            "starting_points": definition.get("starting_points", {}),
            "carousel_enabled":   definition.get("carousel_enabled",   False),
            "carousel_interval":  definition.get("carousel_interval",  60),
            "carousel_pop_count": definition.get("carousel_pop_count", 1),
        }
        self._channels.append(channel)
        self._save_channels()

        # Apply starting points to state.json immediately
        self._apply_starting_points(channel)

        log("[ChannelManager] Created channel '{}' id={}".format(
            channel["name"], channel["id"]))

        # Pre-generate the queue immediately so the channel view can
        # display correct episodes. Skip for filter-only TV channels
        # with large show pools - they build lazily on first play instead.
        self._pregenerate_queue_safe(channel)

        return channel

    def update_channel(self, channel_id: str, definition: dict) -> Optional[ChannelDef]:
        """Update an existing channel; reset state for any changed shows."""
        channel = self.get_channel(channel_id)
        if not channel:
            return None

        old_show_ids    = {s["tvshowid"] for s in channel.get("shows", [])}
        # Snapshot values BEFORE updating — channel is a live reference and
        # will be mutated by channel.update() below.
        old_randomize   = channel.get("randomize",    False)
        old_recycle     = channel.get("recycle",      True)
        old_type           = channel.get("channel_type",    "tv")
        old_carousel_enabled   = channel.get("carousel_enabled",   False)
        old_carousel_interval  = channel.get("carousel_interval",  60)
        old_carousel_pop_count = channel.get("carousel_pop_count", 1)
        # Snapshot queue-affecting fields — these must be captured before
        # channel.update() mutates channel in place, otherwise the
        # _no_queue_change comparison always sees equal values on both sides.
        old_shows          = list(channel.get("shows",           []))
        old_movies         = list(channel.get("movies",          []))
        old_queue_size     = channel.get("queue_size",     30)
        old_interleave     = channel.get("interleave",     None)
        old_filters        = list(channel.get("filters",         []))
        old_excluded_movies = list(channel.get("excluded_movies", []))

        channel.update({
            "name":       definition.get("name",       channel["name"]),
            "shows":      definition.get("shows",      channel["shows"]),
            "randomize":  definition.get("randomize",  channel["randomize"]),
            "recycle":    definition.get("recycle",    channel["recycle"]),
            "queue_size": int(definition.get("queue_size", channel["queue_size"])),
            "visible":    definition.get("visible",    channel["visible"]),
            "channel_type":   definition.get("channel_type",
                              channel.get("channel_type", "tv")),
            "movies":         definition.get("movies",
                              channel.get("movies", [])),
            "folder_path":    definition.get("folder_path",
                              channel.get("folder_path", "")),
            "filters":        definition.get("filters",
                              channel.get("filters", [])),
            "excluded_movies": definition.get("excluded_movies",
                               channel.get("excluded_movies", [])),
            "interleave":     definition.get("interleave",
                              channel.get("interleave")),
            "starting_points": definition.get("starting_points",
                               channel.get("starting_points", {})),
            "carousel_enabled":   definition.get("carousel_enabled",
                                  channel.get("carousel_enabled",   False)),
            "carousel_interval":  definition.get("carousel_interval",
                                  channel.get("carousel_interval",  60)),
            "carousel_pop_count": definition.get("carousel_pop_count",
                                  channel.get("carousel_pop_count", 1)),
        })
        self._save_channels()

        new_show_ids      = {s["tvshowid"] for s in channel["shows"]}
        removed           = old_show_ids - new_show_ids
        new_randomize     = channel["randomize"]
        new_recycle       = channel["recycle"]
        new_type          = channel.get("channel_type", "tv")

        randomize_changed = (old_randomize != new_randomize)
        recycle_changed   = (old_recycle   != new_recycle)
        type_changed      = (old_type      != new_type)
        mode_changed      = randomize_changed or recycle_changed or type_changed

        # Reset state for shows no longer in the channel
        for sid in removed:
            state_key = "{}:{}".format(channel_id, sid)
            self._state.pop(state_key, None)
            self._deleted_state_keys.add(state_key)

        # Capture the active show_index from state BEFORE __show_index__ is
        # cleared below. This lets _build_fresh_queue start the Round Robin
        # rotation from the show that was actually playing at edit time,
        # rather than always defaulting to show[0].
        #
        # Two sources combined:
        #   1. now_playing.json LOCAL path (self.profile, never shared
        #      storage) — confirms this channel is the active channel.
        #      The local copy is always written first by player.py and is
        #      authoritative on this device regardless of shared storage.
        #   2. __show_index__ from self._state (in-memory, not yet cleared)
        #      — the integer index of the last-playing show in the rotation,
        #      written by service.py via save_show_index().
        #
        # Skipped when mode changed — those cases already wipe all state
        # and need a clean start from show[0].
        import os as _os_np
        start_show_index = None
        if not mode_changed and channel.get("channel_type") == "tv":
            _local_np = _os_np.path.join(self.profile, "now_playing.json")
            _np = self._load_json(_local_np, {})
            if _np.get("active_channel_id") == channel_id:
                _si_key = "{}:__show_index__".format(channel_id)
                _si     = self._state.get(_si_key)
                if _si is not None:
                    start_show_index = int(_si)
                    log("[ChannelManager] update_channel: captured "
                        "start_show_index={} for rotation seed".format(
                            start_show_index))

        # Always clear __show_index__ on edit. This key was formerly read by
        # _build_fresh_queue to seed show_index — that read was removed in
        # 1.0.9l (show_index always starts at 0 for a fresh build). The key
        # is now write-only from service.py and leaving a stale value on disk
        # is misleading. Clear it so state.json stays clean.
        show_index_key = "{}:__show_index__".format(channel_id)
        self._state.pop(show_index_key, None)
        self._deleted_state_keys.add(show_index_key)

        # If any mode setting changed (randomize, recycle, channel_type),
        # clear ALL state for this channel so the next play starts fresh
        # from S01E01 with the correct mode applied. Also reset all show
        # states to S01E01 explicitly so the queue rebuilds from the start.
        if mode_changed:
            log("[ChannelManager] Mode changed (randomize={} recycle={} "
                "type={}) - clearing all state for channel {}".format(
                randomize_changed, recycle_changed, type_changed,
                channel_id[:8]))
            keys_to_del = [k for k in self._state
                           if k.startswith("{}:".format(channel_id))]
            for k in keys_to_del:
                del self._state[k]
            self._deleted_state_keys.update(keys_to_del)

            # Reset every show to its first AVAILABLE episode (episode_filters
            # + excluded_episodes applied) so queue rebuilds from scratch
            # without landing on an excluded episode.
            for show in channel.get("shows", []):
                sid  = show["tvshowid"]
                eps  = self.get_available_episodes(show)
                if eps:
                    first = eps[0]
                    self._state["{}:{}".format(channel_id, sid)] = {
                        "next_episode_id": first["episodeid"],
                        "season":          first.get("season",  1),
                        "episode":         first.get("episode", 1),
                        "played_ids":      [],
                    }

            # Delete per-channel queue file so queue is rebuilt fresh
            import xbmcvfs as _xbmcvfs
            queue_path = self._queue_file_path(channel_id)
            if _xbmcvfs.exists(queue_path):
                _xbmcvfs.delete(queue_path)
                log("[ChannelManager] Deleted queue file after "
                    "mode change for channel {}".format(channel_id[:8]))

        self._save_state()

        # For movie channels, always clear the cycle-tracking state on edit.
        # __movie_state__ records which movies have been played this shuffle
        # cycle (played_ids, unplayed_ids). If the channel is edited — even
        # just to add/remove a filter — the effective movie pool can change
        # completely. Inheriting old cycle state causes _build_movie_queue to
        # treat previously-watched movies from the OLD pool as "played" in
        # the NEW pool, leaving only a tiny unplayed fraction. That partial
        # fraction fills a micro-cycle, resets, and the same movies can then
        # reappear immediately in the first full cycle — producing visible
        # early repeats (root cause of TC-9.2 failure).
        #
        # Clearing this key causes _build_movie_queue to fall through to its
        # clean initialisation branch: all movies in the new pool start as
        # unplayed, and the full random shuffle cycle begins fresh. This is
        # analogous to how TV channels reset per-show episode state when
        # edited, and is the correct behaviour for any pool change.
        if new_type == "movies":
            _movie_state_key = "{}:__movie_state__".format(channel_id)
            self._state.pop(_movie_state_key, None)
            self._deleted_state_keys.add(_movie_state_key)
            log("[ChannelManager] update_channel: cleared movie state "
                "for channel {}".format(channel_id[:8]))

        # Apply starting points - force=True overwrites existing state
        # since user explicitly chose new positions during edit
        self._apply_starting_points(channel, force=True)

        log("[ChannelManager] Updated channel id={}".format(channel_id))

        # Regenerate queue. Skip when no queue-affecting fields changed.
        # Carousel settings (carousel_enabled, carousel_interval,
        # carousel_pop_count) do not affect the episode sequence — the
        # existing queue file is valid when only those fields changed.
        # Rebuilding would re-add episodes the carousel already popped.
        # A no-op edit (wizard opened and saved unchanged) must also skip
        # the rebuild for the same reason.
        #
        # Note: old_carousel_* are snapshotted before channel.update() so
        # they reflect the pre-edit values; channel["carousel_*"] now holds
        # the post-edit values.
        _no_queue_change = (
            not mode_changed
            and not removed
            and definition.get("name",            channel["name"])   == channel["name"]
            and definition.get("shows",           old_shows)         == old_shows
            and definition.get("movies",          old_movies)        == old_movies
            and definition.get("queue_size",      old_queue_size)    == old_queue_size
            and definition.get("interleave",      old_interleave)    == old_interleave
            and definition.get("filters",         old_filters)       == old_filters
            and definition.get("excluded_movies", old_excluded_movies) == old_excluded_movies
        )

        if _no_queue_change:
            log("[ChannelManager] update_channel: no queue-affecting fields "
                "changed — skipping queue rebuild to preserve carousel "
                "position for channel {}".format(channel_id[:8]))
        else:
            # Before rebuilding, seed per-show state from the queue tail for
            # any existing show whose state key is absent. This handles the
            # common case where the channel has never been played (so service.py
            # has never written a per-show state key) but the tail's indices
            # correctly reflect where the queue currently sits (e.g. after
            # carousel pops). Without this, _build_fresh_queue sees
            # next_episode_id=None for those shows and resets to S01E01,
            # ignoring the user's "Keep current position" choice.
            #
            # Only applied when no explicit starting_points were set — if the
            # user chose "Set Starting Points manually" or "Surprise Me!",
            # _apply_starting_points already wrote the correct state above and
            # we must not overwrite it here.
            _sp = channel.get("starting_points", {})
            if not _sp and channel.get("channel_type") == "tv":
                # Read the queue file to find the first episode for each
                # existing show. The tail indices record the END of the queue
                # (next episode to append on top-up), not the front. Only
                # the queue file itself reliably records where each show
                # currently sits from the viewer's perspective.
                _qpath = self._queue_file_path(channel_id)
                _queue_front = {}  # sid -> first queue item for that show
                try:
                    import json as _json
                    import xbmcvfs as _xbmcvfs
                    if _xbmcvfs.exists(_qpath):
                        with _xbmcvfs.File(_qpath, "r") as _f:
                            _raw = _f.read()
                        if _raw:
                            _qdata = _json.loads(_raw)
                            for _item in _qdata:
                                _sid = (_item.get("show_id")
                                        or _item.get("_show_id"))
                                if _sid and _sid not in _queue_front:
                                    _queue_front[_sid] = _item
                except Exception as _e:
                    log("[ChannelManager] update_channel: could not read "
                        "queue file for keep-position seeding: {}".format(_e))

                for show in channel.get("shows", []):
                    sid = show["tvshowid"]
                    state_key = "{}:{}".format(channel_id, sid)
                    if state_key not in self._state and sid in _queue_front:
                        _front = _queue_front[sid]
                        self._state[state_key] = {
                            "next_episode_id": _front["episodeid"],
                            "season":          _front.get("season",  1),
                            "episode":         _front.get("episode", 1),
                            "played_ids":      [],
                        }
                        log("[ChannelManager] update_channel: seeded "
                            "show {} state from queue front "
                            "S{}E{} for keep-position "
                            "rebuild".format(
                                sid,
                                _front.get("season", 1),
                                _front.get("episode", 1)))
                self._save_state()

            self._pregenerate_queue_safe(channel,
                                         start_show_index=start_show_index)

        return channel

    def delete_channel(self, channel_id):
        """Delete a channel, its state data and its queue file.
        Also deletes any invisible auto-companion channels that were created
        by Auto-Create Channels and are only referenced by this channel."""
        # Find and delete auto-companion channels first.
        # Companions are named __auto__<channel_name> and are only referenced
        # by the channel being deleted via its interleave config.
        channel = self.get_channel(channel_id)
        if channel:
            from resources.lib.channels.interleave import get_sources
            for source in get_sources(channel):
                companion_id = source.get("channel_id")
                if not companion_id:
                    continue
                companion = self.get_channel(companion_id)
                if (companion
                        and companion.get("name", "").startswith("__auto__")
                        and not companion.get("visible", True)):
                    # Recursively delete the companion (no further companions
                    # since companions are plain movie channels with no
                    # interleave of their own)
                    self.delete_channel(companion_id)
                    log("[ChannelManager] Deleted auto companion "
                        "id={}".format(companion_id))

        before = len(self._channels)
        self._channels = [c for c in self._channels if c["id"] != channel_id]
        if len(self._channels) < before:
            # Clean up ALL state keys for this channel
            keys_to_del = [k for k in self._state
                           if k.startswith("{}:".format(channel_id))]
            for k in keys_to_del:
                del self._state[k]
            self._deleted_state_keys.update(keys_to_del)
            self._save_channels()
            self._save_state()
            # Delete per-channel queue file and any leftover .tmp
            queue_path = self._queue_file_path(channel_id)
            for p in (queue_path, queue_path + ".tmp"):
                try:
                    if xbmcvfs.exists(p):
                        xbmcvfs.delete(p)
                except Exception:
                    pass
            # Clean up resume entries for this channel from shared state
            # and local backup (resume:channel_id:* keys)
            resume_prefix = "resume:{}:".format(channel_id)
            resume_keys = [k for k in list(self._state.keys())
                           if k.startswith(resume_prefix)]
            for k in resume_keys:
                del self._state[k]
            if resume_keys:
                self._deleted_state_keys.update(resume_keys)
                self._save_state()

            # Clean up local resume_backup.json
            try:
                import os as _os2, xbmcvfs as _vfs2, xbmcaddon as _ada2
                _profile2 = _vfs2.translatePath(
                    _ada2.Addon().getAddonInfo("profile"))
                _local2 = _os2.path.join(_profile2, "resume_backup.json")
                if _vfs2.exists(_local2):
                    _backup2 = self._load_json(_local2, {})
                    _bkeys   = [k for k in list(_backup2.keys())
                                if k.startswith(resume_prefix)]
                    for k in _bkeys:
                        del _backup2[k]
                    if _bkeys:
                        self._save_json(_local2, _backup2)
            except Exception as _e2:
                log("[ChannelManager] delete_channel resume_backup cleanup "
                    "error: {}".format(_e2))

            log("[ChannelManager] Deleted channel id={}".format(channel_id))
            return True
        return False

    def toggle_visibility(self, channel_id: str) -> None:
        channel = self.get_channel(channel_id)
        if channel:
            channel["visible"] = not channel.get("visible", True)
            self._save_channels()

    # -- Playback state --------------------------------------------------------

    def _state_key(self, channel_id: str, show_id: int) -> str:
        return f"{channel_id}:{show_id}"

    def _channel_exhausted(self, channel_id: str, channel: dict) -> bool:
        """
        Return True if all shows in a recycle=False channel have been
        fully played.  Always returns False for recycle=True channels.

        Sequential channels: advance_show (via _advance_sequential) writes
        next_episode_id=None when the last episode finishes with
        recycle=False.  We check for that.

        Random channels: exhaustion is tracked via the queue tail marker
        local_played.  A show is exhausted when every episode id it has
        appears in local_played[sid].  We use that for random channels
        because _advance_random always resets next_episode_id to a random
        choice and never writes None.

        IMPORTANT: a missing state key (brand new channel, never played)
        must NOT count as exhausted.  We only treat a show as exhausted
        when its state key actually exists in state.json AND the show meets
        the exhaustion criteria for its mode.
        """
        if channel.get("recycle", True):
            return False

        # Folder channel exhaustion: delegate to FolderQueueBuilder which
        # owns the folder-scanning and played_files state logic.
        if channel.get("channel_type") == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            return FolderQueueBuilder(self).is_exhausted(channel)

        # Movie channel exhaustion: _advance_movie_state empties unplayed_ids
        # when the last movie finishes with recycle=False.
        # If the state key doesn't exist the channel was never played.
        if channel.get("channel_type") == "movies":
            state_key = "{}:__movie_state__".format(channel["id"])
            fresh  = self._load_json(self._state_path, {})
            mstate = fresh.get(state_key)
            if mstate is None:
                return False  # Never played — not exhausted
            unplayed = mstate.get("unplayed_ids", None)
            played   = mstate.get("played_ids", [])
            # Exhausted only when unplayed is empty AND something was played
            # (guards against a fresh reset where played_ids=[] too)
            if unplayed is not None and len(unplayed) == 0 and len(played) > 0:
                return True
            return False

        shows = channel.get("shows", [])
        if not shows:
            return False

        channel_randomize = channel.get("randomize", False)

        # Mixed-mode support: each show may have its own randomize flag.
        # A show is exhausted according to its own mode:
        #   Sequential: next_episode_id=None in state
        #   Random:     all episode ids appear in state["actually_played_ids"]
        # The channel is exhausted only when ALL shows are exhausted.
        #
        # NOTE: random exhaustion previously checked the queue tail's
        # local_played, which tracks episodes placed into the queue file —
        # NOT episodes actually watched. A show with N episodes and a
        # queue_size >= N would have every episode in local_played after
        # the very first (unplayed) queue build, causing a false-positive
        # exhaustion before any playback occurred. actually_played_ids is
        # updated only in _advance_random, which fires when an episode
        # genuinely finishes or is skipped past — never at queue-build time.
        for s in shows:
            sid           = s["tvshowid"]
            show_randomize = s.get("randomize", channel_randomize)

            if show_randomize:
                # Random exhaustion: all episode ids must be in
                # actually_played_ids. A missing/empty state key means the
                # show was never played — not exhausted.
                key = self._state_key(channel_id, sid)
                show_state = self._state.get(key)
                if not show_state:
                    return False
                played = set(show_state.get("actually_played_ids", []))
                if not played:
                    return False  # never actually played anything yet
                # get_available_episodes(): episode_filters + exclusions
                # applied. An excluded episode must never be required to
                # appear in actually_played_ids — it can never legitimately
                # play, so requiring it would make a recycle=False channel
                # with any exclusion unable to ever reach exhaustion.
                episodes = self.get_available_episodes(s)
                if not episodes:
                    continue  # nothing available — cannot block exhaustion
                ep_ids  = {e["episodeid"] for e in episodes}
                if not ep_ids.issubset(played):
                    return False
            else:
                # Sequential exhaustion: advance_show (via
                # _advance_sequential) writes next_episode_id=None when
                # the last episode finishes with recycle=False.
                key = self._state_key(channel_id, sid)
                if key not in self._state:
                    return False
                if self._state[key].get("next_episode_id") is not None:
                    return False

        return True

    def record_folder_file_played(self, channel_id: str,
                                   file_path: str) -> None:
        """
        Record a folder channel file as played for recycle=False tracking.

        Called by service.py whenever a folder item completes naturally
        (onPlayBackEnded) or is skipped past. Appends file_path to the
        played_files list in the channel's show_id=0 state, which
        FolderQueueBuilder._get_played_files() reads when deciding
        whether any unplayed files remain.

        Duplicates are silently ignored — a file is either played or not.
        """
        if not file_path:
            return
        state   = self.get_show_state(channel_id, 0)
        played  = state.get("played_files", [])
        if file_path not in played:
            played.append(file_path)
            state["played_files"] = played
            self.save_show_state(channel_id, 0, state)
            log("[ChannelManager] record_folder_file_played: "
                "channel={} file={}".format(channel_id[:8],
                                            file_path.rsplit("/", 1)[-1]
                                            .rsplit("\\", 1)[-1]))

    def is_channel_exhausted(self, channel_id: str, channel: dict) -> bool:
        """Public wrapper for _channel_exhausted — called by service.py."""
        return self._channel_exhausted(channel_id, channel)

    def get_show_state(self, channel_id: str, show_id: int) -> dict:
        """
        Return the playback state for a show within a channel.
        State shape:
          {
            "next_episode_id": int | None,    # episodeid in Kodi DB
            "season":          int,
            "episode":         int,
            "played_ids":      [],            # for randomize+no-repeat tracking
          }
        """
        key = self._state_key(channel_id, show_id)
        return self._state.get(key, {
            "next_episode_id": None,
            "season":  1,
            "episode": 1,
            "played_ids": [],
        })

    def get_next_episode_for_show(self, channel_id, show):
        """
        Return the next episode dict for a show in a channel.
        Used by the channel view to display "Next: SxxExx - Title".

        Priority:
          1. state.json next_episode_id (tracks actual playback position)
          2. queue file first unplayed entry for this show
          3. First episode in library (fallback for brand new channels)
        """
        import json as _json
        import os as _os
        import xbmcvfs as _xbmcvfs

        show_entry = show if isinstance(show, dict) else {"tvshowid": show}
        sid        = show_entry["tvshowid"]
        episodes   = self.get_available_episodes(show_entry)
        if not episodes:
            return None

        # Priority 1: state.json next_episode_id. Resolved against the
        # available (filtered + exclusion-applied) pool so a pointer left
        # over from a since-excluded episode displays the next real
        # available episode instead of silently falling through to
        # Priority 2/3 (which would look like the show reset).
        state    = self.get_show_state(channel_id, sid)
        next_id  = state.get("next_episode_id")
        if next_id is not None:
            resolved_idx = self._resolve_pointer_index(
                show_entry, next_id, episodes)
            if resolved_idx >= 0:
                return episodes[resolved_idx]

        # Priority 2: first unplayed entry in queue file
        try:
            queue_path = self._resolve_path(
                "queue_{}.json".format(channel_id))
            if _xbmcvfs.exists(queue_path):
                with _xbmcvfs.File(queue_path, "r") as f:
                    queue = _json.loads(f.read())
                played_ids = set(state.get("played_ids", []))
                for item in queue:
                    if item.get("show_id") != sid:
                        continue
                    ep_id = item.get("episodeid")
                    if ep_id in played_ids:
                        continue
                    ep = next((e for e in episodes
                               if e["episodeid"] == ep_id), None)
                    if ep:
                        return ep
        except Exception as e:
            log("[ChannelManager] get_next_episode_for_show error: "
                "{}".format(e))

        # Priority 3: first episode in library
        return episodes[0]

    def get_filtered_episodes(self, show_entry: dict) -> list:
        """Delegate to channels/base.py — single source of truth."""
        return _get_filtered_episodes_fn(show_entry, self.library)

    def get_available_episodes(self, show_entry: dict) -> list:
        """Delegate to channels/base.py — single source of truth."""
        return _get_available_episodes_fn(show_entry, self.library)

    def _resolve_pointer_index(self, show_entry: dict, next_id,
                               available_eps: list) -> int:
        """Delegate to channels/base.py — single source of truth."""
        return _resolve_pointer_index_fn(
            show_entry, next_id, available_eps, self.library)

    def save_show_state(self, channel_id: str, show_id: int, state: dict) -> None:
        key = self._state_key(channel_id, show_id)
        self._state[key] = state
        self._save_state()

    def advance_show(self, channel_id: str, show_id: int,
                     played_episode_id: int,
                     next_ep_id: int = None,
                     next_ep_info: dict = None) -> Optional[EpisodeInfo]:
        """
        Mark `played_episode_id` as watched for this show/channel and
        advance the pointer to the next episode.

        This is the SOLE entry point for TV/serial state advancement —
        service.py calls this on every episode end (and on skip-detected
        advancement) instead of reimplementing the logic locally.

        next_ep_id:   if provided, the queue already knows what plays
                      next — use it directly instead of looking it up.
        next_ep_info: dict with season/episode (and, for serial channels,
                      _show_id/show_id) for next_ep_id. When supplied,
                      no library lookup is needed at all (fast path) —
                      this matters because this is the hottest code path
                      in the addon, firing on every episode completion.

        Returns the new next EpisodeInfo, or None if exhausted and
        recycle is disabled, or on lookup failure.
        """
        channel = self.get_channel(channel_id)
        if not channel:
            return None

        channel_type = channel.get("channel_type", "tv")
        recycle      = channel.get("recycle", True)

        # Serial channels have their own boundary-crossing semantics —
        # handled separately since "next episode" may belong to a
        # different show entirely.
        if channel_type == "serial":
            return self._advance_serial(channel_id, show_id,
                                        played_episode_id, channel,
                                        next_ep_id, next_ep_info)

        # Per-show randomize: look up this show's entry in the channel's
        # shows list so its individual flag (if set) takes precedence over
        # the channel-level flag. Also needed (episode_filters,
        # excluded_episodes) to fetch the correct available episode pool.
        show_entry = next(
            (s for s in channel.get("shows", [])
             if s.get("tvshowid") == show_id), None)
        channel_randomize = channel.get("randomize", False)
        randomize = (show_entry.get("randomize", channel_randomize)
                     if show_entry else channel_randomize)

        episodes = (self.get_available_episodes(show_entry) if show_entry
                    else self.library.get_episodes_for_show(show_id))
        if not episodes:
            return None

        state = self.get_show_state(channel_id, show_id)

        # Fast path: the queue already told us what plays next, so we can
        # write the pointer directly and skip the library walk entirely.
        if next_ep_id is not None:
            if next_ep_info:
                next_season  = next_ep_info.get("season",  1)
                next_episode = next_ep_info.get("episode", 1)
            else:
                next_ep = next((e for e in episodes
                                if e["episodeid"] == next_ep_id), None)
                if not next_ep:
                    log("[ChannelManager] advance_show: next_ep_id {} not "
                        "found for show {}".format(next_ep_id, show_id),
                        level=2)
                    return None
                next_season  = next_ep.get("season",  1)
                next_episode = next_ep.get("episode", 1)

            actually_played = set(state.get("actually_played_ids", []))
            if played_episode_id is not None:
                actually_played.add(played_episode_id)
            if randomize and recycle:
                all_ids = {e["episodeid"] for e in episodes}
                if all_ids and actually_played.issuperset(all_ids):
                    actually_played = set()  # full cycle complete

            state.update({
                "next_episode_id":     next_ep_id,
                "season":              next_season,
                "episode":             next_episode,
                "played_ids":          [],
                "actually_played_ids": list(actually_played),
            })
            self.save_show_state(channel_id, show_id, state)
            log("[ChannelManager] advance_show: fast-path show={} "
                "next_ep={} S{}E{}".format(show_id, next_ep_id,
                                           next_season, next_episode))
            return {"episodeid": next_ep_id, "season": next_season,
                    "episode": next_episode}

        # No next_ep_id supplied — queue ran dry, fall back to a library
        # lookup to pick the next episode.
        if randomize:
            return self._advance_random(channel_id, show_id, state,
                                        episodes, played_episode_id, recycle)
        else:
            return self._advance_sequential(channel_id, show_id, state,
                                            episodes, played_episode_id, recycle)

    def _advance_serial(self, channel_id, show_id, played_episode_id,
                        channel, next_ep_id, next_ep_info) -> Optional[EpisodeInfo]:
        """
        Serial channel advancement. Three cases:

        1. next_ep_id is None (queue ran completely dry) — the
           just-finished show is done; delegate to SerialQueueBuilder to
           reset it to S01E01 and advance __serial_show_idx__.
        2. next_ep_id belongs to a DIFFERENT show (boundary crossing) —
           same delegation as (1) for the OLD (finished) show, then
           write the NEW show's pointer using the fast path.
        3. next_ep_id belongs to the SAME show (ordinary in-show step) —
           fast-path write only; no show reset, no index change.
        """
        from resources.lib.serial import SerialQueueBuilder
        builder = SerialQueueBuilder(self)

        if next_ep_id is None:
            log("[ChannelManager] _advance_serial: queue dry for show={} "
                "— treating as show boundary".format(show_id))
            return builder.advance_show(channel_id, show_id,
                                        played_episode_id, channel)

        # Determine whether next_ep_id belongs to a different show.
        next_show_id = None
        if next_ep_info:
            next_show_id = (next_ep_info.get("_show_id")
                             or next_ep_info.get("show_id"))
        if next_show_id is None:
            try:
                cur_episodes = self.library.get_episodes_for_show(show_id)
                cur_ids = ({e["episodeid"] for e in cur_episodes}
                           if cur_episodes else set())
                if next_ep_id not in cur_ids:
                    for s in channel.get("shows", []):
                        sid = s["tvshowid"]
                        if int(sid) == int(show_id):
                            continue
                        eps = self.library.get_episodes_for_show(sid)
                        if eps and any(e["episodeid"] == next_ep_id
                                      for e in eps):
                            next_show_id = sid
                            break
            except Exception as exc:
                log("[ChannelManager] _advance_serial: boundary lookup "
                    "error: {}".format(exc), level=2)

        target_show_id = show_id
        if next_show_id is not None and int(next_show_id) != int(show_id):
            log("[ChannelManager] _advance_serial: show boundary {} -> "
                "{}".format(show_id, next_show_id))
            builder.advance_show(channel_id, show_id, played_episode_id,
                                 channel)
            target_show_id = int(next_show_id)

        # Fast-path write of the (possibly new) show's pointer.
        state = self.get_show_state(channel_id, target_show_id)
        if next_ep_info:
            next_season  = next_ep_info.get("season",  1)
            next_episode = next_ep_info.get("episode", 1)
        else:
            episodes = self.library.get_episodes_for_show(target_show_id)
            next_ep  = next((e for e in episodes
                             if e["episodeid"] == next_ep_id), None) \
                       if episodes else None
            if not next_ep:
                log("[ChannelManager] _advance_serial: next_ep_id {} not "
                    "found for show {}".format(next_ep_id, target_show_id),
                    level=2)
                return None
            next_season  = next_ep.get("season",  1)
            next_episode = next_ep.get("episode", 1)

        actually_played = set(state.get("actually_played_ids", []))
        # played_episode_id is the episode that JUST FINISHED on show_id.
        # After a boundary crossing target_show_id is a DIFFERENT show, so
        # played_episode_id belongs to the old show — do not contaminate
        # the new show's tracking with it (TC-10.4 bug: ep=138725 from
        # show 2693 appearing in show 1821's actually_played_ids).
        if played_episode_id is not None and (
                int(target_show_id) == int(show_id)):
            actually_played.add(played_episode_id)

        state.update({
            "next_episode_id":     next_ep_id,
            "season":              next_season,
            "episode":             next_episode,
            "played_ids":          [],
            "actually_played_ids": list(actually_played),
        })
        self.save_show_state(channel_id, target_show_id, state)
        log("[ChannelManager] _advance_serial: fast-path show={} "
            "next_ep={} S{}E{}".format(target_show_id, next_ep_id,
                                       next_season, next_episode))
        return {"episodeid": next_ep_id, "season": next_season,
                "episode": next_episode}

    def _advance_sequential(self, channel_id, show_id, state, episodes,
                             played_id, recycle) -> Optional[EpisodeInfo]:
        """Move to the next episode in air-date / season-episode order."""
        ep_ids = [e["episodeid"] for e in episodes]
        try:
            idx = ep_ids.index(played_id)
        except ValueError:
            idx = -1

        next_idx = idx + 1
        if next_idx >= len(episodes):
            if not recycle:
                log("[ChannelManager] _advance_sequential: show {} "
                    "exhausted, recycle=False".format(show_id))
                # Write next_episode_id=None so callers (e.g. queue resume
                # / exhaustion checks) can detect that this show is fully
                # done instead of replaying the last episode.
                self.save_show_state(channel_id, show_id, {
                    "next_episode_id": None,
                    "played_ids":      [],
                })
                return None
            next_idx = 0  # Loop back to S01E01

        next_ep = episodes[next_idx]
        state.update({
            "next_episode_id": next_ep["episodeid"],
            "season":          next_ep.get("season", 1),
            "episode":         next_ep.get("episode", 1),
        })
        self.save_show_state(channel_id, show_id, state)
        return next_ep

    def _advance_random(self, channel_id, show_id, state, episodes,
                        played_id, recycle) -> Optional[EpisodeInfo]:
        """
        Pick a random episode for the next queue slot.
        No-repeat tracking for QUEUE BUILDING is handled by the queue tail
        (local_played in channel_manager's tail file), not by played_ids
        in the show state. The show state's played_ids field is reserved
        and unused for queue building.

        EXHAUSTION tracking is separate and lives in
        state["actually_played_ids"] — updated here with the episode that
        just genuinely finished playing (played_id, passed in by
        service.py's onPlayBackEnded/skip-advance path). This list only
        grows when an episode is confirmed played, never when an episode
        is merely placed into a queue file. _channel_exhausted reads this
        list, not the queue tail, to avoid conflating "queued" with
        "watched" — a show with N episodes and a queue_size >= N would
        otherwise appear exhausted on its very first (unplayed) build.
        """
        ep_ids    = [e["episodeid"] for e in episodes]
        chosen_id = random.choice(ep_ids)
        chosen_ep = next(e for e in episodes if e["episodeid"] == chosen_id)

        actually_played = set(state.get("actually_played_ids", []))
        if played_id is not None:
            actually_played.add(played_id)

        # recycle=True: once every episode has actually been played, reset
        # the tracking list so the cycle can begin again (mirrors how the
        # queue tail's local_played resets for recycle=True shows).
        if recycle and actually_played.issuperset(set(ep_ids)):
            actually_played = set()

        state.update({
            "next_episode_id":     chosen_id,
            "season":              chosen_ep.get("season", 1),
            "episode":             chosen_ep.get("episode", 1),
            "played_ids":          [],
            "actually_played_ids": list(actually_played),
        })
        self.save_show_state(channel_id, show_id, state)
        return chosen_ep

    # -- Queue building --------------------------------------------------------

    def build_queue(self, channel, size=None, start_show_index=None):
        """
        Build a playback queue for a channel.

        If now_playing.json exists for this channel and still has unplayed
        episodes, resume from it rather than building a new random queue.
        This preserves the randomized order across restarts.

        Only builds a fresh queue when:
        - No existing queue file exists
        - The existing queue belongs to a different channel
        - The existing queue is exhausted (all episodes played)
        """
        import json as _json
        import os as _os
        import xbmcvfs as _xbmcvfs

        channel_id  = channel["id"]
        target_size = size or channel.get("queue_size", self._default_queue_size())

        # Route folder channels to FolderQueueBuilder.
        if channel.get("channel_type") == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            if size is None:
                resumed = self._resume_from_existing_queue(channel_id, channel)
                if resumed is not None:
                    if len(resumed) == 0:
                        log("[ChannelManager] Folder channel '{}' exhausted "
                            "(recycle=False) — returning empty queue".format(
                                channel["name"]))
                        return []
                    log("[ChannelManager] Resumed folder queue of {} items "
                        "for channel '{}'".format(len(resumed), channel["name"]))
                    return resumed
            return FolderQueueBuilder(self).build(channel, target_size)

        # Route serial channels to the self-contained serial builder.
        # channels/serial.py (via resources/lib/serial.py shim) owns all
        # queue building and state logic for serial channels.
        if channel.get("channel_type") == "serial":
            from resources.lib.serial import SerialQueueBuilder
            if size is None:
                resumed = self._resume_from_existing_queue(channel_id, channel)
                if resumed is not None:
                    if len(resumed) == 0:
                        log("[ChannelManager] Serial channel '{}' exhausted "
                            "(recycle=False) — returning empty queue".format(
                                channel["name"]))
                        return []
                    log("[ChannelManager] Resumed existing serial queue of "
                        "{} items for channel '{}'".format(
                            len(resumed), channel["name"]))
                    return resumed
            return SerialQueueBuilder(self).build(channel, target_size)

        # Route movie channels to MovieQueueBuilder.
        if channel.get("channel_type") == "movies":
            from resources.lib.channels.movies import MovieQueueBuilder
            if size is None:
                resumed = self._resume_from_existing_queue(channel_id, channel)
                if resumed is not None:
                    if len(resumed) == 0:
                        log("[ChannelManager] Movie channel '{}' exhausted "
                            "(recycle=False) — returning empty queue".format(
                                channel["name"]))
                        return []
                    log("[ChannelManager] Resumed movie queue of {} items "
                        "for channel '{}'".format(len(resumed), channel["name"]))
                    return resumed
            return MovieQueueBuilder(self).build(channel, target_size)

        shows = channel.get("shows", [])

        if not shows:
            log("[ChannelManager] build_queue: no shows in channel {}".format(
                channel_id))
            return []

        # Try to resume from existing now_playing.json
        # This preserves random order across restarts
        if size is None:  # only resume for full queue builds not refills
            resumed = self._resume_from_existing_queue(channel_id, channel)
            if resumed is not None:
                if len(resumed) == 0:
                    # Channel exhausted with recycle=False — do not build
                    # a fresh queue. Return [] so player shows "No episodes
                    # found" instead of restarting from S01E01.
                    log("[ChannelManager] Channel '{}' exhausted "
                        "(recycle=False) — returning empty queue".format(
                            channel["name"]))
                    return []
                log("[ChannelManager] Resumed existing queue of {} items "
                    "for channel '{}'".format(len(resumed), channel["name"]))
                return resumed

            # resumed is None — no queue file exists.
            # For recycle=False, check state before building fresh.
            # If all shows are exhausted, stay exhausted.
            if self._channel_exhausted(channel_id, channel):
                log("[ChannelManager] Channel '{}' exhausted "
                    "(recycle=False, no queue file) — returning "
                    "empty queue".format(channel["name"]))
                return []

        # Route TV channels to TVQueueBuilder.
        from resources.lib.channels.tv import TVQueueBuilder
        return TVQueueBuilder(self).build(channel, target_size,
                                          start_show_index=start_show_index)

    def _build_movie_queue(self, channel, target_size, for_interleave=False):
        """
        Build a queue of movies for a movie channel.

        Movie state is tracked differently from TV episodes:
        - No season/episode concept
        - played_ids tracks which movies have been played this cycle
        - Recycle resets played_ids and starts over when all played
        - State key uses movieid directly: channel_id:movie:<movieid>

        The tail marker tracks position in the movie list for sequential
        mode so top-ups continue from the correct position.
        """
        channel_id = channel["id"]
        movies     = channel.get("movies", [])
        randomize  = channel.get("randomize", False)
        recycle    = channel.get("recycle", True)

        if not movies:
            log("[ChannelManager] Movie channel has no movies defined")
            return []

        # Load movie details from local cache file directly.
        # Using load_local_cache() instead of get_all_movies() ensures
        # we always get fresh data including plots, bypassing the
        # in-memory cache which may have stale data from earlier sessions.
        filters        = channel.get("filters", [])
        excluded_movie_ids = set(channel.get("excluded_movies", []))
        movie_ids      = [m["movieid"] for m in movies
                          if m["movieid"] not in excluded_movie_ids]
        movie_id_set   = set(movie_ids)

        # Always read directly from cache file for queue building
        cached_data   = self.library.load_local_cache()
        if cached_data and cached_data.get("movies"):
            all_lib_movies = [m for m in cached_data["movies"]
                              if m.get("movieid") in movie_id_set]
        else:
            # Fallback to in-memory cache if no file cache exists
            all_lib_movies = self.library.get_all_movies()
            all_lib_movies = [m for m in all_lib_movies
                              if m.get("movieid") in movie_id_set]

        # Apply filters if set
        if filters and all_lib_movies:
            all_lib_movies = self.library._filter_items_in_python(
                all_lib_movies, filters)

        movie_lookup = {m["movieid"]: m for m in all_lib_movies}

        if not movie_lookup:
            log("[ChannelManager] No movies found in library for channel")
            return []

        # Load movie state fresh from disk so we always see the latest
        # played_ids written by _advance_movie_state in service.py.
        # self._state is a stale in-memory snapshot and will miss movies
        # that were marked played during the current playback session.
        state_key = "{}:__movie_state__".format(channel_id)
        try:
            _fresh_state = self._load_json(self._state_path, {})
            movie_state  = _fresh_state.get(state_key, {
                "played_ids": [],
                "next_index": 0,
            })
        except Exception:
            movie_state = self._state.get(state_key, {
                "played_ids": [],
                "next_index": 0,
            })
        played_ids = list(movie_state.get("played_ids", []))
        next_index = movie_state.get("next_index", 0)

        # Dedup channel movie list preserving order
        seen_ids = set()
        unique_movie_ids = []
        for mid in movie_ids:
            if mid not in seen_ids and mid in movie_lookup:
                seen_ids.add(mid)
                unique_movie_ids.append(mid)
        all_available = unique_movie_ids

        # unplayed_ids: movies not yet watched this cycle.
        # Only _advance_movie_state removes from this when a movie is watched.
        stored_unplayed = movie_state.get("unplayed_ids", None)
        if stored_unplayed is not None:
            valid_ids    = set(unique_movie_ids)
            unplayed_ids = [mid for mid in stored_unplayed if mid in valid_ids]
            stored_set   = set(stored_unplayed) | set(played_ids)
            for mid in unique_movie_ids:
                if mid not in stored_set:
                    unplayed_ids.append(mid)
        else:
            unplayed_ids = [mid for mid in unique_movie_ids
                            if mid not in played_ids]

        # For interleave builds: use interleave_index — a simple pointer
        # into a shuffled deck of ALL movies that persists across builds.
        #
        # IMPORTANT: the deck (interleave_order) always contains all_available
        # (every movie in the channel), NOT just unplayed_ids.
        # unplayed_ids and played_ids are purely for detecting when the full
        # watch cycle is complete so we can reshuffle.  They must never be
        # used to filter the deck — doing so removes recently-watched movies
        # from the deck mid-cycle, corrupts interleave_index (the saved index
        # no longer points to the same movie after movies are removed), and
        # can cause the index to clamp back to 0, restarting the deck from
        # the beginning and causing immediate repeats.
        if for_interleave:
            stored_order = movie_state.get("interleave_order", [])
            valid_set    = set(all_available)   # ALL movies, not just unplayed
            # Keep stored order but drop any ids no longer in the channel
            interleave_order = [m for m in stored_order if m in valid_set]
            # Append any movies added to the channel since the deck was built
            in_order = set(interleave_order)
            new_ones = [m for m in all_available if m not in in_order]
            if new_ones:
                random.shuffle(new_ones)
                interleave_order.extend(new_ones)
            interleave_idx = movie_state.get("interleave_index", 0)
            # Clamp only if deck shrank due to removed movies
            if interleave_idx >= len(interleave_order):
                interleave_idx = 0
        else:
            interleave_order = []
            interleave_idx   = 0

        log("[ChannelManager] movie state: "
            "{} played, {} unplayed of {} total{}".format(
                len(played_ids), len(unplayed_ids), len(unique_movie_ids),
                " interleave_idx={}/{}".format(
                    interleave_idx, len(interleave_order))
                if for_interleave else ""))

        queue = []

        if randomize and for_interleave:
            # Walk interleave_order from interleave_idx, picking movies
            # in sequence. Save the final idx so next build continues
            # from exactly where this one left off.
            idx = interleave_idx
            for _ in range(target_size):
                if idx >= len(interleave_order):
                    # Deck is empty — reshuffle ALL movies in the channel.
                    # all_available is the permanent complete list.
                    # unplayed_ids/played_ids are ONLY for tracking the
                    # watch cycle — they don't control what goes in the deck.
                    if not recycle and not all_available:
                        break
                    # Check if the watch cycle is complete
                    if not unplayed_ids:
                        log("[ChannelManager] All movies watched "
                            "- resetting watch cycle")
                        played_ids   = []
                        unplayed_ids = list(all_available)
                    # Reshuffle from the FULL channel movie list
                    interleave_order = list(all_available)
                    random.shuffle(interleave_order)
                    idx = 0
                    if not interleave_order:
                        break
                chosen_id = interleave_order[idx]
                idx += 1
                movie = movie_lookup.get(chosen_id)
                if movie:
                    queue.append(self._normalize_movie(movie, channel_id))
            # Save the final deck position
            interleave_idx = idx

        elif randomize:
            # Direct movie channel build.
            # recycle=True:  use all_available as the pool so the top-up
            #   always has the full movie list to draw from. unplayed_ids
            #   tracks cycle completion but must not restrict the build pool —
            #   doing so causes a single remaining unplayed movie to fill all
            #   top-up slots with the same film.
            # recycle=False: use unplayed_ids so already-watched movies are
            #   not re-queued, and cap at one pass through the pool.
            if recycle:
                # Draw from unplayed_ids so every movie plays once per cycle
                # before any repeats. When unplayed_ids runs out mid-build,
                # start a new cycle (reset played/unplayed) and continue.
                # This preserves the no-repeat guarantee across top-ups while
                # allowing the queue to span multiple cycles when queue_size
                # exceeds the number of movies in the channel.
                working_unplayed = list(unplayed_ids)
                working_played   = list(played_ids)
                while len(queue) < target_size:
                    if not working_unplayed:
                        # Cycle complete — start fresh
                        log("[ChannelManager] Movie cycle complete, "
                            "resetting for next cycle")
                        working_played   = []
                        working_unplayed = list(all_available)
                        if not working_unplayed:
                            break
                    # Shuffle the remaining unplayed pool each time we
                    # draw from it so order is random within the cycle.
                    # Use a copy to avoid modifying working_unplayed in place.
                    draw_pool = list(working_unplayed)
                    random.shuffle(draw_pool)
                    # Prevent back-to-back repeat at cycle boundary:
                    # if the first movie of this draw matches the last
                    # movie added, rotate by 1 position.
                    if (queue and len(draw_pool) > 1 and
                            draw_pool[0] == queue[-1].get("movieid")):
                        draw_pool = draw_pool[1:] + draw_pool[:1]
                    slots_needed = target_size - len(queue)
                    for mid in draw_pool[:slots_needed]:
                        movie = movie_lookup.get(mid)
                        if movie:
                            queue.append(
                                self._normalize_movie(movie, channel_id))
                        working_unplayed.remove(mid)
                        working_played.append(mid)
                # Persist the updated cycle state so the next build
                # and _advance_movie_state stay in sync.
                unplayed_ids = working_unplayed
                played_ids   = working_played
            else:
                pool = list(unplayed_ids)
                if not pool:
                    pass  # recycle=False and pool empty: nothing to queue
                else:
                    # Only one pass through the unplayed pool
                    pass_pool = list(pool)
                    random.shuffle(pass_pool)
                    for mid in pass_pool:
                        movie = movie_lookup.get(mid)
                        if movie:
                            queue.append(
                                self._normalize_movie(movie, channel_id))
        else:
            # Sequential - use next_index, wrap when needed
            for _ in range(target_size):
                if not all_available:
                    break
                if next_index >= len(all_available):
                    if not recycle:
                        break
                    next_index = 0
                chosen_id = all_available[next_index]
                movie     = movie_lookup.get(chosen_id)
                if movie:
                    queue.append(self._normalize_movie(movie, channel_id))
                next_index += 1

        # Save state
        new_state = {
            "played_ids":   played_ids,
            "unplayed_ids": unplayed_ids,
            "next_index":   next_index,
        }
        if for_interleave:
            new_state["interleave_order"] = interleave_order
            new_state["interleave_index"] = interleave_idx
        elif "interleave_order" in movie_state:
            new_state["interleave_order"] = movie_state["interleave_order"]
            new_state["interleave_index"] = movie_state.get(
                "interleave_index", 0)
        self._state[state_key] = new_state
        self._save_state()

        log("[ChannelManager] Built movie queue of {} items for '{}'".format(
            len(queue), channel["name"]))
        return queue

    def _normalize_movie(self, movie, channel_id):
        """Delegate to channels/base.py — single source of truth."""
        return _normalize_movie_fn(movie, channel_id, library=self.library)
    def _pregenerate_queue_safe(self, channel, start_show_index=None):
        """Pregenerate queue - all channels now have specific shows/movies."""
        self._pregenerate_queue(channel, start_show_index=start_show_index)

    def _pregenerate_queue(self, channel, start_show_index=None):
        """
        Build the queue for a channel and write it to the per-channel
        queue file immediately. Called after create_channel and
        update_channel so the channel view always shows correct episode
        info including randomized order without needing to play first.

        Uses build_queue (not _build_fresh_queue directly) so that serial
        channels are routed through serial.py instead of the round-robin
        TV builder.
        """
        import json as _json
        import xbmcvfs as _xbmcvfs

        channel_id = channel["id"]
        try:
            queue = self.build_queue(
                channel,
                channel.get("queue_size", self._default_queue_size()),
                start_show_index=start_show_index)
            if not queue:
                log("[ChannelManager] _pregenerate_queue: empty queue "
                    "for channel {}".format(channel_id))
                return

            # Write queue items to file.
            # _build_fresh_queue already returns fully-normalised items:
            #   - Movies: via _normalize_movie, which reads metadata from
            #     local_library.json (fast, no network call needed).
            #   - TV episodes: via _normalize_ep (minimal fields).
            # We write them directly so the pregenerated queue file
            # contains full movie metadata. This means _resume_from_existing_queue
            # will accept the file and resume the same random order when
            # Play Channel is pressed, instead of rebuilding from scratch
            # and producing a different order.
            data = list(queue)

            queue_path = self._queue_file_path(channel_id)
            with _xbmcvfs.File(queue_path, "w") as f:
                f.write(_json.dumps(data, indent=2))
            first_titles = [ep.get("title", "?")[:20] for ep in data[:3]]
            log("[ChannelManager] Pre-generated queue of {} items "
                "for channel '{}' - first 3: {}".format(
                len(data), channel["name"], first_titles))
        except Exception as e:
            log("[ChannelManager] _pregenerate_queue error: {}".format(e))

    def _queue_file_path(self, channel_id):
        """Return the path to the per-channel queue file.
        Routes through _resolve_path so shared storage is used when
        configured.
        """
        return self._resolve_path("queue_{}.json".format(channel_id))

    def _resume_from_existing_queue(self, channel_id, channel):
        """
        Load the per-channel queue file and return the remaining
        unplayed portion. Returns None if no valid existing queue found.
        """
        import json as _json
        import xbmcvfs as _xbmcvfs

        queue_path = self._queue_file_path(channel_id)

        if not _xbmcvfs.exists(queue_path):
            return None

        try:
            with _xbmcvfs.File(queue_path, "r") as f:
                raw = f.read()
            if not raw:
                return None
            queue = _json.loads(raw)
        except Exception as e:
            log("[ChannelManager] _resume_from_existing_queue read error: "
                "{}".format(e))
            return None

        if not queue:
            return None

        # Verify queue belongs to this channel.
        # Interleaved items carry the foreign channel's _channel_id.
        # Two cases where an item is legitimately in this queue even though
        # its _channel_id != channel_id:
        # 1. _interleaved=True is set (written by apply_interleave on top-up
        #    new_tail items — NOT written by the initial queue build).
        # 2. _channel_id matches the foreign channel configured in this
        #    channel's interleave config (covers initial-build items that
        #    never received _interleaved=True on disk).
        # Without check 2, every resume after stopping while an interleaved
        # TV episode is first in the queue triggers a fresh build (no
        # interleave), silently stripping all TV episodes from the channel.
        first_item = queue[0]
        item_ch_id = (first_item.get("channel_id")
                      or first_item.get("_channel_id", ""))
        if item_ch_id and item_ch_id != channel_id:
            # Allow if _interleaved flag is set
            is_interleaved_item = first_item.get("_interleaved", False)
            # Allow if _channel_id matches configured interleave source
            interleave_cfg     = channel.get("interleave") or {}
            # Handle both legacy single-dict and new list format
            foreign_ch_id      = interleave_cfg.get("channel_id", "") if isinstance(interleave_cfg, dict) else ""
            if not foreign_ch_id and isinstance(channel.get("interleave"), list):
                _foreign_ids   = _interleave_foreign_ids(channel)
                is_foreign_source = item_ch_id in _foreign_ids
            else:
                is_foreign_source  = (foreign_ch_id
                                      and item_ch_id == foreign_ch_id)
            if not is_interleaved_item and not is_foreign_source:
                log("[ChannelManager] Queue belongs to channel {} not "
                    "{} - building fresh queue".format(
                        item_ch_id, channel_id))
                return None

        # Folder channels: return existing queue directly — no rebuild.
        # Top-up handles refilling. Same pattern as movie channels below.
        # The queue file is always valid because FolderQueueBuilder wrote it
        # and _topup_queue maintains it — no metadata freshness check needed.
        if queue and queue[0].get("is_folder_item"):
            for item in queue:
                if "_channel_id" not in item:
                    item["_channel_id"] = item.get("channel_id", channel_id)
                if "_show_id" not in item:
                    item["_show_id"] = 0
            log("[ChannelManager] Resumed folder queue of {} items "
                "for channel '{}'".format(len(queue), channel.get("name", "")))
            return queue

        # Movie channels: return the queue from position 0
        # But first check if the queue has the new metadata format.
        # Old format queues (no year/genre/plot) need to be rebuilt.
        # IMPORTANT: only test metadata on the first item if it is actually
        # a movie entry. An interleaved TV episode at queue[0] has no
        # year/genre/plot fields by design — checking it would always return
        # False and force a rebuild, stripping the interleave.
        if channel.get("channel_type") == "movies":
            first = queue[0] if queue else {}
            first_is_movie = (first.get("is_movie", False)
                              or first.get("movieid", -1) > 0)
            if first_is_movie:
                has_metadata = (first.get("year") or first.get("genre")
                                or first.get("plot"))
                if not has_metadata:
                    log("[ChannelManager] Movie queue missing metadata - "
                        "rebuilding in new format")
                    return None  # Force fresh build

            # If the channel is exhausted (recycle=False, all movies played),
            # delete the queue file and return [] so build_queue shows
            # "No episodes found" instead of replaying the last movie.
            # Mirrors the TV channel exhaustion handling in the same method.
            #
            # Two exhaustion conditions for recycle=False:
            # 1. _channel_exhausted() — unplayed_ids=[] AND played_ids non-empty
            #    (covers the case where _advance_movie_state already completed)
            # 2. The queue contains only the last unplayed movie AND that movie
            #    has already been started (played_ids has all others). This
            #    covers the timing window where pressing Play again during the
            #    final movie would replay it because _advance_movie_state hasn't
            #    fired yet to empty unplayed_ids.
            _is_exhausted = self._channel_exhausted(channel_id, channel)
            if not _is_exhausted and not channel.get("recycle", True):
                _state_key = "{}:__movie_state__".format(channel_id)
                try:
                    _fresh  = self._load_json(self._state_path, {})
                    _mstate = _fresh.get(_state_key, {})
                    _played = set(_mstate.get("played_ids", []))
                    _unpld  = list(_mstate.get("unplayed_ids", []))
                except Exception:
                    _played = set()
                    _unpld  = []
                _queued_ids = [item.get("movieid") for item in queue
                               if item.get("is_movie")]
                # Last-movie timing check:
                # Queue has exactly 1 movie, it's the sole remaining unplayed,
                # and all other channel movies are already in played_ids.
                # That means this movie is currently playing or just finished —
                # do not re-queue it.
                _all_movie_ids = {m["movieid"]
                                  for m in channel.get("movies", [])}
                if (len(_queued_ids) == 1 and
                        len(_unpld) == 1 and
                        _queued_ids[0] == _unpld[0] and
                        (_all_movie_ids - {_queued_ids[0]}).issubset(_played)):
                    _is_exhausted = True

            if _is_exhausted:
                log("[ChannelManager] Movie channel '{}' exhausted "
                    "(recycle=False) - clearing queue file".format(
                        channel["name"]))
                import xbmcvfs as _xv
                if _xv.exists(queue_path):
                    _xv.delete(queue_path)
                return []

            log("[ChannelManager] Resuming movie queue: {} items".format(
                len(queue)))
            for item in queue:
                if "_channel_id" not in item:
                    item["_channel_id"] = item.get("channel_id", channel_id)
                if "_show_id" not in item:
                    item["_show_id"] = 0
            return queue

        # TV channels: The queue file is maintained by _update_queue_file
        # which trims it so position 0 is always the current/next episode.
        # So we simply start from position 0 in almost all cases.
        #
        # We only need to scan if the queue was NOT trimmed (e.g. fresh
        # channel, regenerated queue, or show with no state entry yet).

        # Build lookup sets from state.json
        all_played   = set()
        all_next_ids = set()
        for show in channel.get("shows", []):
            sid   = show["tvshowid"]
            state = self.get_show_state(channel_id, sid)
            all_played.update(state.get("played_ids", []))
            nid = state.get("next_episode_id")
            if nid is not None:
                all_next_ids.add(nid)

        first_ep_id = queue[0].get("episodeid") if queue else None

        # If queue[0] is a known next episode or not yet played,
        # the queue is correctly trimmed - use it as-is from position 0
        if (first_ep_id in all_next_ids or
                first_ep_id not in all_played):
            start_idx = 0
            log("[ChannelManager] Queue correctly trimmed at position 0 "
                "(ep={})".format(first_ep_id))
        else:
            # Queue not trimmed - scan for first next_episode_id match
            start_idx = None
            for i, item in enumerate(queue):
                if item.get("episodeid") in all_next_ids:
                    start_idx = i
                    break
            # Final fallback: first unplayed episode
            if start_idx is None:
                for i, item in enumerate(queue):
                    if item.get("episodeid") not in all_played:
                        start_idx = i
                        break
            if start_idx is None:
                log("[ChannelManager] Existing queue exhausted - "
                    "building fresh")
                return None
            log("[ChannelManager] Resuming queue from position {} "
                "of {}".format(start_idx, len(queue)))

        remaining = queue[start_idx:]

        # CRITICAL: Restore internal keys (_channel_id, _show_id) that
        # player.py needs. now_playing.json stores them as channel_id/show_id
        # (without underscores) so we must remap them here.
        for item in remaining:
            if "_channel_id" not in item:
                item["_channel_id"] = item.get("channel_id", channel_id)
            if "_show_id" not in item:
                item["_show_id"] = item.get("show_id", 0)

        # CRITICAL: Recalculate and resave the queue tail from the actual
        # queue contents so that _topup_queue always has accurate indices.
        #
        # The tail saved by _build_fresh_queue at channel creation can be
        # stale if no starting_points were set (so _apply_starting_points
        # skipped the tail deletion) and a leftover tail from a previous
        # channel config or test session remains on disk.  Without this,
        # _topup_queue reads wrong show_index/local_index values and restarts
        # episodes from the beginning of the show.
        #
        # Walk the full pre-trim queue (not just remaining) so indices reflect
        # the complete build up to the end of the queue file.
        self._recalculate_tail(channel_id, channel, queue)

        recycle = channel.get("recycle", True)

        # For recycle=False: check if all shows are exhausted before
        # deciding whether to top up or play from the remaining queue.
        # When all shows have next_episode_id=None (exhausted), the
        # remaining queue items are already-played episodes — delete the
        # queue file and return None so "No episodes found" is shown.
        if self._channel_exhausted(channel_id, channel):
            log("[ChannelManager] recycle=False and all shows "
                "exhausted — clearing queue file")
            import xbmcvfs as _xv
            if _xv.exists(queue_path):
                _xv.delete(queue_path)
            # Return [] not None — build_queue treats None as "no queue,
            # build fresh" and [] as "exhausted, show No Episodes Found".
            return []

        # If remaining queue is below replenishment threshold, top it up.
        # Skip for recycle=False — top-up would restart exhausted shows.
        threshold = self.get_replenishment_threshold(channel)
        # Top up if queue is short AND the channel is not fully exhausted.
        # Using recycle as the guard was wrong — a recycle=False channel with
        # episodes remaining must still be topped up on resume. Only skip if
        # _channel_exhausted confirms there is genuinely nothing left to add.
        if (len(remaining) <= threshold and
                not self._channel_exhausted(channel_id, channel)):
            target_size = channel.get("queue_size", self._default_queue_size())
            topup_size  = target_size - len(remaining)
            log("[ChannelManager] Queue short ({} items, threshold={}) "
                "- topping up with {} items".format(
                len(remaining), threshold, topup_size))
            remaining = self._topup_queue(channel, remaining, topup_size)

        return remaining

    # -- Queue tail marker helpers -----------------------------------------------

    def _apply_starting_points(self, channel, force=False):
        """
        Write starting_points from the channel definition into state.json.

        On create (force=False): only set state for shows with no entry yet.
        On edit   (force=True):  always overwrite - user explicitly chose
                                 a new starting episode.

        Also clears the queue tail marker and queue file so the next
        play starts fresh from the chosen episode.

        For random channels: seeds played_ids with all episodes EXCEPT
        the chosen one so that random.choice() always picks the Surprise Me
        episode first. After the first episode plays, advance_show clears
        played_ids and normal random selection resumes.

        For sequential channels: sets next_episode_id as before.
        """
        channel_id      = channel["id"]
        starting_points = channel.get("starting_points", {})
        channel_random  = channel.get("randomize", False)

        if not starting_points:
            return

        # Build per-show randomize map (per-show flag may override channel flag)
        show_random_map = {}
        for show in channel.get("shows", []):
            sid = show["tvshowid"]
            show_random_map[sid] = show.get("randomize", channel_random)

        changed = False
        for sid_str, ep_info in starting_points.items():
            try:
                sid = int(sid_str)
            except (ValueError, TypeError):
                sid = sid_str

            state_key  = "{}:{}".format(channel_id, sid)
            is_random  = show_random_map.get(sid, channel_random)

            if force or state_key not in self._state:
                if is_random:
                    # Random channel: seed played_ids with every AVAILABLE
                    # episode (episode_filters applied, excluded_episodes
                    # removed) EXCEPT the chosen one, so it is the only
                    # unplayed episode and random.choice() is forced to
                    # pick it first. Using get_available_episodes() keeps
                    # played_ids limited to the active pool — avoids
                    # accidentally blocking filtered/excluded episodes
                    # that could never be chosen anyway.
                    show_obj = next(
                        (s for s in channel.get("shows", [])
                         if s["tvshowid"] == sid), {"tvshowid": sid})
                    all_eps    = self.get_available_episodes(show_obj)
                    chosen_id  = ep_info["episodeid"]
                    played_ids = [e["episodeid"] for e in all_eps
                                  if e["episodeid"] != chosen_id]
                    self._state[state_key] = {
                        "next_episode_id": chosen_id,
                        "season":          ep_info["season"],
                        "episode":         ep_info["episode"],
                        "played_ids":      played_ids,
                    }
                else:
                    # Sequential channel: next_episode_id is used directly.
                    self._state[state_key] = {
                        "next_episode_id": ep_info["episodeid"],
                        "season":          ep_info["season"],
                        "episode":         ep_info["episode"],
                        "played_ids":      [],
                    }
                changed = True
                log("[ChannelManager] Starting point {} for show {}: "
                    "S{}E{} '{}' (random={}, pool_size={})".format(
                    "updated" if force else "set",
                    sid,
                    ep_info["season"],
                    ep_info["episode"],
                    ep_info.get("title", ""),
                    is_random,
                    1 if is_random else "all"))

        if changed:
            # Clear queue tail so replenishment starts from new position.
            # IMPORTANT: discard from _deleted_state_keys immediately after
            # saving so this one-time deletion does not haunt future
            # _save_state calls in the long-running service instance.
            # Without the discard, service.py's _save_state would keep
            # stripping the tail key from disk on every subsequent write,
            # destroying the tail that _build_fresh_queue correctly saves —
            # causing every top-up to restart from episode 1.
            tail_key = self._tail_key(channel_id)
            self._state.pop(tail_key, None)
            self._deleted_state_keys.add(tail_key)
            self._save_state()
            self._deleted_state_keys.discard(tail_key)  # one-time deletion done

            # Delete queue file so it gets rebuilt from new starting points
            import xbmcvfs as _xbmcvfs
            queue_path = self._queue_file_path(channel_id)
            if _xbmcvfs.exists(queue_path):
                _xbmcvfs.delete(queue_path)
                log("[ChannelManager] Deleted queue file after "
                    "starting point change")

    def _normalize_ep(self, ep, channel_id, show_id):
        """Delegate to channels/base.py — single source of truth."""
        return _normalize_ep_fn(ep, channel_id, show_id)

    def _tail_key(self, channel_id):
        return "{}:__queue_tail__".format(channel_id)

    def _get_tail(self, channel_id):
        """Return the queue tail marker for a channel."""
        return self._state.get(self._tail_key(channel_id), {
            "show_index": 0,
            "indices":    {},
            "played_ids": {},
        })

    def _recalculate_tail(self, channel_id, channel, queue):
        """
        Walk a queue and derive accurate show_index and local_index values,
        then persist them as the queue tail marker.

        Called by _resume_from_existing_queue to correct stale tail data left
        on disk from a previous build or a different channel configuration.
        Only applies to TV channels (serial channels manage their own pointer;
        movie channels do not use a tail marker).

        local_index must store the position WITHIN THE CURRENT CYCLE for each
        show.  For shows with fewer episodes than the total placed in the queue
        (i.e. shows that recycled), this is eps_placed % len(episodes).
        Storing the raw cumulative count causes _topup_queue to see an index
        beyond len(episodes) on the very first access, triggering an immediate
        reset + break that silently skips the show for one full rotation,
        producing a double-length Burn Notice block at the join boundary.
        """
        if channel.get("channel_type") in ("movies", "serial"):
            return

        shows    = channel.get("shows", [])
        if not shows or not queue:
            return

        # Guard: compute what show_index we would derive from the disk queue
        # and compare with the existing tail. If the existing tail is MORE
        # ADVANCED than what the disk queue shows, it came from a previous
        # top-up session that extended beyond the disk queue. Keep it.
        # Only overwrite if the existing tail is missing or BEHIND the queue.
        existing_tail = self._get_tail(channel.get("id", ""))
        existing_show_index = existing_tail.get("show_index", 0)
        # Quick estimate: count completed slots in the disk queue
        _slot_counts = {s["tvshowid"]: 0 for s in shows}
        _simulated   = 0
        for _item in queue:
            _sid = _item.get("show_id") or _item.get("_show_id")
            if _sid not in _slot_counts:
                continue
            _show_obj = next((s for s in shows if s["tvshowid"] == _sid), {})
            _eps      = max(1, int(_show_obj.get("episodes_per_slot", 1)))
            _slot_counts[_sid] += 1
            if _slot_counts[_sid] % _eps == 0:
                _simulated += 1
        if existing_show_index >= _simulated:
            log("[ChannelManager] _recalculate_tail: existing tail "
                "(show_index={}) is current or ahead of disk queue ({}), "
                "keeping it".format(existing_show_index, _simulated))
            return

        show_ids   = [s["tvshowid"] for s in shows]
        local_index  = {sid: 0 for sid in show_ids}
        local_played = {}

        channel_randomize = channel.get("randomize", False)

        # Pre-load episodes for every show once.
        all_episodes = {}
        ep_counts    = {}
        for show in shows:
            sid = show["tvshowid"]
            eps = self.get_available_episodes(show)
            all_episodes[sid] = eps if eps else []
            ep_counts[sid]    = len(eps) if eps else 0

        # Reconstruct local_index by finding the LAST episode of each show
        # in the queue and setting local_index = that episode's position + 1.
        #
        # The previous approach counted the number of episodes per show in the
        # queue and used that count as local_index. This was correct only when
        # a show started from E01 (index 0). When Surprise Me or a manual
        # starting point placed a show mid-series (e.g. S05E06 = index 108),
        # counting 6 queued episodes produced local_index=6 instead of 114,
        # causing the next top-up to restart from near E01 of S01.
        #
        # Reading the actual position of the last queued episode is correct
        # regardless of where the show started: it gives us the absolute
        # index into the episode list, so the top-up continues seamlessly.
        #
        # For recycle=True: if the last queued episode is the final episode
        # of the show (position = n_eps-1), local_index = n_eps which triggers
        # the recycle pre-check in _topup_queue (resets to 0 and retries).
        # For recycle=False: same capping logic as before.
        recycle = channel.get("recycle", True)

        # Find last episode of each show in the queue (walk forward, keep last)
        last_ep_in_queue = {}   # sid → episodeid of last occurrence in queue
        for item in queue:
            sid = item.get("show_id") or item.get("_show_id")
            if sid in show_ids:
                eid = item.get("episodeid")
                if eid is not None:
                    last_ep_in_queue[sid] = eid

        for show in shows:
            sid            = show["tvshowid"]
            episodes       = all_episodes.get(sid, [])
            n_eps          = ep_counts.get(sid, 0)
            show_randomize = show.get("randomize", channel_randomize)

            if show_randomize:
                # Random shows: local_index is unused for ordering.
                # local_played is reconstructed below. Set index to 0.
                local_index[sid] = 0
                continue

            last_eid = last_ep_in_queue.get(sid)
            if last_eid is None:
                # Show has no episodes in queue yet — keep at 0 so
                # _topup_queue's state-seeding fallback takes over.
                local_index[sid] = 0
                continue

            ep_ids = [e["episodeid"] for e in episodes]
            try:
                last_pos = ep_ids.index(last_eid)
            except ValueError:
                local_index[sid] = 0
                continue

            next_pos = last_pos + 1
            if n_eps > 0:
                if recycle:
                    # next_pos == n_eps means show just placed its last
                    # episode; _topup_queue's pre-check will reset to 0.
                    local_index[sid] = next_pos % n_eps if next_pos < n_eps else n_eps
                else:
                    local_index[sid] = min(next_pos, n_eps)
            else:
                local_index[sid] = 0

        # Reconstruct played_ids for random shows from the queue contents.
        #
        # For sequential shows, local_index is sufficient and local_played
        # stays empty. For random shows, local_played in the tail is the
        # sole no-repeat tracking mechanism. When _recalculate_tail left it
        # empty, the next top-up saw a fresh pool and could repeat episodes
        # already present in the queue.
        #
        # Collect the episode IDs placed for each random show from the queue.
        # For a random show, local_index[sid]=0 (set above), so we can't use
        # it as a count here. Instead count the actual episodes in the queue
        # for this show to determine how many are in the current cycle.
        for show in shows:
            sid            = show["tvshowid"]
            show_randomize = show.get("randomize", channel_randomize)
            if not show_randomize:
                continue
            n_eps = ep_counts.get(sid, 0)
            # Collect all episode IDs for this show from the queue in order.
            show_ep_ids = [
                item.get("episodeid")
                for item in queue
                if (item.get("show_id") or item.get("_show_id")) == sid
                and item.get("episodeid") is not None
            ]
            if not show_ep_ids or n_eps == 0:
                local_played[sid] = []
                continue
            # Current cycle count: episodes placed modulo total episodes.
            # If exactly divisible, the show completed a full cycle and the
            # next cycle starts fresh.
            queued_count      = len(show_ep_ids)
            current_cycle_count = queued_count % n_eps
            if current_cycle_count == 0:
                local_played[sid] = []
            else:
                local_played[sid] = show_ep_ids[-current_cycle_count:]

        # show_index must point to the show AFTER the last slot placed.
        # Reconstruct by simulating the rotation order and counting slots.
        simulated_index = 0
        slot_counts     = {sid: 0 for sid in show_ids}
        for item in queue:
            sid = item.get("show_id") or item.get("_show_id")
            if sid not in slot_counts:
                continue
            show_obj     = next((s for s in shows if s["tvshowid"] == sid), {})
            eps_per_slot = max(1, int(show_obj.get("episodes_per_slot", 1)))
            slot_counts[sid] += 1
            if slot_counts[sid] % eps_per_slot == 0:
                # Completed a slot — advance simulated show_index
                simulated_index += 1

        show_index = simulated_index

        self._save_tail(channel_id, show_index, local_index, local_played)
        log("[ChannelManager] _recalculate_tail: show_index={} indices={}".format(
            show_index, local_index))

    def _save_tail(self, channel_id, show_index, local_index, local_played):
        """Persist the queue tail marker after a queue build or top-up."""
        tail = {
            "show_index": show_index,
            "indices":    {str(k): v for k, v in local_index.items()},
            "played_ids": {str(k): list(v) for k, v in local_played.items()},
        }
        self._state[self._tail_key(channel_id)] = tail
        self._save_state()
        log("[ChannelManager] Saved queue tail: show_index={} indices={}".format(
            show_index, dict(local_index)))

    # -- Queue building ----------------------------------------------------------

    def _build_fresh_queue(self, channel, target_size, start_after=None,
                           start_show_index=None):
        """
        Build a completely new queue for the channel.
        Routes to movie or TV episode queue builder based on channel_type.

        NOTE: serial channels must never reach this method — they are always
        routed through build_queue -> SerialQueueBuilder.build().  This guard
        is defensive; the real dispatch lives in build_queue.

        start_after: optional dict {tvshowid: episodeid}.  When provided
        (only from _load_foreign_items during a top-up), each show's
        local_index / local_played is seeded to start AFTER the named
        episode instead of from next_episode_id in state.  This eliminates
        join-boundary overlap when the foreign channel's state pointer lags
        the episodes already sitting in current_queue.

        All callers other than _load_foreign_items pass start_after=None
        (the default) and are completely unaffected.
        """
        if channel.get("channel_type") == "serial":
            log("[ChannelManager] _build_fresh_queue: serial channel '{}' "
                "routed to SerialQueueBuilder".format(channel.get("name", "")))
            from resources.lib.serial import SerialQueueBuilder
            return SerialQueueBuilder(self).build(channel, target_size)

        if channel.get("channel_type") == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            return FolderQueueBuilder(self).build(channel, target_size)

        if channel.get("channel_type") == "movies":
            return self._build_movie_queue(channel, target_size,
                                               for_interleave=False)

        channel_id = channel["id"]
        shows      = channel.get("shows", [])
        randomize  = channel.get("randomize", False)
        recycle    = channel.get("recycle", True)

        # Pre-load all episodes for each show via get_available_episodes(),
        # which applies episode_filters (live DB query when set) and then
        # removes excluded_episodes — single source, see that method for
        # details. Shows with neither filters nor exclusions get the
        # normal cached path unchanged.
        all_episodes = {}
        for show in shows:
            sid = show["tvshowid"]
            eps = self.get_available_episodes(show)
            if show.get("episode_filters") or show.get("excluded_episodes"):
                log("[ChannelManager] _build_fresh_queue: show {} "
                    "filtered/excluded to {} episodes".format(sid, len(eps)))
            if eps:
                all_episodes[sid] = eps

        if not all_episodes:
            log("[ChannelManager] build_queue: no episodes found for any show")
            return []

        # Seed local indices from next_episode_id (current play position).
        # For random channels, seed local_played from the queue tail marker
        # which is where no-repeat tracking actually lives. The show state
        # played_ids is always [] (_advance_random clears it each time) so
        # seeding from there would always give an empty pool, causing repeats.
        tail         = self._get_tail(channel_id)
        tail_played  = {int(k): list(v)
                        for k, v in tail.get("played_ids", {}).items()}

        local_index  = {}
        local_played = {}
        for show in shows:
            sid      = show["tvshowid"]
            episodes = all_episodes.get(sid, [])
            if not episodes:
                continue
            state   = self.get_show_state(channel_id, sid)
            next_id = state.get("next_episode_id")
            ep_ids  = [e["episodeid"] for e in episodes]

            # start_after override: when a top-up passes the last episodeid
            # already sitting in current_queue for this show, seed from the
            # position AFTER that episode rather than from next_episode_id.
            # This prevents the fresh build from re-queuing episodes that are
            # already in current_queue but not yet completed (and therefore
            # not yet written back to state).
            #
            # start_after is only set by _load_foreign_items during top-up.
            # All other callers pass None (the default) and reach the normal
            # next_episode_id seeding below, unchanged.
            after_id = (start_after or {}).get(sid)
            if after_id is not None:
                try:
                    after_pos = ep_ids.index(after_id)
                    # Start at the episode AFTER the one in current_queue.
                    # If after_id is the last episode, after_pos+1 equals
                    # len(episodes), which the existing recycle/exhaust
                    # pre-check will handle correctly on the first slot.
                    local_index[sid] = after_pos + 1
                    log("[ChannelManager] _build_fresh_queue: start_after "
                        "override sid={} ep={} → local_index={}".format(
                        sid, after_id, local_index[sid]))
                except ValueError:
                    # after_id not found in this show's episode list —
                    # fall back to normal seeding so we never block.
                    log("[ChannelManager] _build_fresh_queue: start_after "
                        "ep={} not found for sid={}, using next_episode_id"
                        .format(after_id, sid))
                    after_id = None  # fall through to normal seeding

            if after_id is None:
                # Normal seeding path. Resolver handles the common case
                # (next_id directly present -> index unchanged) as well as
                # a stale pointer left over from an episode that has since
                # been excluded (skips forward past it instead of
                # restarting the show — see _resolve_pointer_index).
                resolved = self._resolve_pointer_index(show, next_id, episodes)
                local_index[sid] = resolved if resolved >= 0 else 0

            # Use tail played_ids for no-repeat tracking (random channels).
            # Fall back to show state played_ids for channels with no tail yet.
            # start_after for random channels: add the after_id to local_played
            # so it is treated as already played in this fresh build, preventing
            # it from being re-selected before the pool advances past it.
            base_played = tail_played.get(sid,
                              list(state.get("played_ids", [])))
            if after_id is not None and after_id not in base_played:
                base_played = list(base_played)
                # Also include ALL episodeids from current_queue for this show,
                # not just the last one, so a multi-episode slot in current_queue
                # does not produce any overlap on a random channel.
                # (start_after carries only the LAST ep, but random channels
                # need the full seen set to avoid re-selecting earlier eps.)
                queued_for_show = (start_after or {}).get(
                    "_played_{}".format(sid), [])
                for seen_id in queued_for_show:
                    if seen_id not in base_played:
                        base_played.append(seen_id)
                if after_id not in base_played:
                    base_played.append(after_id)
            local_played[sid] = base_played

        queue          = []
        queued_files   = set()
        current_cycle  = 0
        # Seed show_index from start_show_index when provided by
        # update_channel. This integer is the __show_index__ that
        # service.py wrote when the last episode started — i.e. which
        # show in the rotation was playing when the edit was made.
        # Using it here means the rebuilt queue starts from that show
        # rather than always defaulting to show[0].
        # Validated against the actual shows list length; falls back to
        # 0 if out of range (e.g. a show was removed during this edit).
        if (start_show_index is not None
                and 0 < start_show_index < len(shows)):
            show_index = start_show_index
            log("[ChannelManager] _build_fresh_queue: seeding "
                "show_index={} from active show".format(show_index))
        else:
            show_index = 0
        exhausted      = set()
        iterations     = 0
        # last_slot_files: tracks file paths placed in each show's most
        # recent slot. Used to skip episodes whose file was already queued
        # in the immediately preceding slot for the SAME show — this catches
        # multi-episode files (e.g. S06E01-02.mkv) where two separate Kodi
        # library entries share one physical file. queued_files alone cannot
        # catch this because it resets at each rotation cycle boundary,
        # which fires between consecutive slots of the same show.
        last_slot_files = {}  # sid -> set of file paths from last slot

        while len(queue) < target_size:
            if len(exhausted) >= len(shows):
                break

            show = shows[show_index % len(shows)]
            sid  = show["tvshowid"]

            # Detect start of a new rotation cycle and clear queued_files
            # so recycle=True shows can repeat their episodes.
            new_cycle = show_index // len(shows)
            if new_cycle > current_cycle:
                current_cycle = new_cycle
                queued_files  = set()

            episodes = all_episodes.get(sid)
            if not episodes:
                show_index += 1
                exhausted.add(sid)
                continue

            ep_ids = [e["episodeid"] for e in episodes]

            # Episodes Per Slot: how many consecutive episodes this show
            # gets before the rotation moves to the next show.
            # Defaults to 1 (existing behaviour) when not set.
            eps_per_slot = max(1, int(show.get("episodes_per_slot", 1)))

            # Per-show randomize: a show-level "randomize" key overrides the
            # channel-level flag so individual shows in a Round Robin channel
            # can be played in random order while others remain sequential.
            show_randomize = show.get("randomize", randomize)

            # Recycle-reset pre-check — MUST run before show_index += 1.
            #
            # Bug: when a show places its last episode, local_index reaches
            # len(episodes). On the NEXT outer loop iteration for that show,
            # the inner loop immediately fires the recycle reset (index=0,
            # break) WITHOUT placing any episode. But show_index was already
            # incremented, so the rotation is off by one: the following show
            # gets two consecutive turns instead of one.
            #
            # Fix: detect the exhausted-pool condition here, before
            # incrementing show_index. For recycle=True, reset the pool and
            # continue (retry this same show_index slot with index/pool
            # reset). For recycle=False, mark exhausted and skip normally.
            # Either way, show_index is only incremented when this show will
            # actually place at least one episode this iteration.
            if show_randomize:
                unplayed_check = [eid for eid in ep_ids
                                  if eid not in local_played.get(sid, [])]
                if not unplayed_check:
                    if not recycle:
                        show_index += 1
                        exhausted.add(sid)
                        continue
                    # recycle=True: reset played pool and retry this slot
                    local_played[sid] = []
                    continue   # retry same show_index; pool now has all eps
            else:
                idx_check = local_index.get(sid, 0)
                if idx_check >= len(episodes):
                    if not recycle:
                        show_index += 1
                        exhausted.add(sid)
                        continue
                    # recycle=True: reset sequential pointer and retry this slot
                    local_index[sid] = 0
                    continue   # retry same show_index; index now 0 → ep1

            show_index += 1

            # Inner slot loop — use while so the slot counter only advances
            # when an episode is actually placed.  This ensures:
            # Fix 1: duplicate multi-episode files (S06E01-02) count as 1 slot
            #        not 2 — the duplicate skip retries the slot.
            # Fix 2: EPS acts as a maximum-per-slot for recycle=True shows.
            #        When a show runs out of new episodes mid-slot (e.g. only
            #        2 episodes exist but EPS=5), break out without adding to
            #        exhausted — the show returns on the next rotation and
            #        picks up any newly downloaded episodes.

            # Record slot start position for rollback if target_size cuts
            # the slot short mid-way.
            if show_randomize:
                _slot_start_played = list(local_played.get(sid, []))
            else:
                _slot_start_index = local_index.get(sid, 0)

            _slot       = 0
            _slot_files = set()   # files placed in THIS slot (for last_slot_files)
            while _slot < eps_per_slot:
                if len(queue) >= target_size:
                    # Roll back to slot start so the tail does not save a
                    # mid-slot position that would cause the next top-up to
                    # start this show's slot partway through.
                    if show_randomize:
                        local_played[sid] = _slot_start_played
                    else:
                        local_index[sid] = _slot_start_index
                    break

                iterations += 1

                if show_randomize:
                    unplayed = [eid for eid in ep_ids
                                if eid not in local_played.get(sid, [])]
                    if not unplayed:
                        if not recycle:
                            exhausted.add(sid)
                            break
                        # recycle=True: pool was reset by pre-check above so
                        # this branch should not be reached in normal operation.
                        # Guard retained as a safety net.
                        local_played[sid] = []
                        break
                    chosen_id = random.choice(unplayed)
                    local_played[sid].append(chosen_id)
                    ep = next(e for e in episodes
                              if e["episodeid"] == chosen_id)
                else:
                    idx = local_index.get(sid, 0)
                    if idx >= len(episodes):
                        if not recycle:
                            exhausted.add(sid)
                            break
                        # recycle=True and episode list exhausted mid-slot
                        # (e.g. eps_per_slot=2, last episode E10 just placed,
                        # index now points past the end). Reset to E01 and
                        # CONTINUE — do not break — so the remaining slot
                        # position(s) are filled from the start of the next
                        # cycle. Breaking here would leave the slot with fewer
                        # episodes than eps_per_slot and produce a misaligned
                        # rotation on every cycle boundary.
                        # Note: the target-size rollback check at the TOP of
                        # this loop fires BEFORE this guard, so if the queue
                        # is already full, the rollback takes priority and this
                        # branch is not reached.
                        local_index[sid] = 0
                        continue
                    ep = episodes[idx]
                    local_index[sid] = idx + 1
                #   in this show's PREVIOUS slot from being placed again in
                #   the current slot. This catches multi-episode files
                #   (e.g. S06E01-02.mkv) where two Kodi library entries
                #   share one physical file. queued_files alone misses this
                #   because the cycle resets between consecutive show slots.
                #   Do NOT advance _slot — retry immediately with the next
                #   episode so the show places a real episode this slot and
                #   rotation stays proportional (no empty slots).
                #
                #   SHORT-SHOW RECYCLE GUARD: if ALL remaining episodes for
                #   this show are in last_slot_files (show has fewer episodes
                #   than EPS, e.g. 4-ep show with EPS=5 recycling), clear
                #   last_slot_files for this show and proceed normally.
                #   Without this, short shows are permanently blocked from
                #   appearing more than once in the queue — last_slot_files
                #   was treating a legitimate recycle as a duplicate.
                ep_file = ep.get("file", "")
                if ep_file and ep_file in queued_files:
                    log("[ChannelManager] _build_fresh_queue: skipping "
                        "duplicate file ep={} file={}".format(
                            ep.get("episodeid"), ep_file))
                    continue   # retry same slot (within-cycle duplicate)
                if ep_file and ep_file in last_slot_files.get(sid, set()):
                    # Before skipping, check if ALL remaining episodes for
                    # this show are blocked by last_slot_files. If so this
                    # is a recycle not a duplicate — clear and proceed.
                    remaining_files = set(
                        e.get("file", "") for e in episodes
                        if e.get("file", "") not in queued_files
                    )
                    if remaining_files and remaining_files.issubset(
                            last_slot_files.get(sid, set())):
                        # All episodes blocked = recycle. Clear and proceed.
                        log("[ChannelManager] _build_fresh_queue: "
                            "short-show recycle for sid={}, clearing "
                            "last_slot_files".format(sid))
                        last_slot_files.pop(sid, None)
                        # ep is already selected, fall through to place it
                    else:
                        log("[ChannelManager] _build_fresh_queue: skipping "
                            "cross-slot multi-ep file ep={} file={}".format(
                                ep.get("episodeid"), ep_file))
                        continue   # retry same slot — place next episode instead
                if ep_file:
                    queued_files.add(ep_file)
                    _slot_files.add(ep_file)

                ep = self._normalize_ep(ep, channel_id, sid)
                queue.append(ep)
                _slot += 1   # only advance slot when episode placed

                if iterations > target_size * len(shows) * 2:
                    break

            # Update last_slot_files for this show with the files placed
            # in this slot so the next slot for the same show can detect
            # multi-episode file duplicates.
            if _slot_files:
                last_slot_files[sid] = _slot_files

        # Save tail marker so top-ups continue from here
        self._save_tail(channel_id, show_index, local_index, local_played)

        interleave_cfg = channel.get("interleave")
        if interleave_cfg:
            queue = self._apply_interleave(queue, interleave_cfg,
                                           channel_name=channel.get("name", ""))

        log("[ChannelManager] Built fresh queue of {} items for channel '{}'"
            .format(len(queue), channel["name"]))
        return queue

    def _topup_queue(self, channel, current_queue, topup_size):
        """
        Append topup_size new items to current_queue continuing from
        the queue tail marker. Routes to movie or TV builder.
        """
        # Folder channels: rebuild from the folder path directly.
        # No tail/state tracking — FolderQueueBuilder always builds fresh
        # from the directory listing and handles ordering/recycling itself.
        if channel.get("channel_type") == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            # Pass already-queued files so the builder can exclude them.
            # This prevents duplicates when threshold > folder size: without
            # this, a 3-file recycle=False folder with threshold=5 would add
            # all 3 files again on the very first top-up (before any file
            # completes), producing a 6-item queue with every file twice.
            queued_files = [item.get("file", "")
                            for item in current_queue if item.get("file")]
            new_items = FolderQueueBuilder(self).build(
                channel, topup_size, queued_files=queued_files)
            if not new_items:
                log("[ChannelManager] _topup_queue: folder build returned empty")
                return current_queue
            # Avoid immediate duplicate at the join boundary
            if current_queue and new_items:
                last_file = current_queue[-1].get("file", "")
                if new_items[0].get("file", "") == last_file:
                    new_items = new_items[1:] + new_items[:1]
            log("[ChannelManager] Folder top-up: {} items".format(
                len(new_items)))
            return current_queue + new_items

        if channel.get("channel_type") == "movies":
            new_movies = self._build_movie_queue(channel, topup_size,
                                                    for_interleave=False)
            # Duplicate guard for recycle=False only.
            # Problem: _build_movie_queue tracks played_ids (fully watched
            # movies) but cannot see movies sitting unplayed in current_queue.
            # For recycle=False channels with fewer movies than the threshold,
            # the top-up fires immediately and re-queues movies that are
            # already pending — causing duplicates.
            #
            # For recycle=True this guard must NOT run. The initial queue is
            # already filled to target_size so current_queue is genuinely
            # short when a top-up fires, and the same movies legitimately
            # appear multiple times across cycles. Filtering them produces
            # 0 new items every time (confirmed in kodi.log).
            if not channel.get("recycle", True):
                channel_id  = channel["id"]
                state_key   = "{}:__movie_state__".format(channel_id)
                try:
                    _st     = self._load_json(self._state_path, {})
                    _played = set(_st.get(state_key, {}).get("played_ids", []))
                except Exception:
                    _played = set()
                # Pending = in current_queue and NOT yet played
                pending_ids = {item.get("movieid") for item in current_queue
                               if item.get("is_movie")
                               and item.get("movieid") not in _played}
                new_movies = [m for m in new_movies
                              if m.get("movieid") not in pending_ids]

            # Prevent the first movie of the top-up block matching the last
            # movie of current_queue. _build_movie_queue's internal boundary
            # check only covers pass-to-pass joins within the build — it has
            # no visibility of current_queue's tail. This join-point check
            # covers the seam between the existing queue and the new block.
            if (current_queue and new_movies and len(new_movies) > 1 and
                    new_movies[0].get("movieid") ==
                    current_queue[-1].get("movieid")):
                new_movies = new_movies[1:] + new_movies[:1]

            log("[ChannelManager] Movie top-up: {} items".format(
                len(new_movies)))
            return current_queue + new_movies

        channel_id = channel["id"]
        shows      = channel.get("shows", [])
        randomize  = channel.get("randomize", False)
        recycle    = channel.get("recycle", True)

        if not shows:
            log("[ChannelManager] _topup_queue: no shows in channel")
            return current_queue

        # Load tail marker
        tail         = self._get_tail(channel_id)
        show_index   = tail.get("show_index", 0)
        local_index  = {int(k): v
                        for k, v in tail.get("indices", {}).items()}
        local_played = {int(k): list(v)
                        for k, v in tail.get("played_ids", {}).items()}

        # Pre-load episodes via get_available_episodes() — applies
        # episode_filters (live DB query when set) then removes
        # excluded_episodes. Single source, see that method.
        all_episodes = {}
        for show in shows:
            sid = show["tvshowid"]
            eps = self.get_available_episodes(show)
            if show.get("episode_filters") or show.get("excluded_episodes"):
                log("[ChannelManager] _topup_queue: show {} "
                    "filtered/excluded to {} episodes".format(sid, len(eps)))
            if eps:
                all_episodes[sid] = eps

        if not all_episodes:
            log("[ChannelManager] _topup_queue: no episodes found")
            return current_queue

        # For shows not yet in the tail (haven't had their first top-up slot),
        # local_index.get(sid, 0) would always return 0, placing E01 regardless
        # of any Surprise Me or manual starting point written into state.
        #
        # Fix: seed local_index from next_episode_id state for any show absent
        # from the tail — exactly as _build_fresh_queue does on first build.
        # Shows already in the tail keep their tail-derived index unchanged.
        # Once a show gets its first episode placed and the tail is saved,
        # it will be in the tail on every subsequent call and this path is skipped.
        tail_sids = set(local_index.keys())
        for show in shows:
            sid = show["tvshowid"]
            if sid not in tail_sids:
                episodes = all_episodes.get(sid)
                if episodes:
                    state    = self.get_show_state(channel_id, sid)
                    next_id  = state.get("next_episode_id")
                    resolved = self._resolve_pointer_index(
                        show, next_id, episodes)
                    local_index[sid] = resolved if resolved >= 0 else 0

        new_items    = []
        # queued_files tracks file paths within the current rotation cycle
        # to block genuine multi-episode file duplicates (S06E01-02 type).
        # It is reset at the start of each new cycle so recycle=True shows
        # can repeat their episodes freely.
        # NOTE: we do NOT seed from current_queue. _recalculate_tail already
        # normalises local_index to the correct within-cycle position, so the
        # top-up naturally continues without duplicating pending tail items.
        # Seeding from current_queue caused short shows to be partially or
        # fully blocked during the first cycle, producing an uneven rotation
        # at the join boundary (e.g. CF gets 1 ep instead of 3 while BN gets 6).
        queued_files  = set()
        current_cycle = show_index // len(shows)
        exhausted     = set()
        iterations    = 0
        # last_slot_files: per-show file set from the most recent completed
        # slot — used to detect cross-slot multi-episode file duplicates.
        # Seed from current_queue so we catch the case where the last episode
        # of the tail queue for this show shared a file with the next episode
        # (e.g. S06E01 is the last item in current_queue, S06E02 is next).
        last_slot_files = {}
        for _show in shows:
            _sid = _show["tvshowid"]
            _show_files = set()
            for _item in reversed(current_queue):
                _item_sid = _item.get("show_id") or _item.get("_show_id")
                if int(_item_sid) == int(_sid):
                    _f = _item.get("file", "")
                    if _f:
                        _show_files.add(_f)
                    break  # only need the last slot's files (last item per show)
            if _show_files:
                last_slot_files[_sid] = _show_files

        # Join-boundary parity fix: if current_queue's last item belongs to
        # the same show that show_index currently points to, the top-up would
        # start with that show again producing a double slot at the join.
        # Advance show_index by 1 to start with the next show instead.
        # This handles the case where a recycle mid-top-up shifts the parity
        # so the tail's show_index no longer aligns with current_queue's end.
        if current_queue and shows:
            last_sid = (current_queue[-1].get("show_id")
                        or current_queue[-1].get("_show_id"))
            if last_sid == shows[show_index % len(shows)]["tvshowid"]:
                log("[ChannelManager] _topup_queue: advancing show_index "
                    "to avoid join-boundary double (show {} would repeat)".format(
                    last_sid))
                show_index += 1

        while len(new_items) < topup_size:
            if len(exhausted) >= len(shows):
                break

            show = shows[show_index % len(shows)]
            sid  = show["tvshowid"]

            # Reset queued_files at the start of each new rotation cycle so
            # recycle=True shows can repeat their episodes.
            new_cycle = show_index // len(shows)
            if new_cycle > current_cycle:
                current_cycle = new_cycle
                queued_files  = set()

            episodes = all_episodes.get(sid)
            if not episodes:
                show_index += 1
                exhausted.add(sid)
                continue

            ep_ids = [e["episodeid"] for e in episodes]

            # Episodes Per Slot: how many consecutive episodes this show
            # gets before the rotation moves to the next show.
            # Defaults to 1 (existing behaviour) when not set.
            eps_per_slot = max(1, int(show.get("episodes_per_slot", 1)))

            # Per-show randomize: overrides channel-level flag per show.
            show_randomize = show.get("randomize", randomize)

            # Recycle-reset pre-check — MUST run before show_index += 1.
            #
            # Bug: when a show places its last episode, local_index reaches
            # len(episodes). On the NEXT outer loop iteration for that show,
            # the inner loop immediately fires the recycle reset (index=0,
            # break) WITHOUT placing any episode. But show_index was already
            # incremented, so the rotation is off by one: the following show
            # gets two consecutive turns instead of one.
            #
            # Fix: detect the exhausted-pool condition here, before
            # incrementing show_index. For recycle=True, reset the pool and
            # continue (retry this same show_index slot with index/pool
            # reset). For recycle=False, mark exhausted and skip normally.
            # Either way, show_index is only incremented when this show will
            # actually place at least one episode this iteration.
            if show_randomize:
                unplayed_check = [eid for eid in ep_ids
                                  if eid not in local_played.get(sid, [])]
                if not unplayed_check:
                    if not recycle:
                        show_index += 1
                        exhausted.add(sid)
                        continue
                    # recycle=True: reset played pool and retry this slot
                    local_played[sid] = []
                    continue   # retry same show_index; pool now has all eps
            else:
                idx_check = local_index.get(sid, 0)
                if idx_check >= len(episodes):
                    if not recycle:
                        show_index += 1
                        exhausted.add(sid)
                        continue
                    # recycle=True: reset sequential pointer and retry this slot
                    local_index[sid] = 0
                    continue   # retry same show_index; index now 0 → ep1

            show_index += 1

            # Inner slot loop — same while-loop pattern as _build_fresh_queue.
            # Slot counter only advances when an episode is actually placed.
            # The topup_size check is intentionally NOT in the inner loop —
            # we always complete the current show's full slot before stopping.
            # This ensures the tail is always saved at a clean slot boundary,
            # so the next top-up starts every show's slot from the beginning
            # and produces a correctly proportioned rotation every time.
            _slot       = 0
            _slot_files = set()   # files placed in THIS slot (for last_slot_files)
            while _slot < eps_per_slot:

                iterations += 1

                if show_randomize:
                    unplayed = [eid for eid in ep_ids
                                if eid not in local_played.get(sid, [])]
                    if not unplayed:
                        if not recycle:
                            exhausted.add(sid)
                            break
                        # recycle=True and random: show has given all its
                        # episodes for this slot pass. Reset played list for
                        # the next rotation but break out now — EPS is a
                        # maximum, not a forced repeat within one slot.
                        local_played[sid] = []
                        break
                    chosen_id = random.choice(unplayed)
                    local_played.setdefault(sid, []).append(chosen_id)
                    ep = next(e for e in episodes
                              if e["episodeid"] == chosen_id)
                else:
                    idx = local_index.get(sid, 0)
                    if idx >= len(episodes):
                        if not recycle:
                            exhausted.add(sid)
                            break
                        # recycle=True and episode list exhausted mid-slot
                        # (e.g. eps_per_slot=2, last episode E10 just placed,
                        # index now points past the end). Reset to E01 and
                        # CONTINUE — do not break — so the remaining slot
                        # position(s) are filled from the start of the next
                        # cycle. Breaking here leaves the slot with fewer
                        # episodes than eps_per_slot, producing a misaligned
                        # rotation on every cycle boundary where a show's
                        # episode list ends mid-slot.
                        local_index[sid] = 0
                        continue
                    ep = episodes[idx]
                    local_index[sid] = idx + 1

                # Duplicate file check — two separate passes:
                # Pass 1 (queued_files): within-cycle duplicates (resets per cycle).
                # Pass 2 (last_slot_files): cross-slot multi-episode file
                #   duplicates that queued_files misses because it resets at
                #   the cycle boundary between consecutive show slots.
                #   SHORT-SHOW RECYCLE GUARD: if ALL remaining episodes for
                #   this show are blocked by last_slot_files, it is a recycle
                #   not a duplicate — clear last_slot_files and proceed.
                ep_file = ep.get("file", "")
                if ep_file and ep_file in queued_files:
                    log("[ChannelManager] _topup_queue: skipping duplicate "
                        "file ep={} file={}".format(
                            ep.get("episodeid"), ep_file))
                    continue   # retry same slot (within-cycle duplicate)
                if ep_file and ep_file in last_slot_files.get(sid, set()):
                    remaining_files = set(
                        e.get("file", "") for e in episodes
                        if e.get("file", "") not in queued_files
                    )
                    if remaining_files and remaining_files.issubset(
                            last_slot_files.get(sid, set())):
                        log("[ChannelManager] _topup_queue: "
                            "short-show recycle for sid={}, clearing "
                            "last_slot_files".format(sid))
                        last_slot_files.pop(sid, None)
                        # ep already selected, fall through to place it
                    else:
                        log("[ChannelManager] _topup_queue: skipping "
                            "cross-slot multi-ep file ep={} file={}".format(
                                ep.get("episodeid"), ep_file))
                        continue   # retry same slot — place next episode instead
                if ep_file:
                    queued_files.add(ep_file)
                    _slot_files.add(ep_file)

                ep = self._normalize_ep(ep, channel_id, sid)
                new_items.append(ep)
                _slot += 1   # only advance slot when episode placed

                if iterations > topup_size * len(shows) * 2:
                    break

            # Update last_slot_files for this show.
            if _slot_files:
                last_slot_files[sid] = _slot_files

        self._save_tail(channel_id, show_index, local_index, local_played)
        log("[ChannelManager] Top-up added {} items to channel '{}'".format(
            len(new_items), channel["name"]))
        return current_queue + new_items


    # -- Public method called by service.py _topup_in_background ---------------

    def refill_queue(self, channel, current_queue, threshold):
        """
        Called by service.py _topup_in_background when the live playlist runs low.
        Tops up current_queue to (threshold * 3) items and returns the
        extended list. Also applies interleave if configured.

        This method was previously missing entirely, causing an AttributeError
        crash whenever the player queue dropped below refill_threshold.
        """
        target_size = max(threshold * 3, channel.get("queue_size", self._default_queue_size()))
        topup_size  = target_size - len(current_queue)

        if topup_size <= 0:
            return current_queue

        log("[ChannelManager] refill_queue: topping up {} items for '{}'".format(
            topup_size, channel["name"]))

        # Serial channels: delegate to serial.py which continues from the
        # current show pointer.  Pass current_queue so build() can scan it
        # and skip episodes already queued for the starting show — without
        # this, build() reads next_episode_id from state which only advances
        # after an episode finishes playing.  At top-up time the last show
        # in the queue may still have unplayed episodes ahead, so state lags
        # reality and build() duplicates those episodes at the join boundary.
        #
        # build() returns only the NEW items (target_size worth, no prefix).
        # We prepend current_queue so the caller (_topup_in_background) can
        # correctly slice off the new tail with extended[len(current_queue):].
        if channel.get("channel_type") == "serial":
            from resources.lib.serial import SerialQueueBuilder
            new_items = SerialQueueBuilder(self).build(
                channel, topup_size, current_queue=current_queue)
            return current_queue + new_items

        extended = self._topup_queue(channel, current_queue, topup_size)

        # Re-apply interleave to the new tail portion only.
        # Pass primary_offset = number of non-interleaved items already in
        # current_queue so _apply_interleave knows where we are in the
        # frequency cycle. Without this, it always starts counting from 0
        # and inserts a movie after `frequency` NEW items, ignoring the
        # items already in the queue - giving too many primary items before
        # the first interleaved movie in the top-up.
        interleave_cfg = channel.get("interleave")
        if interleave_cfg and len(extended) > len(current_queue):
            new_tail = extended[len(current_queue):]
            # Count primary (non-interleaved) episodes since the LAST
            # interleaved item in current_queue.  This tells
            # _apply_interleave how far into the current gap we already
            # are, so the first new movie lands at the right position.
            # Example: current_queue = [ep, ep, MOVIE] -> offset=0
            #          current_queue = [ep, ep]        -> offset=2
            #          current_queue = [MOVIE, ep, ep] -> offset=2
            primary_offset = 0
            for ep in reversed(current_queue):
                if ep.get("_interleaved") or ep.get("is_movie", False):
                    break  # stop at the last interleaved item
                primary_offset += 1

            # Build start_after: for each foreign TV show present in
            # current_queue, record the last episodeid queued.  Pass this
            # to _apply_interleave -> _load_foreign_items -> _build_fresh_queue
            # so the fresh foreign queue starts AFTER those episodes rather
            # than from next_episode_id in state (which only advances when
            # an episode finishes playing, and therefore lags current_queue
            # at top-up time).
            #
            # This eliminates the join-boundary overlap without any post-hoc
            # dedup pass.  The dedup block and stranded-movie pass that
            # previously lived here have been removed (1.1.0u).
            #
            # start_after only applies to TV foreign channels -- movie foreign
            # channels use the unplayed_ids pool which already prevents
            # duplicates.
            foreign_ids = _interleave_foreign_ids({"interleave": interleave_cfg})
            # For start_after logic we only handle the first non-silent TV
            # foreign source.  Multi-source start_after is handled in 1.1.2b.
            foreign_id = foreign_ids[0] if foreign_ids else ""
            start_after = None
            if foreign_id:
                foreign_ch = self.get_channel(foreign_id)
                if (foreign_ch and
                        foreign_ch.get("channel_type") not in ("movies",)):
                    # Last episodeid in current_queue per show, from the
                    # foreign channel.  Only TV episodes carry episodeid > 0.
                    # _channel_id identifies the owning channel regardless of
                    # whether _interleaved is set (the initial build does not
                    # write _interleaved; only new_tail items from top-up do).
                    last_ep_per_show = {}
                    played_per_show  = {}
                    for ep in current_queue:
                        if (ep.get("_channel_id") == foreign_id
                                and ep.get("episodeid", -1) > 0):
                            sid = ep.get("_show_id", 0)
                            eid = ep["episodeid"]
                            last_ep_per_show[sid]  = eid
                            if sid not in played_per_show:
                                played_per_show[sid] = []
                            if eid not in played_per_show[sid]:
                                played_per_show[sid].append(eid)

                    if last_ep_per_show:
                        start_after = dict(last_ep_per_show)
                        # Attach full per-show played lists under a private
                        # key so _build_fresh_queue can seed local_played for
                        # random channels (see start_after handling there).
                        for sid, played in played_per_show.items():
                            start_after["_played_{}".format(sid)] = played
                        log("[ChannelManager] refill_queue: start_after "
                            "built for {} show(s) in foreign channel".format(
                            len(last_ep_per_show)))

            new_tail = self._apply_interleave(
                new_tail, interleave_cfg,
                primary_offset=primary_offset,
                start_after=start_after,
                channel_name=channel.get("name", ""))

            extended = current_queue + new_tail

        # NOTE: deliberately NOT writing the queue file here.
        # When called from the service, _update_queue_file handles the write.
        # service.py _topup_in_background handles playlist appending after
        # playlist extension. A double-write here causes the service to
        # detect a content change, reset _current_file=None, and re-trigger
        # the file-detection loop on the last episode of a no-recycle channel.

        log("[ChannelManager] refill_queue: queue now {} items".format(
            len(extended)))
        return extended

    def _write_queue_file(self, channel_id, queue):
        """Atomically write queue list to queue_{channel_id}.json."""
        self._save_json(self._queue_file_path(channel_id), queue)

    @staticmethod
    def _strip_leading_silents(queue):
        """
        Move any silent interleave items at the front of the queue to the
        tail, so playback always starts with a real (visible) episode or
        movie.

        Silent items are tagged _silent: True by apply_interleave_list()
        in channels/interleave.py. They play invisibly (OSD shows the
        primary channel name, not the bumper title) and the user should
        never see one as the first item on channel start or resume.

        The silent items are moved to the tail in their original order so
        the interleave cadence is preserved as closely as possible.

        Edge case: if ALL items in the queue are silent (extremely unlikely
        but theoretically possible on a nearly-empty interleaved channel),
        the queue is returned unchanged to prevent an empty-queue condition.

        Called by: reorder_queue_from_item(), and service.py
                   _update_queue_file() before writing to disk.
        """
        if not queue:
            return queue

        # Find the first non-silent item
        first_real = next(
            (i for i, item in enumerate(queue)
             if not item.get("_silent")), None)

        if first_real is None:
            # All items are silent — return unchanged
            log("[ChannelManager] _strip_leading_silents: "
                "all items are silent, queue unchanged")
            return queue

        if first_real == 0:
            # Already starts with a real item — nothing to do
            return queue

        # Move leading silents to the tail
        stripped = queue[first_real:] + queue[:first_real]
        log("[ChannelManager] _strip_leading_silents: "
            "moved {} leading silent item(s) to tail".format(first_real))
        return stripped

    def reorder_queue_from_item(self, channel_id, queue_index):
        """
        Rotate the queue so the item at queue_index moves to position 0.
        Items at positions 0..(queue_index-1) are moved to the tail in
        their original order so the channel continues correctly after the
        selected item plays through.

        This mirrors the behaviour of the user skipping forward in the
        Kodi playlist — service.py's existing skip detection advances
        state for all bypassed items naturally when playback starts.

        Returns True on success, False if the queue file is missing,
        unreadable, or queue_index is out of range.

        Called by: side_panel.py only.
        Owns: queue file read + write.  No state.json changes here.
        """
        import json as _json
        import xbmcvfs as _xbmcvfs

        q_path = self._queue_file_path(channel_id)
        if not _xbmcvfs.exists(q_path):
            log("[ChannelManager] reorder_queue_from_item: "
                "queue file not found for {}".format(channel_id))
            return False

        try:
            with _xbmcvfs.File(q_path, "r") as f:
                raw = f.read()
            queue = _json.loads(raw) if raw else []
        except Exception as e:
            log("[ChannelManager] reorder_queue_from_item: "
                "read error: {}".format(e))
            return False

        if not queue:
            log("[ChannelManager] reorder_queue_from_item: empty queue")
            return False

        if queue_index <= 0 or queue_index >= len(queue):
            log("[ChannelManager] reorder_queue_from_item: "
                "index {} out of range (queue len {})".format(
                    queue_index, len(queue)))
            return False

        # Rotate: tail = items before selected + items after selected
        reordered = queue[queue_index:] + queue[:queue_index]

        # Ensure the queue never starts with a silent interleave item.
        # If the selected episode has silent bumpers immediately before it
        # in the raw queue, those ended up at the tail via the rotation above
        # and cannot land at position 0. But if silent items sat AFTER the
        # selected episode's position and were already at the front of the
        # original queue slice, they need to be moved to the tail.
        reordered = self._strip_leading_silents(reordered)

        self._write_queue_file(channel_id, reordered)

        # Clear the resume position for the item that was previously at
        # position 0. The user has explicitly chosen to skip past it by
        # selecting a different item from the side panel — the saved
        # resume point is no longer valid and should not be offered again.
        # We clear ALL items being displaced (positions 0..queue_index-1)
        # to match the behaviour of forward-skipping in the Kodi playlist.
        try:
            for displaced in queue[:queue_index]:
                self.clear_resume_position(displaced)
                log("[ChannelManager] reorder_queue_from_item: "
                    "cleared resume for displaced item ep={} movie={}".format(
                        displaced.get("episodeid"),
                        displaced.get("movieid")))
        except Exception as _e:
            log("[ChannelManager] reorder_queue_from_item: "
                "clear_resume error: {}".format(_e))

        log("[ChannelManager] reorder_queue_from_item: "
            "channel={} rotated to index {} (queue len {})".format(
                channel_id, queue_index, len(queue)))
        return True

    # -- Exact Resume ----------------------------------------------------------

    @staticmethod
    def _resume_key_for_item(item):
        """
        Return the state.json key used to store the resume position for item.

        Key format:
          TV/movie : "resume:<channel_id>:<episodeid_or_movieid>"
          Folder   : "resume:<channel_id>:file:<md5_of_filepath[:16]>"

        Returns None if the item cannot be keyed (no file path and no
        episodeid/movieid — shouldn't happen in practice).
        """
        import hashlib
        channel_id = (item.get("_channel_id")
                      or item.get("channel_id", "unknown"))
        is_movie   = item.get("is_movie", False) or item.get("movieid", -1) > 0

        if item.get("is_folder_item"):
            file_path = item.get("file", "")
            if not file_path:
                return None
            md5 = hashlib.md5(file_path.encode("utf-8")).hexdigest()[:16]
            return "resume:{}:file:{}".format(channel_id, md5)

        item_id = (item.get("movieid", -1) if is_movie
                   else item.get("episodeid", -1))
        if not item_id or item_id < 0:
            return None
        return "resume:{}:{}".format(channel_id, item_id)

    def save_resume_position(self, item, position, total):
        """
        Save exact playback position for item to state.json on the shared
        path.  Called by service.py on stop and by the background
        polling thread (local only for the poll case).

        Key format: resume:<channel_id>:<item_id>
        where item_id is episodeid for TV episodes and movieid for movies.
        For folder items: resume:<channel_id>:file:<md5_of_path[:16]>

        position and total are floats (seconds).
        """
        key = self._resume_key_for_item(item)
        if not key:
            return

        is_movie = item.get("is_movie", False) or item.get("movieid", -1) > 0
        entry = {
            "position":  round(position, 2),
            "total":     round(total,    2),
            "title":     item.get("title", ""),
            "file":      item.get("file",  ""),
            "is_movie":  is_movie,
        }
        try:
            state = self._load_json(self._state_path, {})
            state[key] = entry
            self._save_json(self._state_path, state)
            log("[ChannelManager] Resume saved: {} @ {:.0f}s / {:.0f}s "
                "path={}".format(key, position, total, self._state_path))
        except Exception as e:
            log("[ChannelManager] save_resume_position error: {}".format(e))

    def get_resume_position(self, item):
        """
        Return saved resume entry for item, or None if not found.
        Checks shared state.json first, then local backup.
        Returns None if position is within 30s of end or > 95% complete
        (treat as finished).
        Supports folder items (keyed by MD5 of file path).
        """
        key = self._resume_key_for_item(item)
        if not key:
            return None

        # Check shared state first
        entry = None
        try:
            state = self._load_json(self._state_path, {})
            entry = state.get(key)
        except Exception:
            pass

        # Fall back to local backup if shared had nothing
        if not entry:
            try:
                import os, xbmcvfs, xbmcaddon
                _profile = xbmcvfs.translatePath(
                    xbmcaddon.Addon().getAddonInfo("profile"))
                _local   = os.path.join(_profile, "resume_backup.json")
                _backup  = self._load_json(_local, {})
                entry    = _backup.get(key)
            except Exception:
                pass

        if not entry:
            return None

        position = entry.get("position", 0)
        total    = entry.get("total",    0)

        # Don't resume if at beginning (< 10s) or near end
        if position <= 10:
            return None
        if total > 0 and position >= total - 30:   # within 30s of end
            return None

        return entry

    def clear_channel_resume_points(self, channel_id):
        """
        Remove ALL resume entries for a channel from state.json and the
        local backup. Called when a channel is reset or edited in a way
        that invalidates saved positions (recycle/randomize/type change).

        Resume keys use the format: resume:<channel_id>:<item_id>
        which is a different prefix from the channel state keys
        (<channel_id>:<show_id>), so they must be cleared separately.
        """
        try:
            prefix   = "resume:{}:".format(channel_id)
            # Remove from in-memory state and mark as deleted so that
            # _save_state()'s read-merge-write cannot resurrect them.
            # Without this, a subsequent _save_tail() call reads disk
            # (clean), but merges self._state (still has the key) on top,
            # putting the resume point back into the written file.
            mem_keys = [k for k in self._state if k.startswith(prefix)]
            for k in mem_keys:
                del self._state[k]
            self._deleted_state_keys.update(mem_keys)

            # Also clean from disk directly in case keys existed only there
            state    = self._load_json(self._state_path, {})
            keys_del = [k for k in state if k.startswith(prefix)]
            for k in keys_del:
                del state[k]
            if keys_del or mem_keys:
                self._save_json(self._state_path, state)
                log("[ChannelManager] Cleared {} resume point(s) "
                    "for channel {}".format(
                        len(set(keys_del) | set(mem_keys)), channel_id[:8]))
            else:
                log("[ChannelManager] No resume points to clear "
                    "for channel {}".format(channel_id[:8]))
        except Exception as e:
            log("[ChannelManager] clear_channel_resume_points error: "
                "{}".format(e))

        # Also clear from local backup
        try:
            import os, xbmcvfs, xbmcaddon
            _profile = xbmcvfs.translatePath(
                xbmcaddon.Addon().getAddonInfo("profile"))
            _local   = os.path.join(_profile, "resume_backup.json")
            _backup  = self._load_json(_local, {})
            prefix   = "resume:{}:".format(channel_id)
            keys_del = [k for k in _backup if k.startswith(prefix)]
            for k in keys_del:
                del _backup[k]
            if keys_del:
                self._save_json(_local, _backup)
        except Exception:
            pass

    def clear_resume_position(self, item):
        """
        Remove resume entry for item — called when item finishes naturally.
        Supports folder items (keyed by MD5 of file path).
        """
        key = self._resume_key_for_item(item)
        if not key:
            return
        try:
            state = self._load_json(self._state_path, {})
            if key in state:
                del state[key]
                self._save_json(self._state_path, state)
                log("[ChannelManager] Resume cleared: {}".format(key))
        except Exception as e:
            log("[ChannelManager] clear_resume_position error: {}".format(e))

        # Also remove from in-memory state and mark as deleted so that
        # any subsequent _save_state() merge cannot resurrect the key.
        # _save_state does a read-before-write merge (disk + self._state),
        # so if the key still lives in self._state it will be written back
        # over the deletion above — _deleted_state_keys prevents that.
        self._state.pop(key, None)
        self._deleted_state_keys.add(key)

        # Also clear from local backup
        try:
            import os, xbmcvfs, xbmcaddon
            _profile = xbmcvfs.translatePath(
                xbmcaddon.Addon().getAddonInfo("profile"))
            _local   = os.path.join(_profile, "resume_backup.json")
            _backup  = self._load_json(_local, {})
            if key in _backup:
                del _backup[key]
                self._save_json(_local, _backup)
        except Exception:
            pass

    def save_resume_position_local(self, item, position, total):
        """
        Save resume position directly to shared state.json.
        Previously wrote to a separate local resume_backup.json to avoid
        SMB writes during playback, but writing directly is simpler, halves
        the file I/O, and means crash recovery works without a separate
        promote step on clean stop.
        """
        self.save_resume_position(item, position, total)

    # -- Interleave ------------------------------------------------------------

    def _save_interleave_index(self, channel_id, count):
        """
        Advance and save interleave_index for channel_id by count.
        Called by _apply_interleave after placing exactly count movies.
        """
        state_key  = "{}:__movie_state__".format(channel_id)
        try:
            _fresh = self._load_json(self._state_path, {})
            mstate = _fresh.get(state_key, {})
        except Exception:
            mstate = self._state.get(state_key, {})
        order = mstate.get("interleave_order", [])
        idx   = mstate.get("interleave_index", 0) + count
        # If index exceeds order length, wrap and reshuffle
        if order and idx >= len(order):
            unplayed = mstate.get("unplayed_ids", [])
            if unplayed:
                new_order = list(unplayed)
                random.shuffle(new_order)
                mstate["interleave_order"] = new_order
                idx = idx - len(order)  # carry over remainder
            else:
                idx = 0
        mstate["interleave_index"] = idx
        self._state[state_key] = mstate
        self._save_state()
        log("[ChannelManager] interleave_index advanced by {} to {}".format(
            count, idx))

    def get_interleave_sources(self, channel: dict) -> list:
        """
        Return the normalised list of interleave source configs for *channel*.
        Handles both legacy single-dict and new list format transparently.
        Delegates to channels/interleave.py — single source of truth.
        """
        return _interleave_get_sources(channel)

    def advance_interleave_counters(self, channel_id: str,
                                    channel: dict) -> list:
        """
        Increment all per-source interleave counters for *channel* by 1
        (one primary channel item just completed naturally).

        Reads current counter values from state.json, delegates pure counter
        logic to channels/interleave.py, persists updated values, and returns
        the list of source configs that fired (reached their threshold).

        Counter state key: "{channel_id}:interleave_counters"
        Value: dict {source_channel_id: int}

        Returns [] when the channel has no interleave sources.
        Called only from service.py._handle_end() on natural item completion.
        """
        sources = _interleave_get_sources(channel)
        if not sources:
            return []

        state_key = "{}:interleave_counters".format(channel_id)
        counters  = self._state.get(state_key) or {}

        updated, fired = _interleave_advance_counters(sources, counters)

        self._state[state_key] = updated
        self._save_state()

        if fired:
            log("[ChannelManager] advance_interleave_counters: {} source(s) "
                "fired for channel {}".format(len(fired), channel_id[:8]))
        return fired

    def _apply_interleave(self, queue, interleave_cfg, primary_offset=0,
                          start_after=None, channel_name=""):
        """Delegate to channels/interleave.py — single source of truth.

        interleave_cfg: the raw value from channel["interleave"] (single dict
        or list).  We build a temporary channel dict so get_sources() can
        normalise it in one place.

        channel_name: the primary channel's display name, passed through so
        silent items can tag _channel_name correctly for OSD display.

        start_after: optional dict {tvshowid: episodeid} passed only from
        refill_queue.  When set, _load_foreign_items will pass it to
        _build_fresh_queue so the foreign TV queue starts after the last
        episode already present in current_queue, eliminating join-boundary
        duplicates without a post-hoc dedup pass.
        """
        def _foreign_fn(foreign_id, foreign_ch, needed):
            return self._load_foreign_items(
                foreign_id, foreign_ch, needed, start_after=start_after)

        # Wrap raw cfg in a minimal channel dict so get_sources() can
        # normalise it (handles single-dict and list transparently).
        # Include name so silent items can tag _channel_name for OSD display.
        _tmp_channel = {"interleave": interleave_cfg, "name": channel_name}
        return _apply_interleave_list(
            queue, _tmp_channel,
            get_foreign_items_fn=_foreign_fn,
            get_channel_fn=self.get_channel,
            primary_offset=primary_offset,
        )
    def _load_foreign_items(self, foreign_id, foreign_ch, needed,
                            start_after=None):
        """
        Return `needed` items from the foreign channel for interleaving,
        cycling if necessary.

        IMPORTANT: We must NOT use the runtime queue file (queue_{id}.json)
        because that file is trimmed by the service as items play - it shrinks
        to 1 item when the foreign channel is nearly exhausted, causing the
        interleave to repeat that one item over and over.

        Instead we always build a fresh batch from the foreign channel's
        full content. This is fast since it reads from local_library.json
        and respects the foreign channel's current state pointers so the
        interleaved items continue from where that channel left off.

        start_after: optional dict {tvshowid: episodeid} passed only from
        refill_queue (via _apply_interleave closure).  Forwarded to
        _build_fresh_queue so the fresh TV queue starts after the last
        episode already sitting in current_queue.  Has no effect for movie
        foreign channels (they use unplayed_ids pool management).
        """
        try:
            if foreign_ch.get("channel_type") == "movies":
                batch = self._build_movie_queue(
                    foreign_ch, needed, for_interleave=True)
            elif foreign_ch.get("channel_type") == "serial":
                # Serial interleave source: use the dedicated interleave build
                # path so that standalone serial playback state
                # (__serial_show_idx__, next_episode_id) is never touched.
                # The interleave build tracks position with its own independent
                # state keys and produces exactly `needed` items (no LOOKAHEAD)
                # so _load_foreign_items never truncates mid-show.
                from resources.lib.channels.serial import SerialQueueBuilder
                foreign_ch_copy = dict(foreign_ch)
                foreign_ch_copy.pop("interleave", None)
                batch = SerialQueueBuilder(self).build(
                    foreign_ch_copy, needed, for_interleave=True)
            else:
                # Strip the foreign channel's own interleave config before
                # building so that nested interleave does not trigger a
                # recursive _apply_interleave call inside _build_fresh_queue.
                foreign_ch_copy = dict(foreign_ch)
                foreign_ch_copy.pop("interleave", None)
                batch = self._build_fresh_queue(
                    foreign_ch_copy, needed, start_after=start_after)
            if batch:
                return batch[:needed]
        except Exception as e:
            log("[ChannelManager] _load_foreign_items build error "
                "for '{}' (type={}): {}".format(
                foreign_ch.get("name", foreign_id),
                foreign_ch.get("channel_type", "unknown"),
                e), xbmc.LOGWARNING)

        return []

    # -- Reset / Regenerate helpers --------------------------------------------

    def advance_movie_state(self, channel_id: str, ep: dict,
                            channel: dict) -> None:
        """
        Update movie played/unplayed state when a movie finishes playing
        naturally (not skipped). Called only from _handle_end via
        PlaybackMonitor._handle_end.

        Marks movie_id as played in __movie_state__.
        The queue builder (_build_movie_queue) owns pool management —
        it removes movies from unplayed_ids when queuing them. This method
        only records that a movie was actually watched to completion.
        """
        import random as _random

        movie_id = ep.get("movieid", -1)
        if movie_id < 0:
            return

        state_path = self._resolve_path("state.json")
        state_all  = self._load_json(state_path, {})
        key        = "{}:__movie_state__".format(channel_id)
        mstate     = state_all.get(key, {"played_ids": [], "next_index": 0})

        played_ids   = list(mstate.get("played_ids",   []))
        unplayed_ids = list(mstate.get("unplayed_ids", []))

        movie_ch = self.get_channel(channel_id)
        if movie_ch:
            total_movies  = len(movie_ch.get("movies", []))
            do_recycle    = movie_ch.get("recycle", True)
            all_movie_ids = [m["movieid"] for m in movie_ch.get("movies", [])]
        else:
            total_movies  = len(channel.get("movies", []))
            do_recycle    = channel.get("recycle", True)
            all_movie_ids = [m["movieid"] for m in channel.get("movies", [])]

        # Seed unplayed on first play
        if not unplayed_ids and not played_ids and total_movies > 0:
            unplayed_ids = list(all_movie_ids)

        # Only count as played if currently in unplayed pool.
        # Second-cycle occurrences (queue > pool size) are silently skipped.
        if movie_id in unplayed_ids:
            unplayed_ids.remove(movie_id)
            if movie_id not in played_ids:
                played_ids.append(movie_id)
        elif movie_id not in played_ids:
            played_ids.append(movie_id)
        # else: already played this cycle, second-cycle — skip.

        if not unplayed_ids and total_movies > 0:
            if do_recycle:
                log("[ChannelManager] Movie channel exhausted ({}/{}) "
                    "- recycling".format(len(played_ids), total_movies))
                played_ids   = []
                unplayed_ids = list(all_movie_ids)
            else:
                log("[ChannelManager] Movie channel exhausted - recycle=False")
        elif total_movies == 0:
            log("[ChannelManager] advance_movie_state: could not determine "
                "total movies for channel {}".format(channel_id))

        mstate["played_ids"]   = played_ids
        mstate["unplayed_ids"] = unplayed_ids
        state_all[key]         = mstate
        self._save_json(state_path, state_all)
        log("[ChannelManager] Movie state updated: played={} unplayed={} "
            "total={}".format(len(played_ids), len(unplayed_ids), total_movies))

    def save_show_index(self, channel_id: str, show_index: int) -> None:
        """
        Persist which show index is currently playing so build_queue
        can resume from the right show after a mid-episode stop.
        Moved from service.py._save_show_index — state writes must go
        through channel_manager.
        """
        state_path = self._resolve_path("state.json")
        state_all  = self._load_json(state_path, {})
        key        = "{}:__show_index__".format(channel_id)
        state_all[key] = show_index
        self._save_json(state_path, state_all)
        log("[ChannelManager] Saved show_index={} for channel {}".format(
            show_index, channel_id))

    def reset_show_to_start(self, channel_id: str, show_id: int) -> bool:
        """
        Reset a single show's episode pointer back to S01E01 within a channel.
        Clears the queue tail marker and deletes the queue file so the next
        build reflects the reset. Pregenerates a fresh queue.

        Returns True if reset succeeded, False if no episodes found.
        Called by router.reset_next_episode — keeps all state writes in CM.
        """
        import xbmcvfs as _xbmcvfs

        channel    = self.get_channel(channel_id)
        show_entry = None
        if channel:
            show_entry = next(
                (s for s in channel.get("shows", [])
                 if int(s["tvshowid"]) == int(show_id)), None)

        episodes = (self.get_available_episodes(show_entry) if show_entry
                    else self.library.get_episodes_for_show(show_id))
        if not episodes:
            return False

        first_ep = episodes[0]
        self.save_show_state(channel_id, show_id, {
            "next_episode_id": first_ep["episodeid"],
            "season":          first_ep.get("season",  1),
            "episode":         first_ep.get("episode", 1),
            "played_ids":      [],
        })

        # Clear tail marker so the next build reconstructs from state
        tail_key = self._tail_key(channel_id)
        self._state.pop(tail_key, None)
        self._save_state()

        # Delete the stale queue file so the next play rebuilds from scratch.
        # Must delete BOTH the shared-path copy (written by _pregenerate_queue
        # and _write_queue_file) AND the local profile copy (written by
        # service.py as a staging copy during active playback).
        # _open_tv_channel prefers the local copy when it exists — if we only
        # delete the shared copy, the stale local copy shadows the freshly
        # regenerated file and the channel view shows the old episode order
        # until the user closes and reopens the channel.
        queue_path  = self._queue_file_path(channel_id)
        local_q     = os.path.join(
            self.profile, "queue_{}.json".format(channel_id))
        if _xbmcvfs.exists(queue_path):
            _xbmcvfs.delete(queue_path)
        if _xbmcvfs.exists(local_q):
            _xbmcvfs.delete(local_q)

        # Pregenerate a fresh queue so the channel view shows correct info
        channel = self.get_channel(channel_id)
        if channel:
            self._pregenerate_queue(channel)

        return True

    def reset_channel(self, channel_id):
        """
        Reset ALL shows and movie state in a channel back to the very
        beginning (S01E01 / first movie / first in queue).

        What is cleared:
          - Every state key for this channel (show pointers, movie state,
            tail marker, show_index)
          - The queue file

        The queue is then rebuilt immediately so the channel view reflects
        the new positions.  Returns the channel dict or None if not found.
        """
        channel = self.get_channel(channel_id)
        if not channel:
            return None

        keys_to_del = [k for k in self._state
                       if k.startswith("{}:".format(channel_id))]
        for k in keys_to_del:
            del self._state[k]
        self._deleted_state_keys.update(keys_to_del)
        self._save_state()

        # Resume keys use a different prefix (resume:<channel_id>:)
        # and are not caught by the loop above — clear them explicitly.
        self.clear_channel_resume_points(channel_id)

        import xbmcvfs as _xbmcvfs
        queue_path = self._queue_file_path(channel_id)
        local_q    = os.path.join(
            self.profile, "queue_{}.json".format(channel_id))
        if _xbmcvfs.exists(queue_path):
            _xbmcvfs.delete(queue_path)
        if _xbmcvfs.exists(local_q):
            _xbmcvfs.delete(local_q)

        log("[ChannelManager] reset_channel: cleared {} state keys "
            "for '{}'".format(len(keys_to_del), channel["name"]))

        # Clear _deleted_state_keys BEFORE pregenerate so that the new
        # movie/TV state written by _build_movie_queue is not stripped
        # out by _save_state's deleted-key merge.
        # reset_channel already saved the cleared state above — the
        # deleted-key tracking has served its purpose.
        self._deleted_state_keys.clear()

        self._pregenerate_queue(channel)
        return channel

    def regenerate_queue(self, channel_id):
        """
        Regenerate the queue after an interleave change.

        Preserves the existing episode ORDER (critical for random channels
        so the randomised sequence is not discarded).  Strips any existing
        interleaved items from the queue, then re-weaves the new interleave
        configuration on top of the remaining TV/movie episodes.

        Falls back to a full rebuild only when no valid queue file exists.
        """
        import xbmcvfs as _xbmcvfs

        channel = self.get_channel(channel_id)
        if not channel:
            return None

        log("[ChannelManager] regenerate_queue: rebuilding from current "
            "positions for '{}'".format(channel["name"]))

        queue_path = self._queue_file_path(channel_id)
        existing_queue = None

        # Try to load the existing queue
        if _xbmcvfs.exists(queue_path):
            try:
                with _xbmcvfs.File(queue_path, "r") as f:
                    raw = f.read()
                if raw:
                    existing_queue = json.loads(raw)
            except Exception as e:
                log("[ChannelManager] regenerate_queue: could not read "
                    "existing queue: {}".format(e))

        interleave_cfg = channel.get("interleave")

        if existing_queue:
            # Strip out any previously interleaved foreign items,
            # keeping only the primary channel's own episodes/movies.
            primary_items = [item for item in existing_queue
                             if not item.get("_interleaved")]

            if primary_items:
                # Re-apply the new interleave config (if any) on top of
                # the preserved primary episode order.
                if interleave_cfg:
                    new_queue = self._apply_interleave(
                        primary_items, interleave_cfg, primary_offset=0,
                        channel_name=channel.get("name", ""))
                    log("[ChannelManager] regenerate_queue: preserved {} "
                        "primary items, wove in interleave → {} total".format(
                            len(primary_items), len(new_queue)))
                else:
                    new_queue = primary_items
                    log("[ChannelManager] regenerate_queue: interleave "
                        "removed, {} primary items remain".format(
                            len(new_queue)))

                self._write_queue_file(channel_id, new_queue)
                log("[ChannelManager] regenerate_queue: done for "
                    "'{}'".format(channel["name"]))
                return channel

        # No usable existing queue — fall back to full rebuild
        log("[ChannelManager] regenerate_queue: no existing queue, "
            "rebuilding from state positions")
        tail_key = self._tail_key(channel_id)
        self._state.pop(tail_key, None)
        self._deleted_state_keys.add(tail_key)
        self._save_state()
        if _xbmcvfs.exists(queue_path):
            _xbmcvfs.delete(queue_path)
        self._pregenerate_queue(channel)
        return channel

