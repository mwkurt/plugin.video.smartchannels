"""
resources/lib/coming_up_next.py
================================
Compatibility shim — the canonical implementation has moved to
resources/lib/overlays/coming_up_next.py as part of the 1.1.0 rewrite.

All imports from this path continue to work.
"""
from resources.lib.overlays.coming_up_next import (  # noqa: F401
    show_overlay, load_settings, ComingUpNextWindow
)
