# utils/paths.py
#
# OWNS:   resolve_path(), load_json(), save_json(), shared_root(),
#         path_join(), and the _s() string helper.
#         These are the ONLY implementations of these functions in the
#         entire codebase.  All other modules import from here.
#
# NEVER:  Kodi playback control, state logic, UI rendering, JSON-RPC calls.
#
# CALLERS: Any module may import and call these utilities.
#
# If you are writing a resolve_path(), load_json(), or save_json() anywhere
# other than this file, you are in the wrong place. Delete it and import this.

from __future__ import annotations

import json
import os

import xbmc
import xbmcaddon
import xbmcvfs

_ADDON_ID = "plugin.video.smartchannels"


def _get_profile() -> str:
    """Return the local addon profile directory path."""
    return xbmcvfs.translatePath(
        xbmcaddon.Addon(_ADDON_ID).getAddonInfo("profile"))


def shared_root() -> str:
    """
    Return the shared storage root path if configured, else empty string.
    Converts Windows UNC paths (\\\\Server\\share or //Server/share)
    to smb://Server/share so xbmcvfs handles them uniformly.
    """
    try:
        raw = xbmcaddon.Addon(_ADDON_ID).getSetting(
            "shared_storage_path").strip()
    except Exception:
        raw = ""
    if raw in ("", "smb://", "smb:/"):
        return ""
    if raw.startswith("\\\\") or raw.startswith("//"):
        raw = raw.lstrip("\\/")
        raw = "smb://" + raw.replace("\\", "/")
    return raw.rstrip("/").rstrip("\\")


def path_join(root: str, filename: str) -> str:
    """
    Join root and filename correctly for both local and network paths.
    Network paths (smb://, nfs://, etc.) use forward slash.
    Local paths use os.path.join.
    """
    if "://" in root:
        return root.rstrip("/") + "/" + filename
    return os.path.join(root, filename)


def resolve_path(filename: str) -> str:
    """
    Return the full path for *filename*.

    Routes to the configured shared storage root when set, otherwise
    to the local addon profile directory.  Works for local drives,
    mapped drives, SMB, NFS.
    """
    profile = _get_profile()
    shared  = shared_root()
    if shared:
        if not xbmcvfs.exists(shared):
            try:
                xbmcvfs.mkdirs(shared)
            except Exception as exc:
                xbmc.log("[{}][paths] Cannot create shared dir {}: {}".format(
                    _ADDON_ID, shared, exc), xbmc.LOGWARNING)
        return path_join(shared, filename)
    return os.path.join(profile, filename)


def load_json(path: str, default):
    """
    Read and parse a JSON file from *path*.
    Returns *default* if the file does not exist or cannot be parsed.
    """
    if xbmcvfs.exists(path):
        try:
            with xbmcvfs.File(path, "r") as f:
                return json.loads(f.read())
        except Exception as exc:
            xbmc.log("[{}][paths] load_json failed {}: {}".format(
                _ADDON_ID, path, exc), xbmc.LOGWARNING)
    return default


def save_json(path: str, data) -> bool:
    """
    Serialise *data* as JSON and write to *path*.

    Local profile paths: written directly via xbmcvfs.File (always works).
    Shared / network paths: written to a local temp copy first, then
    copied to the destination.  Falls back to plain open() for local
    mapped drives (e.g. E:\\SharedFolder) where xbmcvfs.copy may fail.

    Returns True on success, False on failure.
    """
    profile  = _get_profile()
    json_str = json.dumps(data, indent=2, ensure_ascii=False)
    is_shared = not path.startswith(profile)

    if not is_shared:
        try:
            with xbmcvfs.File(path, "w") as f:
                f.write(json_str)
            return True
        except Exception as exc:
            xbmc.log("[{}][paths] save_json failed {}: {}".format(
                _ADDON_ID, path, exc), xbmc.LOGERROR)
            return False
    else:
        local_copy = os.path.join(profile, os.path.basename(path))
        try:
            with xbmcvfs.File(local_copy, "w") as f:
                f.write(json_str)
            ok = xbmcvfs.copy(local_copy, path)
            if not ok:
                xbmc.log("[{}][paths] save_json xbmcvfs.copy failed to {}, "
                         "open() fallback".format(_ADDON_ID, path),
                         xbmc.LOGWARNING)
                if "://" not in path:
                    with xbmcvfs.File(local_copy, "r") as _src, \
                         xbmcvfs.File(path,        "w") as _dst:
                        _dst.write(_src.read())
                else:
                    xbmc.log("[{}][paths] save_json SMB copy failed, "
                             "write lost: {}".format(_ADDON_ID, path),
                             xbmc.LOGWARNING)
            return True
        except Exception as exc:
            xbmc.log("[{}][paths] save_json failed {}: {}".format(
                _ADDON_ID, path, exc), xbmc.LOGERROR)
            return False


def _s(addon: xbmcaddon.Addon, string_id: int, fallback: str = "") -> str:
    """Return localised string for *string_id*, falling back to *fallback*."""
    try:
        val = addon.getLocalizedString(string_id)
        return val if val else fallback
    except Exception:
        return fallback
