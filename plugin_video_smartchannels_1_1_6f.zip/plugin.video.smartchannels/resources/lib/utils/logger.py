"""
resources/lib/utils/logger.py
==============================
Thin wrapper around xbmc.log so all addon messages share a consistent
prefix and respect the user's chosen log-level setting.
"""

import xbmc
import xbmcaddon

_ADDON_ID = "plugin.video.smartchannels"
_PREFIX   = f"[{_ADDON_ID}] "


def log(message: str, level: int = xbmc.LOGINFO) -> None:
    """
    Write a message to the Kodi log.

    Args:
        message: Text to log.
        level:   xbmc.LOGINFO (default), xbmc.LOGDEBUG, xbmc.LOGWARNING,
                 xbmc.LOGERROR, xbmc.LOGFATAL.
    """
    try:
        addon      = xbmcaddon.Addon(_ADDON_ID)
        log_pref   = int(addon.getSetting("log_level") or "0")
        # 0=Info, 1=Debug, 2=Warning  (matches settings.xml option order)
        # When preference is Info, suppress Debug-level addon messages
        if log_pref == 0 and level == xbmc.LOGDEBUG:
            return
    except Exception:
        pass  # If addon not initialised yet just let the message through

    xbmc.log(_PREFIX + str(message), level=level)
