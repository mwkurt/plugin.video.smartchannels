"""
resources/lib/utils/extra_folders.py
=====================================

OWNS:   Loading and saving the extra_folders.json list.
        Extra folders are user-configured paths for non-library media
        (commercials, bumpers, interstitials) that can be added to channels.

NEVER:  Duration scanning, playback control, UI rendering, JSON-RPC calls.

CALLERS: router.py — manage_extra_folders() action
"""

import json
import os

import xbmc
import xbmcvfs

from resources.lib.utils.logger  import log
from resources.lib.utils.paths   import load_json, save_json

_EXTRA_FOLDERS_FILE = "extra_folders.json"


def load_extra_folders(profile: str) -> list:
    """Load extra_folders.json. Returns [] if missing or corrupt."""
    path   = os.path.join(profile, _EXTRA_FOLDERS_FILE)
    result = load_json(path, [])
    return result if isinstance(result, list) else []


def save_extra_folders(profile: str, folders: list) -> bool:
    """Save extra_folders.json."""
    path = os.path.join(profile, _EXTRA_FOLDERS_FILE)
    return save_json(path, folders)
