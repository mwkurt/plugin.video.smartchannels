# state.py
#
# OWNS:   All reads and writes to state.json, queue_{id}.json,
#         channels.json, now_playing.json, and resume position data.
#         This is the ONLY module that should open these files.
#
# NEVER:  Kodi JSON-RPC calls, queue building logic, UI rendering,
#         playback control, or any business logic beyond serialisation.
#
# CALLERS: channel_manager.py is the ONLY caller of state write methods.
#          service.py and overlay modules may call read-only methods.
#          router.py must NEVER call state.py directly — go through CM.
#
# STATUS: Boundary defined. File I/O currently lives in channel_manager.py
#         (_save_state, _save_channels, _write_queue_file, save_resume_position,
#         get_resume_position, clear_resume_position). Migration to this module
#         is a post-1.1.0 cleanup task once all other phases are stable.
#
# When implemented, this module will expose:
#   load_state(profile)          -> dict
#   save_state(profile, data)    -> None
#   load_channels(profile)       -> list
#   save_channels(profile, data) -> None
#   load_queue(channel_id)       -> list
#   write_queue(channel_id, data)-> None
#   load_now_playing()           -> dict
#   write_now_playing(data)      -> None
#   save_resume_position(...)    -> None
#   get_resume_position(...)     -> dict | None
#   clear_resume_position(...)   -> None
