# overlays/epg_overlay.py
#
# OWNS:   All rendering and user interaction for the EPG overlay.
#         See EPG_OVERLAY_SPEC.md for full specification.
#         Requires Duration Cache feature to be complete before implementation.
#
# NEVER:  State writes of any kind.
#         Playback callbacks (all in service.py).
#         Queue building or modification.
#         JSON-RPC calls (read data from library cache only).
#
# CALLERS: service.py and router.py (action=show_epg).
#          Calls player.start_channel() for channel switching.
#
# Implementation target: post-1.1.0 (after Duration Cache).
# In 1.1.0 this file exists as a stub only.
