# plugin.video.smartchannels
## Smart TV Channels for Kodi 21 (Omega)

---

## Folder Structure

```
plugin.video.smartchannels/
|
+-- addon.py                          ? Entry point; parses URL params & dispatches
+-- addon.xml                         ? Kodi manifest (id, version, requires)
|
+-- resources/
    +-- settings.xml                  ? Addon settings schema (library, playback, UI)
    +-- language/
    |   +-- English/
    |       +-- strings.xml           ? All localised strings (IDs 30001-32058)
    |
    +-- lib/
        +-- __init__.py
        +-- router.py                 ? URL action ? controller mapping
        +-- channel_manager.py        ? CRUD, state persistence, queue building
        +-- library.py                ? Kodi JSON-RPC wrapper (TV shows, episodes, movies)
        +-- player.py                 ? SmartPlayer + SmartPlayerMonitor (xbmc.Player subclass)
        |
        +-- ui/
        |   +-- __init__.py
        |   +-- menus.py              ? Top-level menu renderer
        |   +-- channels.py          ? Channel listing, open channel, wizards, interleave dialog
        |
        +-- utils/
            +-- __init__.py
            +-- logger.py            ? xbmc.log wrapper with prefix + level filter
```

---

## Architecture Overview

```
addon.py
  +-> Router (router.py)
        +-> MainMenu (ui/menus.py)          - top-level directory view
        +-> ChannelUI (ui/channels.py)      - channel directory views & dialogs
        |     +-> ChannelManager            - reads/writes channels.json + state.json
        |           +-> LibraryClient       - Kodi JSON-RPC (VideoLibrary.* methods)
        +-> SmartPlayer (player.py)         - builds xbmc.PlayList and starts playback
              +-> SmartPlayerMonitor        - xbmc.Player subclass watching for end events
                    +-> ChannelManager.advance_show()  - updates persistent pointer
                    +-> ChannelManager.refill_queue()  - appends more items when low
```

---

## Data Files (stored in addon profile folder)

| File            | Purpose                                                    |
|-----------------|------------------------------------------------------------|
| `channels.json` | List of all channel definition dicts                       |
| `state.json`    | Per `channel_id:show_id` playback pointer & played_ids     |

### Channel definition schema
```json
{
  "id":         "uuid-string",
  "name":       "Evening Drama",
  "shows":      [{"tvshowid": 42, "title": "Breaking Bad"}, ...],
  "randomize":  false,
  "recycle":    true,
  "queue_size": 50,
  "visible":    true,
  "filters":    [{"type": "genre", "value": "Drama"}],
  "interleave": {"channel_id": "other-uuid", "frequency": 4}
}
```

### State entry schema
```json
{
  "channel_id:show_id": {
    "next_episode_id": 1234,
    "season": 2,
    "episode": 5,
    "played_ids": [1001, 1002, 1003]
  }
}
```

---

## URL Routing Reference

| URL params                                              | Handler                        |
|---------------------------------------------------------|--------------------------------|
| (none) or `?action=main_menu`                           | `Router.main_menu`             |
| `?action=list_channels`                                 | `Router.list_channels`         |
| `?action=open_channel&channel_id=<id>`                  | `Router.open_channel`          |
| `?action=play_channel&channel_id=<id>`                  | `Router.play_channel`          |
| `?action=create_channel`                                | `Router.create_channel`        |
| `?action=edit_channel&channel_id=<id>`                  | `Router.edit_channel`          |
| `?action=delete_channel&channel_id=<id>`                | `Router.delete_channel`        |
| `?action=toggle_channel_visibility&channel_id=<id>`     | `Router.toggle_visibility`     |
| `?action=manage_interleave&channel_id=<id>`             | `Router.manage_interleave`     |
| `?action=settings`                                      | `Router.open_settings`         |
| `?action=refresh_library`                               | `Router.refresh_library`       |

---

## Prompt Series

This plugin is built across multiple prompts:

1. **Prompt 1 (this file)** - Project specification, folder structure, `addon.py` routing, all core modules
2. **Prompt 2** - Channel creation wizard enhancements, genre/year filter support
3. **Prompt 3** - Player monitor deep dive, queue persistence across Kodi restarts
4. **Prompt 4** - MySQL/MariaDB direct backend, settings wiring
5. **Prompt 5** - Polish: artwork, context menus, error handling, testing guide

---

## Installation

1. Zip the `plugin.video.smartchannels/` folder.
2. In Kodi: Add-ons ? Install from zip file ? select your zip.
3. Or copy the folder directly to `~/.kodi/addons/plugin.video.smartchannels/`.
4. Enable the addon and navigate to Video Add-ons ? Smart TV Channels.
