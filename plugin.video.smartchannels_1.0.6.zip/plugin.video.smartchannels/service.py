"""
service.py - Persistent background service for plugin.video.smartchannels.
Starts with Kodi and runs for its entire lifetime.
Watches now_playing.json written by the plugin and updates state.json
when episodes finish playing.
"""

import json
import os
import random
import threading

import threading
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON    = xbmcaddon.Addon()
ADDON_ID = "plugin.video.smartchannels"
PROFILE  = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}][service] {}".format(ADDON_ID, msg), level=level)


def load_json(path, default):
    if xbmcvfs.exists(path):
        try:
            with xbmcvfs.File(path, "r") as f:
                return json.loads(f.read())
        except Exception as e:
            log("load_json failed {}: {}".format(path, e), xbmc.LOGWARNING)
    return default


def save_json(path, data):
    """
    Write JSON to path.

    If path is inside the local profile directory, use xbmcvfs.File
    directly — this always works.

    If path is on a shared drive or network location, write a local copy
    in the profile first then copy to the shared destination.
    Falls back to plain Python open() for local/mapped Windows paths
    (e.g. E:\\SharedFolder) where xbmcvfs.copy may fail.
    """
    import os as _os
    json_str = json.dumps(data, indent=2)

    is_shared = not path.startswith(PROFILE)

    if not is_shared:
        try:
            with xbmcvfs.File(path, "w") as f:
                f.write(json_str)
            return True
        except Exception as e:
            log("save_json failed {}: {}".format(path, e), xbmc.LOGERROR)
            return False
    else:
        local_copy = _os.path.join(PROFILE, _os.path.basename(path))
        try:
            with xbmcvfs.File(local_copy, "w") as f:
                f.write(json_str)
            ok = xbmcvfs.copy(local_copy, path)
            if not ok:
                log("save_json xbmcvfs.copy failed to {}, open() fallback".format(
                    path), xbmc.LOGWARNING)
                if "://" not in path:
                    with open(local_copy, "r", encoding="utf-8") as _src, \
                         open(path, "w", encoding="utf-8") as _dst:
                        _dst.write(_src.read())
            return True
        except Exception as e:
            log("save_json failed {}: {}".format(path, e), xbmc.LOGERROR)
            return False


def resolve_path(filename):
    """
    Return the full path for *filename*.
    Routes shared files (channels.json, state.json, queue_*.json,
    now_playing.json) to the configured shared storage root when the
    'shared_storage_path' addon setting is non-empty.
    local_library.json always stays local.
    """
    _LOCAL_ONLY: set = set()  # all files use shared path when configured
    try:
        raw = ADDON.getSetting("shared_storage_path").strip()
    except Exception:
        raw = ""
    if raw in ("", "smb://", "smb:/"):
        raw = ""
    # Convert Windows UNC (\\\\Server\\share) to smb://Server/share
    if raw.startswith("\\\\") or raw.startswith("//"):
        raw = raw.lstrip("\\/")
        raw = "smb://" + raw.replace("\\", "/")
    shared = raw.rstrip("/").rstrip("\\") if raw else ""
    if shared and filename not in _LOCAL_ONLY:
        if not xbmcvfs.exists(shared):
            try:
                xbmcvfs.mkdirs(shared)
            except Exception as exc:
                log("Cannot create shared dir {}: {}".format(shared, exc),
                    xbmc.LOGWARNING)
        # Network paths use forward slash; local paths use os.path.join
        if "://" in shared:
            resolved = shared + "/" + filename
        else:
            resolved = os.path.join(shared, filename)
        log("resolve_path: {} -> {} (shared)".format(filename, resolved))
        return resolved
    resolved = os.path.join(PROFILE, filename)
    log("resolve_path: {} -> {} (local)".format(filename, resolved))
    return resolved


def get_episodes(show_id):
    """Fetch all episodes for a show via JSON-RPC."""
    payload = json.dumps({
        "jsonrpc": "2.0", "id": 1,
        "method": "VideoLibrary.GetEpisodes",
        "params": {
            "tvshowid":   show_id,
            "properties": ["title", "season", "episode", "file",
                           "showtitle", "runtime"],
            "sort":       {"order": "ascending", "method": "episode"},
        }
    })
    try:
        result = json.loads(xbmc.executeJSONRPC(payload))
        return result.get("result", {}).get("episodes", [])
    except Exception as e:
        log("get_episodes error: {}".format(e), xbmc.LOGERROR)
        return []


def advance_state(channel_id, show_id, played_ep_id, channel,
                  next_ep_id=None, next_ep_info=None):
    """
    Advance the state pointer for show_id after played_ep_id finishes.
    Reads state.json, updates it, writes it back.

    next_ep_id:   if provided, use this as the next episode pointer.
    next_ep_info: dict with season/episode for next_ep_id, avoids DB lookup.
                  If not provided and next_ep_id is set, we look it up.
    """
    state_path = resolve_path("state.json")
    state_all  = load_json(state_path, {})
    key        = "{}:{}".format(channel_id, show_id)
    state      = state_all.get(key, {
        "next_episode_id": None,
        "season":          1,
        "episode":         1,
        "played_ids":      [],
    })

    randomize = channel.get("randomize", False)
    recycle   = channel.get("recycle", True)

    # played_ids in the show state entry is not used for no-repeat tracking.
    # The queue tail (__queue_tail__) handles that during queue building.
    # We always write played_ids: [] to keep the state entry clean and to
    # self-heal any legacy bloat from older versions.

    log("advance_state: show={} played={} next_ep_id={} randomize={}".format(
        show_id, played_ep_id, next_ep_id, randomize))

    if next_ep_id is not None:
        # Use episode info from queue if provided - avoids DB roundtrip
        if next_ep_info:
            state.update({
                "next_episode_id": next_ep_id,
                "season":          next_ep_info.get("season",  1),
                "episode":         next_ep_info.get("episode", 1),
                "played_ids":      [],
            })
            log("advance_state: used queue info next_ep_id={} S{}E{}".format(
                next_ep_id,
                next_ep_info.get("season"),
                next_ep_info.get("episode")))
        else:
            # Fall back to DB lookup only when no episode info provided
            episodes = get_episodes(show_id)
            next_ep  = next((e for e in episodes
                             if e["episodeid"] == next_ep_id), None) if episodes else None
            if next_ep:
                state.update({
                    "next_episode_id": next_ep_id,
                    "season":          next_ep.get("season",  1),
                    "episode":         next_ep.get("episode", 1),
                    "played_ids":      [],
                })
                log("advance_state: DB lookup next_ep_id={} S{}E{}".format(
                    next_ep_id,
                    next_ep.get("season"),
                    next_ep.get("episode")))
            else:
                log("advance_state: next_ep_id {} not found".format(
                    next_ep_id), xbmc.LOGWARNING)
                return
    elif randomize:
        # Fallback: queue ran completely dry - pick randomly from full library.
        # This path is rarely reached in normal operation since the top-up
        # keeps the queue populated, but must remain for edge cases.
        episodes = get_episodes(show_id)
        if not episodes:
            log("advance_state: no episodes for show {}".format(show_id),
                xbmc.LOGWARNING)
            return
        ep_ids    = [e["episodeid"] for e in episodes]
        chosen_id = random.choice(ep_ids)
        chosen_ep = next((e for e in episodes
                         if e["episodeid"] == chosen_id), episodes[0])
        state.update({
            "next_episode_id": chosen_id,
            "season":          chosen_ep.get("season",  1),
            "episode":         chosen_ep.get("episode", 1),
            "played_ids":      [],
        })
    else:
        # Sequential mode - next_ep_id is None means show reached end
        # Need episodes list to find current position and wrap/stop
        episodes = get_episodes(show_id)
        if not episodes:
            log("advance_state: no episodes for show {}".format(show_id),
                xbmc.LOGWARNING)
            return
        ep_ids = [e["episodeid"] for e in episodes]
        try:
            idx = ep_ids.index(played_ep_id)
        except ValueError:
            idx = -1
        next_idx = idx + 1
        if next_idx >= len(episodes):
            if not recycle:
                log("Show {} exhausted, recycle=False".format(show_id))
                return
            next_idx = 0
        next_ep = episodes[next_idx]
        state.update({
            "next_episode_id": next_ep["episodeid"],
            "season":          next_ep.get("season",  1),
            "episode":         next_ep.get("episode", 1),
            "played_ids":      [],
        })

    state_all[key] = state
    if save_json(state_path, state_all):
        log("state.json updated: show={} next_ep={}".format(
            show_id, state["next_episode_id"]))
    else:
        log("FAILED to write state.json", xbmc.LOGERROR)


class SmartPlayer(xbmc.Player):
    """
    Long-lived xbmc.Player subclass.
    Tracks currently playing episode and writes state on episode end.
    Also handles exact resume: saves position on stop, seeks on AV start.
    """

    def __init__(self):
        super(SmartPlayer, self).__init__()
        self._lock        = threading.Lock()
        self._current_ep  = None
        self._channel_id  = None
        self._show_id     = None
        self._channel     = None
        self._service_ref = None  # set by SmartChannelsService after init
        self._resume_sought = False
        self._poll_timer    = None
        self._pending_resume_save = None  # (ep, pos, total) set by timer, written by service loop

        # Resume settings are read lazily in _load_resume_settings()
        # the first time set_now_playing() is called. Reading at __init__
        # time is unreliable because the service starts before Kodi has
        # finished loading addon settings, causing getSetting() to return
        # empty strings even when the settings file has correct values.
        self._resume_on_stop = True   # safe defaults until settings load
        self._poll_interval  = 300
        self._resume_ask     = True
        self._resume_settings_loaded = False

        log("SmartPlayer monitor initialised")

    def _load_resume_settings(self):
        """Read resume settings from addon. Called lazily at first channel
        launch to ensure Kodi has fully loaded settings by then."""
        try:
            _addon = xbmcaddon.Addon()
            self._resume_on_stop = (
                _addon.getSetting("resume_on_stop").lower() == "true")
            _interval = int(_addon.getSetting("resume_poll_interval") or "5")
            self._poll_interval  = max(0, _interval) * 60
            self._resume_ask     = (
                _addon.getSetting("resume_ask_user").lower() == "true")
            self._resume_settings_loaded = True
            log("Resume settings loaded: on_stop={} interval={}s ask={}".format(
                self._resume_on_stop, self._poll_interval, self._resume_ask))
        except Exception as _e:
            log("_load_resume_settings error: {} - using defaults".format(_e))

    def set_now_playing(self, ep, channel_id, show_id, channel):
        # Load resume settings on first call — by now Kodi has fully
        # loaded addon settings so getSetting() returns correct values.
        if not self._resume_settings_loaded:
            self._load_resume_settings()
        # Capture the previous episode before overwriting _current_ep.
        # If we are transitioning to a new episode, the previous one
        # finished naturally so its resume entry should be cleared.
        with self._lock:
            prev_ep          = self._current_ep
            self._current_ep = ep
            self._channel_id = channel_id
            self._show_id    = show_id
            self._channel    = channel
            log("set_now_playing: show_id={} ep_id={} title={}".format(
                show_id,
                ep.get("episodeid"),
                ep.get("title")))

        # Clear resume entry for the episode that just finished naturally.
        # onPlayBackEnded only fires when the whole playlist ends, so this
        # is the reliable place to clear between-episode resume entries.
        # Use file path comparison (not episodeid) as the reliable unique
        # identifier — works for both TV episodes and movies.
        prev_file = prev_ep.get("file") if prev_ep else None
        curr_file = ep.get("file")
        log("set_now_playing: prev_file={} curr_file={}".format(
            prev_file, curr_file))
        if prev_ep and prev_file and prev_file != curr_file:
            try:
                svc = self._service_ref
                mgr = svc._get_manager() if svc else None
                if mgr:
                    mgr.clear_resume_position(prev_ep)
                    log("set_now_playing: cleared resume for prev ep={}".format(
                        prev_ep.get("episodeid") or prev_ep.get("movieid")))
                else:
                    log("set_now_playing: no manager, could not clear resume")
            except Exception as _e:
                log("set_now_playing: clear_resume error: {}".format(_e))
        elif not prev_ep:
            log("set_now_playing: no prev_ep to clear")
        elif prev_file == curr_file:
            log("set_now_playing: same file, no clear needed")

        # Start poll timer here as a guaranteed trigger point.
        # onAVStarted also starts it, but set_now_playing is called
        # from the service loop and is reliable on all Kodi versions.
        self._start_poll_timer()

        # Write a minimal state entry for this show if none exists yet.
        # This ensures that if playback is stopped mid-episode before
        # onPlayBackEnded fires, state.json still has an entry for this
        # show pointing to the current episode so resume works correctly.
        # Movies (show_id=0) use __movie_state__ - skip TV-style entry.
        is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
        if is_movie:
            return

        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})
        key        = "{}:{}".format(channel_id, show_id)
        if key not in state_all:
            state_all[key] = {
                "next_episode_id": ep.get("episodeid"),
                "season":          ep.get("season",  1),
                "episode":         ep.get("episode", 1),
                "played_ids":      [],
            }
            save_json(state_path, state_all)
            log("Created initial state entry for show {}".format(show_id))

    def onPlayBackStarted(self):
        log("onPlayBackStarted")
        self._resume_sought = False

    def onAVStarted(self):
        """Fires when AV data is available - safe to call seekTime here."""
        log("onAVStarted")
        if not self._resume_on_stop or self._resume_sought:
            return
        svc = self._service_ref
        if not svc:
            return
        # _current_ep is set by set_now_playing from the service loop.
        # onAVStarted fires almost instantly; the service loop may not have
        # run yet. Run the resume check in a background thread so we can
        # wait as long as needed without blocking the player callback.
        threading.Thread(target=self._do_resume_check, daemon=True).start()

    def _do_resume_check(self):
        """
        Background thread: look up resume entry for the currently playing
        file and seek to it if found.

        Does NOT wait for _current_ep — instead reads the queue file
        directly to find episode metadata for the playing file. This makes
        it resilient to the service loop not having ticked yet.
        """
        svc = self._service_ref
        if not svc:
            return

        # Capture playing file immediately — this is reliable even before
        # the service loop runs.
        try:
            playing_file = self.getPlayingFile()
        except Exception:
            log("_do_resume_check: not playing, aborting")
            return

        if not playing_file:
            return

        # Find the episode in the queue file that matches the playing file.
        # Use the active queue path the service already knows about.
        ep = None
        channel_id = None

        # First try _current_ep (may already be set if service loop was fast)
        with self._lock:
            ep_candidate = self._current_ep
        if ep_candidate and ep_candidate.get("file") == playing_file:
            ep = ep_candidate
            channel_id = (ep.get("_channel_id") or ep.get("channel_id"))

        # If not, scan the queue file directly
        if not ep:
            try:
                queue_path = svc._active_queue_path
                if queue_path and xbmcvfs.exists(queue_path):
                    with xbmcvfs.File(queue_path, "r") as _f:
                        _raw = _f.read()
                    if _raw:
                        import json as _json
                        _queue = _json.loads(_raw)
                        for _item in _queue:
                            if _item.get("file") == playing_file:
                                ep = _item
                                channel_id = (_item.get("_channel_id")
                                              or _item.get("channel_id"))
                                break
            except Exception as _e:
                log("_do_resume_check: queue scan error: {}".format(_e))

        if not ep or not channel_id:
            log("_do_resume_check: could not identify playing episode")
            return

        if self._resume_sought:
            return

        mgr = svc._get_manager()
        if not mgr:
            return

        # Build the resume key directly so we read from shared state first,
        # then local backup — both may have valid entries.
        is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
        item_id  = (ep.get("movieid", -1) if is_movie
                    else ep.get("episodeid", -1))
        if not item_id or item_id < 0:
            return

        try:
            entry = mgr.get_resume_position(ep)
        except Exception as _e:
            log("_do_resume_check: get_resume_position error: {}".format(_e))
            return

        if not entry:
            self._start_poll_timer()
            return

        position = entry.get("position", 0)
        title    = ep.get("title", "")
        ts       = "{:d}:{:02d}".format(int(position) // 60, int(position) % 60)

        # Pause immediately so the user doesn't see the beginning of the
        # episode play while the dialog is shown.
        try:
            self.pause()
            log("_do_resume_check: paused for resume dialog")
        except Exception as _e:
            log("_do_resume_check: pause error: {}".format(_e))

        do_seek = True
        if self._resume_ask:
            choice = xbmcgui.Dialog().yesno(
                "Smart TV Channels",
                "{} — resume from {}?".format(title[:40], ts),
                nolabel="Start Over",
                yeslabel="Resume")
            do_seek = choice
        self._resume_sought = True
        try:
            if do_seek:
                self.seekTime(position)
                log("_do_resume_check: sought to {:.0f}s for {}".format(
                    position, title))
            else:
                # User chose Start Over — seek to beginning
                self.seekTime(0)
                log("_do_resume_check: start over, seeking to 0")
            # Give Kodi a moment to complete the seek, then explicitly
            # resume. We use xbmc.executebuiltin("PlayerControl(Play)")
            # rather than pause() toggle or isPaused() check because
            # seekTime() can reset the paused state internally, making
            # isPaused() unreliable immediately after a seek.
            xbmc.sleep(500)
            xbmc.executebuiltin("PlayerControl(Play)")
            log("_do_resume_check: resumed playback")
        except Exception as _e:
            log("_do_resume_check: seek/resume error: {}".format(_e))
        self._start_poll_timer()

    def onPlayBackEnded(self):
        """
        Fires when an item in the playlist finishes naturally.
        Advance state and increment _queue_position so the skip
        detector in _check_now_playing does not double-count this
        as a skip when the next item starts.
        Clear any resume entry since item finished naturally.
        """
        log("onPlayBackEnded - advancing state")
        self._stop_poll_timer()
        # Clear resume entry - item finished naturally, no need to resume
        svc = self._service_ref
        if svc:
            with self._lock:
                ep = self._current_ep
            if ep:
                try:
                    mgr = svc._get_manager()
                    if mgr:
                        mgr.clear_resume_position(ep)
                except Exception as _e:
                    log("onPlayBackEnded: clear_resume error: {}".format(_e))
        self._handle_end()
        self._resume_sought = False
        # Increment position so skip detector knows this end was natural
        if self._service_ref:
            self._service_ref._queue_position += 1
            log("onPlayBackEnded - queue_position advanced to {}".format(
                self._service_ref._queue_position))

    def onPlayBackStopped(self):
        """
        User stopped playback manually. Resume position is already saved
        in state.json by the poll timer — nothing to promote. Do NOT
        advance state so the stopped episode remains current.
        """
        log("onPlayBackStopped - resume position already saved by poll timer")
        self._stop_poll_timer()
        if self._resume_on_stop:
            # Poll timer already wrote position directly to state.json on
            # the shared path — nothing more to do on a clean stop.
            log("onPlayBackStopped: resume position already in state.json "
                "from last poll save")
        with self._lock:
            self._current_ep = None
        self._resume_sought = False

    def onPlayBackError(self):
        log("onPlayBackError - advancing state")
        self._stop_poll_timer()
        self._handle_end()

    def _start_poll_timer(self):
        """Start background polling timer to save position locally."""
        self._stop_poll_timer()
        if not self._resume_on_stop or self._poll_interval <= 0:
            return
        self._poll_timer = threading.Timer(
            self._poll_interval, self._poll_save)
        self._poll_timer.daemon = True
        self._poll_timer.start()
        log("Poll timer started ({:.0f}s interval)".format(self._poll_interval))

    def _stop_poll_timer(self):
        """Cancel the background poll timer if running."""
        if self._poll_timer:
            self._poll_timer.cancel()
            self._poll_timer = None

    def _poll_save(self):
        """Store current position for the service loop to write on main thread.
        xbmcvfs SMB writes must happen on the main thread on Android/Shield."""
        try:
            with self._lock:
                ep = self._current_ep
            if ep:
                pos   = self.getTime()
                total = self.getTotalTime()
                if pos > 10:
                    self._pending_resume_save = (ep, pos, total)
                    log("Poll save queued: {:.0f}s (will write on main thread)".format(pos))
        except Exception as _e:
            log("_poll_save error: {}".format(_e))
        self._start_poll_timer()

    def _handle_end(self):
        with self._lock:
            ep         = self._current_ep
            channel_id = self._channel_id
            show_id    = self._show_id
            channel    = self._channel

        if not ep and self._service_ref:
            # _current_ep was cleared (e.g. by a rapid stop+play).
            # Fall back to queue[_queue_position] which is the item
            # that just finished naturally.
            svc = self._service_ref
            pos = max(0, svc._queue_position - 1)
            if svc._queue and pos < len(svc._queue):
                fallback = svc._queue[pos]
                ep       = fallback
                show_id  = fallback.get("show_id", 0)
                if not channel_id:
                    channel_id = fallback.get("channel_id",
                                              fallback.get("_channel_id"))
                if not channel and channel_id:
                    channel = svc._get_channel(channel_id)
                log("_handle_end: used queue fallback ep={} show={}".format(
                    ep.get("episodeid"), show_id))

        if not ep or not channel_id or not channel:
            log("_handle_end: missing context - ep={} ch={} show={}".format(
                ep, channel_id, show_id), xbmc.LOGWARNING)
            return

        # Movie channels: update movie state directly.
        # Interleaved movies (_interleaved=True) are from a foreign channel
        # and must NOT update that channel's played_ids when watched inside
        # the primary TV channel.
        if ep.get("is_movie") or ep.get("movieid", -1) > 0:
            # Always advance movie state for interleaved movies too,
            # so the foreign channel tracks which movies have been seen.
            service_ref = self._service_ref
            if service_ref:
                service_ref._advance_movie_state(channel_id, ep, channel)
            else:
                log("_handle_end: no service_ref, cannot advance movie state",
                    xbmc.LOGWARNING)
            return

        if not show_id:
            log("_handle_end: no show_id for TV episode", xbmc.LOGWARNING)
            return

        # Find the next episode for this show in the queue so state
        # stays in sync with the pre-determined queue order.
        # Pass full episode info to avoid DB lookup.
        next_ep_id   = None
        next_ep_info = None
        service_ref  = self._service_ref
        if service_ref:
            queue = service_ref._queue
            for i, q_ep in enumerate(queue):
                if q_ep.get("episodeid") == ep.get("episodeid"):
                    for future_ep in queue[i + 1:]:
                        if future_ep.get("show_id") == show_id:
                            next_ep_id   = future_ep.get("episodeid")
                            next_ep_info = {
                                "season":  future_ep.get("season",  1),
                                "episode": future_ep.get("episode", 1),
                            }
                            break
                    break

        advance_state(channel_id, show_id,
                      ep.get("episodeid", -1), channel,
                      next_ep_id=next_ep_id,
                      next_ep_info=next_ep_info)


class SmartChannelsService(xbmc.Monitor):
    """Main service - runs for Kodi's lifetime."""

    def __init__(self):
        super(SmartChannelsService, self).__init__()
        self.player           = SmartPlayer()
        self.player._service_ref = self   # give player access to queue
        self.pointer_path     = resolve_path("now_playing.json")
        self.channels_path    = resolve_path("channels.json")
        self._active_queue_path = None    # path to current channel queue file
        self._last_file       = None
        self._current_file    = None
        self._queue           = []
        self._queue_position  = 0    # tracks current position for skip detection
        log("Service started - profile={}".format(PROFILE))

        # Check if local library cache needs rebuilding
        # Do this in background so it doesn't block service startup
        self._start_cache_rebuild_if_needed()

        # Orphaned shared folder check:
        # If Kodi's 'Remove + delete data' wiped the local profile but
        # the shared folder setting survived (stored in Kodi's addon DB,
        # not in the profile), offer to clean the shared folder.
        threading.Thread(target=self._check_orphaned_shared_data,
                         daemon=True).start()

    def _get_channel(self, channel_id):
        channels = load_json(self.channels_path, [])
        for ch in channels:
            if ch["id"] == channel_id:
                return ch
        return None

    def _get_manager(self):
        """Return a ChannelManager instance (created on demand)."""
        try:
            from resources.lib.channel_manager import ChannelManager
            return ChannelManager(xbmcaddon.Addon())
        except Exception as _e:
            log("_get_manager error: {}".format(_e), xbmc.LOGWARNING)
            return None

    def _check_now_playing(self):
        """
        Read now_playing.json pointer to find the active channel queue file,
        then load the per-channel queue and match the currently playing file.

        Also handles SKIPPING: when the playing file changes, we find
        all episodes that were skipped over and advance their state pointers.
        """
        # Step 1: Read pointer file to find active channel queue.
        # Try shared path first; fall back to local profile copy
        # (player.py always writes both, so local is always current).
        pointer_raw = None
        for ptr_path in [self.pointer_path,
                         os.path.join(PROFILE, "now_playing.json")]:
            if not xbmcvfs.exists(ptr_path):
                continue
            try:
                with xbmcvfs.File(ptr_path, "r") as f:
                    pointer_raw = f.read()
                if pointer_raw:
                    break
            except Exception:
                continue

        if not pointer_raw:
            return

        try:
            pointer = json.loads(pointer_raw)
            queue_filename = pointer.get("queue_file", "")
            if not queue_filename:
                return
            queue_path = resolve_path(queue_filename)
        except Exception as e:
            log("Cannot parse now_playing pointer: {}".format(e),
                xbmc.LOGWARNING)
            return

        # Step 2: Load the per-channel queue file
        if not xbmcvfs.exists(queue_path):
            return

        try:
            with xbmcvfs.File(queue_path, "r") as f:
                raw = f.read()
        except Exception as e:
            log("Cannot read queue file: {}".format(e), xbmc.LOGWARNING)
            return

        if not raw:
            return

        # Reload queue if file changed OR if we switched to a different channel
        channel_switched = (queue_path != self._active_queue_path
                            and self._active_queue_path is not None)
        content_changed  = (raw != self._last_file)

        if content_changed or channel_switched:
            if channel_switched:
                log("Channel switched - resetting queue state")
            elif content_changed:
                log("Queue file content changed - resetting position")

            # Always reset position and current file tracking when the
            # queue content changes. This covers:
            #   - Channel switch (different queue_path)
            #   - Same channel replayed (new random order written by
            #     _write_now_playing overwrites pregenerated queue)
            #   - Queue regenerated or refilled
            self._current_file   = None  # force re-registration
            self._queue_position = 0
            self._last_file         = raw
            self._active_queue_path = queue_path
            try:
                self._queue = json.loads(raw)
                log("Queue loaded from {}: {} items".format(
                    queue_filename, len(self._queue)))
                self._queue_position = self._find_resume_position(self._queue)
                log("Queue position seeded to {} on load".format(
                    self._queue_position))
            except Exception as e:
                log("Queue file parse error: {}".format(e), xbmc.LOGWARNING)
                return

        if not self.player.isPlaying():
            return

        # Get currently playing file path
        try:
            playing_file = self.player.getPlayingFile()
        except Exception as e:
            log("getPlayingFile error: {}".format(e), xbmc.LOGWARNING)
            return

        if playing_file == self._current_file:
            return  # Already registered this file - nothing to do

        log("File change detected: {}".format(playing_file))
        log("Current queue has {} items, last_position={}".format(
            len(self._queue), self._queue_position))

        # New file detected - find its position in the queue.
        #
        # A movie (or episode) may appear more than once in the queue
        # (e.g. a 13-movie channel with queue_size=20 repeats 7 movies).
        # We use Kodi's playlist position as the ground truth when available,
        # since file path matching alone cannot distinguish two identical files
        # at different queue positions (e.g. skip to occurrence 2 of a movie).
        last_position = self._queue_position
        new_position  = None

        def _file_matches(ep, playing_file):
            queue_file = ep.get("file", "")
            if queue_file == playing_file:
                return True
            if queue_file and playing_file:
                qf = queue_file.split("/")[-1].split("\\")[-1]
                pf = playing_file.split("/")[-1].split("\\")[-1]
                if qf and pf and qf == pf:
                    return True
            return False

        # Strategy 1: Use Kodi's playlist position directly.
        # xbmc.PlayList.getposition() returns the current cursor index.
        # This is the most reliable method and handles duplicate files.
        try:
            playlist    = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            kodi_pos    = playlist.getposition()
            if (kodi_pos >= 0 and kodi_pos < len(self._queue)
                    and _file_matches(self._queue[kodi_pos], playing_file)):
                new_position = kodi_pos
                log("Matched at queue[{}] via Kodi playlist position".format(
                    kodi_pos))
        except Exception as e:
            log("getposition() failed: {}".format(e), xbmc.LOGWARNING)

        # Strategy 2: Fallback - scan forward from last_position.
        # Used when Kodi position is unavailable or doesn't match
        # (e.g. queue was refilled and Kodi/internal positions diverged).
        if new_position is None:
            for i in range(last_position, len(self._queue)):
                if _file_matches(self._queue[i], playing_file):
                    new_position = i
                    log("Matched at queue[{}] (forward scan from {})".format(
                        i, last_position))
                    break

        # Strategy 3: Wrap-around scan from beginning.
        if new_position is None:
            for i in range(0, last_position):
                if _file_matches(self._queue[i], playing_file):
                    new_position = i
                    log("Matched at queue[{}] (wrap-around scan)".format(i))
                    break

        if new_position is None:
            log("Playing file not found in queue: {}".format(playing_file),
                xbmc.LOGWARNING)
            log("Queue files: {}".format(
                [ep.get("file","").split("/")[-1]
                 for ep in self._queue[:5]]))
            return

        log("New file at queue[{}]: {}".format(
            new_position, playing_file.split("/")[-1]))

        # SKIP DETECTION: if new_position > last_position + 1,
        # episodes were skipped. Advance state for each skipped episode
        # so state.json reflects the true watch position.
        # last_position already set during file matching above
        log("Skip check: new_position={} last_position={}".format(
            new_position, last_position))
        if new_position > last_position:
            skipped_count = new_position - last_position
            log("Detected {} skipped episode(s) - advancing state".format(
                skipped_count))
            for skip_idx in range(last_position, new_position):
                skipped_ep = self._queue[skip_idx]
                skip_channel_id = skipped_ep.get("channel_id", "")
                skip_show_id    = skipped_ep.get("show_id",    0)
                skip_channel    = self._get_channel(skip_channel_id)
                if skip_channel:
                    # Handle movie skips separately.
                    # Interleaved movies (_interleaved=True) belong to a
                    # foreign channel and must NOT update that channel's
                    # played_ids - they were not watched in their own channel.
                    if (skipped_ep.get("is_movie")
                            or skipped_ep.get("movieid", -1) > 0):
                        is_interleaved = skipped_ep.get("_interleaved", False)
                        log("Skip loop movie: id={} title={} interleaved={}".format(
                            skipped_ep.get("movieid", -1),
                            skipped_ep.get("title", "?")[:20],
                            is_interleaved))
                        # Always advance movie state - whether interleaved
                        # or not. This ensures the foreign channel's
                        # __movie_state__ tracks which movies have been
                        # seen via interleave so they don't repeat until
                        # all have been seen (then recycle).
                        self._advance_movie_state(
                            skip_channel_id, skipped_ep, skip_channel)
                        continue

                    log("Advancing skipped ep: queue[{}] show={} ep={}".format(
                        skip_idx, skip_show_id,
                        skipped_ep.get("episodeid")))
                    # Clear any resume entry for the skipped episode so it
                    # doesn't incorrectly offer to resume next time it appears.
                    try:
                        _mgr = self._get_manager()
                        if _mgr:
                            _mgr.clear_resume_position(skipped_ep)
                    except Exception as _ce:
                        log("Skip: clear_resume error: {}".format(_ce))
                    next_ep_id   = None
                    next_ep_info = None
                    for future_idx in range(skip_idx + 1, len(self._queue)):
                        future_ep = self._queue[future_idx]
                        if future_ep.get("show_id") == skip_show_id:
                            next_ep_id   = future_ep.get("episodeid")
                            next_ep_info = {
                                "season":  future_ep.get("season",  1),
                                "episode": future_ep.get("episode", 1),
                            }
                            break
                    advance_state(
                        channel_id   = skip_channel_id,
                        show_id      = skip_show_id,
                        played_ep_id = skipped_ep.get("episodeid", -1),
                        channel      = skip_channel,
                        next_ep_id   = next_ep_id,
                        next_ep_info = next_ep_info,
                    )

        # Update position and register the now-playing episode
        self._queue_position = new_position
        self._current_file   = playing_file

        ep = self._queue[new_position]

        # The item's channel_id may be a FOREIGN channel (interleaved item).
        # For state advancement we use the item's own channel_id.
        # For queue file management we ALWAYS use the PRIMARY channel id
        # (from the queue file we are currently tracking) so we never
        # accidentally overwrite the foreign channel's queue file.
        item_channel_id    = ep.get("channel_id", "")
        show_id            = ep.get("show_id",    0)
        item_channel       = self._get_channel(item_channel_id)

        # Derive primary channel id from the active queue file path
        # e.g. ".../queue_abc123.json" -> "abc123..."
        import re as _re
        primary_channel_id = item_channel_id  # fallback
        if self._active_queue_path:
            m = _re.search(r"queue_([^.]+)[.]json$", self._active_queue_path)
            if m:
                primary_channel_id = m.group(1)
        primary_channel = self._get_channel(primary_channel_id)

        if item_channel:
            self.player.set_now_playing(
                ep, item_channel_id, show_id, item_channel)

        if primary_channel:
            # Save show index using primary channel context
            shows    = primary_channel.get("shows", [])
            show_ids = [s["tvshowid"] for s in shows]
            if show_id in show_ids:
                idx = show_ids.index(show_id)
                self._save_show_index(primary_channel_id, idx)

            # Rewrite the queue file using the PRIMARY channel id
            # so interleaved items never corrupt the foreign channel's file
            self._update_queue_file(primary_channel_id, new_position)
        elif item_channel:
            # Primary channel not found but item channel is - use item channel
            # as last resort (shouldn't happen in normal operation)
            log("Primary channel not found, using item channel for queue update",
                xbmc.LOGWARNING)
            self._update_queue_file(item_channel_id, new_position)
        else:
            log("Channel {} not found in channels.json".format(
                item_channel_id), xbmc.LOGWARNING)

    def _advance_movie_state(self, channel_id, ep, channel):
        """
        Update movie played state when a movie finishes.
        Marks the movie as played in __movie_state__ so it
        won't repeat until all movies in the channel have played.
        """
        movie_id   = ep.get("movieid", -1)
        if movie_id < 0:
            return

        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})
        key        = "{}:__movie_state__".format(channel_id)
        mstate     = state_all.get(key, {"played_ids": [], "next_index": 0})

        played_ids   = list(mstate.get("played_ids", []))
        unplayed_ids = list(mstate.get("unplayed_ids", []))

        # Add to played, remove from unplayed.
        # interleave_order/interleave_index are NOT modified here —
        # they are managed purely by _build_movie_queue.
        if movie_id not in played_ids:
            played_ids.append(movie_id)
        if movie_id in unplayed_ids:
            unplayed_ids.remove(movie_id)

        # Look up the actual movie channel
        from resources.lib.channel_manager import ChannelManager as _CM
        _mgr         = _CM(ADDON)
        movie_ch     = _mgr.get_channel(channel_id)
        if movie_ch:
            total_movies  = len(movie_ch.get("movies", []))
            do_recycle    = movie_ch.get("recycle", True)
            all_movie_ids = [m["movieid"] for m in movie_ch.get("movies", [])]
        else:
            total_movies  = len(channel.get("movies", []))
            do_recycle    = channel.get("recycle", True)
            all_movie_ids = [m["movieid"] for m in channel.get("movies", [])]

        # When unplayed pool is empty, all movies have been seen this cycle
        if not unplayed_ids and total_movies > 0:
            if do_recycle:
                log("Movie channel exhausted ({}/{}) - recycling".format(
                    len(played_ids), total_movies))
                played_ids   = []
                unplayed_ids = list(all_movie_ids)
            else:
                log("Movie channel exhausted - recycle=False")
        elif total_movies == 0:
            log("_advance_movie_state: could not determine total movies "
                "for channel {}".format(channel_id))

        mstate["played_ids"]   = played_ids
        mstate["unplayed_ids"] = unplayed_ids
        state_all[key]         = mstate
        save_json(state_path, state_all)
        log("Movie state updated: played={} unplayed={} total={}".format(
            len(played_ids), len(unplayed_ids), total_movies))

    def _find_resume_position(self, queue):
        """
        Find the correct starting position in the queue.

        For movie queues: always return 0. Movie entries use episodeid=-1
        which is meaningless for position detection. The queue file is
        already written in the correct playback order by _write_now_playing
        or trimmed by _update_queue_file.

        For TV queues: the queue file is trimmed so position 0 is always
        correct in normal operation. We only need to scan if the queue
        was not trimmed (fresh channel, regenerated queue).
        """
        if not queue:
            return 0

        # Movie queues: episodeid=-1 for all entries - always start at 0
        if queue[0].get("is_movie") or queue[0].get("movieid", -1) > 0:
            log("_find_resume_position: movie queue - starting at 0")
            return 0

        # TV queues: use state.json to verify position
        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})

        all_played   = set()
        all_next_ids = set()
        for key, val in state_all.items():
            if isinstance(val, dict):
                if "played_ids" in val:
                    all_played.update(val.get("played_ids", []))
                nid = val.get("next_episode_id")
                if nid is not None and nid != -1:
                    all_next_ids.add(nid)

        first_ep_id = queue[0].get("episodeid")

        # Queue is correctly trimmed - start at 0
        if first_ep_id in all_next_ids or first_ep_id not in all_played:
            log("_find_resume_position: TV queue correctly trimmed, "
                "starting at 0 (ep={})".format(first_ep_id))
            return 0

        # Queue not trimmed - scan for first next_episode_id match
        if all_next_ids:
            for i, ep in enumerate(queue):
                if ep.get("episodeid") in all_next_ids:
                    log("_find_resume_position: found next_ep at "
                        "index {}".format(i))
                    return max(0, i - 1)

        # Final fallback: first unplayed episode
        for i, ep in enumerate(queue):
            if ep.get("episodeid") not in all_played:
                log("_find_resume_position: first unplayed at "
                    "index {}".format(i))
                return max(0, i - 1)

        return 0

    def _persist_queue(self):
        """
        Write the current in-memory queue to its queue file on disk.
        Called by onAVStarted so the queue file stays current after
        each skip or natural episode end.
        Always re-resolves the destination via resolve_path() so a
        shared-path change mid-session is picked up immediately.
        """
        if not self._active_queue_path or not self._queue:
            return
        try:
            import os as _os
            # Re-resolve filename through current shared path setting
            import re as _re2
            _m = _re2.search(r'(queue_[^/\\]+\.json)$',
                             self._active_queue_path)
            queue_filename = _m.group(1) if _m else \
                os.path.basename(self._active_queue_path)
            dest = resolve_path(queue_filename)
            # Update cached path so _update_queue_file stays in sync
            self._active_queue_path = dest
            json_str = json.dumps(self._queue, indent=2)
            is_shared = not dest.startswith(PROFILE)
            if not is_shared:
                with xbmcvfs.File(dest, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os.path.join(PROFILE, _os.path.basename(dest))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, dest):
                    if "://" not in dest:
                        with open(local_copy, "r", encoding="utf-8") as _s, \
                             open(dest, "w", encoding="utf-8") as _d:
                            _d.write(_s.read())
            log("_persist_queue: wrote {} items to {}".format(
                len(self._queue), self._active_queue_path))
        except Exception as e:
            log("_persist_queue error: {}".format(e), xbmc.LOGWARNING)

    def _update_queue_file(self, channel_id, current_position):
        """
        Rewrite the per-channel queue file starting from current_position.
        After trimming, checks if remaining items are below the replenishment
        threshold. If so, triggers a background top-up so playback never
        runs dry.
        """
        queue_path = resolve_path("queue_{}.json".format(channel_id))
        try:
            remaining = self._queue[current_position:]

            # Check replenishment threshold BEFORE writing.
            # Use len(remaining) - 1 because remaining[0] is the currently
            # playing item and is already consumed from the user's perspective.
            channel   = self._get_channel(channel_id)
            if channel:
                threshold    = self._get_threshold(channel)
                items_left   = max(0, len(remaining) - 1)
                if items_left <= threshold:
                    log("Queue below threshold ({} <= {}) - triggering "
                        "top-up for channel {}".format(
                        items_left, threshold, channel_id[:8]))
                    remaining = self._topup_in_background(
                        channel, remaining)

            import os as _os
            json_str = json.dumps(remaining, indent=2)
            is_shared = not queue_path.startswith(PROFILE)
            if not is_shared:
                with xbmcvfs.File(queue_path, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os.path.join(PROFILE,
                                           _os.path.basename(queue_path))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, queue_path):
                    log("_update_queue_file copy failed {}, open() fallback".format(
                        queue_path), xbmc.LOGWARNING)
                    if "://" not in queue_path:
                        with open(local_copy, "r", encoding="utf-8") as _s, \
                             open(queue_path, "w", encoding="utf-8") as _d:
                            _d.write(_s.read())

            # Update in-memory state
            self._queue             = remaining
            self._queue_position    = 0
            self._active_queue_path = queue_path
            self._last_file         = json.dumps(remaining, indent=2)
            log("Queue file updated for channel {}: {} items remaining".format(
                channel_id[:8], len(remaining)))

            # No playlist manipulation during active playback.
            # The playlist append on top-up (in _topup_in_background)
            # is sufficient to keep Kodi from running out of items.
            # Clearing/rebuilding the playlist while playing causes
            # Kodi to skip the current item and corrupts movie state.
        except Exception as e:
            log("_update_queue_file error: {}".format(e), xbmc.LOGWARNING)

    def _get_threshold(self, channel):
        """Return replenishment threshold from user setting."""
        try:
            threshold = max(1, int(
                ADDON.getSetting("refill_threshold") or "15"))
            queue_size = channel.get("queue_size",
                max(10, int(ADDON.getSetting(
                    "default_queue_size") or "30")))
            # Cap threshold at half queue_size so it doesn't fire
            # on every item when threshold >= queue_size
            if threshold >= queue_size:
                threshold = max(1, queue_size // 2)
            return threshold
        except Exception:
            return 15

    def _topup_in_background(self, channel, current_queue):
        """
        Top up the queue synchronously. Returns the extended queue.
        Uses refill_queue so interleave is applied to new tail items.
        Also appends new items to Kodi's active video playlist so
        playback continues without hitting 'can't find item to play'.
        """
        try:
            threshold = self._get_threshold(channel)

            from resources.lib.channel_manager import ChannelManager
            from resources.lib.player import _make_listitem
            import xbmcaddon
            addon   = xbmcaddon.Addon()
            manager = ChannelManager(addon)

            extended = manager.refill_queue(channel, current_queue, threshold)
            new_items = extended[len(current_queue):]

            # Append new items to Kodi's live video playlist so the player
            # doesn't run out of items before the top-up is visible.
            if new_items:
                try:
                    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    for ep in new_items:
                        li = _make_listitem(ep)
                        playlist.add(ep["file"], li)
                    log("Top-up: appended {} items to Kodi playlist "
                        "(playlist now {} items)".format(
                            len(new_items), playlist.size()))
                except Exception as pe:
                    log("Top-up playlist append error: {}".format(pe),
                        xbmc.LOGWARNING)

            log("Top-up complete: {} -> {} items".format(
                len(current_queue), len(extended)))
            return extended
        except Exception as e:
            log("_topup_in_background error: {}".format(e), xbmc.LOGWARNING)
            return current_queue

    def onNotification(self, sender, method, data):
        """
        Listen for Kodi library scan completion to auto-rebuild cache.
        """
        if method == "VideoLibrary.OnScanFinished":
            log("VideoLibrary.OnScanFinished - rebuilding library cache")
            xbmc.executebuiltin(
                "Notification(Smart TV Channels,"
                "Library scan done - updating cache...,3000)")
            threading.Thread(
                target=self._rebuild_library_cache,
                daemon=True).start()

    def _start_cache_rebuild_if_needed(self):
        """
        Start a background cache rebuild if the local cache is missing
        or older than the configured max age (default 7 days).
        Shows a toast notification so user knows what is happening.
        """
        try:
            import xbmcaddon as _xbmcaddon
            from resources.lib.library import LibraryClient
            addon   = _xbmcaddon.Addon()
            library = LibraryClient(addon)

            max_age = int(addon.getSetting("cache_max_age_days") or "7")
            age     = library.local_cache_age_days()

            auto_rebuild = addon.getSetting(
                "cache_auto_rebuild") != "false"
            if age > max_age:
                if not library.local_cache_exists():
                    msg = "Building library cache for first time..."
                    log("[Service] {}".format(msg))
                    xbmc.executebuiltin(
                        "Notification(Smart TV Channels,{},4000)".format(msg))
                    threading.Thread(
                        target=self._rebuild_library_cache,
                        daemon=True).start()
                elif auto_rebuild:
                    msg = "Refreshing library cache ({:.0f} days old)...".format(
                        age)
                    log("[Service] {}".format(msg))
                    xbmc.executebuiltin(
                        "Notification(Smart TV Channels,{},4000)".format(msg))
                    threading.Thread(
                        target=self._rebuild_library_cache,
                        daemon=True).start()
                else:
                    log("[Service] Cache is {:.0f} days old but "
                        "auto-rebuild is disabled".format(age))
            else:
                log("[Service] Local cache is {:.1f} days old - OK".format(age))
        except Exception as e:
            log("[Service] Cache check error: {}".format(e))

    def _rebuild_library_cache(self):
        """
        Rebuild the local library cache in a background thread.
        Shows progress via Kodi notifications.
        """
        try:
            import xbmcaddon as _xbmcaddon
            from resources.lib.library import LibraryClient
            addon   = _xbmcaddon.Addon()
            library = LibraryClient(addon)

            log("[Service] Background cache rebuild started")

            def _on_progress(pct, msg):
                log("[Service] Cache rebuild {}%: {}".format(pct, msg))

            success = library.build_local_cache(
                progress_callback=_on_progress)

            if success:
                xbmc.executebuiltin(
                    "Notification(Smart TV Channels,"
                    "Library cache updated!,3000)")
                log("[Service] Cache rebuild complete")
            else:
                xbmc.executebuiltin(
                    "Notification(Smart TV Channels,"
                    "Cache rebuild failed - check logs,4000)")
        except Exception as e:
            log("[Service] Cache rebuild error: {}".format(e))

    def _save_show_index(self, channel_id, show_index):
        """
        Persist which show index is currently playing so build_queue
        can resume from the right show after a mid-episode stop.
        """
        state_path = resolve_path("state.json")
        state_all  = load_json(state_path, {})
        key        = "{}:__show_index__".format(channel_id)
        state_all[key] = show_index
        save_json(state_path, state_all)
        log("Saved show_index={} for channel {}".format(show_index, channel_id))

    def _check_orphaned_shared_data(self):
        """
        Called at startup.  If the shared folder has addon data files
        but the local profile has NO channels.json, it likely means
        Kodi's built-in 'Remove addon + delete data' wiped the local
        profile but left the shared folder untouched.
        Show a notification so the user knows to use
        [Delete All Addon Data] before removing the addon.
        """
        try:
            raw = ADDON.getSetting("shared_storage_path").strip()
            if raw in ("", "smb://", "smb:/"):
                return  # no shared folder configured
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = raw.lstrip("\\/")
                raw = "smb://" + raw.replace("\\", "/")
            shared = raw.rstrip("/").rstrip("\\")
            if not shared:
                return

            # Check shared folder has data files
            if "://" in shared:
                shared_channels = shared + "/channels.json"
            else:
                shared_channels = os.path.join(shared, "channels.json")

            if not xbmcvfs.exists(shared_channels):
                return  # shared folder is already empty - nothing to warn about

            # Check local profile is missing channels.json
            local_channels = os.path.join(PROFILE, "channels.json")
            if xbmcvfs.exists(local_channels):
                return  # local profile intact - normal startup

            # If shared storage is configured and local channels.json is
            # missing, this is the expected state for a secondary client —
            # channels live on the shared path by design. Only the primary
            # client (the one that created the channels) has a local copy.
            # There is no orphan scenario here so we return silently.
            #
            # True orphan detection (local wiped without Delete All) would
            # require a separate marker file written locally — not worth the
            # complexity for a home multi-client setup.
            return
        except Exception as e:
            log("[Service] _check_orphaned_shared_data error: {}".format(e))

    def run(self):
        log("Service run loop started")
        consecutive_errors = 0
        tick = 0
        while not self.abortRequested():
            try:
                # Flush any pending resume save from poll timer thread.
                # Written here on the main thread so xbmcvfs SMB works
                # correctly on all platforms including Android/Shield.
                pending = self.player._pending_resume_save
                if pending:
                    self.player._pending_resume_save = None
                    ep, pos, total = pending
                    try:
                        mgr = self._get_manager()
                        if mgr:
                            mgr.save_resume_position(ep, pos, total)
                            log("Poll save written: {:.0f}s".format(pos))
                    except Exception as _pe:
                        log("Poll save write error: {}".format(_pe))
                self._check_now_playing()
                consecutive_errors = 0
            except Exception as e:
                consecutive_errors += 1
                log("Service loop error #{}: {} - continuing".format(
                    consecutive_errors, e), xbmc.LOGWARNING)
                import traceback
                log("Traceback: {}".format(traceback.format_exc()),
                    xbmc.LOGWARNING)
                # Back off slightly on persistent errors but never stop
                if consecutive_errors > 10:
                    if self.waitForAbort(5):
                        break
                    continue

            # Heartbeat every 5 minutes so we can confirm service is alive
            tick += 1
            if tick % 300 == 0:
                log("Service heartbeat: still running (tick={})".format(tick))

            if self.waitForAbort(1):
                break
        log("Service stopped")


if __name__ == "__main__":
    service = SmartChannelsService()
    service.run()
