"""
resources/lib/ui/channels.py
==============================
All channel-related UI. Uses addon.getLocalizedString() with fallbacks.
"""

from __future__ import annotations

from urllib.parse import urlencode
from typing import Optional

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

from resources.lib.channel_manager import ChannelManager
from resources.lib.utils.logger     import log


def _s(addon, sid, fallback):
    """Get localised string with hardcoded fallback."""
    v = addon.getLocalizedString(sid)
    return v if v.strip() else fallback


class ChannelUI:

    def __init__(self, handle, base_url, addon, manager):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon
        self.manager  = manager

    def _url(self, **kwargs):
        return "{}?{}".format(self.base_url, urlencode(kwargs))

    def _s(self, sid, fallback):
        return _s(self.addon, sid, fallback)

    # -- Channel list ----------------------------------------------------------

    def list_channels(self, params):
        channels = self.manager.get_visible_channels()
        log("[ChannelUI] list_channels - {} visible channels".format(len(channels)))

        for ch in channels:
            self._add_channel_item(ch)

        # Read management items toggle — default True (show them)
        try:
            _show_mgmt = self.addon.getSetting(
                "show_management_items") != "false"
        except Exception:
            _show_mgmt = True

        if _show_mgmt:
            li = xbmcgui.ListItem(label="[+ Create New Channel]")
            li.setArt({"icon": "DefaultAddSource.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="create_channel"),
                li, isFolder=False)

            # Show cache status in label
            import os as _os2
            import xbmcvfs as _xbmcvfs2
            _profile2    = _xbmcvfs2.translatePath(
                self.addon.getAddonInfo("profile"))
            _cache_path2 = _os2.path.join(_profile2, "local_library.json")
            if _xbmcvfs2.exists(_cache_path2):
                try:
                    import time as _time2
                    _stat2    = _xbmcvfs2.Stat(_cache_path2)
                    _age2     = (_time2.time() - _stat2.st_mtime()) / 86400.0
                    _clabel   = "[Refresh Library Cache] ({:.0f}d old)".format(
                        _age2)
                except Exception:
                    _clabel = "[Refresh Library Cache]"
            else:
                _clabel = "[Build Library Cache - Not built yet]"
            li = xbmcgui.ListItem(label=_clabel)
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="refresh_library"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label="[Settings]")
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="open_settings"),
                li, isFolder=False)

            # Show clear shared path only when a shared path is configured
            try:
                _shared = self.addon.getSetting(
                    "shared_storage_path").strip()
                _shared_active = (bool(_shared)
                                  and _shared not in ("smb://", "smb:/"))
            except Exception:
                _shared_active = False
            if _shared_active:
                li = xbmcgui.ListItem(
                    label="[Use Kodi Addon Data Folder (clear shared path)]")
                li.setArt({"icon": "DefaultAddonNone.png"})
                xbmcplugin.addDirectoryItem(
                    self.handle, self._url(action="clear_shared_path"),
                    li, isFolder=False)

            li = xbmcgui.ListItem(label="[Backup Addon Data]")
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="backup_data"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label="[Restore Addon Data]")
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="restore_data"),
                li, isFolder=False)

            li = xbmcgui.ListItem(
                label="[Delete All Addon Data (run before uninstalling)]")
            li.setArt({"icon": "DefaultAddonNone.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="delete_all_data"),
                li, isFolder=False)

    def _add_channel_item(self, ch):
        shows        = ch.get("shows", [])
        show_count   = len(shows)
        randomized   = "  [R]" if ch.get("randomize") else ""
        channel_type = ch.get("channel_type", "tv")

        if channel_type == "movies":
            movie_count = len(ch.get("movies", []))
            filters     = ch.get("filters", [])
            if filters:
                type_str = "  ({} movies, filtered)".format(movie_count)
            else:
                type_str = "  ({} movie{})".format(
                    movie_count, "s" if movie_count != 1 else "")
        else:
            filters  = ch.get("filters", [])
            filtered = " [filtered]" if filters else ""
            type_str = "  ({} show{}{})".format(
                show_count,
                "s" if show_count != 1 else "",
                filtered)

        # Interleave badge
        il_cfg = ch.get("interleave")
        if il_cfg and il_cfg.get("channel_id"):
            foreign = self.manager.get_channel(il_cfg["channel_id"])
            if foreign:
                freq   = int(il_cfg.get("frequency", 4))
                jitter = int(il_cfg.get("jitter", 0))
                if jitter == 0:
                    il_str = "  +IL:{}/{}".format(foreign["name"][:12], freq)
                else:
                    il_str = "  +IL:{}/{}+/-{}".format(
                        foreign["name"][:12], freq, jitter)
            else:
                il_str = "  +IL:?"
        else:
            il_str = ""

        try:
            _show_count = self.addon.getSetting(
                "show_episode_count") != "false"
        except Exception:
            _show_count = True
        if _show_count:
            from resources.lib.channel_manager import ChannelManager
            _q_path = self.manager._queue_file_path(ch["id"])
            try:
                import xbmcvfs as _xbmcvfs2, json as _json2
                if _xbmcvfs2.exists(_q_path):
                    with _xbmcvfs2.File(_q_path, "r") as _qf:
                        _q = _json2.loads(_qf.read())
                    _count_str = "  [{} ep]".format(len(_q))
                else:
                    _count_str = ""
            except Exception:
                _count_str = ""
        else:
            _count_str = ""
        label = ch["name"]

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideoPlaylists.png"})
        li.setInfo("video", {"title": ch["name"]})

        ctx = [
            ("Channel Info",
             "RunPlugin({})".format(self._url(action="channel_info",      channel_id=ch["id"]))),
            ("Play Channel",
             "RunPlugin({})".format(self._url(action="play_channel",      channel_id=ch["id"]))),
            ("Edit Channel",
             "RunPlugin({})".format(self._url(action="edit_channel",      channel_id=ch["id"]))),
            ("Reset Channel to Start",
             "RunPlugin({})".format(self._url(action="reset_channel",     channel_id=ch["id"]))),
            ("Delete Channel",
             "RunPlugin({})".format(self._url(action="delete_channel",    channel_id=ch["id"]))),
            ("Toggle Visibility",
             "RunPlugin({})".format(self._url(action="toggle_channel_visibility", channel_id=ch["id"]))),
            ("Manage Interleave",
             "RunPlugin({})".format(self._url(action="manage_interleave", channel_id=ch["id"]))),
        ]
        li.addContextMenuItems(ctx, replaceItems=False)

        xbmcplugin.addDirectoryItem(
            self.handle,
            self._url(action="open_channel", channel_id=ch["id"]),
            li, isFolder=True)

    # -- Channel Info ----------------------------------------------------------

    def channel_info(self, params):
        """Show a dialog with full channel configuration and status."""
        channel_id = params["channel_id"]
        ch         = self.manager.get_channel(channel_id)
        if not ch:
            return

        import json as _json, xbmcvfs as _vfs

        channel_type = ch.get("channel_type", "tv")
        randomize    = ch.get("randomize",    False)
        recycle      = ch.get("recycle",      True)
        shows        = ch.get("shows",        [])
        movies       = ch.get("movies",       [])
        lines        = []

        if channel_type == "movies":
            # -- Movie channel -------------------------------------------------
            filters     = ch.get("filters", [])
            rotation    = "Random" if randomize else "Sequential"
            recycle_str = "Repeat" if recycle else "Play Once"
            lines.append("Type:      Movie Channel")
            lines.append("Rotation:  {}".format(rotation))
            lines.append("Playback:  {}".format(recycle_str))
            if filters:
                lines.append("Filters:   Yes")
            lines.append("Movies:    {}".format(len(movies)))
        else:
            # -- TV channel ----------------------------------------------------
            rotation    = "Random" if randomize else "Round-Robin"
            recycle_str = "Repeat" if recycle else "Play Once"
            lines.append("Type:      TV Channel")
            lines.append("Rotation:  {}".format(rotation))
            lines.append("Playback:  {}".format(recycle_str))
            lines.append("")
            if shows:
                lines.append("Shows ({} total):".format(len(shows)))
                for show in shows:
                    lines.append("  {}".format(show.get("title", "Unknown")))

        # -- Queue depth -------------------------------------------------------
        lines.append("")
        try:
            _q_path = self.manager._queue_file_path(channel_id)
            if _vfs.exists(_q_path):
                with _vfs.File(_q_path, "r") as _qf:
                    _q = _json.loads(_qf.read())
                lines.append("Queue:     {} items".format(len(_q)))
            else:
                lines.append("Queue:     not built")
        except Exception:
            lines.append("Queue:     unavailable")

        # -- Interleave config -------------------------------------------------
        il_cfg = ch.get("interleave")
        if il_cfg and il_cfg.get("channel_id"):
            foreign = self.manager.get_channel(il_cfg["channel_id"])
            if foreign:
                freq    = int(il_cfg.get("frequency",   4))
                jitter  = int(il_cfg.get("jitter",      0))
                count   = int(il_cfg.get("count_per",   1))
                jit_str = " +/-{}".format(jitter) if jitter else ""
                lines.append("Interleave: {} every {}{} eps{}".format(
                    foreign["name"],
                    freq, jit_str,
                    ", {} per slot".format(count) if count > 1 else ""))
            else:
                lines.append("Interleave: (channel not found)")

        xbmcgui.Dialog().textviewer(
            ch["name"] + " - Channel Info",
            "\n".join(lines))

    # -- Open channel ----------------------------------------------------------

    def open_channel(self, params):
        channel_id   = params["channel_id"]
        channel      = self.manager.get_channel(channel_id)
        if not channel:
            return

        channel_type = channel.get("channel_type", "tv")
        xbmcplugin.setPluginCategory(self.handle, channel["name"])
        xbmcplugin.setContent(
            self.handle,
            "movies" if channel_type == "movies" else "episodes")

        play_url = self._url(action="play_channel", channel_id=channel_id)

        li = xbmcgui.ListItem(label=">> Play Channel")
        li.setArt({"icon": "DefaultVideoPlaylists.png"})
        xbmcplugin.addDirectoryItem(self.handle, play_url, li, isFolder=False)

        if channel_type == "movies":
            self._open_movie_channel(channel_id, channel, play_url)
        else:
            self._open_tv_channel(channel_id, channel, play_url)

    def _open_movie_channel(self, channel_id, channel, play_url):
        """Show upcoming movies from the queue file."""
        import json
        import xbmcvfs
        queue_path = self.manager._queue_file_path(channel_id)

        upcoming = []
        if xbmcvfs.exists(queue_path):
            try:
                with xbmcvfs.File(queue_path, "r") as f:
                    try:
                        _nu = max(1, int(
                            self.addon.getSetting(
                                "num_upcoming_programs") or "5"))
                    except Exception:
                        _nu = 5
                    upcoming = json.loads(f.read())[:_nu]
            except Exception:
                pass

        if upcoming:
            for item in upcoming:
                _is_movie = (not item.get("tvshowtitle") and
                             (item.get("is_movie") or
                              item.get("movieid", -1) > 0 or
                              not item.get("episodeid")))
                if _is_movie:
                    _title = item.get("title", "Unknown")
                    _year  = item.get("year", "")
                    label  = "[Movie] {}{}".format(
                        _title, " ({})".format(_year) if _year else "")
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo("video", {
                        "title": _title, "year": _year,
                        "plot":  item.get("plot", ""),
                        "mediatype": "movie",
                    })
                else:
                    _show     = item.get("tvshowtitle", "")
                    _ep_title = item.get("title", "")
                    _s        = item.get("season", 0)
                    _e        = item.get("episode", 0)
                    if _show:
                        label = "{} - S{:02d}E{:02d} - {}".format(
                            _show, _s, _e, _ep_title)
                    else:
                        label = "S{:02d}E{:02d} - {}".format(_s, _e, _ep_title)
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo("video", {
                        "tvshowtitle": _show,
                        "title":       _ep_title,
                        "season":      _s,
                        "episode":     _e,
                        "mediatype":   "episode",
                    })
                xbmcplugin.addDirectoryItem(
                    self.handle, play_url, li, isFolder=False)
        else:
            for m in channel.get("movies", [])[:20]:
                li = xbmcgui.ListItem(label=m.get("title", "Movie"))
                xbmcplugin.addDirectoryItem(
                    self.handle, play_url, li, isFolder=False)

        log("[ChannelUI] Movie channel: {} upcoming".format(len(upcoming)))

    def _open_tv_channel(self, channel_id, channel, play_url):
        """Show next episode per show, plus any interleaved items
        that are up next in the queue."""
        import json
        import xbmcvfs

        shows = list(channel.get("shows", []))
        if shows:
            state_path = self.manager._resolve_path("state.json")
            try:
                with xbmcvfs.File(state_path, "r") as f:
                    state_all = json.loads(f.read())
                key       = "{}:__show_index__".format(channel_id)
                start_idx = int(state_all.get(key, 0))
                if start_idx > 0:
                    shows = shows[start_idx:] + shows[:start_idx]
            except Exception:
                pass

        # Read queue file to find interleaved items at the front
        # so they appear in the channel detail view in correct position.
        interleaved_pending = []
        try:
            q_path = self.manager._queue_file_path(channel_id)
            if xbmcvfs.exists(q_path):
                with xbmcvfs.File(q_path, "r") as _f:
                    _q = json.loads(_f.read())
                # Collect any interleaved items that appear before
                # the first non-interleaved (TV episode) item
                for _item in _q:
                    if _item.get("_interleaved"):
                        interleaved_pending.append(_item)
                    else:
                        break  # stop at first TV episode
        except Exception:
            pass

        # How many upcoming programs to show total
        try:
            _num_up = max(1, int(
                self.addon.getSetting("num_upcoming_programs") or "5"))
        except Exception:
            _num_up = 5

        # Build upcoming list from the actual queue in play order.
        # This shows interleaved movies and TV episodes in the correct
        # sequence rather than one-per-show.
        upcoming_items = []
        try:
            import os as _osu
            q_path = self.manager._queue_file_path(channel_id)
            # For shared paths, try local profile copy first
            # (always written there as staging copy — guaranteed readable)
            profile = xbmcvfs.translatePath(
                self.addon.getAddonInfo("profile"))
            local_q = _osu.path.join(
                profile, "queue_{}.json".format(channel_id))
            read_path = local_q if xbmcvfs.exists(local_q) else q_path
            if xbmcvfs.exists(read_path):
                with xbmcvfs.File(read_path, "r") as _qf:
                    _raw = _qf.read()
                if _raw:
                    upcoming_items = json.loads(_raw)[:_num_up]
            log("[ChannelUI] read {} upcoming from {}".format(
                len(upcoming_items), read_path))
        except Exception as _e:
            log("[ChannelUI] upcoming read error: {}".format(_e))

        if upcoming_items:
            # Show queue items in play order
            for _item in upcoming_items:
                _is_movie = (_item.get("_interleaved") or
                             _item.get("is_movie") or
                             _item.get("movieid", -1) > 0 or
                             not _item.get("episodeid"))
                if _is_movie:
                    _title = _item.get("title", "Unknown")
                    _year  = _item.get("year", "")
                    _label = "[Movie] {}{}".format(
                        _title,
                        " ({})".format(_year) if _year else "")
                    _li = xbmcgui.ListItem(label=_label)
                    _li.setInfo("video", {
                        "title": _title, "year": _year,
                        "plot":  _item.get("plot", ""),
                        "mediatype": "movie",
                    })
                    _thumb = (_item.get("thumbnail", "")
                              or _item.get("thumb", ""))
                    if _thumb:
                        _li.setArt({"thumb": _thumb, "icon": _thumb})
                else:
                    _show     = _item.get("tvshowtitle", "")
                    _ep_title = _item.get("title", "")
                    _s        = _item.get("season", 0)
                    _e        = _item.get("episode", 0)
                    if _show:
                        _label = "{} - S{:02d}E{:02d} - {}".format(
                            _show, _s, _e, _ep_title)
                    else:
                        _label = "S{:02d}E{:02d} - {}".format(
                            _s, _e, _ep_title)
                    _li = xbmcgui.ListItem(label=_label)
                    _li.setInfo("video", {
                        "tvshowtitle": _show,
                        "title":       _ep_title,
                        "season":      _s,
                        "episode":     _e,
                        "mediatype":   "episode",
                    })
                xbmcplugin.addDirectoryItem(self.handle, play_url,
                                            _li, isFolder=False)
            log("[ChannelUI] TV channel: {} upcoming items".format(
                len(upcoming_items)))
            return

        # Fallback: no queue file — show one entry per show
        # Show interleaved items first
        for _item in interleaved_pending:
            _title  = _item.get("title", "Unknown")
            _year   = _item.get("year", "")
            _label  = "[Movie] {}{}".format(
                _title, " ({})".format(_year) if _year else "")
            _li = xbmcgui.ListItem(label=_label)
            _li.setInfo("video", {"title": _title, "year": _year})
            xbmcplugin.addDirectoryItem(self.handle, play_url,
                                        _li, isFolder=False)

        for show in shows:
            show_id    = show["tvshowid"]
            show_title = show.get("title", "Show {}".format(show_id))
            next_ep    = self.manager.get_next_episode_for_show(
                channel_id, show)

            log("[ChannelUI] show={} next_ep={}".format(show_title, next_ep))

            if next_ep:
                s          = next_ep.get("season",  0)
                e          = next_ep.get("episode", 0)
                ep_title   = next_ep.get("title", "")
                try:
                    _show_next = self.addon.getSetting(
                        "show_next_episode") != "false"
                except Exception:
                    _show_next = True
                if _show_next:
                    full_label = "{} - Next: S{:02d}E{:02d} - {}".format(
                        show_title, s, e, ep_title)
                else:
                    full_label = show_title
                li = xbmcgui.ListItem(label=full_label)
                li.setInfo("video", {
                    "tvshowtitle": show_title,
                    "season":      s,
                    "episode":     e,
                    "title":       ep_title,
                    "plot":        next_ep.get("plot", ""),
                })
                thumb = (next_ep.get("art", {}).get("thumb")
                         or next_ep.get("thumbnail", ""))
                if thumb:
                    li.setArt({"thumb": thumb, "icon": thumb})
            else:
                log("[ChannelUI] No next_ep for {}".format(show_title))
                full_label = "{} - (no episodes found)".format(show_title)
                li         = xbmcgui.ListItem(label=full_label)

            # Context menu: Reset this show back to S01E01
            reset_url = self._url(
                action="reset_next_episode",
                channel_id=channel_id,
                show_id=show_id)
            li.addContextMenuItems([
                ("Reset to S01E01",
                 "RunPlugin({})".format(reset_url)),
            ], replaceItems=False)

            xbmcplugin.addDirectoryItem(self.handle, play_url,
                                        li, isFolder=False)

        log("[ChannelUI] TV channel: {} shows".format(len(shows)))

    def create_channel_wizard(self, params):
        result = self._run_wizard(existing=None)
        if result:
            xbmcgui.Dialog().notification(
                "Smart TV Channels",
                "Creating '{}' - please wait...".format(
                    result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 5000)
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            try:
                self.manager.create_channel(result)
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            xbmcgui.Dialog().notification(
                "Smart TV Channels",
                "Channel '{}' created!".format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh")

    def edit_channel_wizard(self, params):
        channel_id = params.get("channel_id")
        existing   = self.manager.get_channel(channel_id)
        if not existing:
            return
        result = self._run_wizard(existing=existing)
        if result:
            xbmcgui.Dialog().notification(
                "Smart TV Channels",
                "Updating '{}' - please wait...".format(
                    result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 5000)
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            try:
                self.manager.update_channel(channel_id, result)
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            xbmcgui.Dialog().notification(
                "Smart TV Channels",
                "Channel '{}' updated!".format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")

    def _run_wizard(self, existing):
        """
        Multi-step channel creation/edit wizard.
        Supports both TV Show channels and Movie channels.

        TV Steps:
          1. Channel name
          2. Channel type (TV / Movies)
          3. Select TV shows
          4. Randomize or Round-Robin
          4a. Shuffle show rotation (Round Robin only)
          4b. Custom starting point per show (Round Robin only)
          5. Recycle
          6. Queue size
          7. Visibility

        Movie Steps:
          1. Channel name
          2. Channel type
          3. Select movies (all / genre / year / specific)
          4. Random or In-Order
          5. Recycle (replay all when exhausted)
          6. Queue size
          7. Visibility
        """
        import random as _random

        d = xbmcgui.Dialog()

        # ---- Step 1: Name ---------------------------------------------------
        name = d.input(
            "Enter channel name:",
            existing["name"] if existing else "",
            type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            d.ok("Smart TV Channels", "Channel name cannot be empty.")
            return None

        # ---- Step 2: Channel type -------------------------------------------
        default_type  = existing.get("channel_type", "tv") if existing else "tv"
        type_presel   = 0 if default_type == "tv" else 1
        # d.select does not support preselect - show current value in title
        type_label  = " (current: {})".format(
            "TV Shows" if default_type == "tv" else "Movies") if existing else ""
        type_choice = d.select(
            "Channel Type{}".format(type_label),
            ["TV Shows (episodes in rotation)",
             "Movies (film library)"])
        if type_choice < 0:
            return None
        channel_type = "tv" if type_choice == 0 else "movies"

        # ---- Step 3: Content selection --------------------------------------
        # Initialize all output vars with safe defaults
        selected_shows  = []
        selected_movies = []
        starting_points = {}
        filters         = []

        # Pre-fetch library data NOW before showing any dialogs
        # so all subsequent selections are instant (data already cached)
        if channel_type == "tv":
            existing_filters = existing.get("filters", []) if existing else []
            existing_shows   = existing.get("shows", []) if existing else []

            # Show pool starts as full library
            # User can optionally filter to narrow it first
            show_pool = self.manager.library.get_all_tvshows()
            if not show_pool:
                d.ok("Smart TV Channels",
                     "No TV shows found in your library.")
                return None

            # Offer filter option if user wants to narrow the list
            if len(show_pool) > 20:
                use_filter = d.yesno(
                    "Show Selection",
                    "Your library has {} shows. Filter first to narrow "
                    "the list?".format(len(show_pool)),
                    nolabel="Show All",
                    yeslabel="Filter First")
                if use_filter:
                    filters   = self._build_filters(existing_filters, "tv")
                    if filters:
                        filtered = self.manager.library                            .get_tvshows_with_filters(filters)
                        if filtered:
                            show_pool = filtered
                            d.ok("Filter Results",
                                 "{} shows match. Now select which to "
                                 "include.".format(len(show_pool)))
                        else:
                            d.ok("Smart TV Channels",
                                 "No shows match. Showing full library.")

            show_labels = [s["title"] for s in show_pool]
            preselected = []
            if existing:
                ex_ids      = {s["tvshowid"] for s in existing_shows}
                preselected = [i for i, s in enumerate(show_pool)
                               if s["tvshowid"] in ex_ids]

            chosen = d.multiselect(
                "Select TV Shows ({} available)".format(len(show_pool)),
                show_labels,
                preselect=preselected)
            if chosen is None:
                return None
            if not chosen:
                d.ok("Smart TV Channels", "No shows selected.")
                return None

            selected_shows = [
                {"tvshowid": show_pool[i]["tvshowid"],
                 "title":    show_pool[i]["title"]}
                for i in chosen
            ]


        else:
            # Movie selection
            all_movies = self.manager.library.get_all_movies()
            if not all_movies:
                d.ok("Smart TV Channels",
                     "No movies found in your library.")
                return None

            filter_choice = d.select(
                "Movie Selection Method",
                ["All Movies ({} total)".format(len(all_movies)),
                 "Filter by Genre",
                 "Filter by Year",
                 "Select Specific Movies"])
            if filter_choice < 0:
                return None

            if filter_choice == 0:
                # All movies - filters applied at queue build time
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in all_movies
                ]

            elif filter_choice == 1:
                genres = self.manager.library.get_all_genres("movie")
                if not genres:
                    d.ok("Smart TV Channels", "No genres found.")
                    return None
                chosen_genre = d.select("Select Genre", genres)
                if chosen_genre < 0:
                    return None
                filtered = self.manager.library.get_movies_by_genre(
                    genres[chosen_genre])
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in filtered
                ]
                if not selected_movies:
                    d.ok("Smart TV Channels",
                         "No movies found for genre: {}".format(
                             genres[chosen_genre]))
                    return None
                d.ok("Smart TV Channels",
                     "Selected {} movies in '{}'.".format(
                         len(selected_movies), genres[chosen_genre]))

            elif filter_choice == 2:
                years = sorted(
                    set(m["year"] for m in all_movies if m.get("year")),
                    reverse=True)
                if not years:
                    d.ok("Smart TV Channels", "No year data found.")
                    return None
                year_labels  = [str(y) for y in years]
                chosen_year  = d.select("Select Year", year_labels)
                if chosen_year < 0:
                    return None
                filtered = self.manager.library.get_movies_by_year(
                    years[chosen_year])
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in filtered
                ]
                if not selected_movies:
                    d.ok("Smart TV Channels",
                         "No movies found for year: {}".format(
                             years[chosen_year]))
                    return None
                d.ok("Smart TV Channels",
                     "Selected {} movies from {}.".format(
                         len(selected_movies), years[chosen_year]))

            else:
                movie_labels = [m["title"] for m in all_movies]
                preselected  = []
                if existing:
                    existing_ids = {m["movieid"]
                                    for m in existing.get("movies", [])}
                    preselected  = [i for i, m in enumerate(all_movies)
                                    if m["movieid"] in existing_ids]
                chosen = d.multiselect("Select Movies", movie_labels,
                                       preselect=preselected)
                if chosen is None:
                    return None
                if not chosen:
                    d.ok("Smart TV Channels", "No movies selected.")
                    return None
                selected_movies = [
                    {"movieid": all_movies[i]["movieid"],
                     "title":   all_movies[i]["title"]}
                    for i in chosen
                ]

        # ---- Step 3b: Movie filter rules ------------------------------------
        # For movie channels, add filter step here
        # TV channel filters are handled during show selection above
        if channel_type == "movies":
            existing_filters = existing.get("filters", []) if existing else []
            add_filters = d.yesno(
                "Movie Filters",
                "Add filter rules to narrow movies? "
                "(Genre, Year, MPAA, Studio, Watched status)",
                nolabel="No Filters",
                yeslabel="Add Filters")
            if add_filters:
                filters = self._build_filters(existing_filters, "movies")
            else:
                filters = existing_filters

        # ---- Step 4: Playback order -----------------------------------------
        if existing:
            default_rand = existing.get("randomize", False)
        else:
            try:
                default_rand = self.addon.getSetting(
                    "default_randomize") == "true"
            except Exception:
                default_rand = False
        if channel_type == "movies":
            randomize = d.yesno(
                "Movie Order",
                "Play movies in random order?",
                nolabel="In Order", yeslabel="Random",
                defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
                if default_rand else xbmcgui.DLG_YESNO_NO_BTN)
        else:
            randomize = d.yesno(
                "Playback Order", "Play episodes in random order?",
                nolabel="Round-Robin", yeslabel="Random",
                defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
                if default_rand else xbmcgui.DLG_YESNO_NO_BTN)

        # ---- Step 4a: Shuffle show rotation (Round Robin TV, 2+ shows) ------
        if channel_type == "tv" and not randomize and len(selected_shows) > 1:
            shuffle = d.yesno(
                "Show Rotation Order",
                "Shuffle the order the shows rotate in? "
                "(e.g. A-B-C might become B-C-A)",
                nolabel="Keep Selection Order",
                yeslabel="Shuffle")
            if shuffle:
                while True:
                    _random.shuffle(selected_shows)
                    new_order = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(selected_shows))
                    _accept_order = d.yesno(
                        "Rotation Order",
                        new_order[:300],
                        nolabel="Shuffle Again",
                        yeslabel="Accept")
                    if _accept_order:
                        break

        # ---- Step 4b: Custom starting point (all TV channels) ---------------
        if channel_type == "tv" and selected_shows:
            import random as _sp_random
            _start_choice = d.select(
                "Starting Point",
                [
                    "Start from S01E01 (default)",
                    "Set Starting Points manually",
                    "Surprise Me! (random starting episodes)",
                ])
            # -1 = cancelled → treat as default (S01E01)

            # ---- Surprise Me ----------------------------------------
            if _start_choice == 2:
                while True:
                    # Pick a completely random episode for every show
                    _surprise_picks = {}
                    for _sp_show in selected_shows:
                        _sp_sid = _sp_show["tvshowid"]
                        _sp_eps = self.manager.library                                 .get_episodes_for_show(_sp_sid)
                        if _sp_eps:
                            _sp_ep = _sp_random.choice(_sp_eps)
                            _surprise_picks[_sp_sid] = _sp_ep

                    # Build summary for the user to review
                    _summary_lines = []
                    for _sp_show in selected_shows:
                        _sp_sid = _sp_show["tvshowid"]
                        _sp_ep  = _surprise_picks.get(_sp_sid)
                        if _sp_ep:
                            _summary_lines.append(
                                "{}: S{:02d}E{:02d} - {}".format(
                                    _sp_show["title"],
                                    _sp_ep["season"],
                                    _sp_ep["episode"],
                                    _sp_ep.get("title", "")))
                        else:
                            _summary_lines.append(
                                "{}: No episodes found".format(
                                    _sp_show["title"]))

                    _summary = "\n".join(_summary_lines)
                    _accept = d.yesno(
                        "Surprise Me! — Starting Episodes",
                        _summary,
                        nolabel="Try Again",
                        yeslabel="Accept")

                    if _accept:
                        # User happy — write picks into starting_points
                        for _sp_show in selected_shows:
                            _sp_sid = _sp_show["tvshowid"]
                            _sp_ep  = _surprise_picks.get(_sp_sid)
                            if _sp_ep:
                                starting_points[_sp_sid] = {
                                    "episodeid": _sp_ep["episodeid"],
                                    "season":    _sp_ep["season"],
                                    "episode":   _sp_ep["episode"],
                                    "title":     _sp_ep.get("title", ""),
                                }
                        break
                    # else: loop and pick again

            # ---- Manual starting points -----------------------------
            elif _start_choice == 1:
              for show in selected_shows:
                sid        = show["tvshowid"]
                show_title = show["title"]

                # Show current position when editing
                nolabel = "Start from S01E01"
                if existing:
                    cur = self.manager.get_show_state(
                        existing.get("id", ""), sid)
                    if cur.get("next_episode_id"):
                        nolabel = "Keep: S{:02d}E{:02d}".format(
                            cur.get("season", 1),
                            cur.get("episode", 1))

                do_set = d.yesno(
                    show_title,
                    "Set a starting episode for {}?".format(show_title),
                    nolabel=nolabel,
                    yeslabel="Choose Episode")
                if not do_set:
                    continue

                episodes = self.manager.library.get_episodes_for_show(sid)
                if not episodes:
                    d.ok("Smart TV Channels",
                         "No episodes found for {}.".format(show_title))
                    continue

                seasons       = sorted(set(e["season"] for e in episodes))
                season_labels = ["Season {}".format(s) for s in seasons]

                # Pre-select current season when editing
                default_s = 0
                if existing:
                    cur = self.manager.get_show_state(
                        existing.get("id", ""), sid)
                    cs  = cur.get("season", 1)
                    if cs in seasons:
                        default_s = seasons.index(cs)

                # Show current season in title when editing
                cur_s_label = ""
                if existing and default_s > 0:
                    cur_s_label = " (current: Season {})".format(
                        seasons[default_s])
                season_choice = d.select(
                    "Starting season for {}{}".format(
                        show_title, cur_s_label),
                    season_labels)
                if season_choice < 0:
                    continue

                chosen_season = seasons[season_choice]
                season_eps    = sorted(
                    [e for e in episodes if e["season"] == chosen_season],
                    key=lambda e: e["episode"])
                ep_labels = [
                    "S{:02d}E{:02d} - {}".format(
                        e["season"], e["episode"], e["title"])
                    for e in season_eps
                ]

                # Pre-select current episode when editing
                default_e = 0
                if existing:
                    cur     = self.manager.get_show_state(
                        existing.get("id", ""), sid)
                    cur_nid = cur.get("next_episode_id")
                    for i, ep in enumerate(season_eps):
                        if ep["episodeid"] == cur_nid:
                            default_e = i
                            break

                # Show current episode in title when editing
                cur_e_label = ""
                if existing and default_e > 0 and default_e < len(ep_labels):
                    cur_e_label = " (current: {})".format(
                        ep_labels[default_e])
                ep_choice = d.select(
                    "Starting episode for {}{}".format(
                        show_title, cur_e_label[:40]),
                    ep_labels)
                if ep_choice < 0:
                    continue

                chosen_ep = season_eps[ep_choice]
                starting_points[sid] = {
                    "episodeid": chosen_ep["episodeid"],
                    "season":    chosen_ep["season"],
                    "episode":   chosen_ep["episode"],
                    "title":     chosen_ep["title"],
                }
                log("[ChannelUI] Starting point {}: S{}E{}".format(
                    show_title,
                    chosen_ep["season"],
                    chosen_ep["episode"]))

        # ---- Step 5: Recycle ------------------------------------------------
        if existing:
            default_rec = existing.get("recycle", True)
        else:
            try:
                default_rec = self.addon.getSetting(
                    "default_recycle") != "false"
            except Exception:
                default_rec = True
        if channel_type == "movies":
            recycle = d.yesno(
                "Recycling",
                "When all movies have played, start over from the beginning?",
                nolabel="Stop", yeslabel="Repeat",
                defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
                if default_rec else xbmcgui.DLG_YESNO_NO_BTN)
        else:
            recycle = d.yesno(
                "Recycling",
                "When a show is exhausted, loop back to S01E01?",
                nolabel="Stop", yeslabel="Recycle",
                defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
                if default_rec else xbmcgui.DLG_YESNO_NO_BTN)

        # ---- Step 6: Queue size ---------------------------------------------
        try:
            _default_qs = max(10, int(
                self.addon.getSetting("default_queue_size") or "30"))
        except Exception:
            _default_qs = 30
        qs_str = d.input(
            "Target queue size (10-200):",
            str(existing.get("queue_size", _default_qs)) if existing
            else str(_default_qs),
            type=xbmcgui.INPUT_NUMERIC)
        try:
            queue_size = max(10, min(200, int(qs_str or str(_default_qs))))
        except ValueError:
            queue_size = _default_qs

        # ---- Step 7: Visibility ---------------------------------------------
        default_vis = existing.get("visible", True) if existing else True
        visible = d.yesno(
            "Visibility", "Show this channel in your channel list?",
            nolabel="Hide", yeslabel="Show",
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
            if default_vis else xbmcgui.DLG_YESNO_NO_BTN)

        return {
            "name":             name,
            "channel_type":     channel_type,
            "shows":            selected_shows,
            "movies":           selected_movies,
            "randomize":        randomize,
            "recycle":          recycle,
            "queue_size":       queue_size,
            "visible":          visible,
            "filters":          filters,
            "interleave":       existing.get("interleave") if existing else None,
            "starting_points":  starting_points,
        }

    # -- Interleave ------------------------------------------------------------

    # -- Filter builder --------------------------------------------------------

    def _build_filters(self, existing_filters, media_type="tv"):
        """
        Interactive filter rule builder.
        Allows combining multiple rules with AND/OR logic.

        Returns a list of filter dicts, or existing_filters if cancelled.
        """
        d = xbmcgui.Dialog()

        # Show current filters summary
        filters  = list(existing_filters) if existing_filters else []
        modified = False

        while True:
            # Build current filter summary for display
            if filters:
                summary = []
                for i, f in enumerate(filters):
                    op = f.get("operator", "and").upper()
                    prefix = "" if i == 0 else "{} ".format(op)
                    comp   = f.get("comparison", "")
                    comp_str = {
                        "greaterthan":      ">",
                        "lessthan":         "<",
                        "greaterthanequal": ">=",
                        "lessthanequal":    "<=",
                        "equals":           "=",
                    }.get(comp, "")
                    summary.append("{}{}: {} {}{}".format(
                        prefix,
                        f.get("type", "").capitalize(),
                        comp_str,
                        f.get("value", ""),
                        "" if not comp_str else ""))
                current = "Current filters: " + " | ".join(summary)
            else:
                current = "No filters (shows/movies from entire library)"

            action = d.select(
                "Manage Filters",
                [current,
                 "Add filter rule",
                 "Remove last filter rule",
                 "Clear all filters",
                 "Done"])

            if action < 0 or action == 4:
                break
            elif action == 0:
                # Just display current - do nothing
                pass
            elif action == 1:
                # Add a new filter rule
                new_filter = self._add_filter_rule(d, filters, media_type)
                if new_filter:
                    filters.append(new_filter)
                    modified = True
            elif action == 2:
                # Remove last rule
                if filters:
                    filters.pop()
                    modified = True
            elif action == 3:
                # Clear all
                filters = []
                modified = True

        return filters

    def _add_filter_rule(self, d, existing_filters, media_type):
        """
        Add a single filter rule. Returns a filter dict or None.
        """
        # Filter types available
        if media_type == "movies":
            type_options = [
                ("genre",   "Genre"),
                ("year",    "Year"),
                ("mpaa",    "MPAA Rating"),
                ("studio",  "Studio"),
                ("rating",  "Minimum Rating"),
            ]
        else:
            type_options = [
                ("genre",   "Genre"),
                ("year",    "Year (first aired)"),
                ("studio",  "Network/Studio"),
                ("rating",  "Minimum Rating"),
            ]

        type_labels  = [t[1] for t in type_options]
        type_choice  = d.select("Filter Type", type_labels)
        if type_choice < 0:
            return None

        ftype, flabel = type_options[type_choice]

        # Operator (AND/OR) - only ask if there are existing filters
        operator = "and"
        if existing_filters:
            op_choice = d.select(
                "Combine with existing filters using:",
                ["AND (must match ALL rules)",
                 "OR  (match ANY rule)"])
            if op_choice < 0:
                return None
            operator = "or" if op_choice == 1 else "and"

        # Value selection based on type
        if ftype == "genre":
            genres = self.manager.library.get_all_genres(
                "movie" if media_type == "movies" else "tvshow")
            if not genres:
                d.ok("Smart TV Channels", "No genres found in library.")
                return None
            choice = d.select("Select Genre", genres)
            if choice < 0:
                return None
            return {"type": "genre", "value": genres[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "year":
            comp_choice = d.select(
                "Year comparison",
                ["After year (greater than)",
                 "Before year (less than)",
                 "Exactly this year"])
            if comp_choice < 0:
                return None
            comp_map = {
                0: "greaterthan",
                1: "lessthan",
                2: "equals",
            }
            comp = comp_map[comp_choice]

            year_str = d.input("Enter year (e.g. 1990):", "",
                               type=xbmcgui.INPUT_NUMERIC)
            if not year_str:
                return None
            try:
                year = int(year_str)
                if year < 1888 or year > 2100:
                    raise ValueError
            except ValueError:
                d.ok("Smart TV Channels", "Invalid year entered.")
                return None
            return {"type": "year", "value": str(year),
                    "operator": operator, "comparison": comp}

        elif ftype == "mpaa":
            # Common MPAA ratings + fetch from library
            common = ["G", "PG", "PG-13", "R", "NC-17",
                      "NR", "TV-G", "TV-PG", "TV-14", "TV-MA"]
            lib_ratings = self.manager.library.get_mpaa_ratings("movie")
            all_ratings = sorted(set(common + lib_ratings))
            if not all_ratings:
                d.ok("Smart TV Channels", "No MPAA ratings found.")
                return None
            choice = d.select("Select MPAA Rating", all_ratings)
            if choice < 0:
                return None
            return {"type": "mpaa", "value": all_ratings[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "studio":
            studios = self.manager.library.get_studios(
                "movie" if media_type == "movies" else "tv")
            if not studios:
                d.ok("Smart TV Channels", "No studios found in library.")
                return None
            choice = d.select("Select Studio / Network", studios)
            if choice < 0:
                return None
            return {"type": "studio", "value": studios[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "rating":
            comp_choice = d.select(
                "Rating comparison",
                ["Minimum rating (>=)",
                 "Maximum rating (<=)",
                 "Exactly this rating"])
            if comp_choice < 0:
                return None
            comp_map = {0: "greaterthanequal",
                        1: "lessthanequal", 2: "equals"}
            comp = comp_map[comp_choice]

            rating_str = d.input("Enter rating (0-10):", "7",
                                 type=xbmcgui.INPUT_NUMERIC)
            if not rating_str:
                return None
            try:
                rating = float(rating_str)
                if rating < 0 or rating > 10:
                    raise ValueError
            except ValueError:
                d.ok("Smart TV Channels", "Invalid rating (use 0-10).")
                return None
            return {"type": "rating", "value": str(rating),
                    "operator": operator, "comparison": comp}

        return None

    # -- Interleave ------------------------------------------------------------

    def manage_interleave_dialog(self, params):
        """
        Full interleave configuration dialog.

        Step 1 - Pick foreign channel (or remove interleave)
        Step 2 - Fixed vs Jitter mode
        Step 3 - Frequency (N)
        Step 4 - Jitter amount (jitter mode only)

        Saves: {"channel_id": str, "frequency": int, "jitter": int}
        jitter=0 means fixed/exact mode.
        """
        channel_id = params.get("channel_id")
        channel    = self.manager.get_channel(channel_id)
        if not channel:
            return

        d     = xbmcgui.Dialog()
        other = [c for c in self.manager.get_all_channels()
                 if c["id"] != channel_id]

        if not other:
            d.ok("Smart TV Channels",
                 "No other channels available to interleave.")
            return

        # ---- Step 1: Choose source channel ----------------------------------
        existing   = channel.get("interleave") or {}
        cur_src_id = existing.get("channel_id", "")

        # Build a set of channel IDs that would create a circular reference.
        # A circular ref exists if the foreign channel already interleaves
        # back to this channel (A→B→A) or to any channel in the chain.
        def _would_be_circular(foreign_id, origin_id, visited=None):
            if visited is None:
                visited = set()
            if foreign_id in visited:
                return True
            visited.add(foreign_id)
            foreign_ch = self.manager.get_channel(foreign_id)
            if not foreign_ch:
                return False
            next_id = (foreign_ch.get("interleave") or {}).get("channel_id")
            if not next_id:
                return False
            if next_id == origin_id:
                return True
            return _would_be_circular(next_id, origin_id, visited)

        # Put currently selected channel first in the list for easy re-edit
        sorted_other = sorted(other,
                              key=lambda c: (0 if c["id"] == cur_src_id else 1,
                                             c["name"]))

        # Mark channels with warnings where applicable
        def _label(c):
            parts = [c["name"]]
            if c["id"] == cur_src_id:
                parts.append("(current)")
            if _would_be_circular(c["id"], channel_id):
                parts.append("[CIRCULAR - not recommended]")
            elif (c.get("interleave") or {}).get("channel_id"):
                parts.append("[has interleave - nesting not supported]")
            return " ".join(parts)

        labels = ["[Remove Interleave]"] + [
            _label(c) for c in sorted_other
        ]
        choice = d.select(
            "Interleave items from which channel?", labels)

        if choice == -1:
            return  # cancelled

        if choice == 0:
            channel["interleave"] = None
            self.manager._save_channels()
            # Rebuild queue so interleaved items are removed immediately
            self.manager.regenerate_queue(channel_id)
            xbmcgui.Dialog().notification(
                "Smart TV Channels",
                "Interleave removed from '{}'".format(channel["name"]),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.sleep(300)
            xbmc.executebuiltin("Container.Refresh")
            return

        src = sorted_other[choice - 1]

        # Warn and block circular references
        if _would_be_circular(src["id"], channel_id):
            d.ok("Smart TV Channels",
                 "Cannot interleave '{}' into '{}' — this would "
                 "create a circular reference (A→B→A). "
                 "Please choose a different channel.".format(
                     src["name"], channel["name"]))
            return

        # Warn if the foreign channel itself has an interleave
        # (nested interleave is not supported — inner interleave is ignored)
        if (src.get("interleave") or {}).get("channel_id"):
            foreign_il = self.manager.get_channel(
                src["interleave"]["channel_id"])
            foreign_il_name = foreign_il["name"] if foreign_il else "unknown"
            ok = d.yesno(
                "Smart TV Channels",
                "'{}' already has '{}' interleaved into it. "
                "Nested interleaving is not supported — '{}' items "
                "will NOT appear in this channel.\n\n"
                "Continue anyway?".format(
                    src["name"], foreign_il_name, foreign_il_name))
            if not ok:
                return

        # If user picked a different channel, reset existing config
        if src["id"] != cur_src_id:
            existing = {}

        # ---- Step 2: Fixed vs Jitter mode -----------------------------------
        cur_jitter = int(existing.get("jitter", 0))
        mode_choice = d.select(
            "Interleave mode for '{}'?".format(src["name"]),
            [
                "Fixed  - insert exactly every N items  {}".format(
                    "(current)" if cur_jitter == 0 else ""),
                "Random - insert every N +/- J items    {}".format(
                    "(current)" if cur_jitter > 0  else ""),
            ])

        if mode_choice == -1:
            return  # cancelled

        use_jitter = (mode_choice == 1)

        # ---- Step 3: Frequency ----------------------------------------------
        cur_freq = str(int(existing.get("frequency", 4)))
        if use_jitter:
            freq_prompt = (
                "Insert roughly every N items  (centre of range):"
            )
        else:
            freq_prompt = (
                "Insert exactly every N items:"
            )

        freq_str = d.input(freq_prompt, cur_freq,
                           type=xbmcgui.INPUT_NUMERIC)
        try:
            frequency = max(1, int(freq_str or cur_freq))
        except ValueError:
            frequency = 4

        # ---- Step 4: Jitter amount (jitter mode only) -----------------------
        jitter = 0
        if use_jitter:
            max_jitter  = frequency - 1          # can't go below gap of 1
            cur_jit_str = str(min(cur_jitter, max_jitter) if cur_jitter else
                              min(2, max_jitter))
            jit_prompt = (
                "Randomness +/- items (e.g. 2 means N-2 to N+2):"
            )
            jit_str = d.input(
                jit_prompt,
                cur_jit_str,
                type=xbmcgui.INPUT_NUMERIC)
            try:
                jitter = max(0, min(max_jitter, int(jit_str or cur_jit_str)))
            except ValueError:
                jitter = min(2, max_jitter)

        # ---- Step 5: Count per slot ----------------------------------------
        cur_count = int(existing.get("count_per", 1))
        count_str = d.input(
            "Items per insertion\n"
            "How many items to insert from '{}' at each slot?\n"
            "(current: {})".format(src["name"], cur_count),
            defaultt=str(cur_count),
            type=xbmcgui.INPUT_NUMERIC)
        try:
            count_per = max(1, int(count_str or cur_count))
        except (ValueError, TypeError):
            count_per = cur_count

        # ---- Save -----------------------------------------------------------
        channel["interleave"] = {
            "channel_id": src["id"],
            "frequency":  frequency,
            "jitter":     jitter,
            "count_per":  count_per,
        }
        self.manager._save_channels()

        # Regenerate queue so the new interleave pattern takes effect
        self.manager.regenerate_queue(channel_id)

        count_label = " x{}".format(count_per) if count_per > 1 else ""
        if jitter == 0:
            summary = "every {} items{}".format(frequency, count_label)
        else:
            summary = "every {}-{} items{} (N={} +/-{})".format(
                max(1, frequency - jitter), frequency + jitter,
                count_label, frequency, jitter)

        log("[ChannelUI] Interleave set: {} from '{}' {}".format(
            channel["name"], src["name"], summary))

        xbmcgui.Dialog().notification(
            "Smart TV Channels",
            "Interleave set: {} {}.".format(src["name"], summary),
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
