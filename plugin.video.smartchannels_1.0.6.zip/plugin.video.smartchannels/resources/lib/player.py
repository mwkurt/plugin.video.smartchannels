"""
resources/lib/player.py
========================
SmartPlayer orchestrates channel playback.

Flow:
  1. start_channel()      - builds initial queue, creates xbmc.PlayList,
                            starts playback via xbmc.Player.
  2. SmartPlayerMonitor   - subclasses xbmc.Player to receive onPlayBackEnded /
                            onPlayBackStopped events.
  3. On each episode end the monitor:
       a. Removes the played item from the front of the internal queue.
       b. Calls ChannelManager.advance_show() to update the state pointer.
       c. If queue < refill_threshold, calls ChannelManager.refill_queue().
       d. Appends new items to the live xbmc.PlayList.
"""

from __future__ import annotations

import threading

import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.channel_manager import ChannelManager
from resources.lib.utils.logger     import log


class SmartPlayerMonitor(xbmc.Player):
    """
    Subclass of xbmc.Player that monitors playback events for one channel
    session. Runs until the user stops playback or the queue is exhausted.
    """

    def __init__(self, addon, manager, channel, queue, playlist):
        super(SmartPlayerMonitor, self).__init__()
        self.addon     = addon
        self.manager   = manager
        self.channel   = channel
        self.queue     = queue        # mutable list - we pop from front
        self.playlist  = playlist
        self._active   = True
        self._lock     = threading.Lock()
        # Track how many items have started so we know when a new one begins

        try:
            queue_size        = max(10, int(
                addon.getSetting("default_queue_size") or "30"))
            refill_raw        = max(1, int(
                addon.getSetting("refill_threshold") or "15"))
            # If threshold >= queue size, cap it at half queue size so
            # refill doesn't trigger on every single item play.
            if refill_raw >= queue_size:
                self.refill_threshold = max(1, queue_size // 2)
            else:
                self.refill_threshold = refill_raw
        except (ValueError, TypeError):
            self.refill_threshold = 15

        # Resume settings
        try:
            self._resume_on_stop = (
                addon.getSetting("resume_on_stop").lower() == "true")
            _interval = int(addon.getSetting("resume_poll_interval") or "5")
            self._poll_interval  = max(0, _interval) * 60  # convert to seconds
            self._resume_ask     = (
                addon.getSetting("resume_ask_user").lower() == "true")
        except Exception:
            self._resume_on_stop = True
            self._poll_interval  = 300   # 5 minutes default
            self._resume_ask     = True

        self._current_item  = None   # item currently playing
        self._poll_timer    = None   # background polling thread
        self._resume_sought = False  # True after seek on resume

    # -- xbmc.Player callbacks -------------------------------------------------

    def onPlayBackEnded(self):
        """
        Fires when the entire playlist finishes (last item played through).
        Advance state for the final item and clear any resume entry.
        """
        log("[SmartPlayerMonitor] onPlayBackEnded - playlist finished")
        self._stop_poll_timer()
        if self._current_item:
            self.manager.clear_resume_position(self._current_item)
        self._on_item_finished()

    def onPlayBackStopped(self):
        """User stopped — save exact position then deactivate."""
        log("[SmartPlayerMonitor] onPlayBackStopped - saving resume position")
        if self._resume_on_stop and self._current_item:
            try:
                pos   = self.getTime()
                total = self.getTotalTime()
                if pos > 10:
                    # Save to shared SMB state (accurate on-stop save)
                    self.manager.save_resume_position(
                        self._current_item, pos, total)
            except Exception as _e:
                log("[SmartPlayerMonitor] resume save error: {}".format(_e))
        self._stop_poll_timer()
        self._active = False

    def onPlayBackStarted(self):
        """Track which item is now playing and start poll timer."""
        log("[SmartPlayerMonitor] onPlayBackStarted")
        # Only set _current_item here for the very first item.
        # For subsequent items, _do_advance already sets _current_item
        # correctly when it pops the finished item.  Setting queue[0]
        # here on item transitions would point at the just-finished item
        # (not yet popped) and corrupt the resume tracking.
        with self._lock:
            if self._current_item is None and self.queue:
                self._current_item  = self.queue[0]
                self._resume_sought = False
        self._start_poll_timer()

    def onAVStarted(self):
        """
        Fires when audio/video actually starts rendering — safe to seek here.
        If we have a resume position for this item and user confirmed, seek now.
        """
        if not self._resume_on_stop or not self._current_item:
            return
        if self._resume_sought:
            return
        self._resume_sought = True

        entry = self.manager.get_resume_position(self._current_item)
        if not entry:
            return

        pos   = entry.get("position", 0)
        title = entry.get("title", "")
        h     = int(pos // 3600)
        m     = int((pos % 3600) // 60)
        s     = int(pos % 60)
        ts    = "{:d}:{:02d}:{:02d}".format(h, m, s) if h else "{:d}:{:02d}".format(m, s)

        if self._resume_ask:
            choice = xbmcgui.Dialog().yesno(
                "Resume",
                "{} — resume from {}?".format(title[:40], ts),
                nolabel="Start from Beginning",
                yeslabel="Resume from {}".format(ts))
            if not choice:
                return   # user chose start from beginning — don't seek

        try:
            self.seekTime(pos)
            log("[SmartPlayerMonitor] Sought to {:.0f}s for {}".format(
                pos, title[:30]))
        except Exception as _e:
            log("[SmartPlayerMonitor] seekTime error: {}".format(_e))

    def onPlayBackError(self):
        log("[SmartPlayerMonitor] onPlayBackError - skipping item")
        self._on_item_finished()

    # -- Internal queue management ---------------------------------------------

    def _on_item_finished(self):
        """Public entry point — acquires lock then delegates."""
        with self._lock:
            self._do_advance()

    def _do_advance(self):
        """Lock-free inner body — must be called with self._lock held."""
        if not self._active:
            return

        if not self.queue:
            log("[SmartPlayerMonitor] Queue empty - stopping")
            self._active = False
            return

        # Pop the item that just played
        played     = self.queue.pop(0)
        # Clear resume entry — item finished naturally
        if self._resume_on_stop:
            try:
                self.manager.clear_resume_position(played)
            except Exception:
                pass
        # Update current item pointer
        self._current_item = self.queue[0] if self.queue else None
        self._resume_sought = False
        channel_id = (played.get("_channel_id")
                      or played.get("channel_id")
                      or self.channel["id"])
        show_id    = (played.get("_show_id")
                      or played.get("show_id"))
        is_movie   = (played.get("is_movie", False)
                      or played.get("movieid", -1) > 0)

        log("[SmartPlayerMonitor] _do_advance: "
            "show_id={} ep={} is_movie={} interleaved={}".format(
            show_id, played.get("episodeid", -1),
            is_movie, played.get("_interleaved", False)))

        # Advance state for TV episodes only.
        # Excluded: movies (show_id==0 or is_movie), interleaved items,
        # and anything with no valid show_id.
        if show_id and not is_movie and not played.get("_interleaved"):
            self.manager.advance_show(
                channel_id, show_id, played.get("episodeid", -1))

        # Refill if below threshold
        if len(self.queue) < self.refill_threshold:
            log("[SmartPlayerMonitor] Refilling queue ({} items left)".format(
                len(self.queue)))
            self.queue = self.manager.refill_queue(
                self.channel, self.queue, self.refill_threshold)
            new_items = self.queue[max(0, len(self.queue) - 10):]
            self._append_to_playlist(new_items)

        # Persist updated queue to disk so service and channel view
        # always reflect what has actually played or been skipped.
        try:
            self.manager._write_queue_file(
                self.channel["id"], self.queue)
        except Exception as _e:
            log("[SmartPlayerMonitor] queue persist error: {}".format(_e))

    def _start_poll_timer(self):
        """Start background polling timer if interval > 0 and resume enabled."""
        self._stop_poll_timer()
        if not self._resume_on_stop or self._poll_interval <= 0:
            return
        self._poll_timer = threading.Timer(
            self._poll_interval, self._poll_save)
        self._poll_timer.daemon = True
        self._poll_timer.start()
        log("[SmartPlayerMonitor] Poll timer started ({:.0f}s)".format(
            self._poll_interval))

    def _stop_poll_timer(self):
        """Cancel the background poll timer if running."""
        if self._poll_timer:
            self._poll_timer.cancel()
            self._poll_timer = None

    def _poll_save(self):
        """
        Called by the background timer — saves position to LOCAL backup only
        (no SMB write during active playback).  Reschedules itself.
        """
        if not self._active or not self._current_item:
            return
        try:
            pos   = self.getTime()
            total = self.getTotalTime()
            if pos > 10:
                self.manager.save_resume_position_local(
                    self._current_item, pos, total)
                log("[SmartPlayerMonitor] Poll save: {:.0f}s".format(pos))
        except Exception as _e:
            log("[SmartPlayerMonitor] _poll_save error: {}".format(_e))
        # Reschedule
        self._start_poll_timer()

    def _append_to_playlist(self, items):
        for ep in items:
            li = _make_listitem(ep)
            self.playlist.add(ep["file"], li)
        log("[SmartPlayerMonitor] Appended {} items to playlist".format(len(items)))


# -- Top-level player controller -----------------------------------------------

class SmartPlayer:
    """High-level controller: builds the playlist and starts playback."""

    def __init__(self, addon, manager):
        self.addon   = addon
        self.manager = manager

    def start_channel(self, channel):
        log("[SmartPlayer] Starting channel '{}'".format(channel["name"]))

        # Warn user if refill threshold >= queue size
        try:
            _qs  = channel.get("queue_size", 30)
            _rt  = max(1, int(
                self.addon.getSetting("refill_threshold") or "15"))
            if _rt >= _qs:
                xbmcgui.Dialog().notification(
                    "Smart TV Channels",
                    "Warning: Refill threshold ({}) >= queue size ({}). "
                    "Threshold capped at {}. Adjust in Settings.".format(
                        _rt, _qs, max(1, _qs // 2)),
                    xbmcgui.NOTIFICATION_WARNING, 6000)
                log("[SmartPlayer] Warning: refill_threshold {} >= "
                    "queue_size {} - capped at {}".format(
                        _rt, _qs, max(1, _qs // 2)))
        except Exception:
            pass

        queue = self.manager.build_queue(channel)
        if not queue:
            xbmcgui.Dialog().ok(
                "Smart TV Channels",
                "No episodes found for this channel."
            )
            return

        # Write queue file and pointer BEFORE building playlist so:
        # 1. Channel view shows correct episodes immediately
        # 2. Service can start monitoring the correct queue file
        self._write_now_playing(queue, channel["id"])

        first_titles = [ep.get("title", "?")[:20] for ep in queue[:3]]
        log("[SmartPlayer] Play queue first 3: {}".format(first_titles))

        # Build the xbmc.PlayList
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()

        for ep in queue:
            li = _make_listitem(ep)
            playlist.add(ep["file"], li)

        log("[SmartPlayer] Playlist built with {} items".format(len(queue)))

        # Create monitor before starting playback so no events are missed
        monitor = SmartPlayerMonitor(
            addon    = self.addon,
            manager  = self.manager,
            channel  = channel,
            queue    = list(queue),
            playlist = playlist,
        )

        # Start playback - service handles state updates via now_playing pointer
        monitor.play(playlist)
        log("[SmartPlayer] Playback started")


    def _resolve_path(self, filename):
        """
        Return the full path for *filename*, respecting the
        shared_storage_path addon setting.  Mirrors the logic in
        service.resolve_path and ChannelManager._resolve_path.
        local_library.json always stays local.
        """
        import os
        import xbmcvfs
        _LOCAL_ONLY: set = set()  # all files use shared path when configured
        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
        except Exception:
            raw = ""
        # A single space is the XML default — treat as blank
        raw = raw.strip()
        if raw in ("smb://", "smb:/"):
            raw = ""
        # Convert Windows UNC (\\\\Server\\share) to smb://Server/share
        if raw.startswith("\\\\") or raw.startswith("//"):
            raw = raw.lstrip("\\/")
            raw = "smb://" + raw.replace("\\", "/")
        shared = raw.rstrip("/").rstrip("\\") if raw else ""
        if shared and filename not in _LOCAL_ONLY:
            if not xbmcvfs.exists(shared):
                try:
                    xbmcvfs.mkdirs(shared)
                except Exception:
                    pass
            # Network paths use forward slash; local paths use os.path.join
            if "://" in shared:
                return shared + "/" + filename
            return os.path.join(shared, filename)
        profile = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        return os.path.join(profile, filename)

    def _write_now_playing(self, queue, primary_channel_id=None):
        """
        Write a per-channel queue file: queue_{channel_id}.json
        primary_channel_id must always be passed explicitly.
        Never derive from queue items — interleaved items carry the
        foreign channel's _channel_id giving the wrong filename.
        """
        import json, os
        import xbmcvfs
        profile = xbmcvfs.translatePath(
            self.addon.getAddonInfo("profile"))

        if not queue:
            return

        # Always use the explicitly passed primary channel ID
        first_ep   = queue[0]
        channel_id = (primary_channel_id
                      or first_ep.get("channel_id", "")
                      or first_ep.get("_channel_id", ""))

        # Normalize queue entries - minimal for TV, richer for movies
        data = []
        for ep in queue:
            cid      = ep.get("_channel_id") or ep.get("channel_id", "")
            sid      = ep.get("_show_id") if ep.get("_show_id") is not None                        else ep.get("show_id", 0)
            is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0

            if is_movie:
                # Movies keep metadata for playlist display.
                # _interleaved MUST be preserved so the service can
                # distinguish foreign interleaved movies from primary
                # channel movies when advancing state.
                genre = ep.get("genre", "")
                if isinstance(genre, list):
                    genre = ", ".join(genre)
                entry = {
                    "channel_id":  cid,
                    "_channel_id": cid,
                    "show_id":     0,
                    "_show_id":    0,
                    "movieid":     ep.get("movieid", -1),
                    "episodeid":   -1,
                    "title":       ep.get("title",   ""),
                    "season":      0,
                    "episode":     0,
                    "file":        ep.get("file",    ""),
                    "is_movie":    True,
                    "year":        ep.get("year",    0),
                    "genre":       genre,
                    "plot":        ep.get("plot",    ""),
                    "rating":      ep.get("rating",  0),
                    "mpaa":        ep.get("mpaa",    ""),
                    "runtime":     ep.get("runtime", 0),
                }
                if ep.get("_interleaved"):
                    entry["_interleaved"] = True
                data.append(entry)
            else:
                # TV episodes - minimal fields only
                data.append({
                    "channel_id":  cid,
                    "_channel_id": cid,
                    "show_id":     sid,
                    "_show_id":    sid,
                    "episodeid":   ep.get("episodeid", -1),
                    "tvshowtitle": ep.get("tvshowtitle", ""),
                    "title":       ep.get("title",   ""),
                    "season":      ep.get("season",  0),
                    "episode":     ep.get("episode", 0),
                    "file":        ep.get("file",    ""),
                })

        # Write per-channel queue file (atomic: write .tmp then rename)
        queue_filename = "queue_{}.json".format(channel_id)
        queue_path     = self._resolve_path(queue_filename)
        queue_tmp      = queue_path + ".tmp"
        try:
            import os as _os2
            json_str = json.dumps(data, indent=2)
            is_shared = not queue_path.startswith(profile)
            if not is_shared:
                with xbmcvfs.File(queue_path, "w") as _f:
                    _f.write(json_str)
            else:
                local_copy = _os2.path.join(profile,
                                            _os2.path.basename(queue_path))
                with xbmcvfs.File(local_copy, "w") as _f:
                    _f.write(json_str)
                if not xbmcvfs.copy(local_copy, queue_path):
                    if "://" not in queue_path:
                        with open(local_copy, "r", encoding="utf-8") as _s, \
                             open(queue_path, "w", encoding="utf-8") as _d:
                            _d.write(_s.read())
            log("[SmartPlayer] {} written ({} items)".format(
                queue_filename, len(data)))
        except Exception as e:
            log("[SmartPlayer] Failed to write queue file: {}".format(e))

        # Write now_playing.json pointer
        # Always write to local profile first (guaranteed to work).
        # Also write to shared path if configured.
        # The service reads from shared path via resolve_path(), but
        # ALSO checks the local profile as a fallback if shared read fails.
        pointer_path = self._resolve_path("now_playing.json")
        try:
            import os as _os3
            _ptr_str = json.dumps({
                "active_channel_id": channel_id,
                "queue_file": queue_filename,
            }, indent=2)
            # Always write local copy first
            local_ptr = _os3.path.join(profile, "now_playing.json")
            with xbmcvfs.File(local_ptr, "w") as _f2:
                _f2.write(_ptr_str)
            log("[SmartPlayer] now_playing.json written (local)")
            # Also push to shared path if different
            if pointer_path != local_ptr:
                ok = xbmcvfs.copy(local_ptr, pointer_path)
                if ok:
                    log("[SmartPlayer] now_playing.json copied to shared")
                else:
                    log("[SmartPlayer] now_playing.json shared copy failed "
                        "- service will use local copy", level=1)
        except Exception as e:
            log("[SmartPlayer] Failed to write now_playing pointer: {}".format(e))


# -- List item builder ---------------------------------------------------------

def _make_listitem(ep):
    """
    Build an xbmcgui.ListItem from an episode or movie queue dict.
    NOTE: ListItem lives in xbmcgui, NOT xbmc.
    Handles both TV episodes and movies.
    """
    title      = ep.get("title", "Unknown")
    is_movie   = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
    if not is_movie:
        show   = ep.get("tvshowtitle", "") or ep.get("showtitle", "")
        season = int(ep.get("season",  0) or 0)
        ep_num = int(ep.get("episode", 0) or 0)
        if show:
            label = "{} - S{:02d}E{:02d} - {}".format(
                show, season, ep_num, title)
        else:
            label = title
    else:
        label = title
    li = xbmcgui.ListItem(label=label)

    if is_movie:
        movie_id = int(ep.get("movieid", -1) or -1)

        # If metadata is missing from queue entry (old format queue file),
        # look it up from the local library cache
        year    = int(ep.get("year",    0) or 0)
        plot    = ep.get("plot",    "") or ""
        genre   = ep.get("genre",   "") or ""
        rating  = float(ep.get("rating", 0) or 0)
        mpaa    = ep.get("mpaa",    "") or ""
        runtime = int(ep.get("runtime", 0) or 0)

        if movie_id > 0 and not year:
            # Missing metadata - look up from local cache
            try:
                import xbmcaddon as _xbmcaddon
                _addon   = _xbmcaddon.Addon()
                from resources.lib.library import LibraryClient
                _lib     = LibraryClient(_addon)
                _movies  = _lib.get_all_movies()
                _m       = next((m for m in _movies
                                 if m.get("movieid") == movie_id), None)
                if _m:
                    year    = int(_m.get("year",   0) or 0)
                    plot    = (_m.get("plot",   "") or "")[:300]
                    genre   = _m.get("genre",  [])
                    if isinstance(genre, list):
                        genre = " / ".join(genre)
                    rating  = float(_m.get("rating", 0) or 0)
                    mpaa    = _m.get("mpaa",   "") or ""
                    runtime = int(_m.get("runtime", 0) or 0)
            except Exception as e:
                log("[SmartPlayer] Cache lookup failed: {}".format(e))

        if isinstance(genre, list):
            genre = " / ".join(genre)

        log("[SmartPlayer] Movie ListItem: id={} title={} year={} "
            "plot_len={} genre={} rating={}".format(
            movie_id, title[:20], year, len(plot), genre[:20], rating))

        # Use InfoTagVideo API (Kodi 21+) to avoid deprecation warning
        try:
            tag = li.getVideoInfoTag()
            tag.setMediaType("movie")
            tag.setDbId(movie_id)
            tag.setTitle(title)
            tag.setOriginalTitle(title)
            tag.setPlot(plot)
            tag.setPlotOutline(plot[:100] if plot else "")
            tag.setYear(year)
            tag.setGenres([g.strip() for g in genre.split("/") if g.strip()])
            tag.setRating(rating)
            tag.setMpaa(mpaa)
            tag.setDuration(runtime)
        except Exception:
            li.setInfo("video", {
                "mediatype": "movie", "dbid": movie_id,
                "title": title, "plot": plot, "year": year,
                "genre": genre, "rating": rating,
                "mpaa": mpaa, "duration": runtime,
            })
        li.setProperty("IsPlayable", "true")
    else:
        # TV episodes - use InfoTagVideo API
        try:
            tag = li.getVideoInfoTag()
            tag.setMediaType("episode")
            tag.setTitle(title)
            tag.setTvShowTitle(ep.get("tvshowtitle", "") or ep.get("showtitle", ""))
            tag.setSeason(int(ep.get("season",  0) or 0))
            tag.setEpisode(int(ep.get("episode", 0) or 0))
            tag.setPlot(ep.get("plot", ""))
            tag.setDuration(int(ep.get("runtime", 0) or 0))
        except Exception:
            li.setInfo("video", {
                "mediatype":   "episode",
                "title":       title,
                "tvshowtitle": ep.get("tvshowtitle", "") or ep.get("showtitle", ""),
                "season":      int(ep.get("season",  0) or 0),
                "episode":     int(ep.get("episode", 0) or 0),
                "plot":        ep.get("plot",    ""),
                "duration":    int(ep.get("runtime", 0) or 0),
            })

    # Artwork - use whatever is available in the queue entry
    art   = ep.get("art", {})
    thumb = art.get("thumb") or ep.get("thumbnail", "")
    if thumb:
        li.setArt({"thumb": thumb, "icon": thumb})

    li.setProperty("IsPlayable", "true")
    return li
