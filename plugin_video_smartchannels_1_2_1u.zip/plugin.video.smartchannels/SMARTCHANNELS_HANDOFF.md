# plugin.video.smartchannels — Project Handoff

## Overview

Custom Kodi 21/22 (Omega/Piers, Python 3) addon that creates smart TV-style
channels playing TV episodes, movies, folder media, serial content, audio, and
party mode music in configurable rotation with persistent queue/state management,
auto top-up, channel scheduling, and broadcast-style overlays.

- **Owner/Developer:** Mark
- **Home setup:** MySQL-backed shared Kodi library; NAS at 192.168.1.11;
  NVIDIA Shield as primary playback device; Windows 10 PC as primary test machine
- **Current build:** `1.2.1u`
- **Last built zip:** `plugin_video_smartchannels_1_2_1u.zip`
- **addon.xml version:** `1.2.1u`
- **Goal:** Submission to official Kodi addon repository
- **Working directory:** `/home/claude/plugin_work/build_out/plugin.video.smartchannels/`
- **Output zips:** `/mnt/user-data/outputs/` — uncompressed (`-0` flag),
  exclude `*.pyc` and `__pycache__`
- **strings.po last used ID:** `#32804`
- **strings.po next free ID:** `#32805`
- **addon.xml version must match zip filename on every build**

---

## Test Status (as of end of this session)

Tests run against 1.2.1u using the Playback Behavior Test Matrix.

| Test | Result |
|------|--------|
| Natural End — TV, RR, Recycle, Mid-queue | ✅ PASS |
| Skip handling (multiple skip counts) | ✅ PASS |
| Queue top-up at threshold | ✅ PASS |
| Audio CUN timing | ❌ OPEN BUG (see below) |
| Carousel pop + silent sweep | ✅ PASS (confirmed in overnight log) |
| TV Round Robin sequential order (overnight) | ✅ PASS (full episode sequence verified) |
| Movie channel last-movie resume | ✅ PASS (fixed in 1.2.1u) |

**Next test to run:** Continue Playback Behavior Test Matrix from where left off.
Audio CUN timing bug must be fixed before audio CUN tests can pass.

---

## Open Bugs

### Audio CUN fires too early (poll timer starts at 60s instead of 10s)

**Confirmed from log evidence.** The audio poll timer starts at 60s interval
instead of 10s for audio channels. Root cause: when `onPlayBackStarted` fires
and `_start_poll_timer` is called, `_current_ep` may not yet be set to the
audio item, so the `is_audio` check evaluates False and the timer starts at
the video interval (60s). The CUN then fires incorrectly because 60s into a
short song leaves little remaining time and the video lead window maths fires
when it shouldn't.

**Fix needed:** In `service.py`, the poll timer start logic must check the
channel type from the channel dict (not from `_current_ep`) when deciding
the interval for audio channels. This requires a log to confirm the exact
timing sequence — request a new log showing the poll timer start and the
first CUN fire for an audio channel.

**Status:** Root cause confirmed from log, fix not yet written.
One "Build On Top" available (no failed fix attempts made).

---

## Changes This Session (1.2.1m → 1.2.1u)

### 1.2.1n — Audio channel improvements
- Removed Recycle/Stop from audio wizard (hardcoded recycle=True)
- Added "Random (no repeats)" playback order option
- String #32804 added

### 1.2.1o — Bug fix: audio queue items missing artist/album/songid
- `_write_now_playing()` in `player.py` had no audio branch; audio items
  fell through to the TV minimal format, stripping artist, album, songid,
  is_audio, and all music metadata from queue items on every write
- Fixed by adding a dedicated audio/party branch preserving all music fields

### 1.2.1p — Bug fix: "Random (no repeats)" showing as "Random" in channel info
- The channel info dialog had a separate order_str lookup dict that was
  missing the no_repeat entry

### 1.2.1q — Architecture fix: audio no_repeat state I/O moved to channel_manager
- `_no_repeat_filter` and `record_no_repeat_played` in audio.py were calling
  `self._cm._load_json` / `self._cm._save_json` directly (private methods)
- Fixed by adding public methods `get_audio_no_repeat_played` and
  `set_audio_no_repeat_played` to channel_manager.py

### 1.2.1r — Bug fix: no_repeat tracking never fires on this Kodi platform
- `onPlayBackEnded` does not fire reliably for audio playlist transitions
  on this build; transitions appear as "Detected 1 skipped episode(s)"
- Added audio branch to skip loop in service.py to call
  `record_no_repeat_played` there, matching the actual event that fires

### 1.2.1s — Bug fix: audio channels creating spurious TV-style state entry
- `set_now_playing` was creating a state.json entry shaped like a TV episode
  for every audio song start
- Fixed by adding `or ep.get("is_audio")` to the guard that skips this for movies

### 1.2.1t — Party channel improvements
- Removed Recycle/Stop from party wizard (hardcoded recycle=True)
- Added "Random (no repeats)" playback order option using file paths (not songid)
- State tracked under `ch_<id>:party_no_repeat_played` in state.json
- New public methods on channel_manager: `get_party_no_repeat_played`,
  `set_party_no_repeat_played`
- Channel info and channel list display updated to show playback order
- Skip loop and `_handle_end` both record played files for party channels

### 1.2.1u — Bug fix: last movie resume replaced by exhaustion dialog
- When skipping to the last movie on a recycle=False channel, `_update_queue_file`
  triggered a top-up returning 0 new items; the skip-exhaustion check
  `len(remaining) <= 1` fired, deleted the queue file, and set
  `_pending_exhausted_channel` while the movie was still playing
- Resume positions written afterwards were orphaned
- Fixed by changing `<= 1` to `== 0` so the queue file is only deleted when
  the queue is genuinely empty (last item has finished); `onPlayBackEnded`
  handles exhaustion after natural completion

### README.md updated
- Full rewrite covering all features through 1.2.1u
- Audio channel, Party Mode, Channel Scheduling, Duration Cache, Songs Cache,
  Lower Third Ticker, Channel Logo Overlay all fully documented
- Known Limitations expanded with audio/party no-repeat notes and platform notes

---

## Audio Channel Architecture Notes

### no_repeat tracking
- **Audio channels:** tracked by `songid` in `state.json` key
  `ch_<id>:audio_no_repeat_played` (list of int songid values)
- **Party channels:** tracked by file path in `state.json` key
  `ch_<id>:party_no_repeat_played` (list of file path strings)
- State I/O via public channel_manager methods only (not private _load/_save_json)
- Tracking fires in skip loop (primary path on this platform) AND in
  `_handle_end` (for platforms where `onPlayBackEnded` fires reliably)
- Requires channel created after 1.2.1o for songid/file to be present in queue items
- Full cycle reset (played list cleared) when all songs/files have been heard

### Queue items for audio/party
- Written by dedicated branch in `player.py` `_write_now_playing()`
- Fields preserved: `is_audio`, `songid`, `artist`, `album`, `genre`, `year`,
  `track`, `thumbnail`, plus all standard fields
- Party items also get `is_party_item=True`

### Recycle/Stop
- Audio channels: always recycle=True, no exhaustion tracking, Stop removed from wizard
- Party channels: always recycle=True, no exhaustion tracking, Stop removed from wizard
- Folder channels: Recycle/Stop meaningful and working — keep as-is
- TV/Movie/Serial channels: Recycle/Stop meaningful and working — keep as-is

---

## Completed Features (all confirmed stable)

- TV/Movie/Serial/Folder channel types
- Persistent queue, state management, auto top-up
- Unified Interleave (multi-source with silent flag)
- Episode/Movie/Serial Exclusions
- Round Robin rotation
- Carousel / Pseudo Live
- Coming Up Next overlay (video + audio)
- Channel Logo Overlay (timed, 5s default)
- Side Panel (two-pane WindowXML) — song/track selection plays selected item
- Lower Third Ticker (with schedule-aware upcoming programming promos)
- Duration Cache
- Channel Scheduling (fire blocks, soft-start, Once with date targeting)
- Audio Channels (artist/album/genre/all filters, balanced shuffle, song
  exclusions, no-repeat mode)
- Party Mode (local and NAS folder audio, no-repeat mode)
- Songs Cache (26,362 songs, ~2.5 min to build, instant read after)
- Channel Sort (A-Z, Move Up/Down in Side Panel)
- Channel Info shows schedule relationships (target/source)
- Auto-Create Channels
- Backup & Restore

---

## Cleanup Items (pre-repo-submission)

### 1. Hardcoded string in player.py (repo submission blocker)
**Location:** `resources/lib/player.py` lines 46-48
**Issue:** Refill threshold warning notification uses hardcoded English:
```python
xbmcgui.Dialog().notification(
    "Smart TV Channels",
    "Warning: Refill threshold ({}) >= queue size ({}). "
    "Threshold capped at {}. Adjust in Settings."...
```
**Fix needed:** Add a `strings.po` entry and replace with `self._s()` call.
This is a repo submission blocker — all user-visible strings must go through
strings.po.

### 2. folder.py direct state access (architectural)
**Location:** `resources/lib/channels/folder.py` line 151
**Issue:** Calls `self._cm._load_json(self._cm._state_path, {})` directly —
same private-method access pattern that was fixed in audio.py (1.2.1q).
**Fix needed:** Add public methods `get_folder_state` / `set_folder_state`
to `channel_manager.py` and update `folder.py` to use them.
**Note:** Not a functional bug, purely architectural. Lower priority than #1.

---

## On The Horizon

- **EPG Overlay (1.3.0a)** — full spec written and approved
  (`SPEC_1_3_0a_LiveClock_EPG.md`). Two parts:
  1. Live Clock Channels — wall-clock timeline, tune in mid-programme
  2. Multi-Channel EPG Grid — full-screen programme guide
  Next free string ID for this feature: #32805

- **ffprobe Batch NFO Scanner** — spec written, pending approval
  (`SPEC_ffprobe_batch_scanner.md`). Windows-only utility to pre-scan
  folder library files with ffprobe and write companion NFOs in bulk,
  before first playback.

- **Audio Now Playing Overlay (1.2.2a)** — spec written and approved
  (`SPEC_1_2_2a_AudioNowPlaying.md`). Persistent overlay during audio
  channel playback showing current song metadata and upcoming tracks.

- **Audio CUN timing fix** — open bug documented above. Fix before
  building 1.2.2a Audio Now Playing Overlay.

---

## Architecture Rules (NEVER VIOLATE)

1. `service.py` owns ALL playback callbacks, state advancement, resume,
   top-up, playlist management
2. `player.py` owns ONLY `start_channel()` and `_write_now_playing()`
3. `channel_manager.py` owns queue building, state read/write, library access
4. NO duplicate code between files
5. NO playback event handlers outside `service.py`
6. No hardcoded dialog text — all user-visible strings through `strings.po`
7. All code written for Kodi official repo submission standard
8. MANDATORY strings audit before and after every change touching strings
9. One feature or fix at a time
10. Never break working functionality
11. **FAILED FIX PROTOCOL:** One "Build On Top" permitted when root cause is
    confirmed and only implementation detail was wrong. After two failed
    attempts on same bug, always Roll Back to last confirmed-working zip.
12. CHANGELOG entry written BEFORE packaging
13. **PRE-CODING CHECKLIST** (mandatory before any new function):
    - What does this function do? (one sentence)
    - Which module owns it per the boundary map?
    - Does it already exist anywhere in the codebase?
    - If yes: import it. If no: write it in the correct module only.

---

## Packaging Command

```bash
cd /home/claude/plugin_work/build_out && zip -0 -r \
  /mnt/user-data/outputs/plugin_video_smartchannels_VERSION.zip \
  plugin.video.smartchannels \
  --exclude "*.pyc" --exclude "*/__pycache__/*" --exclude "*/__pycache__"
```

## Rollback Command

```bash
cd /home/claude/plugin_work/build_out && rm -rf plugin.video.smartchannels && \
  unzip -q /mnt/user-data/outputs/plugin_video_smartchannels_VERSION.zip
```

## Strings Audit Script

```python
import re, glob
from collections import Counter
base = "/home/claude/plugin_work/build_out/plugin.video.smartchannels"
with open(base + "/resources/language/resource.language.en_gb/strings.po") as f:
    po = f.read()
all_ids = re.findall(r'msgctxt "#(\d+)"', po)
defined = set(int(x) for x in all_ids)
dupes = {k: v for k, v in Counter(all_ids).items() if v > 1}
code_ids = set()
for fpath in glob.glob(base + "/**/*.py", recursive=True):
    with open(fpath) as f: src = f.read()
    for m in re.findall(r'(?:getLocalizedString|_s)\s*\(\s*(\d{5})\b', src):
        code_ids.add(int(m))
with open(base + "/resources/settings.xml") as f: xml = f.read()
xml_ids = set(int(x) for x in re.findall(r'label="(\d+)"', xml))
broken = sorted((code_ids | xml_ids) - defined)
print("Duplicates:", dupes or "NONE")
print("Broken:", broken or "NONE")
print("Highest ID: #{}".format(max(defined)))
```

---

## Log Filtering

For playback events, queue operations, overlay lifecycle, carousel, scheduling,
and errors: filtered smartchannels-only log is sufficient.

For input/focus/window issues: full unfiltered log required.

Standard filter:
```bash
grep -i "smartchannel\|fire_block\|block.*item\|onPlayBack\|carousel\|scheduler\|advance_show\|no_repeat\|audio.*complet\|party.*complet" kodi.log \
  | grep -v "CAddonSettings\|playlists/video\|playlists/inprogress\|xsp\|LOCAL STORAGE"
```
