# Smart TV Channels — Test Checklist 1.2.0a
## Features under test: Audio Channels, Party Mode, Channel Sort Order
## Baseline: 1.1.9t (confirmed)

---

## Pre-Test Setup

- Kodi music library must be scraped and contain at least 20 songs
  across at least 3 artists and 2 genres for meaningful filter testing
- Have a folder of mp3/flac files accessible (local or network share)
  for Party Mode testing
- Have at least 4 channels already created for sort order testing
- Filtered smartchannels log is sufficient for all tests below

---

## §1 — Channel Sort Order

**§1.1 — Move Down**
- Open channel list; note current order (channels A, B, C, D...)
- Right-click channel A → "Move Down"
- Confirm channel list immediately refreshes
- Confirm order is now B, A, C, D...
- Restart Kodi; confirm order B, A, C, D... persists (written to channels.json)

**§1.2 — Move Up**
- Right-click channel A (now in position 2) → "Move Up"
- Confirm order returns to A, B, C, D...

**§1.3 — Boundary behaviour**
- Right-click the first channel → "Move Up"
- Confirm nothing changes (no error, no crash, list unchanged)
- Right-click the last channel → "Move Down"
- Confirm nothing changes

**§1.4 — Interaction with hidden channels**
- Hide channel B (toggle visibility)
- Move channel A down
- Confirm A swaps with C (hidden channels are included in the
  underlying array even when not displayed — verify in channels.json)
- Unhide B; confirm order is correct

**§1.5 — Regression: existing context menu items**
- Confirm Play, Edit, Reset, Delete, Hide, Set Icon, Add Schedule,
  Manage Interleave, View Exclusions all still present and functional
  after sort menu items added

---

## §2 — Audio Channel Creation

**§2.1 — Full library (no filter)**
- Settings → Create Channel → Audio
- Select "No Filter (full library)"
- Select "Random"
- Select "Recycle: Yes"
- Name: "All Music"
- Confirm → channel created
- Log: confirm `[AudioQueueBuilder] built N songs` line

**§2.2 — Artist filter**
- Create Audio channel → "Filter by Artist"
- Select 2 artists from the multiselect picker
- Confirm only songs by those artists appear in the queue JSON

**§2.3 — Filter mode: genre + year**
- Create Audio channel → "Filter by Genre, Year, Rating"
- Add genre filter: "Rock" (contains)
- Add year filter: > 1980
- Confirm queue contains only matching songs

**§2.4 — Filter mode: played status**
- Add filter: played status = "Unplayed"
- Confirm queue contains no songs with playcount > 0
  (verify via Kodi library or log)

**§2.5 — Album order**
- Create Audio channel with "Album Order" selected
- Inspect queue JSON: confirm songs are sorted by
  albumartist → album → disc → track, not random

**§2.6 — Recycle=False exhaustion**
- Create small Audio channel (single artist with ~5 songs), recycle=No
- Play all songs through to natural end
- Confirm exhaustion dialog appears (same as video channels)

---

## §3 — Audio Playback

**§3.1 — Basic playback**
- Open Audio channel → plays
- Confirm OSD shows correct artist and title (from getMusicInfoTag)
- Confirm album art visible in OSD (thumbnail set correctly)

**§3.2 — Queue top-up**
- Play through several songs
- Confirm new songs added to queue when below refill threshold
- Log: `[ChannelManager] Audio top-up: N items`

**§3.3 — Skip**
- While audio channel playing, press Next
- Confirm skip detected and counted correctly in log
- Confirm next song begins playing

**§3.4 — Natural end**
- Let a song play to natural end
- Log: `_handle_end: audio item completed, queue advances naturally`
- Confirm NO advance_show / advance_movie_state calls in log
- Confirm next song plays

**§3.5 — No resume offered**
- Stop audio channel mid-song
- Reopen channel
- Confirm NO resume dialog appears (resume not applicable to audio)

**§3.6 — Channel list display**
- Confirm audio channel shows `[Audio] Random` or `[Audio] Album Order`
  and `(filtered)` when filters are set

---

## §4 — Audio Coming Up Next

**§4.1 — CUN fires for audio**
- Create Audio channel; set `cun_audio_enabled = true`,
  `cun_audio_lead = 20s`, `cun_audio_duration = 15s`,
  `cun_audio_min_duration = 30s`
- Play a song longer than 30s
- Confirm CUN overlay appears ~20s before end
- Confirm overlay shows: Artist name / Song title / Album name

**§4.2 — CUN suppressed for short songs**
- Set `cun_audio_min_duration = 200s`
- Play a song shorter than 200s
- Confirm NO CUN overlay appears

**§4.3 — CUN audio_enabled = false**
- Set `cun_audio_enabled = false`
- Play any song
- Confirm NO CUN overlay appears for audio
- Confirm CUN still appears normally for video channels

**§4.4 — Poll timer fires for audio**
- Log: confirm `Poll timer started (10s interval)` when audio channel starts
  (not 300s / 5 min as with video)
- For video channel: confirm `Poll timer started (Ns interval)` where N is
  the user's resume poll interval setting × 60

**§4.5 — CUN display content**
- For library Audio channel: confirm Artist / Song Title / Album shown
- For Party Mode channel: confirm filename (title) shown; artist/album
  lines absent (empty) or suppressed

---

## §5 — Party Mode Channel

**§5.1 — Creation**
- Settings → Create Channel → Party Mode
- Enter path to folder of audio files
- Name: "Party Mix"
- Recycle: Yes
- Confirm → channel created
- Log: `[PartyQueueBuilder] Found N audio files in <path>`

**§5.2 — Audio-only files**
- Put a mix of .mp3, .flac, and .mkv (video) in the folder
- Create Party Mode channel
- Confirm queue contains only audio files (.mp3/.flac)
- Confirm .mkv is NOT included

**§5.3 — Network share path**
- Point Party Mode at a UNC/SMB path (\\Server\music or smb://...)
- Confirm files are found and queue builds correctly

**§5.4 — Playback**
- Open Party Mode channel → plays
- Confirm OSD shows filename (no artist/album metadata)
- Confirm random order each time channel is rebuilt

**§5.5 — Recycle=False**
- Create Party Mode channel with small folder (~5 files), recycle=No
- Play all files through
- Confirm exhaustion dialog appears

**§5.6 — is_audio poll timer**
- Log: confirm `Poll timer started (10s interval)` for Party Mode channel
  (same fast-poll as library Audio channel)

---

## §6 — Regression: Existing Video Channels

**§6.1 — TV channel: natural end, skip, top-up**
- Play a TV channel through 2 natural ends and 1 skip
- Confirm state advances correctly (show_index, episode_id)
- Confirm NO audio-branch log lines appear

**§6.2 — Movie channel: natural end**
- Play a movie to natural end
- Confirm advance_movie_state called in log
- Confirm resume cleared

**§6.3 — Folder channel: natural end**
- Play a Folder (video) channel
- Confirm `is_folder_item` path taken in _handle_end
- Confirm audio poll timer NOT used (video poll interval)

**§6.4 — Serial channel**
- Play 2 episodes on a serial channel
- Confirm serial state advances correctly

**§6.5 — CUN for video unchanged**
- Confirm CUN still fires for TV/movie channels at the existing
  lead_minutes setting
- Confirm `cun_audio_enabled = false` does NOT affect video CUN

**§6.6 — Channel sort: scheduling unaffected**
- Move a channel that has an active schedule
- Confirm schedule still fires correctly (schedule references channel
  by ID, not by position)

**§6.7 — Channel sort: interleave unaffected**
- Move a channel that is an interleave source for another channel
- Confirm interleave still works (interleave references by channel ID)

**§6.8 — Poll timer interval for video**
- Start a TV channel
- Log: confirm `Poll timer started` shows resume_poll_interval × 60
  seconds (NOT 10s)

---

## §7 — Strings and Settings Audit

Run the strings audit script before and after the build:
- Zero duplicates
- Zero broken references
- All new audio CUN settings visible in Settings UI
- All new string IDs used exactly once

---

## §8 — Edge Cases

**§8.1 — Empty audio library**
- Create Audio channel when music library has no songs
- Confirm graceful error (notification or dialog), no crash

**§8.2 — Party Mode: empty folder**
- Create Party Mode channel pointing at empty folder
- Confirm graceful empty-queue handling, no crash

**§8.3 — Audio channel as schedule source**
- Create a schedule with an Audio channel as the source
- Confirm fire_block() pulls audio items and tags them with _schedule_id
- Confirm block items play correctly on target channel

**§8.4 — Side panel with audio channels**
- Open Side Panel
- Confirm Audio and Party channels appear in channel list
- Confirm ticker shows audio channel queue head


---

## §9 — Folder Default Duration Unit Fix

**§9.1 — Default value**
- Fresh install (or reset settings): confirm `folder_default_duration`
  shows 120 in Settings UI (not 20)
- Create a folder channel with a file that has no companion NFO
- Inspect the queue JSON: confirm `"duration": 120` (seconds) not
  `"duration": 1200` (old 20-minute default in seconds)

**§9.2 — Custom value set by user**
- Set `folder_default_duration` to 30 in Settings
- Rebuild a folder channel queue (delete queue file or reset channel)
- Inspect queue JSON: confirm `"duration": 30` on items without NFOs
- Confirm side panel shows ~0:30 for those items

**§9.3 — NFO items unaffected**
- A file with an existing companion NFO should read its real duration
  regardless of the default setting
- Confirm `duration_is_default: false` on those items in queue JSON

**§9.4 — Party Mode inherits correct default**
- Create a Party Mode channel with files that have no companion NFOs
- Confirm queue items show `"duration": 120` (or whatever default is set)
  not 1200

**§9.5 — CHANGELOG note visible**
- Confirm CHANGELOG entry warns users who had a custom minute-based
  value set that they need to update it to the equivalent seconds value

**§9.6 — Regression: existing folder channels with NFOs**
- Play a folder channel that has companion NFOs already written
- Confirm durations are read from NFOs correctly, unaffected by the
  unit change (NFOs store absolute seconds, no conversion needed)

---

## §10 — Party Mode Library Path Matching

**§10.1 — Files in Kodi music library (NAS/SMB path)**
- Create a Party Mode channel pointing at a folder that is also
  in your Kodi music library (e.g. smb://192.168.1.11/music/Queen/)
- Inspect queue JSON: confirm matched files have artist, album, title
  from library metadata, not filename stem
- Confirm `"songid"` is set (not -1) on matched items
- Confirm `"duration"` is the real library duration (not 0)
- Confirm `"thumbnail"` is set to album art path

**§10.2 — Files NOT in Kodi music library**
- Create a Party Mode channel pointing at a folder of audio files
  that have never been scraped into Kodi (e.g. a folder of bumpers
  or jingles outside your library paths)
- Inspect queue JSON: confirm these items have `"songid": -1`,
  `"artist": ""`, `"album": ""`, `"duration": 0`
- Confirm `"title"` is the filename stem (no extension, no path)

**§10.3 — Mixed folder (some in library, some not)**
- Point Party Mode at a folder containing both scraped and unscraped files
- Confirm queue JSON shows library metadata for scraped files and
  filename-stem fallback for unscraped files — both in the same queue

**§10.4 — UNC path entry by user**
- Create Party Mode channel using a UNC path (\\192.168.1.11\music\Queen\)
  for a folder that is in your Kodi library
- Confirm path matching still works despite UNC vs smb:// form difference
- Confirm scraped metadata appears on queue items

**§10.5 — Library unavailable (MySQL down)**
- Temporarily make the music library unreachable
- Create or rebuild a Party Mode channel
- Confirm channel builds successfully with filename-stem fallback
- Confirm no crash or error dialog — log shows fallback warning only
- Restore library; confirm next rebuild picks up metadata correctly

**§10.6 — CUN for library-matched party items**
- A party item matched from the library has real duration
- Confirm CUN fires correctly based on that duration
  (respects `cun_audio_min_duration`)

**§10.7 — CUN suppressed for unmatched party items**
- A party item with `duration=0` (not in library)
- Confirm CUN does NOT fire for that item
  (suppressed by `total == 0` check in audio CUN trigger)
