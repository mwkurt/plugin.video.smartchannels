# Smart TV Channels — Test Checklist Addendum 1.2.0d
## Covers: new features and regression areas introduced in 1.2.0b–1.2.0d
## Base checklist: SmartChannels_TestChecklist_1_2_0a.md
## Use both documents together. This addendum does not replace the base.

---

## Corrections to Base Checklist (1.2.0a)

### §1.5 — Regression: context menu items (UPDATED)
The following items from the original §1.5 are **intentionally absent**
on Audio and Party channels as of 1.2.0c/1.2.0d. Do NOT treat their
absence as a failure:
- **Add Schedule** — suppressed for audio and party channels
- **Manage Interleave** — suppressed for audio and party channels

The corrected assertion is:
- On **TV, Movie, Serial, Folder** channels: confirm Add Schedule,
  Manage Interleave, View Exclusions (TV/Serial/Movie only) all present
- On **Audio and Party** channels: confirm Add Schedule and Manage
  Interleave are **absent**; View Exclusions absent (unchanged)

### §8.3 — Audio channel as schedule source (UPDATED)
The original §8.3 tested that an audio channel could be a schedule
source. This is **no longer possible** as of 1.2.0c. The corrected
test is in §A6.3 below.

---

## §A1 — Album Picker (Artist mode, new in 1.2.0d)

**§A1.1 — Album picker appears after artist selection**
- Create Audio channel → Filter by Artist
- Select 1 or more artists → confirm
- Confirm an album picker dialog appears for EACH selected artist,
  showing that artist's albums as a checklist with all ticked by default
- Log: `[LibraryClient] get_all_songs: N songs` (library called once,
  cached for subsequent album lookups)

**§A1.2 — All albums included (nothing deselected)**
- Select an artist; in the album picker leave ALL albums ticked
- Complete wizard and save
- Inspect `channels.json` for the new channel:
  `"included_albums": {"Artist Name": []}` — empty list means all included
- Inspect queue JSON: confirm songs from ALL that artist's albums appear

**§A1.3 — Specific albums selected**
- Select an artist; in the album picker tick only 2 of their albums
- Complete wizard and save
- Inspect `channels.json`:
  `"included_albums": {"Artist Name": ["Album A", "Album B"]}`
- Inspect queue JSON: confirm ONLY songs from those 2 albums appear;
  songs from other albums of that artist are absent
- Log: no `excluded_songs: removed` lines (album filter is not
  song-exclusion; it's applied in `_apply_included_albums`)

**§A1.4 — Multiple artists, different album selections**
- Select 2 artists: Artist A (select 1 album), Artist B (select all albums)
- Inspect queue JSON: Artist A songs only from chosen album;
  Artist B songs from all albums; no songs from other artists
- Confirm the total song count matches the sum of selected albums' tracks

**§A1.5 — Artist with no albums found in library**
- If any selected artist has no songs in the library (edge case):
  wizard should not crash; `included_albums[artist] = []` (all included
  by default), queue builds with whatever the artist filter returns

**§A1.6 — Edit channel: album selections pre-filled**
- Edit an audio channel that has specific albums selected
- At the album picker step: confirm previously selected albums are
  pre-ticked; unselected albums are unticked
- Change selection; save → `channels.json` and queue both updated correctly

**§A1.7 — Switching mode clears album data**
- Edit an audio channel that has `included_albums` and `excluded_songs` set
- At Step 1, switch to Advanced Filter (mode 2)
- Save → inspect `channels.json`:
  `"included_albums": {}`, `"excluded_songs": []` — both cleared
- Queue contains songs from the new filter rules only

---

## §A2 — Song Exclusions (new in 1.2.0d)

**§A2.1 — Song exclusion dialog appears**
- In the audio wizard artist mode, at the song exclusion step:
  "Do you want to exclude specific songs?" → Yes
- Confirm the artist picker loop appears, then album picker, then
  song multiselect with track number and title for each song

**§A2.2 — Songs excluded from queue**
- Select 3 songs to exclude across 2 albums; save
- Inspect `channels.json`: `"excluded_songs": [songid1, songid2, songid3]`
- Inspect queue JSON: none of those 3 songs appear (by file path or songid)
- Log: `[AudioQueueBuilder] excluded_songs: removed 3 song(s)`

**§A2.3 — Song exclusion pre-selected on edit**
- Edit a channel with existing excluded songs
- At the song exclusion step → Yes
- Navigate to the album containing an excluded song
- Confirm that song's checkbox is pre-ticked in the multiselect
- Remove it from exclusion; save → `excluded_songs` no longer contains
  that songid; song reappears in queue

**§A2.4 — No exclusions (answered No)**
- In the wizard, at the "Exclude songs?" prompt → No
- Confirm existing `excluded_songs` list is preserved unchanged
  (answering No does not clear prior exclusions — it just skips the step)

**§A2.5 — All songs in an album excluded**
- Exclude every song in one album for an artist
- Queue JSON: no songs from that album; other albums still present
- Channel plays without error

**§A2.6 — Exclusions combined with album filter**
- Select 2 albums for an artist; then exclude 2 songs from one of them
- Queue must contain: all songs from album A except the 2 excluded +
  all songs from album B
- Verify count: (album_A_total - 2) + album_B_total songs for that artist

---

## §A3 — Balanced Shuffle (new in 1.2.0d)

**§A3.1 — Balanced option appears in wizard**
- Create Audio channel → Step 3 (Playback Order)
- Confirm three options: Random / Balanced (equal artist airtime) /
  Album Order
- Select Balanced; save → `channels.json`: `"audio_order": "balanced"`,
  `"randomize": true`

**§A3.2 — Artist interleaving confirmed**
- Create a balanced channel with 2 artists of very different catalogue
  sizes (e.g. one with 50 songs, one with 10 songs)
- Inspect queue JSON (30 items): confirm songs alternate between artists
  — no run of more than ~3 consecutive songs from the same artist
- The exact pattern will have some jitter but should be visibly
  interleaved, not clustered

**§A3.3 — Balanced does not affect album-order channels**
- A channel with `audio_order="album"` should be unaffected
- Inspect queue: songs still sorted albumartist → album → disc → track

**§A3.4 — Random still works (regression)**
- A channel with `audio_order="random"` should still use pure shuffle
- Log: no `_balanced_shuffle` reference in log for a random channel
- Queue order is different on each rebuild (probabilistic — rebuild twice
  and compare)

**§A3.5 — Balanced top-up**
- Let a balanced channel drain below top-up threshold
- Log: `[AudioQueueBuilder] top-up: N new items`
- Inspect queue tail: new items are balanced-shuffled from remaining songs
- Note: a small artist-cluster at the join point between old tail and new
  top-up is acceptable (documented limitation)

---

## §A4 — Channel Info Audio/Party Branches (new in 1.2.0d)

**§A4.1 — Audio channel info: artist mode**
- Open Channel Info on an audio channel configured with artist mode
- Confirm dialog shows:
  - "Audio Channel" type label
  - Playback order (Random / Balanced / Album Order)
  - When exhausted (Recycle / Stop)
  - "Content: Filter by Artist"
  - Each artist name
  - Each album for that artist indented underneath (all of them)
  - "X song(s) excluded" line if excluded_songs is non-empty
  - Queue item count

**§A4.2 — Audio channel info: all albums for artist**
- Artist with 5 albums, all included (`included_albums[artist] = []`)
- Channel Info shows all 5 album names indented under the artist
- No "All albums included" summary line — all albums listed individually

**§A4.3 — Audio channel info: advanced filter mode**
- Open Channel Info on a channel using advanced filters (genre + year)
- Confirm shows "Content: Advanced Filter" and lists each filter rule
  (e.g. "Genre = Rock", "AND Year > 1980")
- No artist list, no album list

**§A4.4 — Audio channel info: full library**
- Open Channel Info on a full-library audio channel
- Confirm shows "Content: Full Library" — no artists, no albums

**§A4.5 — Party channel info**
- Open Channel Info on a Party Mode channel
- Confirm shows: "Party Mode Channel", folder path, recycle setting,
  queue count
- No artist/album/filter lines

**§A4.6 — TV channel info unchanged (regression)**
- Open Channel Info on a TV channel
- Confirm existing TV channel info displays correctly — show list,
  episode count, exclusion count, carousel status
- No audio-branch lines appear

---

## §A5 — Context Menu Suppressions (new in 1.2.0c/1.2.0d)

**§A5.1 — Add Schedule absent on audio channel**
- Right-click an Audio channel
- Confirm "Add Schedule" does NOT appear in the context menu

**§A5.2 — Add Schedule absent on party channel**
- Right-click a Party Mode channel
- Confirm "Add Schedule" does NOT appear in the context menu

**§A5.3 — Manage Interleave absent on audio channel**
- Right-click an Audio channel
- Confirm "Manage Interleave" does NOT appear

**§A5.4 — Manage Interleave absent on party channel**
- Right-click a Party Mode channel
- Confirm "Manage Interleave" does NOT appear

**§A5.5 — TV/Movie channels unaffected (regression)**
- Right-click a TV channel and a Movie channel
- Confirm both Add Schedule AND Manage Interleave still present on both

**§A5.6 — Serial channel (regression)**
- Right-click a Serial channel
- Confirm Add Schedule present; Manage Interleave absent (was already
  suppressed for serial before 1.2.0d — confirm still correct)

---

## §A6 — Schedule Wizard Target/Source Filtering (new in 1.2.0c/1.2.0d)

**§A6.1 — Audio channel absent from target picker**
- Open Schedule Wizard (any channel → Add Schedule, or Settings →
  Manage Schedules → Add)
- At Step 2 (Target Channel): confirm Audio channels do NOT appear
  in the target picker list

**§A6.2 — Party channel absent from target picker**
- Same as §A6.1: confirm Party Mode channels do NOT appear in the
  target picker list

**§A6.3 — Audio channel absent from source picker (replaces old §8.3)**
- At Step 3 (Source Channel): confirm Audio channels do NOT appear
  in the source picker list (was already excluded in 1.2.0a; confirm
  still correct after 1.2.0d changes)

**§A6.4 — TV/Movie/Folder channels still appear as targets**
- Confirm TV, Movie, and Folder channels DO appear in the target picker
- Confirm they also appear as source options (unless carousel-enabled)

**§A6.5 — Pre-selected target from context menu**
- Right-click a TV channel → Add Schedule
- Step 2 (Target Channel) opens with that TV channel pre-selected
- Confirm this still works correctly after the audio/party filtering

---

## §A7 — Backwards Compatibility (existing audio channels)

**§A7.1 — Old audio channel (no included_albums/excluded_songs)**
- If you have an audio channel created in 1.2.0a that has no
  `included_albums` or `excluded_songs` keys in `channels.json`
- Confirm it plays correctly without any error
- Log: no `excluded_songs: removed` line (empty set, skipped)
- Log: `[AudioQueueBuilder] built N songs` — full artist pool used

**§A7.2 — Old audio channel edit**
- Edit an old audio channel (no album/song data)
- At the album picker step: all albums pre-ticked (default)
- At song exclusion: "No" — no existing exclusions
- Save → channel gains `included_albums` and `excluded_songs: []`
- Queue rebuilds correctly

**§A7.3 — Old audio channel: balanced order**
- Edit an old audio channel; change order to Balanced
- Save; play — confirm interleaved playback
- `channels.json`: `"audio_order": "balanced"` stored correctly

---

## §A8 — Carousel Source Channel Guard (new in 1.2.0c)

**§A8.1 — Carousel blocked on schedule source channel**
- Configure a channel as a source in an active schedule
- Edit that channel; proceed to Step 8 (Carousel)
- Confirm informational dialog appears explaining carousel is unavailable
- Confirm carousel step is skipped; `carousel_enabled` remains false

**§A8.2 — Carousel channel absent from source picker**
- Have a channel with carousel enabled
- Open Schedule Wizard → Step 3 (Source Channel)
- Confirm that carousel-enabled channel does NOT appear in source list
- If it was the only eligible source, confirm "no source channels
  available" message appears

**§A8.3 — Carousel note dialog shown**
- When opening the source picker with at least one carousel-excluded
  channel, confirm the informational dialog appears before the picker:
  "Note: channels with carousel enabled are excluded..."

**§A8.4 — Non-source channels can still enable carousel (regression)**
- Edit a channel that is NOT a schedule source
- Confirm carousel step (Step 8) appears normally with Yes/No prompt
- Enable carousel; save — works correctly

---

## §A9 — Boundary / Edge Cases

**§A9.1 — Artist with songs on multiple albums, some excluded by album,
          some excluded by song**
- Select artist; include only album A; exclude 1 song from album A
- Queue must contain: all songs from album A except the excluded one
- Songs from album B (not selected) must be absent

**§A9.2 — Balanced shuffle with single artist**
- Create a balanced channel with only 1 artist selected
- Queue should play that artist's songs in a shuffled order (balanced
  with one artist degenerates to pure shuffle — confirm no error/crash)

**§A9.3 — Balanced shuffle with one artist having 0 songs**
- After album filtering, one artist ends up with no qualifying songs
- Confirm balanced shuffle handles empty pool gracefully (no crash,
  remaining artist plays normally)

**§A9.4 — Channel Info: audio channel with no excluded songs**
- Open Channel Info on an audio channel with `excluded_songs: []`
- Confirm "X song(s) excluded" line does NOT appear (only shown when
  excluded_songs is non-empty)

**§A9.5 — Very long album list in Channel Info**
- An artist with many albums (e.g. 20+): Channel Info textviewer
  should scroll correctly in Kodi; no truncation or crash

---

## Log Lines to Confirm

| Feature | Expected log line |
|---------|------------------|
| Album filter applied | `[AudioQueueBuilder] excluded_songs: removed N song(s)` (only if excluded_songs non-empty) |
| Balanced shuffle | No specific log line — confirm by queue inspection |
| Carousel source guard | `[Carousel] check_all: skipping '...' — active schedule source channel` |
| Boundary top-up skip | `_update_queue_file: skipping top-up — block reload pending` |
| Block resume fix | `_recalculate_tail: skipping — queue contains scheduled block items` |

---

*Addendum written: 2026-07-21*
*Applies to: 1.2.0d (base checklist: 1.2.0a)*
