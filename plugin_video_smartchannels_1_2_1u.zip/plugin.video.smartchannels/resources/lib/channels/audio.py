"""
resources/lib/channels/audio.py
================================
Queue builder for Audio channels (channel_type="audio").

OWNS:   Fetching songs from the Kodi music library, applying audio_filters,
        included_albums, excluded_songs, ordering (random/balanced/album),
        and building/topping-up the queue.

NEVER:  State reads/writes, playback control, UI rendering.
        All library access via self._cm.library (LibraryClient).
        All queue file I/O via channel_manager methods.

CALLERS: channel_manager.py only — via build_queue() and _topup_queue().
"""

from __future__ import annotations

import random

from resources.lib.channels.base import BaseQueueBuilder
from resources.lib.utils.logger  import log


class AudioQueueBuilder(BaseQueueBuilder):
    """
    Queue builder for Audio channels backed by the Kodi music library.

    Queue item keys:
        channel_id, _channel_id, songid, title, artist, album, genre,
        year, duration, file, track, disc, thumbnail, is_audio=True

    No NFO, no Duration Cache — duration comes directly from
    AudioLibrary.GetSongs response.

    Playback order values:
        "random"   — pure shuffle (random.shuffle)
        "balanced" — artist-interleaved shuffle: each artist gets equal
                     turns regardless of catalogue size (1.2.0d)
        "album"    — albumartist -> album -> disc -> track sort
    """

    def build(self, channel: dict, target_size: int,
              current_queue=None) -> list:
        """
        Build a fresh queue or top up an existing one.

        current_queue=None  -- fresh build: fetch all matching songs,
                               order them, trim to target_size.
        current_queue=list  -- top-up: re-fetch, exclude files already
                               in current_queue, append up to target_size
                               new items and return current_queue + new.
        """
        channel_id      = channel["id"]
        filters         = channel.get("audio_filters", [])
        order           = channel.get("audio_order", "random")
        included_albums = channel.get("included_albums", {})
        excluded_songs  = set(channel.get("excluded_songs", []))

        # Fetch songs from library (cached within the LibraryClient instance)
        try:
            songs = self._cm.library.get_songs_with_filters(filters)
        except Exception as e:
            log("[AudioQueueBuilder] library fetch error: {}".format(e))
            return current_queue if current_queue is not None else []

        if not songs:
            log("[AudioQueueBuilder] no songs found for channel '{}'".format(
                channel.get("name", channel_id)))
            return current_queue if current_queue is not None else []

        # Apply included_albums filter -- only when artist mode was used
        # and at least one artist has an explicit album selection.
        # included_albums = {"Artist Name": ["Album A", "Album B"], ...}
        # An artist with an empty list means all albums included for them.
        if included_albums:
            songs = self._apply_included_albums(songs, filters,
                                                included_albums)

        # Apply excluded_songs -- set of songid ints
        if excluded_songs:
            before = len(songs)
            songs  = [s for s in songs
                      if s.get("songid", -1) not in excluded_songs]
            log("[AudioQueueBuilder] excluded_songs: removed {} song(s)".format(
                before - len(songs)))

        if not songs:
            log("[AudioQueueBuilder] no songs remain after exclusions "
                "for channel '{}'".format(channel.get("name", channel_id)))
            return current_queue if current_queue is not None else []

        if current_queue is not None:
            # Top-up: exclude files already sitting in the queue
            queued_files = {item.get("file", "") for item in current_queue}
            songs = [s for s in songs
                     if s.get("file", "") not in queued_files]

            # no_repeat mode: also exclude song IDs played this cycle.
            # full_pool is the complete available song set (after exclusions)
            # used to detect when every song has played and the cycle resets.
            if order == "no_repeat":
                full_pool_ids = {s.get("songid", -1) for s in songs} | \
                                {item.get("songid", -1) for item in current_queue}
                songs = self._no_repeat_filter(
                    channel_id, songs, full_pool_ids)

            if not songs:
                log("[AudioQueueBuilder] top-up: all songs already queued")
                return current_queue

        # Order
        songs = self._sort_songs(songs, order)

        # Trim to target_size
        songs = songs[:target_size]

        # Build queue items
        items = []
        for s in songs:
            artist_list = s.get("artist", [])
            artist_str  = (", ".join(artist_list)
                           if isinstance(artist_list, list)
                           else str(artist_list))
            genre_list  = s.get("genre", [])
            genre_str   = (", ".join(genre_list)
                           if isinstance(genre_list, list)
                           else str(genre_list))
            items.append({
                "channel_id":  channel_id,
                "_channel_id": channel_id,
                "songid":      s.get("songid",    -1),
                "title":       s.get("title",      ""),
                "artist":      artist_str,
                "album":       s.get("album",      ""),
                "genre":       genre_str,
                "year":        int(s.get("year",   0) or 0),
                "duration":    int(s.get("duration", 0) or 0),
                "file":        s.get("file",       ""),
                "track":       int(s.get("track",  0) or 0),
                "disc":        int(s.get("disc",   0) or 0),
                "thumbnail":   s.get("thumbnail",  ""),
                "is_audio":    True,
            })

        if current_queue is not None:
            log("[AudioQueueBuilder] top-up: {} new items for '{}'".format(
                len(items), channel.get("name", channel_id)))
            return current_queue + items

        log("[AudioQueueBuilder] built {} items for '{}'".format(
            len(items), channel.get("name", channel_id)))
        return items

    def _apply_included_albums(self, songs: list, filters: list,
                               included_albums: dict) -> list:
        """
        Filter songs to only those whose album appears in included_albums
        for their matched artist.

        Only applied when mode = Artist picker (all filters have type=artist).
        For artists with an empty album list, all their albums are included.
        Songs from artists not in included_albums are excluded entirely.
        """
        if not filters or not all(f.get("type") == "artist"
                                  for f in filters):
            return songs

        artist_names_lower = {name.lower(): name
                               for name in included_albums.keys()}
        result = []
        for song in songs:
            song_artists = song.get("artist", [])
            if isinstance(song_artists, str):
                song_artists = [song_artists]
            for sa in song_artists:
                sa_lower = sa.lower()
                matched_name = None
                for configured_lower, configured_name in \
                        artist_names_lower.items():
                    if configured_lower in sa_lower:
                        matched_name = configured_name
                        break
                if matched_name is None:
                    continue
                allowed_albums = included_albums.get(matched_name, [])
                # Empty list = all albums allowed for this artist
                if not allowed_albums or \
                        song.get("album", "") in allowed_albums:
                    result.append(song)
                    break  # don't double-add if song matches multiple artists
        return result

    def _no_repeat_filter(self, channel_id: str, songs: list,
                          full_pool_ids: set) -> list:
        """
        Filter songs for no_repeat mode.

        Reads the played-songids list via channel_manager public API.
        Excludes any song whose songid appears in that list.
        If excluding played songs leaves nothing (all songs have been heard),
        resets the played list and returns all songs — starting a new cycle.
        """
        played    = set(self._cm.get_audio_no_repeat_played(channel_id))
        available = [s for s in songs if s.get("songid", -1) not in played]

        if not available:
            # Every song in the pool has been played — reset and start over.
            log("[AudioQueueBuilder] no_repeat: full cycle complete for \'{}\'"
                ", resetting played list".format(channel_id))
            self._cm.set_audio_no_repeat_played(channel_id, [])
            played    = set()
            available = songs  # all songs are fair game again

        log("[AudioQueueBuilder] no_repeat: {}/{} songs available ({} played)"
            .format(len(available), len(full_pool_ids), len(played)))
        return available

    def record_no_repeat_played(self, channel_id: str, songid: int) -> None:
        """
        Record a song as played for no_repeat tracking.
        Called from service.py _handle_end when audio_order == no_repeat.
        """
        if songid < 0:
            return
        played = self._cm.get_audio_no_repeat_played(channel_id)
        if songid not in played:
            played.append(songid)
            self._cm.set_audio_no_repeat_played(channel_id, played)

    def _sort_songs(self, songs: list, order: str) -> list:
        """
        Order the song list.

        order=="random"    -- pure shuffle.
        order=="no_repeat" -- pure shuffle (repeat avoidance handled upstream).
        order=="balanced"  -- artist-interleaved shuffle (1.2.0d).
        order=="album"     -- albumartist -> album -> disc -> track.
        Anything else      -- treat as random.
        """
        songs = list(songs)   # copy -- don't mutate the cached library list
        if order == "album":
            def _album_key(s):
                aa = s.get("albumartist", [])
                aa_str = (", ".join(aa) if isinstance(aa, list) else str(aa))
                return (
                    aa_str.lower(),
                    s.get("album", "").lower(),
                    int(s.get("disc",  0) or 0),
                    int(s.get("track", 0) or 0),
                )
            songs.sort(key=_album_key)
        elif order == "album_shuffle":
            songs = self._album_shuffle(songs)
        elif order == "balanced":
            songs = self._balanced_shuffle(songs)
        elif order == "no_repeat":
            random.shuffle(songs)   # same as random; repeat avoidance is upstream
        else:
            random.shuffle(songs)
        return songs

    def _album_shuffle(self, songs: list) -> list:
        """
        Album-coherent shuffle.

        Groups songs by album, shuffles the album sequence randomly, then
        sorts tracks within each album by disc -> track number.

        Result: complete albums play through in order, but the sequence of
        albums is randomised across all artists.

        If included_albums stored a preferred per-artist album order (from
        the wizard's Set Order Manually step), that ordering is already
        reflected in the channel's included_albums dict and was applied
        upstream by _apply_included_albums. The shuffle here operates on
        whatever albums remain after that filter.
        """
        # Group songs by album title
        by_album = {}
        for s in songs:
            key = s.get("album", "") or "Unknown Album"
            by_album.setdefault(key, []).append(s)

        # Sort tracks within each album: disc -> track
        for album_songs in by_album.values():
            album_songs.sort(key=lambda s: (
                int(s.get("disc",  0) or 0),
                int(s.get("track", 0) or 0),
            ))

        # Shuffle the album sequence
        album_keys = list(by_album.keys())
        random.shuffle(album_keys)

        # Flatten back to a single list
        result = []
        for key in album_keys:
            result.extend(by_album[key])
        return result

    def _balanced_shuffle(self, songs: list) -> list:
        """
        Artist-interleaved shuffle.

        Groups songs by primary artist, shuffles each group independently,
        then interleaves in round-robin order with per-pass artist-order
        jitter so it doesn't feel mechanical.

        Result: each artist gets equal turns regardless of catalogue size.
        """
        by_artist = {}
        for s in songs:
            artist_list = s.get("artist", [])
            if isinstance(artist_list, list) and artist_list:
                key = artist_list[0]
            elif isinstance(artist_list, str) and artist_list:
                key = artist_list
            else:
                key = "Unknown"
            by_artist.setdefault(key, []).append(s)

        pools = list(by_artist.values())
        for pool in pools:
            random.shuffle(pool)

        result  = []
        indices = list(range(len(pools)))
        while True:
            random.shuffle(indices)
            added_any = False
            for i in indices:
                if pools[i]:
                    result.append(pools[i].pop(0))
                    added_any = True
            if not added_any:
                break
        return result
