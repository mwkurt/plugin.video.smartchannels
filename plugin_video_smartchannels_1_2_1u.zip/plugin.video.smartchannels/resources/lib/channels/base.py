# channels/base.py
#
# OWNS:   Shared utilities used by all queue builder modules:
#         normalize_ep(), normalize_movie(), apply_interleave(),
#         get_filtered_episodes(), get_available_episodes(),
#         resolve_pointer_index(), and the BaseQueueBuilder abstract class.
#
# NEVER:  State reads/writes, playback control, UI rendering.
#         Any channel-type-specific logic belongs in the channel's own module.
#
# CALLERS: channels/tv.py, channels/movies.py, channels/serial.py
#          all via inheritance or direct import.
#          channel_manager.py does NOT call base.py directly — it calls
#          self._normalize_ep / self._apply_interleave / self.get_filtered_episodes
#          / self.get_available_episodes / self._resolve_pointer_index,
#          which delegate here.

from __future__ import annotations

from resources.lib.utils.logger import log


def normalize_ep(ep: dict, channel_id: str, show_id,
                 skip_missing_duration: bool = True) -> dict:
    """
    Strip an episode or movie dict down to the minimal fields needed
    for the queue file. Handles both TV episodes and movies.
    Avoids bloating the file with art, thumbnails etc.

    Duration is read from the companion NFO file at normalisation time
    and stored on the item. Items with duration=0 (missing/unreadable NFO)
    are returned as None when skip_missing_duration=True so the caller
    can record the miss and skip the item.

    Pre-1.1.7a items in existing queues have no "duration" key;
    callers use item.get("duration", 0) for backwards compatibility.
    """
    from resources.lib.utils.duration_cache import get_duration as _get_dur
    is_movie = ep.get("is_movie", False) or ep.get("movieid", -1) > 0
    cid      = ep.get("_channel_id") or ep.get("channel_id", channel_id)
    sid      = ep.get("_show_id") or ep.get("show_id", show_id)

    duration = _get_dur(ep)
    if skip_missing_duration and duration <= 0:
        return None     # caller must call record_missing_duration and skip

    if is_movie:
        return {
            "channel_id":  cid,
            "_channel_id": cid,
            "show_id":     0,
            "_show_id":    0,
            "movieid":     ep.get("movieid", -1),
            "episodeid":   -1,
            "title":       ep.get("title", ""),
            "season":      0,
            "episode":     0,
            "file":        ep.get("file", ""),
            "is_movie":    True,
            "duration":    duration,
        }
    return {
        "channel_id":  cid,
        "_channel_id": cid,
        "show_id":     sid,
        "_show_id":    sid,
        "episodeid":   ep.get("episodeid", -1),
        "tvshowtitle": ep.get("showtitle", ep.get("tvshowtitle", "")),
        "title":       ep.get("title", ""),
        "season":      ep.get("season",  0),
        "episode":     ep.get("episode", 0),
        "file":        ep.get("file",    ""),
        "duration":    duration,
    }


def normalize_movie(movie: dict, channel_id: str, library=None) -> dict:
    """
    Normalize a movie dict to the standard queue format.
    Includes metadata needed for playlist display.
    If fields are missing (old cache), fetches from local cache via library.
    """
    movie_id = movie.get("movieid", -1)
    genre    = movie.get("genre", [])
    year     = movie.get("year",  0)
    plot     = movie.get("plot",  "") or ""
    rating   = movie.get("rating", 0)
    mpaa     = movie.get("mpaa",  "") or ""
    runtime  = movie.get("runtime", 0)

    if movie_id > 0 and not year and not plot and library:
        try:
            cached = library.load_local_cache()
            if cached:
                m = next((x for x in cached.get("movies", [])
                          if x.get("movieid") == movie_id), None)
                if m:
                    year    = m.get("year",    0)
                    plot    = (m.get("plot",   "") or "")[:300]
                    genre   = m.get("genre",   genre)
                    rating  = m.get("rating",  rating)
                    mpaa    = m.get("mpaa",    mpaa) or ""
                    runtime = m.get("runtime", runtime)
        except Exception as e:
            log("[channels/base] normalize_movie cache lookup error: {}".format(e))

    if isinstance(genre, list):
        genre_str = ", ".join(genre)
    else:
        genre_str = str(genre) if genre else ""

    return {
        "channel_id":  channel_id,
        "_channel_id": channel_id,
        "show_id":     0,
        "_show_id":    0,
        "movieid":     movie_id,
        "episodeid":   -1,
        "title":       movie.get("title", ""),
        "season":      0,
        "episode":     0,
        "file":        movie.get("file", ""),
        "is_movie":    True,
        "year":        int(year or 0),
        "genre":       genre_str,
        "plot":        plot[:300] if plot else "",
        "rating":      float(rating or 0),
        "mpaa":        mpaa,
        "runtime":     int(runtime or 0),
        "duration":    int(runtime or 0),
    }


def get_filtered_episodes(show_entry: dict, library) -> list:
    """
    Return a show's episode pool with episode_filters applied ONLY —
    no exclusions. Single source for what was previously a duplicated
    get_episodes_with_filters()/get_episodes_for_show() dual-branch,
    inlined at multiple call sites across channel_manager.py,
    channels/serial.py, and ui/channels.py.

    Used directly by the Exclusions picker UI (which needs to know
    what's eligible to exclude — the current filtered pool — without
    exclusions already removing items from view).

    show_entry: a show dict from channel["shows"], must contain
    "tvshowid" and may contain "episode_filters".
    library: the LibraryClient instance (channel_manager.library).
    """
    sid        = show_entry["tvshowid"]
    ep_filters = show_entry.get("episode_filters", [])
    if ep_filters:
        return library.get_episodes_with_filters(sid, ep_filters)
    return library.get_episodes_for_show(sid)


def get_available_episodes(show_entry: dict, library) -> list:
    """
    Return a show's ACTUALLY PLAYABLE episode pool: episode_filters
    applied, then excluded_episodes removed.

    This is the pool every piece of playback/queue-building logic must
    use when deciding what CAN play next — as opposed to
    get_filtered_episodes(), which the Exclusions picker uses to see
    what's eligible to exclude in the first place.

    show_entry: a show dict from channel["shows"], must contain
    "tvshowid" and may contain "episode_filters" and
    "excluded_episodes".
    library: the LibraryClient instance (channel_manager.library).
    """
    eps = get_filtered_episodes(show_entry, library)
    excluded = show_entry.get("excluded_episodes", [])
    if not excluded:
        return eps
    excluded_set = set(excluded)
    return [e for e in eps if e["episodeid"] not in excluded_set]


def resolve_pointer_index(show_entry: dict, next_id, available_eps: list,
                          library) -> int:
    """
    Resolve a stored next_episode_id against a show's CURRENT available
    (filtered + exclusion-applied) episode pool, returning the index
    into available_eps to seed local_index/display with.

    This exists because a stored next_episode_id can go stale: it was a
    valid pointer when written, but the show was edited afterward to
    exclude that exact episode. Every call site that seeds a local
    index from next_episode_id previously handled a "pointer not found"
    ValueError by falling back to index 0 — but that fallback means
    restarting the show from its first available episode, which is
    correct for a genuinely missing/deleted episode but wrong for an
    excluded one: the user excluded one episode, not asked to restart
    the whole show.

    This resolver instead walks forward from the excluded pointer's
    ORIGINAL position (using the filtered-but-not-exclusion-trimmed
    order, so the position is still meaningful) and returns the first
    still-available episode from that point on — i.e. "skip forward
    past what's excluded, keep going" rather than "start over".

    Returns -1 if available_eps is empty (nothing playable at all).
    """
    if not available_eps:
        return -1

    avail_ids = [e["episodeid"] for e in available_eps]

    if next_id is None:
        return 0

    try:
        return avail_ids.index(next_id)
    except ValueError:
        pass  # next_id isn't directly available — resolve below

    full_eps = get_filtered_episodes(show_entry, library)
    full_ids = [e["episodeid"] for e in full_eps]
    try:
        orig_idx = full_ids.index(next_id)
    except ValueError:
        # Pointer isn't found anywhere at all (e.g. episode removed from
        # the Kodi library entirely) — unchanged pre-existing fallback
        # behaviour.
        return 0

    avail_id_set = set(avail_ids)
    for eid in full_ids[orig_idx:]:
        if eid in avail_id_set:
            return avail_ids.index(eid)

    # Nothing from the pointer's position onward survived exclusion —
    # wrap to the start of the available pool. recycle=False exhaustion
    # is detected and written independently by
    # advance_show()/_advance_sequential() at actual playback-advance
    # time; this only affects where a rebuilt/resumed queue starts.
    return 0


def apply_interleave(queue, interleave_cfg, get_foreign_items_fn,
                     get_channel_fn, primary_offset=0):
    """
    Weave items from a foreign channel into `queue`.

    Extracted from channel_manager._apply_interleave. All foreign-channel
    access is done through the two callables so this function has no direct
    dependency on ChannelManager.

    get_foreign_items_fn(foreign_id, foreign_ch, needed) -> list
    get_channel_fn(channel_id)                           -> dict | None
    """
    import random

    if not queue or not interleave_cfg:
        return queue

    foreign_id = interleave_cfg.get("channel_id")
    frequency  = max(1, int(interleave_cfg.get("frequency",  4)))
    jitter     = max(0, int(interleave_cfg.get("jitter",     0)))
    count_per  = max(1, int(interleave_cfg.get("count_per",  1)))

    if not foreign_id:
        return queue

    foreign_ch = get_channel_fn(foreign_id)
    if not foreign_ch:
        log("[channels/base] apply_interleave: foreign channel {} "
            "not found - skipping".format(foreign_id))
        return queue

    min_gap = max(1, frequency - jitter)
    _primary_since = primary_offset % frequency if frequency else 0
    needed = 0
    for _ in queue:
        _primary_since += 1
        if _primary_since >= min_gap:
            needed += 1
            _primary_since = 0
    if needed == 0:
        return queue
    needed = needed * count_per

    foreign_items = get_foreign_items_fn(foreign_id, foreign_ch, needed)
    if not foreign_items:
        log("[channels/base] apply_interleave: no items from '{}' "
            "- skipping".format(foreign_ch["name"]))
        return queue

    tagged = []
    for item in foreign_items:
        item = dict(item)
        item["_channel_id"]  = (item.get("_channel_id")
                                or item.get("channel_id", foreign_id))
        item["_show_id"]     = (item.get("_show_id")
                                or item.get("show_id", 0))
        item["_interleaved"] = True
        tagged.append(item)

    result        = []
    foreign_index = 0
    primary_since = primary_offset % frequency if frequency else 0

    if jitter == 0:
        next_gap = frequency
    else:
        next_gap = random.randint(max(1, frequency - jitter),
                                  frequency + jitter)

    for primary_item in queue:
        result.append(primary_item)
        primary_since += 1
        if primary_since >= next_gap and foreign_index < len(tagged):
            for _ in range(count_per):
                if foreign_index < len(tagged):
                    result.append(tagged[foreign_index])
                    foreign_index += 1
            primary_since = 0
            if jitter == 0:
                next_gap = frequency
            else:
                next_gap = random.randint(max(1, frequency - jitter),
                                          frequency + jitter)

    mode_str = (
        "every {}x{}".format(frequency, count_per)
        if jitter == 0
        else "every {}+/-{}x{} (range {}-{})".format(
            frequency, jitter, count_per,
            max(1, frequency - jitter), frequency + jitter))
    log("[channels/base] apply_interleave: inserted {} items from '{}' "
        "({}, offset={})".format(
        foreign_index, foreign_ch["name"], mode_str, primary_offset))

    return result


class BaseQueueBuilder:
    """
    Abstract base for all channel queue builders.
    Subclasses receive a ChannelManager instance and call its
    infrastructure methods rather than duplicating them.
    """

    def __init__(self, channel_manager):
        self._cm = channel_manager

    def build(self, channel: dict, target_size: int,
              current_queue=None) -> list:
        raise NotImplementedError

    # Convenience delegates so subclasses can call self._normalize_ep(...)
    def _normalize_ep(self, ep, channel_id, show_id):
        return normalize_ep(ep, channel_id, show_id)

    def _normalize_movie(self, movie, channel_id):
        return normalize_movie(movie, channel_id,
                               library=self._cm.library)
