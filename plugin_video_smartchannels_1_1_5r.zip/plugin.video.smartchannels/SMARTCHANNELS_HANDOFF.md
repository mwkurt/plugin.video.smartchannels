# plugin.video.smartchannels — Project Handoff

## Overview

Custom Kodi 21 (Omega / Python 3) addon that creates smart TV-style channels
playing TV episodes and movies in configurable rotation with persistent
queue/state management and auto top-up.

- **Owner/Developer:** Mark
- **Primary test machine:** Windows 10 PC. Shield is primary playback device.
- **Confirmed working baseline:** `1.1.5a`
- **Goal:** Eventual submission to the official Kodi addon repository
- **Working directory:** `/home/claude/plugin_work/build_out/plugin.video.smartchannels/`
- **Output zips:** `/mnt/user-data/outputs/` — uncompressed (`-0` flag),
  exclude `*.pyc` and `__pycache__`
- **strings.po last used ID:** `#32645`
- **strings.po total strings:** 443 (zero duplicates, zero broken)
- **Pre-existing orphaned strings (harmless):** #32183–32191, #32222, #32231,
  #32256, #32281, #32286, #32441, #32443, #32444, #32497, #32512, #32517
- **Next free string ID:** `#32646`
- **addon.xml version must match zip filename on every build**

---

## Current Build — 1.1.4o

All carousel tests TC-CAR.1 through TC-CAR.9 confirmed passing.
TC-CAR.9b through TC-CAR.12e and TC-CAR.SIL.1–10 are the open test
cases for this session's work.

---

## Architecture Rules — NEVER VIOLATE

1. `service.py` owns ALL playback callbacks, state advancement, resume,
   top-up, playlist management
2. `player.py` owns ONLY `start_channel()` and `_write_now_playing()`
3. `channel_manager.py` owns queue building, state read/write, library access
4. NO duplicate code between files — check before every change
5. NO playback event handlers outside `service.py`
6. **NO hardcoded user-visible strings** — all through strings.po via `_s()`
   - Log lines to kodi.log are exempt (developer-facing)
   - Every dialog title, body text, button label, setting label → strings.po
7. All code written for Kodi official repo submission standards
8. All file I/O through `xbmcvfs`
9. MANDATORY before/after code audit on every change: read the full method
   before editing, verify in context after, check all callers unaffected,
   syntax-check all modified files
10. One feature or fix at a time
11. Never break working functionality
12. **FAILED FIX PROTOCOL:** Before touching any code after a failed fix,
    explicitly state "Roll Back" or "Build On Top" and why (1–2 sentences).
    If this declaration is missing, push back before writing any code.
13. **CHANGELOG:** Every new build gets a `CHANGELOG.md` entry before packaging
14. **STRINGS:** Run audit script before AND after every session involving strings
15. **Read this handoff fully at the start of every session**

---

## Key Files

| File | Responsibility |
|------|---------------|
| `service.py` | Background service: playback events, skip detection, resume, top-up, exhaustion, CUN, carousel tick |
| `player.py` | `start_channel()`, `_write_now_playing()` only |
| `resources/lib/channel_manager.py` | Queue building, state I/O, library access, interleave |
| `resources/lib/carousel.py` | Carousel channel manager — owns ALL carousel logic |
| `resources/lib/channels/serial.py` | Serial queue builder |
| `resources/lib/channels/interleave.py` | Interleave weaving logic |
| `resources/lib/ui/channels.py` | Channel wizard including carousel step (TV+Movie only) |
| `resources/language/resource.language.en_gb/strings.po` | All UI strings — last ID #32590, 388 total |
| `CHANGELOG.md` | Version history — write entry BEFORE packaging |

---

## Channel Types

| Type | Description |
|------|-------------|
| `tv` | Round Robin or Random TV show rotation with per-show episode filters and exclusions |
| `movies` | Movie channel with optional filters and exclusions |
| `serial` | Single or multiple shows in strict serial order |
| `folder` | Media files from a directory path (no Kodi library needed) |

Both TV and Movie channels support carousel. Serial and Folder do not.

---

## Carousel Feature — Confirmed in 1.1.4o

Per-channel setting for TV and Movie channels. While nobody is watching,
every N minutes, M real items are removed from the front of the queue
file using Option A trailing sweep — silent interleaved items are swept
for free and do not count against pop_count. After every pop the queue
is immediately topped up to full depth via `_topup_queue`. When the user
opens the channel they pick up wherever the queue currently sits.

### Architecture
- `carousel.py` — owns ALL carousel logic
- `service.py` — two additions only:
  - Startup catch-up: `CarouselManager.check_all()` before run loop
  - `if tick % 60 == 0:` carousel check in run loop
- `channel_manager.py` — carousel fields in create/update whitelists;
  `_no_queue_change` guard in `update_channel`
- `ui/channels.py` — wizard Step 8 for TV and Movie channels only

### State key
`{channel_id}:__carousel__` → `{"last_pop_time": <float unix timestamp>}`

### Channel fields
| Field | Type | Default | Meaning |
|---|---|---|---|
| `carousel_enabled` | bool | False | Whether carousel is active |
| `carousel_interval` | int | 60 | Minutes between pops |
| `carousel_pop_count` | int | 1 | Real items removed per pop |

### Constants (carousel.py)
- `CAROUSEL_MIN_INTERVAL = 20` — enforced by wizard
- `CAROUSEL_QUEUE_FLOOR = 2` — last-resort safety constant (superseded
  by dynamic refill_threshold guard as primary clamp)

### Silent item sweep (Option A — 1.1.4o)
Silent interleaved items (`_silent=True`) are swept for free. The pop
walks forward counting only real items. After the last counted real item,
any immediately-following silents are also swept. The queue front is
always a real program after every pop.

### Pop guard
`pop_count` is clamped so at least `get_replenishment_threshold()` real
items remain after the pop (20% of queue_size, minimum 5).

### Resume behaviour
Resume cleared on pop via `clear_resume_position()`. Key also removed
from `self._state` and added to `_deleted_state_keys` to prevent
resurrection via `_save_state` merge (fixed in 1.1.4l).

---

## _no_queue_change Guard — update_channel

`update_channel` in `channel_manager.py` skips `_pregenerate_queue_safe`
when none of these fields changed: `name`, `shows`, `movies`,
`queue_size`, `interleave`, `filters`, `excluded_movies`, `mode`.
Carousel field changes and no-op edits both correctly skip the rebuild,
preserving the carousel's popped position.

---

## strings.po Audit Script

```python
import re, glob
from collections import Counter
base = "/home/claude/plugin_work/build_out/plugin.video.smartchannels"
with open(base + "/resources/language/resource.language.en_gb/strings.po") as f:
    po = f.read()
all_ids = re.findall(r'msgctxt "#(\d+)"', po)
defined = set(int(x) for x in all_ids)
dupes = {k: v for k, v in Counter(all_ids).items() if v > 1}
code_ids = set()
for fpath in glob.glob(base + "/**/*.py", recursive=True):
    with open(fpath) as f: src = f.read()
    joined = src.replace("\n", " ")
    for m in re.findall(r'(?:getLocalizedString|_s)\s*\(\s*(\d{5})\b', joined):
        code_ids.add(int(m))
with open(base + "/resources/settings.xml") as f: xml = f.read()
xml_ids = set(int(x) for x in re.findall(r'label="(\d+)"', xml))
xml_ids |= set(int(x) for x in re.findall(r'values="(\d+)"', xml))
all_used = code_ids | xml_ids
broken = sorted(all_used - defined)
orphaned = sorted(defined - all_used)
print("Duplicates:", dupes or "NONE")
print("Broken:", broken or "NONE")
print("Orphaned:", orphaned or "NONE")
print("Highest ID: #{}".format(max(defined)))
print("Total strings:", len(defined))
```

---

## Feature Queue

### Next confirmed feature
**Auto-Channel Creation** — COMPLETE in 1.1.5a.
- `resources/lib/ui/auto_channels.py` — full 9-screen wizard
- Wired into main screen, router.py, addon.py dispatch table
- Strings #32591–#32645 (55 strings)

### Possible future features (in dependency order)

**Channel Side Panel** — replaces EPG (see note below). A custom
`xbmcgui.WindowXML` panel that appears to the right of the channel list
when a channel is highlighted, showing the upcoming queue as a scrollable
episode/movie list. The user can arrow right into the panel and select
any item to start playback from that point, or select "Play Channel" to
start from the front. The panel updates as the user moves between
channels. No Duration Cache required — reads existing queue files.
Requires building a custom window to replace the current Kodi-managed
channel list directory view. Significant UI build but no new playback
or state logic.

**Note — EPG replaced by Side Panel:** The EPG Overlay and Side Panel
serve the same practical purpose (browsing upcoming content) but at
different moments. The Side Panel covers the pre-playback selection
moment; the EPG covered the mid-playback guide moment. The Side Panel
requires no Duration Cache and is significantly simpler to build. EPG
has been dropped from the queue in favour of Side Panel.

**Duration Cache** — prerequisite for Scheduled Programming only.
Library items first; ffprobe extension for Windows phase 2. Only needed
if Scheduled Programming is confirmed wanted.

**Scheduled Programming** — requires Duration Cache. User creates a
hidden movie/TV channel as the content source and a schedule entry
defining: source channel, target channel, item count, date/time. The
service rebuilds the target channel's queue ahead of the scheduled time,
inserting the scheduled item at the position nearest the target time
(calculated from item durations). No mid-episode cuts — always starts
and ends at natural item boundaries. Approximate timing is acceptable.
Shelved until Duration Cache is built.

---

## Known Open Bugs

### Redundant top-up on recycle=False exhausting channels
**Symptom:** For a recycle=False channel where the show has fewer
episodes than queue_size, `_topup_queue` fires on every episode
transition once the queue drops below threshold, returns 0 items each
time, and rewrites the tail marker unnecessarily.
**Impact:** Log noise and redundant disk writes only. Playback unaffected.
**Fix:** Add early-exit in `_topup_queue` when recycle=False and all
shows are exhausted.
**When:** Next session that touches `_topup_queue`.

---

## Lower Priority Feature Queue (no committed build date)

### Per-Show Expire in Round Robin
A per-show toggle for sequential (non-random) Round Robin TV channels.
When enabled on a specific show, that show plays through all its episodes
once and then permanently drops out of the rotation. The channel's other
shows continue cycling normally forever.

**Example:** Channel has Seinfeld, 3rd Rock, and Frasier. Frasier is
flagged expire_on_complete. Once Frasier's last episode plays it is gone
from the rotation permanently. Seinfeld and 3rd Rock keep cycling.

**Use case:** Watching a limited series or miniseries once as part of a
channel without having to remember to remove it manually afterward.

**Config:** New per-show key `shows[].expire_on_complete: true` (default
`false`). Set only in the creation wizard — not editable after creation.

**Architecture:** Mirrors the existing per-show `randomize` override
pattern. `_advance_sequential` already writes the exhaustion marker
(`next_episode_id: None`) on a show's last episode for recycle=False
channels — this feature gates that same write per-show instead of
channel-wide. The existing `_topup_queue` round-robin loop already
tracks a per-show `exhausted` set and skips exhausted shows.

**Before building:** Verify that `_topup_queue`'s round-robin loop
correctly continues indefinitely with a shrinking subset of active shows,
and that `episodes_per_slot` timing and `show_index` cycling are not
thrown off as shows drop out.

**Out of scope:** Serial channels (concept doesn't apply) and
channel-level `recycle=False` (all shows already behave this way).

---

### Notify on New Episodes
Per-show toggle on TV channels. When the library cache rebuilds after a
Kodi library scan (`VideoLibrary.OnScanFinished` → `_rebuild_library_cache`
already hooked in `service.py`), check `get_recently_added_episodes()`
against the `tvshowid` sets of all channels where any show has
`notify_new_episodes: true`. Fire a Kodi toast notification for each match:
"Smart Channels — New episode: The Office S09E23 - Finale."

To avoid repeat notifications across restarts, store a pruned set of
already-notified episode IDs in state.json under a dedicated key.

**Infrastructure already in place:**
- `onNotification` → `_rebuild_library_cache` hook in `service.py`
- `get_recently_added_episodes()` in `library.py`
- Toast notification pattern already used elsewhere in service.py

**New work needed:** per-show wizard toggle, post-rebuild comparison method
in `channel_manager.py`, notified-IDs state key.

---

### Queue File Write Lock
A file-level mutex in `utils/paths.py` to prevent silent data corruption
from concurrent queue file writes. Currently `_write_queue_file` has no
lock — carousel pop, playback top-up, and `onPlayBackEnded` all call
`save_json` directly with no mutual exclusion.

**Real risk:** Carousel pop vs `onPlayBackEnded` race — the carousel tick
and a natural episode end can both attempt to write the same queue file
in the brief window between one episode ending and the next starting.
Last write wins silently. No crash, but wrong queue state possible.

**Fix:** A `threading.Lock()` keyed by file path in a module-level dict
in `utils/paths.py`. Acquired before any write, released after. All queue
file writes become mutually exclusive regardless of calling thread.
Single-file change — `utils/paths.py` only.

**Priority note:** The carousel's architectural guard (skips currently-
playing channels) prevents the most common overlap. Risk is real but
infrequent given the 60-second tick interval. NAS/SMB shared storage
raises the risk slightly due to the write-to-temp-then-copy pattern.

---

## Maybe — Low priority, no committed build date

### Compact JSON Lists
A custom JSON serialiser in `utils/paths.py` replacing `json.dumps(data, indent=2)`
with a renderer that keeps flat lists of numbers/strings on a single line while
keeping objects and nested structures normally indented. Purely cosmetic — the
addon reads either format identically. Reduces state.json and queue files
significantly when `played_ids` or `interleave_order` contain many entries.
Single-file change, needs careful testing for all data types the addon writes.

---

## Removed from Queue (Mark's decision)
- End of Queue Warning
- Smart Playlist Channel
- Binge Mode / Auto-skip Credits
- Multiple Interleave Sources (superseded by existing multi-source interleave)

---

## Test Procedure Status

**PASSING:** TC-1.x through TC-17.1, TC-EXC.1–16, TC-UI.1–3,
TC-RR.1–2, TC-EPS.1, TC-9.x through TC-13.x, TC-CAR.1–9

**OPEN (this session's work):**
- TC-CAR.9b — Carousel resumes popping after stop
- TC-CAR.9c — Skip-while-playing still works after 1.1.4j
- TC-CAR.9d — Queue survives Kodi close mid-playback
- TC-CAR.10 — Resume cleared for popped items (including no resurrection)
- TC-CAR.11 — Resume works on non-carousel channels
- TC-CAR.12 through TC-CAR.12e — Queue rebuild guard variants
- TC-INFO.1 through TC-INFO.7 — Channel Info and View Exclusions
- TC-CAR.SIL.1 through TC-CAR.SIL.10 — Silent-item-aware pop

**Test procedure documents:**
- `SmartChannels_TestProcedure_1_1_3g.md` — TC-1.x through TC-17.1
- `SmartChannels_TestProcedure_1_1_4a_thru_1_1_4l.md` — TC-CAR.1–12e, TC-INFO.1–7
- `SmartChannels_TestProcedure_TC-CAR-SIL_1_1_4o.md` — TC-CAR.SIL.1–10

---

## Version History — 1.1.4 Series

| Version | Change |
|---------|--------|
| 1.1.4a | Feature: Carousel Channel (carousel.py, wizard step, service hooks) |
| 1.1.4b | Fix: Carousel fields not persisted (missing from whitelists) |
| 1.1.4c | Improvement: Carousel channels support resume; resume cleared on pop |
| 1.1.4d | Improvement: Carousel minimum interval reduced from 30 to 20 minutes |
| 1.1.4e | Fix: Hardcoded minimum interval in wizard (now uses CAROUSEL_MIN_INTERVAL) |
| 1.1.4f | Fix: Popped episodes reappear after channel edit (attempted, two-bug root cause) |
| 1.1.4g | Fix: _only_carousel_changed — old_carousel_* snapshotted after update; no-op edit triggered rebuild |
| 1.1.4h | Fix: filters and excluded_movies not checked in _no_queue_change guard |
| 1.1.4i | Feature: Channel Info shows carousel status and exclusion counts; View Exclusions context menu |
| 1.1.4j | Fix: _channel_id not cleared on stop — carousel permanently skipped channel after first play |
| 1.1.4k | Fix: Queue deleted on Kodi shutdown — _channel_id now only cleared when not abortRequested() |
| 1.1.4l | Fix: Resume resurrected after carousel pop — clear_resume_position now removes from self._state and _deleted_state_keys |
| 1.1.4m | Fix: Carousel queue not topped up after pop while idle |
| 1.1.4n | Fix: Post-pop top-up added 3× too many items (refill_queue threshold misuse — now uses _topup_queue directly) |
| 1.1.4o | Feature: Silent-item-aware pop (Option A trailing sweep); pop guard uses refill_threshold |

---

## Coding Standards

- Uncompressed zips only (`zip -0`)
- Exclude `*.pyc` and `__pycache__/`
- Label zip with version: `plugin_video_smartchannels_1_1_4o.zip`
- addon.xml version must match zip filename
- Bug fix letters: 1.1.4p, 1.1.4q...
- Feature releases: 1.1.5a etc.
- Read entire method before editing
- After any change: syntax check, verify in context, check all callers
- CHANGELOG.md entry written BEFORE zip is packaged
- All user-visible strings through strings.po — no exceptions
- Log lines (kodi.log) may be hardcoded — developer-facing
