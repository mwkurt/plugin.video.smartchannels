"""
resources/lib/ui/channels.py
==============================
All channel-related UI.

OWNS:   All channel list rendering, channel wizard, interleave dialog,
        filter builder, and channel info dialog.

NEVER:  State reads/writes (use channel_manager), playback (use player),
        JSON-RPC calls (use library). Hardcoded user-visible strings —
        all text via self._s() from strings.po.
"""

from __future__ import annotations

from urllib.parse import urlencode
from typing import Optional

import xbmc
import xbmcplugin
import xbmcgui
import xbmcaddon

from resources.lib.channel_manager import ChannelManager
from resources.lib.utils.logger     import log


class ChannelUI:

    def __init__(self, handle, base_url, addon, manager):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon
        self.manager  = manager

    def _url(self, **kwargs):
        return "{}?{}".format(self.base_url, urlencode(kwargs))

    def _s(self, sid: int) -> str:
        """Return localised string from strings.po. Never hardcode text."""
        return self.addon.getLocalizedString(sid)

    # -- Channel list ----------------------------------------------------------

    def list_channels(self, params):
        import xbmcaddon as _xa
        self.addon  = _xa.Addon()
        show_hidden = self.addon.getSetting("show_hidden_channels") == "true"
        if show_hidden:
            channels = self.manager.get_all_channels()
        else:
            channels = self.manager.get_visible_channels()
        log("[ChannelUI] list_channels - {} channels (show_hidden={})".format(
            len(channels), show_hidden))

        for ch in channels:
            self._add_channel_item(ch)

        try:
            _show_mgmt = self.addon.getSetting(
                "show_management_items") != "false"
        except Exception:
            _show_mgmt = True

        if _show_mgmt:
            li = xbmcgui.ListItem(label=self._s(32202))
            li.setArt({"icon": "DefaultAddSource.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="create_channel"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label=self._s(32591))
            li.setArt({"icon": "DefaultAddSource.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="auto_create_channels"),
                li, isFolder=False)

            import os as _os2
            import xbmcvfs as _xbmcvfs2
            _profile2    = _xbmcvfs2.translatePath(
                self.addon.getAddonInfo("profile"))
            _cache_path2 = _os2.path.join(_profile2, "local_library.json")
            if _xbmcvfs2.exists(_cache_path2):
                try:
                    import time as _time2
                    _stat2  = _xbmcvfs2.Stat(_cache_path2)
                    _age2   = (_time2.time() - _stat2.st_mtime()) / 86400.0
                    _clabel = self._s(32377).format(int(_age2))
                except Exception:
                    _clabel = self._s(32203)
            else:
                _clabel = self._s(32376)
            li = xbmcgui.ListItem(label=_clabel)
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="refresh_library"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label=self._s(32378))
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="open_settings"),
                li, isFolder=False)

            try:
                _shared = self.addon.getSetting(
                    "shared_storage_path").strip()
                _shared_active = (bool(_shared)
                                  and _shared not in ("smb://", "smb:/"))
            except Exception:
                _shared_active = False
            if _shared_active:
                li = xbmcgui.ListItem(label=self._s(32379))
                li.setArt({"icon": "DefaultAddonNone.png"})
                xbmcplugin.addDirectoryItem(
                    self.handle, self._url(action="clear_shared_path"),
                    li, isFolder=False)

            li = xbmcgui.ListItem(label=self._s(32380))
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="backup_data"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label=self._s(32381))
            li.setArt({"icon": "DefaultAddonService.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="restore_data"),
                li, isFolder=False)

            li = xbmcgui.ListItem(label=self._s(32382))
            li.setArt({"icon": "DefaultAddonNone.png"})
            xbmcplugin.addDirectoryItem(
                self.handle, self._url(action="delete_all_data"),
                li, isFolder=False)

    def _add_channel_item(self, ch):
        shows        = ch.get("shows", [])
        show_count   = len(shows)
        randomized   = "  [R]" if ch.get("randomize") else ""
        channel_type = ch.get("channel_type", "tv")

        if channel_type == "movies":
            movie_count = len(ch.get("movies", []))
            filters     = ch.get("filters", [])
            if filters:
                type_str = "  ({} movies, filtered)".format(movie_count)
            else:
                type_str = "  ({} movie{})".format(
                    movie_count, "s" if movie_count != 1 else "")
        elif channel_type == "serial":
            type_str = "  [Serial] ({} show{})".format(
                show_count, "s" if show_count != 1 else "")
        elif channel_type == "folder":
            folder_path = ch.get("folder_path", "")
            folder_name = folder_path.rstrip("/").rstrip("\\").rsplit("/", 1)[-1]
            folder_name = folder_name.rsplit("\\", 1)[-1].replace("%20", " ")
            type_str = "  [Folder] {}{}".format(
                folder_name[:20], randomized)
        else:
            filters  = ch.get("filters", [])
            filtered = " [filtered]" if filters else ""
            type_str = "  ({} show{}{})".format(
                show_count,
                "s" if show_count != 1 else "",
                filtered)

        il_cfg = ch.get("interleave")
        if il_cfg:
            from resources.lib.channels.interleave import get_sources
            il_sources = get_sources(ch)
            if il_sources:
                src     = il_sources[0]
                foreign = self.manager.get_channel(src["channel_id"])
                if foreign:
                    freq   = src["frequency"]
                    jitter = src["jitter"]
                    extra  = " +{}".format(len(il_sources) - 1) if len(il_sources) > 1 else ""
                    if jitter == 0:
                        il_str = "  +IL:{}/{}{}".format(foreign["name"][:12], freq, extra)
                    else:
                        il_str = "  +IL:{}/{}+/-{}{}".format(
                            foreign["name"][:12], freq, jitter, extra)
                else:
                    il_str = "  +IL:?"
            else:
                il_str = ""
        else:
            il_str = ""

        try:
            _show_count = self.addon.getSetting(
                "show_episode_count") != "false"
        except Exception:
            _show_count = True
        if _show_count:
            _q_path = self.manager._queue_file_path(ch["id"])
            try:
                import xbmcvfs as _xbmcvfs2, json as _json2
                if _xbmcvfs2.exists(_q_path):
                    with _xbmcvfs2.File(_q_path, "r") as _qf:
                        _q = _json2.loads(_qf.read())
                    _count_str = "  [{} ep]".format(len(_q))
                else:
                    _count_str = ""
            except Exception:
                _count_str = ""
        else:
            _count_str = ""

        label = ch["name"]
        if not ch.get("visible", True):
            label = "[H] " + label

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideoPlaylists.png"})
        li.setInfo("video", {"title": ch["name"]})

        ctx = [
            (self._s(32383),
             "RunPlugin({})".format(self._url(action="channel_info",
                                              channel_id=ch["id"]))),
            (self._s(32204),
             "RunPlugin({})".format(self._url(action="play_channel",
                                              channel_id=ch["id"]))),
            (self._s(32205),
             "RunPlugin({})".format(self._url(action="edit_channel",
                                              channel_id=ch["id"]))),
            (self._s(32331),
             "RunPlugin({})".format(self._url(action="reset_channel",
                                              channel_id=ch["id"]))),
            (self._s(32206),
             "RunPlugin({})".format(self._url(action="delete_channel",
                                              channel_id=ch["id"]))),
            (self._s(32207),
             "RunPlugin({})".format(self._url(
                 action="toggle_channel_visibility",
                 channel_id=ch["id"]))),
        ]
        if channel_type != "serial":
            ctx.append(
                (self._s(32208),
                 "RunPlugin({})".format(self._url(
                     action="manage_interleave",
                     channel_id=ch["id"]))))
        # View Exclusions — TV, Serial, and Movie channels only
        # (Folder channels have no per-item exclusion concept)
        if channel_type in ("tv", "serial", "movies"):
            ctx.append(
                (self._s(32578),
                 "RunPlugin({})".format(self._url(
                     action="view_exclusions",
                     channel_id=ch["id"]))))
        li.addContextMenuItems(ctx, replaceItems=False)

        xbmcplugin.addDirectoryItem(
            self.handle,
            self._url(action="open_channel", channel_id=ch["id"]),
            li, isFolder=True)

    # -- Channel Info ----------------------------------------------------------

    def channel_info(self, params):
        """Show a dialog with full channel configuration and status."""
        channel_id = params["channel_id"]
        ch         = self.manager.get_channel(channel_id)
        if not ch:
            return

        import json as _json, xbmcvfs as _vfs

        channel_type = ch.get("channel_type", "tv")
        randomize    = ch.get("randomize",    False)
        recycle      = ch.get("recycle",      True)
        shows        = ch.get("shows",        [])
        movies       = ch.get("movies",       [])
        lines        = []

        if channel_type == "movies":
            filters          = ch.get("filters", [])
            excluded_movies  = ch.get("excluded_movies", [])
            rotation         = self._s(32224) if randomize else self._s(32384)
            recycle_str      = self._s(32228) if recycle   else self._s(32385)
            lines.append(self._s(32388))
            lines.append(self._s(32391).format(rotation))
            lines.append(self._s(32392).format(recycle_str))
            if filters:
                lines.append(self._s(32393))
            lines.append(self._s(32394).format(len(movies)))
            if excluded_movies:
                _excl_n = len(excluded_movies)
                lines.append(self._s(32588).format(_excl_n)
                             if _excl_n != 1
                             else self._s(32589).format(_excl_n))
        elif channel_type == "serial":
            recycle_str = self._s(32386) if recycle else self._s(32387)
            lines.append(self._s(32389))
            lines.append(self._s(32392).format(recycle_str))
            lines.append("")
            if shows:
                lines.append(self._s(32395).format(len(shows)))
                for i, show in enumerate(shows):
                    lines.append("  {}. {}".format(
                        i + 1, show.get("title", "")))
        elif channel_type == "folder":
            rotation    = self._s(32224) if randomize else self._s(32384)
            recycle_str = self._s(32228) if recycle   else self._s(32385)
            lines.append(self._s(32513))
            lines.append(self._s(32514).format(
                ch.get("folder_path", "").replace("%20", " ")))
            lines.append(self._s(32391).format(rotation))
            lines.append(self._s(32392).format(recycle_str))
        else:
            # TV channel
            rotation    = self._s(32224) if randomize else self._s(32223)
            recycle_str = self._s(32228) if recycle   else self._s(32385)
            lines.append(self._s(32390))
            lines.append(self._s(32391).format(rotation))
            lines.append(self._s(32392).format(recycle_str))
            lines.append("")
            if shows:
                lines.append(self._s(32396).format(len(shows)))
                for show in shows:
                    _title = show.get("title", "")
                    _eps   = show.get("episodes_per_slot", 1)
                    _rand  = show.get("randomize", False)
                    _excl  = show.get("excluded_episodes", [])
                    _notes = []
                    if _eps > 1:
                        _notes.append("{} eps/slot".format(_eps))
                    if _rand:
                        _notes.append(self._s(32224).lower())
                    if _notes:
                        lines.append("  {} [{}]".format(
                            _title, ", ".join(_notes)))
                    else:
                        lines.append("  {}".format(_title))
                    if _excl:
                        _n = len(_excl)
                        lines.append(self._s(32586).format(_n)
                                     if _n != 1
                                     else self._s(32587).format(_n))

        lines.append("")
        try:
            _q_path = self.manager._queue_file_path(channel_id)
            if _vfs.exists(_q_path):
                with _vfs.File(_q_path, "r") as _qf:
                    _q = _json.loads(_qf.read())
                lines.append(self._s(32397).format(len(_q)))
            else:
                lines.append(self._s(32398))
        except Exception:
            lines.append(self._s(32399))

        il_cfg = ch.get("interleave")
        if il_cfg:
            from resources.lib.channels.interleave import get_sources
            il_sources = get_sources(ch)
            for src in il_sources:
                foreign = self.manager.get_channel(src["channel_id"])
                if foreign:
                    freq    = src["frequency"]
                    jitter  = src["jitter"]
                    count   = src["count_per"]
                    silent  = src["silent"]
                    jit_str = " +/-{}".format(jitter) if jitter else ""
                    sil_str = " [silent]" if silent else ""
                    lines.append(self._s(32400).format(
                        foreign["name"],
                        freq, jit_str,
                        ", {} per slot".format(count) if count > 1 else "") + sil_str)
                else:
                    lines.append(self._s(32401))

        # Carousel status — TV and Movie channels only
        if ch.get("carousel_enabled", False):
            lines.append("")
            _interval  = int(ch.get("carousel_interval",  60))
            _pop_count = int(ch.get("carousel_pop_count", 1))
            lines.append(self._s(32581).format(_interval, _pop_count)
                         if _pop_count == 1
                         else self._s(32582).format(_interval, _pop_count))
            try:
                import time as _time
                from resources.lib.carousel import _STATE_KEY as _CAR_KEY
                _state_all  = self.manager._load_json(
                    self.manager._state_path, {})
                _car_state  = _state_all.get(_CAR_KEY.format(channel_id), {})
                _last_pop   = _car_state.get("last_pop_time")
                if _last_pop is None:
                    lines.append(self._s(32585))
                else:
                    _elapsed_s  = _time.time() - _last_pop
                    _remaining  = (_interval * 60) - _elapsed_s
                    if _remaining <= 0:
                        lines.append(self._s(32584))
                    else:
                        lines.append(self._s(32583).format(
                            int(_remaining // 60) + 1))
            except Exception:
                lines.append(self._s(32585))

        xbmcgui.Dialog().textviewer(
            self._s(32402).format(ch["name"]),
            "\n".join(lines))

    # -- View Exclusions -------------------------------------------------------

    def view_exclusions(self, params):
        """
        Show a scrollable textviewer listing all excluded episodes (TV/Serial)
        and excluded movies (Movie channel) for the channel.
        """
        channel_id = params["channel_id"]
        ch         = self.manager.get_channel(channel_id)
        if not ch:
            return

        channel_type    = ch.get("channel_type", "tv")
        shows           = ch.get("shows",          [])
        movies          = ch.get("movies",          [])
        excluded_movies = ch.get("excluded_movies", [])
        lines           = []

        # TV and Serial: per-show episode exclusions
        if channel_type in ("tv", "serial"):
            for show in shows:
                excl_ids = show.get("excluded_episodes", [])
                if not excl_ids:
                    continue
                lines.append(show.get("title", ""))
                # Resolve IDs to S##E## - Title strings via library.
                # get_filtered_episodes returns the pool BEFORE exclusions
                # are applied, so excluded IDs will be present in it.
                try:
                    all_eps  = self.manager.get_filtered_episodes(show)
                    id_map   = {e["episodeid"]: e for e in all_eps}
                    excl_set = set(excl_ids)
                    for ep in all_eps:
                        if ep["episodeid"] not in excl_set:
                            continue
                        lines.append("  S{:02d}E{:02d} - {}".format(
                            ep.get("season",  0),
                            ep.get("episode", 0),
                            ep.get("title",   "")))
                except Exception:
                    # Library unavailable — fall back to ID list
                    for eid in excl_ids:
                        lines.append("  episodeid: {}".format(eid))
                lines.append("")

        # Movie channel: excluded movies
        if channel_type == "movies" and excluded_movies:
            lines.append(self._s(32590))
            excl_set  = set(excluded_movies)
            movie_map = {m["movieid"]: m.get("title", str(m["movieid"]))
                         for m in movies}
            for mid in excluded_movies:
                lines.append("  {}".format(
                    movie_map.get(mid, "movieid: {}".format(mid))))
            lines.append("")

        if not lines:
            lines.append(self._s(32580))

        xbmcgui.Dialog().textviewer(
            self._s(32579).format(ch["name"]),
            "\n".join(lines))

    # -- Open channel ----------------------------------------------------------

    def open_channel(self, params):
        channel_id   = params["channel_id"]
        channel      = self.manager.get_channel(channel_id)
        if not channel:
            return

        channel_type = channel.get("channel_type", "tv")
        xbmcplugin.setPluginCategory(self.handle, channel["name"])
        xbmcplugin.setContent(
            self.handle,
            "movies" if channel_type == "movies" else "episodes")

        play_url = self._url(action="play_channel", channel_id=channel_id)

        li = xbmcgui.ListItem(label=self._s(32403))
        li.setArt({"icon": "DefaultVideoPlaylists.png"})
        xbmcplugin.addDirectoryItem(self.handle, play_url, li, isFolder=False)

        if channel_type == "movies":
            self._open_movie_channel(channel_id, channel, play_url)
        elif channel_type == "folder":
            self._open_folder_channel(channel_id, channel, play_url)
        else:
            self._open_tv_channel(channel_id, channel, play_url)

    def _open_movie_channel(self, channel_id, channel, play_url):
        """Show upcoming movies from the queue file."""
        import json
        import xbmcvfs
        queue_path = self.manager._queue_file_path(channel_id)

        upcoming = []
        if xbmcvfs.exists(queue_path):
            try:
                with xbmcvfs.File(queue_path, "r") as f:
                    try:
                        _nu = max(1, int(
                            self.addon.getSetting(
                                "num_upcoming_programs") or "5"))
                    except Exception:
                        _nu = 5
                    upcoming = json.loads(f.read())[:_nu]
            except Exception:
                pass

        if upcoming:
            for item in upcoming:
                _is_movie = (not item.get("tvshowtitle") and
                             (item.get("is_movie") or
                              item.get("movieid", -1) > 0 or
                              not item.get("episodeid")))
                if _is_movie:
                    _title = item.get("title", "")
                    _year  = item.get("year", "")
                    label  = "[Movie] {}{}".format(
                        _title, " ({})".format(_year) if _year else "")
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo("video", {
                        "title": _title, "year": _year,
                        "plot":  item.get("plot", ""),
                        "mediatype": "movie",
                    })
                else:
                    _show     = item.get("tvshowtitle", "")
                    _ep_title = item.get("title", "")
                    _s        = item.get("season", 0)
                    _e        = item.get("episode", 0)
                    if _show:
                        label = "{} - S{:02d}E{:02d} - {}".format(
                            _show, _s, _e, _ep_title)
                    else:
                        label = "S{:02d}E{:02d} - {}".format(_s, _e, _ep_title)
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo("video", {
                        "tvshowtitle": _show,
                        "title":       _ep_title,
                        "season":      _s,
                        "episode":     _e,
                        "mediatype":   "episode",
                    })
                xbmcplugin.addDirectoryItem(
                    self.handle, play_url, li, isFolder=False)
        else:
            for m in channel.get("movies", [])[:20]:
                li = xbmcgui.ListItem(label=m.get("title", ""))
                xbmcplugin.addDirectoryItem(
                    self.handle, play_url, li, isFolder=False)

        log("[ChannelUI] Movie channel: {} upcoming".format(len(upcoming)))

    def _open_folder_channel(self, channel_id, channel, play_url):
        """Show upcoming items from the folder channel queue file."""
        import json
        import xbmcvfs

        _num_up   = max(1, int(
            self.addon.getSetting("num_upcoming_programs") or "5"))
        read_path = self.manager._queue_file_path(channel_id)

        upcoming = []
        if xbmcvfs.exists(read_path):
            try:
                with xbmcvfs.File(read_path, "r") as _qf:
                    _raw = _qf.read()
                if _raw:
                    upcoming = json.loads(_raw)[:_num_up]
            except Exception:
                pass

        log("[ChannelUI] Folder channel: {} upcoming items from {}".format(
            len(upcoming), read_path))

        if upcoming:
            for item in upcoming:
                title = item.get("title", "")
                li    = xbmcgui.ListItem(label=title)
                li.setInfo("video", {"title": title, "mediatype": "video"})
                xbmcplugin.addDirectoryItem(
                    self.handle, play_url, li, isFolder=False)
        else:
            # No queue yet — show folder path as info
            folder_path = channel.get("folder_path", "")
            li = xbmcgui.ListItem(
                label=self._s(32514).format(folder_path[-50:]))
            xbmcplugin.addDirectoryItem(
                self.handle, play_url, li, isFolder=False)

    def _open_tv_channel(self, channel_id, channel, play_url):
        """Show next episode per show, plus any interleaved items
        that are up next in the queue."""
        import json
        import xbmcvfs

        shows = list(channel.get("shows", []))
        if shows:
            state_path = self.manager._resolve_path("state.json")
            try:
                with xbmcvfs.File(state_path, "r") as f:
                    state_all = json.loads(f.read())
                key       = "{}:__show_index__".format(channel_id)
                start_idx = int(state_all.get(key, 0))
                if start_idx > 0:
                    shows = shows[start_idx:] + shows[:start_idx]
            except Exception:
                pass

        interleaved_pending = []
        try:
            q_path = self.manager._queue_file_path(channel_id)
            if xbmcvfs.exists(q_path):
                with xbmcvfs.File(q_path, "r") as _f:
                    _q = json.loads(_f.read())
                for _item in _q:
                    if _item.get("_interleaved") and not _item.get("_silent"):
                        interleaved_pending.append(_item)
                    elif not _item.get("_interleaved"):
                        break
        except Exception:
            pass

        try:
            _num_up = max(1, int(
                self.addon.getSetting("num_upcoming_programs") or "5"))
        except Exception:
            _num_up = 5

        upcoming_items = []
        try:
            read_path = self.manager._queue_file_path(channel_id)
            if xbmcvfs.exists(read_path):
                with xbmcvfs.File(read_path, "r") as _qf:
                    _raw = _qf.read()
                if _raw:
                    # Filter silent items BEFORE applying the count limit so
                    # they don't consume slots from the visible upcoming count.
                    _all = json.loads(_raw)
                    upcoming_items = [i for i in _all
                                      if not i.get("_silent")][:_num_up]
            log("[ChannelUI] read {} upcoming from {}".format(
                len(upcoming_items), read_path))
        except Exception as _e:
            log("[ChannelUI] upcoming read error: {}".format(_e))

        if upcoming_items:
            for _item in upcoming_items:
                # Silent interleave items are intentionally invisible in the
                # addon's own playlist view. They appear in Kodi's internal
                # video playlist only.
                if _item.get("_silent"):
                    continue
                _is_movie = (_item.get("is_movie") or
                             _item.get("movieid", -1) > 0 or
                             (not _item.get("tvshowtitle") and
                              not _item.get("is_folder_item") and
                              _item.get("episodeid", -1) < 0))
                if _is_movie:
                    _title = _item.get("title", "")
                    _year  = _item.get("year", "")
                    _label = "[Movie] {}{}".format(
                        _title,
                        " ({})".format(_year) if _year else "")
                    _li = xbmcgui.ListItem(label=_label)
                    _li.setInfo("video", {
                        "title": _title, "year": _year,
                        "plot":  _item.get("plot", ""),
                        "mediatype": "movie",
                    })
                    _thumb = (_item.get("thumbnail", "")
                              or _item.get("thumb", ""))
                    if _thumb:
                        _li.setArt({"thumb": _thumb, "icon": _thumb})
                else:
                    _show     = _item.get("tvshowtitle", "")
                    _ep_title = _item.get("title", "")
                    _s        = _item.get("season", 0)
                    _e        = _item.get("episode", 0)
                    if _show:
                        _label = "{} - S{:02d}E{:02d} - {}".format(
                            _show, _s, _e, _ep_title)
                    else:
                        _label = "S{:02d}E{:02d} - {}".format(
                            _s, _e, _ep_title)
                    _li = xbmcgui.ListItem(label=_label)
                    _li.setInfo("video", {
                        "tvshowtitle": _show,
                        "title":       _ep_title,
                        "season":      _s,
                        "episode":     _e,
                        "mediatype":   "episode",
                    })
                    _show_id_ctx = _item.get("_show_id", 0)
                    if _show_id_ctx:
                        _reset_url = self._url(
                            action="reset_next_episode",
                            channel_id=channel_id,
                            show_id=_show_id_ctx,
                            show_title=_show)
                        _li.addContextMenuItems([
                            (self._s(32334),
                             "RunPlugin({})".format(_reset_url)),
                        ], replaceItems=False)
                xbmcplugin.addDirectoryItem(self.handle, play_url,
                                            _li, isFolder=False)
            log("[ChannelUI] TV channel: {} upcoming items".format(
                len(upcoming_items)))
            return

        # Fallback: no queue file — show one entry per show
        for _item in interleaved_pending:
            _title  = _item.get("title", "")
            _year   = _item.get("year", "")
            _label  = "[Movie] {}{}".format(
                _title, " ({})".format(_year) if _year else "")
            _li = xbmcgui.ListItem(label=_label)
            _li.setInfo("video", {"title": _title, "year": _year})
            xbmcplugin.addDirectoryItem(self.handle, play_url,
                                        _li, isFolder=False)

        for show in shows:
            show_id    = show["tvshowid"]
            show_title = show.get("title", "")
            next_ep    = self.manager.get_next_episode_for_show(
                channel_id, show)

            log("[ChannelUI] show={} next_ep={}".format(show_title, next_ep))

            if next_ep:
                s          = next_ep.get("season",  0)
                e          = next_ep.get("episode", 0)
                ep_title   = next_ep.get("title", "")
                try:
                    _show_next = self.addon.getSetting(
                        "show_next_episode") != "false"
                except Exception:
                    _show_next = True
                if _show_next:
                    full_label = "{} - Next: S{:02d}E{:02d} - {}".format(
                        show_title, s, e, ep_title)
                else:
                    full_label = show_title
                li = xbmcgui.ListItem(label=full_label)
                li.setInfo("video", {
                    "tvshowtitle": show_title,
                    "season":      s,
                    "episode":     e,
                    "title":       ep_title,
                    "plot":        next_ep.get("plot", ""),
                })
                thumb = (next_ep.get("art", {}).get("thumb")
                         or next_ep.get("thumbnail", ""))
                if thumb:
                    li.setArt({"thumb": thumb, "icon": thumb})
            else:
                log("[ChannelUI] No next_ep for {}".format(show_title))
                full_label = "{} - ({})".format(show_title, self._s(32239))
                li         = xbmcgui.ListItem(label=full_label)

            reset_url = self._url(
                action="reset_next_episode",
                channel_id=channel_id,
                show_id=show_id,
                show_title=show_title)
            li.addContextMenuItems([
                (self._s(32334),
                 "RunPlugin({})".format(reset_url)),
            ], replaceItems=False)

            xbmcplugin.addDirectoryItem(self.handle, play_url,
                                        li, isFolder=False)

        log("[ChannelUI] TV channel: {} shows".format(len(shows)))

    def create_channel_wizard(self, params):
        result = self._run_wizard(existing=None)
        if result:
            xbmcgui.Dialog().notification(
                self._s(32289),
                self._s(32404).format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 5000)
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            try:
                self.manager.create_channel(result)
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            xbmcgui.Dialog().notification(
                self._s(32289),
                self._s(32406).format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh")

    def edit_channel_wizard(self, params):
        channel_id = params.get("channel_id")
        existing   = self.manager.get_channel(channel_id)
        if not existing:
            return
        old_randomize = existing.get("randomize",    False)
        old_recycle   = existing.get("recycle",      True)
        old_type      = existing.get("channel_type", "tv")

        result = self._run_wizard(existing=existing)
        if result:
            new_randomize = result.get("randomize",    False)
            new_recycle   = result.get("recycle",      True)
            new_type      = result.get("channel_type", "tv")

            resume_invalidated = (
                old_randomize != new_randomize or
                old_recycle   != new_recycle   or
                old_type      != new_type
            )

            if resume_invalidated:
                xbmcgui.Dialog().ok(
                    self._s(32289),
                    self._s(32405).format(existing.get("name", "")))
                self.manager.clear_channel_resume_points(channel_id)

            xbmcgui.Dialog().notification(
                self._s(32289),
                self._s(32407).format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 5000)
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            try:
                self.manager.update_channel(channel_id, result)
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            xbmcgui.Dialog().notification(
                self._s(32289),
                self._s(32408).format(result.get("name", "")),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")

    def _run_wizard(self, existing):
        """
        Multi-step channel creation/edit wizard.
        """
        import random as _random

        d = xbmcgui.Dialog()

        # ---- Step 1: Name ---------------------------------------------------
        name = d.input(
            self._s(32219),
            existing["name"] if existing else "",
            type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            d.ok(self._s(32289), self._s(32214))
            return None

        # ---- Step 2: Channel type -------------------------------------------
        default_type  = existing.get("channel_type", "tv") if existing else "tv"
        _type_display = {
            "tv":     self._s(32409),
            "movies": self._s(32410),
            "serial": self._s(32411),
            "folder": self._s(32506),
        }
        type_label  = self._s(32495).format(
            _type_display.get(default_type, default_type)) if existing else ""
        type_choice = d.select(
            self._s(32268).format(type_label),
            [
                self._s(32269),
                self._s(32270),
                self._s(32271),
                self._s(32505),
            ])
        if type_choice < 0:
            return None
        if type_choice == 0:
            channel_type = "tv"
        elif type_choice == 1:
            channel_type = "movies"
        elif type_choice == 2:
            channel_type = "serial"
        else:
            channel_type = "folder"

        if channel_type == "serial":
            return self._run_serial_wizard(d, existing, name)

        if channel_type == "folder":
            return self._run_folder_wizard(d, existing, name)

        # ---- Step 3: Content selection --------------------------------------
        selected_shows  = []
        selected_movies = []
        starting_points = {}
        filters         = []

        if channel_type == "tv":
            existing_filters = existing.get("filters", []) if existing else []
            existing_shows   = existing.get("shows", []) if existing else []

            show_pool = self.manager.library.get_all_tvshows()
            if not show_pool:
                d.ok(self._s(32289), self._s(32217))
                return None

            if len(show_pool) > 20:
                use_filter = d.yesno(
                    self._s(32412),
                    self._s(32413).format(len(show_pool)),
                    nolabel=self._s(32414),
                    yeslabel=self._s(32415))
                if use_filter:
                    filters = self._build_filters(existing_filters, "tv")
                    if filters:
                        filtered = self.manager.library \
                            .get_tvshows_with_filters(filters)
                        if filtered:
                            show_pool = filtered
                            d.ok(self._s(32416),
                                 self._s(32417).format(len(show_pool)))
                        else:
                            d.ok(self._s(32289), self._s(32418))

            show_labels = [s["title"] for s in show_pool]
            preselected = []
            if existing:
                ex_ids      = {s["tvshowid"] for s in existing_shows}
                preselected = [i for i, s in enumerate(show_pool)
                               if s["tvshowid"] in ex_ids]

            chosen = d.multiselect(
                self._s(32419).format(len(show_pool)),
                show_labels,
                preselect=preselected)
            if chosen is None:
                return None
            if not chosen:
                d.ok(self._s(32289), self._s(32215))
                return None

            selected_shows = [
                {"tvshowid": show_pool[i]["tvshowid"],
                 "title":    show_pool[i]["title"]}
                for i in chosen
            ]

            if existing and existing_shows:
                _existing_map   = {s["tvshowid"]: s
                                   for s in existing_shows}
                _existing_order = {s["tvshowid"]: idx
                                   for idx, s in enumerate(existing_shows)}
                _max_idx        = len(existing_shows)
                selected_shows.sort(
                    key=lambda s: _existing_order.get(
                        s["tvshowid"], _max_idx))
                for _s in selected_shows:
                    _prev = _existing_map.get(_s["tvshowid"])
                    if _prev:
                        if "episodes_per_slot" in _prev:
                            _s["episodes_per_slot"] = \
                                _prev["episodes_per_slot"]
                        if "randomize" in _prev:
                            _s["randomize"] = _prev["randomize"]
                        if "episode_filters" in _prev:
                            _s["episode_filters"] = \
                                _prev["episode_filters"]
                        if "excluded_episodes" in _prev:
                            _s["excluded_episodes"] = \
                                _prev["excluded_episodes"]

        else:
            # Movie selection
            all_movies = self.manager.library.get_all_movies()
            if not all_movies:
                d.ok(self._s(32289), self._s(32420))
                return None

            filter_choice = d.select(
                self._s(32421),
                [self._s(32422).format(len(all_movies)),
                 self._s(32423),
                 self._s(32424),
                 self._s(32425)])
            if filter_choice < 0:
                return None

            if filter_choice == 0:
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in all_movies
                ]

            elif filter_choice == 1:
                genres = self.manager.library.get_all_genres("movie")
                if not genres:
                    d.ok(self._s(32289), self._s(32426))
                    return None
                chosen_genre = d.select(self._s(32427), genres)
                if chosen_genre < 0:
                    return None
                filtered = self.manager.library.get_movies_by_genre(
                    genres[chosen_genre])
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in filtered
                ]
                if not selected_movies:
                    d.ok(self._s(32289),
                         self._s(32428).format(genres[chosen_genre]))
                    return None
                d.ok(self._s(32289),
                     self._s(32429).format(
                         len(selected_movies), genres[chosen_genre]))

            elif filter_choice == 2:
                years = sorted(
                    set(m["year"] for m in all_movies if m.get("year")),
                    reverse=True)
                if not years:
                    d.ok(self._s(32289), self._s(32430))
                    return None
                year_labels  = [str(y) for y in years]
                chosen_year  = d.select(self._s(32431), year_labels)
                if chosen_year < 0:
                    return None
                filtered = self.manager.library.get_movies_by_year(
                    years[chosen_year])
                selected_movies = [
                    {"movieid": m["movieid"], "title": m["title"]}
                    for m in filtered
                ]
                if not selected_movies:
                    d.ok(self._s(32289),
                         self._s(32432).format(years[chosen_year]))
                    return None
                d.ok(self._s(32289),
                     self._s(32433).format(
                         len(selected_movies), years[chosen_year]))

            else:
                movie_labels = [m["title"] for m in all_movies]
                preselected  = []
                if existing:
                    existing_ids = {m["movieid"]
                                    for m in existing.get("movies", [])}
                    preselected  = [i for i, m in enumerate(all_movies)
                                    if m["movieid"] in existing_ids]
                chosen = d.multiselect(self._s(32434), movie_labels,
                                       preselect=preselected)
                if chosen is None:
                    return None
                if not chosen:
                    d.ok(self._s(32289), self._s(32435))
                    return None
                selected_movies = [
                    {"movieid": all_movies[i]["movieid"],
                     "title":   all_movies[i]["title"]}
                    for i in chosen
                ]

        # ---- Step 3b: Movie filter rules ------------------------------------
        if channel_type == "movies":
            existing_filters = existing.get("filters", []) if existing else []
            add_filters = d.yesno(
                self._s(32436),
                self._s(32437),
                nolabel=self._s(32438),
                yeslabel=self._s(32439))
            if add_filters:
                filters = self._build_filters(existing_filters, "movies")
            else:
                filters = existing_filters

        # ---- Step 4: Playback order -----------------------------------------
        if existing:
            default_rand = existing.get("randomize", False)
        else:
            try:
                default_rand = self.addon.getSetting(
                    "default_randomize") == "true"
            except Exception:
                default_rand = False
        if channel_type == "movies":
            _rand_choice = d.select(
                self._s(32440),
                [self._s(32442),    # In Order
                 self._s(32224),    # Random
                 self._s(32569)],   # Cancel
                preselect=1 if default_rand else 0)
            if _rand_choice < 0 or _rand_choice == 2:
                return None
            randomize = (_rand_choice == 1)
        else:
            _rand_choice = d.select(
                self._s(32221),
                [self._s(32223),    # Round-Robin
                 self._s(32224),    # Random
                 self._s(32569)],   # Cancel
                preselect=1 if default_rand else 0)
            if _rand_choice < 0 or _rand_choice == 2:
                return None
            randomize = (_rand_choice == 1)

        if randomize and channel_type == "tv":
            for _s in selected_shows:
                _s.pop("randomize", None)

        # ---- Step 4a: Show rotation order (Round Robin TV, 2+ shows) --------
        if channel_type == "tv" and not randomize and len(selected_shows) > 1:

            _shows_changed = False
            _change_notice = ""
            if existing and existing_shows:
                _prev_ids       = [s["tvshowid"] for s in existing_shows]
                _new_ids        = [s["tvshowid"] for s in selected_shows]
                _added_titles   = [s["title"] for s in selected_shows
                                   if s["tvshowid"] not in set(_prev_ids)]
                _removed_titles = [s["title"] for s in existing_shows
                                   if s["tvshowid"] not in set(_new_ids)]
                if _added_titles or _removed_titles:
                    _shows_changed = True
                    _lines = []
                    if _added_titles:
                        _lines.append(self._s(32251).format(
                            ", ".join(_added_titles)))
                    if _removed_titles:
                        _lines.append(self._s(32252).format(
                            ", ".join(_removed_titles)))
                    _current_order = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(selected_shows))
                    _lines.append("")
                    _lines.append(self._s(32253))
                    _lines.append(_current_order)
                    _change_notice = "\n".join(_lines)

            _order_title = self._s(32240)
            if _shows_changed and _change_notice:
                d.ok(_order_title,
                     self._s(32254) + "\n\n" + _change_notice)

            _order_choice = d.select(
                _order_title,
                [
                    self._s(32242),
                    self._s(32243),
                    self._s(32244),
                ])

            if _order_choice == 1:
                while True:
                    _random.shuffle(selected_shows)
                    _new_order = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(selected_shows))
                    # Display the shuffled result before the choice dialog
                    d.ok(self._s(32240), _new_order[:300])
                    _shuf_choice = d.select(
                        self._s(32240),
                        [self._s(32246),    # Accept
                         self._s(32245),    # Shuffle Again
                         self._s(32569)])   # Cancel
                    if _shuf_choice < 0 or _shuf_choice == 2:
                        return None
                    if _shuf_choice == 0:
                        break

            elif _order_choice == 2:
                while True:
                    _remaining   = list(selected_shows)
                    _ordered     = []

                    for _pos in range(len(selected_shows)):
                        _labels = [s["title"] for s in _remaining]
                        _pick   = d.select(
                            self._s(32247).format(_pos + 1),
                            _labels)
                        if _pick < 0:
                            _ordered = list(selected_shows)
                            break
                        _ordered.append(_remaining[_pick])
                        _remaining.pop(_pick)

                    _summary = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(_ordered))
                    # Display the chosen order before the confirm/redo choice
                    d.ok(self._s(32249), _summary)
                    _confirm = d.select(
                        self._s(32249),
                        [
                            self._s(32246),
                            self._s(32250),
                        ])
                    if _confirm == 0:
                        selected_shows = _ordered
                        break
                    elif _confirm == 1:
                        continue
                    else:
                        break

        # ---- Step 4a-ii: Episodes Per Slot -----------------------------------
        if channel_type == "tv" and len(selected_shows) > 1:
            _any_nondefault = any(
                s.get("episodes_per_slot", 1) != 1 for s in selected_shows)
            if _any_nondefault:
                _do_eps = True
            else:
                _eps_entry = d.select(
                    self._s(32255),
                    [self._s(32258),    # Yes, customise
                     self._s(32257),    # No, keep 1 each
                     self._s(32569)])   # Cancel
                if _eps_entry < 0 or _eps_entry == 2:
                    return None
                _do_eps = (_eps_entry == 0)
            if _do_eps:
                for _eps_show in selected_shows:
                    _eps_title = _eps_show.get("title", "")
                    _cur_eps   = int(_eps_show.get("episodes_per_slot", 1))
                    _eps_str   = d.input(
                        self._s(32259).format(_eps_title, _cur_eps),
                        defaultt=str(_cur_eps),
                        type=xbmcgui.INPUT_NUMERIC)
                    try:
                        _new_eps = max(1, int(_eps_str or _cur_eps))
                    except (ValueError, TypeError):
                        _new_eps = _cur_eps
                    _eps_show["episodes_per_slot"] = _new_eps
            else:
                for _eps_show in selected_shows:
                    _eps_show.pop("episodes_per_slot", None)

        # ---- Step 4a-iii: Per-show randomize --------------------------------
        if channel_type == "tv" and not randomize and len(selected_shows) > 1:
            _any_show_rand = any(
                s.get("randomize", False) for s in selected_shows)
            if _any_show_rand:
                _do_psr = True
            else:
                _do_psr = d.yesno(
                    self._s(32260),
                    self._s(32261),
                    nolabel=self._s(32262),
                    yeslabel=self._s(32263))
            if _do_psr:
                for _psr_show in selected_shows:
                    _psr_title  = _psr_show.get("title", "")
                    _cur_rand   = _psr_show.get("randomize", False)
                    _psr_choice = d.yesno(
                        self._s(32264).format(_psr_title),
                        self._s(32265).format(_psr_title),
                        nolabel=self._s(32266),
                        yeslabel=self._s(32267),
                        defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
                        if _cur_rand else xbmcgui.DLG_YESNO_NO_BTN)
                    if _psr_choice:
                        _psr_show["randomize"] = True
                    else:
                        _psr_show.pop("randomize", None)
            else:
                for _psr_show in selected_shows:
                    _psr_show.pop("randomize", None)

        # ---- Step 4a-iv: Per-show episode filters ----------------------------
        # Offer per-show episode filters for any TV channel with at least one
        # show selected. Filters are stored on each show dict as
        # "episode_filters": [...] and applied at queue-build time by
        # channel_manager via library.get_episodes_with_filters().
        # This step is optional — skipping leaves episode_filters unchanged
        # (empty for new shows, preserved for existing shows).
        if channel_type == "tv" and selected_shows:
            _any_existing_ef = any(
                s.get("episode_filters") for s in selected_shows)
            _do_ef = _any_existing_ef or d.yesno(
                self._s(32537),
                self._s(32538),
                nolabel=self._s(32548),   # "No, skip filters"
                yeslabel=self._s(32549))  # "Yes, set filters"
            if _do_ef:
                for _ef_show in selected_shows:
                    _ef_title   = _ef_show.get("title", "")
                    _cur_ef     = list(_ef_show.get("episode_filters", []))
                    _new_ef     = self._build_episode_filters(
                        d, _ef_title, _cur_ef)
                    if _new_ef is not None:
                        if _new_ef:
                            _ef_show["episode_filters"] = _new_ef
                        else:
                            _ef_show.pop("episode_filters", None)
            else:
                # User declined — preserve existing filters, don't clear them
                pass

        # ---- Step 4a-v: Episode exclusions (show-picker flow) ---------------
        # One channel-level Yes/No entry point, then a show-picker loop so
        # the user can work through multiple shows without being asked
        # separately for each one. Shows the current exclusion count per
        # show in the picker label so the user always knows their current
        # state without having to enter each show to check.
        if channel_type == "tv" and selected_shows:
            _do_any_ex = d.yesno(
                self._s(32552),
                self._s(32553),
                nolabel=self._s(32554),
                yeslabel=self._s(32555))
            if _do_any_ex:
                while True:
                    _ex_labels = []
                    for _es in selected_shows:
                        _ec = len(_es.get("excluded_episodes", []))
                        _ex_labels.append("{} — {}".format(
                            _es.get("title", ""),
                            self._s(32558).format(_ec) if _ec
                            else self._s(32559)))
                    _ex_labels.append(self._s(32466))  # Done
                    _ex_pick = d.select(self._s(32564), _ex_labels)
                    if _ex_pick < 0 or _ex_pick == len(selected_shows):
                        break
                    _ex_show  = selected_shows[_ex_pick]
                    _ex_title = _ex_show.get("title", "")
                    _cur_excl = list(_ex_show.get("excluded_episodes", []))
                    _new_excl = self._build_episode_exclusions(
                        d, _ex_show, _ex_title, _cur_excl)
                    if _new_excl:
                        _ex_show["excluded_episodes"] = _new_excl
                    else:
                        _ex_show.pop("excluded_episodes", None)

        # ---- Step 4b: Custom starting point ---------------------------------
        # Only offered for sequential channels (randomize=False at channel
        # level) or round-robin channels where at least one show is sequential.
        # For fully random channels, starting point is meaningless — random
        # picks any episode from the pool regardless of what is set here.
        _any_sequential = any(
            not s.get("randomize", randomize) for s in selected_shows)
        if channel_type == "tv" and selected_shows and _any_sequential:
            import random as _sp_random
            _start_choice = d.select(
                self._s(32445),
                [
                    self._s(32567) if existing else self._s(32446),
                    self._s(32447),
                    self._s(32448),
                ])

            if _start_choice == 2:
                # Only pick starting episodes for sequential shows.
                # A show is sequential if neither the channel nor the show
                # has randomize=True.
                _seq_shows = [s for s in selected_shows
                              if not s.get("randomize", randomize)]
                while True:
                    _surprise_picks = {}
                    for _sp_show in _seq_shows:
                        _sp_sid = _sp_show["tvshowid"]
                        _sp_eps = self.manager.get_available_episodes(_sp_show)
                        if _sp_eps:
                            _sp_ep = _sp_random.choice(_sp_eps)
                            _surprise_picks[_sp_sid] = _sp_ep

                    _summary_lines = []
                    for _sp_show in _seq_shows:
                        _sp_sid = _sp_show["tvshowid"]
                        _sp_ep  = _surprise_picks.get(_sp_sid)
                        if _sp_ep:
                            _summary_lines.append(
                                "{}: S{:02d}E{:02d} - {}".format(
                                    _sp_show["title"],
                                    _sp_ep["season"],
                                    _sp_ep["episode"],
                                    _sp_ep.get("title", "")))
                        else:
                            _summary_lines.append(
                                "{}: {}".format(
                                    _sp_show["title"],
                                    self._s(32458).format("")))

                    _summary = "\n".join(_summary_lines)
                    # Display the selected starting episodes before the choice
                    d.ok(self._s(32449), _summary)
                    _accept_choice = d.select(
                        self._s(32449),
                        [self._s(32246),    # Accept
                         self._s(32450),    # Try Again
                         self._s(32569)])   # Cancel
                    if _accept_choice < 0 or _accept_choice == 2:
                        return None
                    if _accept_choice == 0:
                        for _sp_show in _seq_shows:
                            _sp_sid = _sp_show["tvshowid"]
                            _sp_ep  = _surprise_picks.get(_sp_sid)
                            if _sp_ep:
                                starting_points[_sp_sid] = {
                                    "episodeid": _sp_ep["episodeid"],
                                    "season":    _sp_ep["season"],
                                    "episode":   _sp_ep["episode"],
                                    "title":     _sp_ep.get("title", ""),
                                }
                        break

            elif _start_choice == 1:
                # Only set manual starting points for sequential shows.
                _seq_shows_manual = [s for s in selected_shows
                                     if not s.get("randomize", randomize)]
                for show in _seq_shows_manual:
                    sid        = show["tvshowid"]
                    show_title = show["title"]

                    nolabel = self._s(32451)
                    if existing:
                        cur = self.manager.get_show_state(
                            existing.get("id", ""), sid)
                        if cur.get("next_episode_id"):
                            nolabel = self._s(32452).format(
                                cur.get("season", 1),
                                cur.get("episode", 1))

                    do_set = d.yesno(
                        show_title,
                        self._s(32454).format(show_title),
                        nolabel=nolabel,
                        yeslabel=self._s(32453))
                    if not do_set:
                        continue

                    episodes = self.manager.get_available_episodes(show)
                    if not episodes:
                        d.ok(self._s(32289),
                             self._s(32458).format(show_title))
                        continue

                    seasons       = sorted(set(e["season"] for e in episodes))
                    season_labels = [self._s(32455).format(s) for s in seasons]

                    default_s = 0
                    if existing:
                        cur = self.manager.get_show_state(
                            existing.get("id", ""), sid)
                        cs  = cur.get("season", 1)
                        if cs in seasons:
                            default_s = seasons.index(cs)

                    cur_s_label = ""
                    if existing and default_s > 0:
                        cur_s_label = self._s(32459).format(
                            seasons[default_s])
                    season_choice = d.select(
                        self._s(32456).format(show_title, cur_s_label),
                        season_labels)
                    if season_choice < 0:
                        continue

                    chosen_season = seasons[season_choice]
                    season_eps    = sorted(
                        [e for e in episodes
                         if e["season"] == chosen_season],
                        key=lambda e: e["episode"])
                    ep_labels = [
                        "S{:02d}E{:02d} - {}".format(
                            e["season"], e["episode"], e["title"])
                        for e in season_eps
                    ]

                    default_e = 0
                    if existing:
                        cur     = self.manager.get_show_state(
                            existing.get("id", ""), sid)
                        cur_nid = cur.get("next_episode_id")
                        for i, ep in enumerate(season_eps):
                            if ep["episodeid"] == cur_nid:
                                default_e = i
                                break

                    cur_e_label = ""
                    if existing and default_e > 0 and default_e < len(ep_labels):
                        cur_e_label = self._s(32495).format(
                            ep_labels[default_e])
                    ep_choice = d.select(
                        self._s(32457).format(
                            show_title, cur_e_label[:40]),
                        ep_labels)
                    if ep_choice < 0:
                        continue

                    chosen_ep = season_eps[ep_choice]
                    starting_points[sid] = {
                        "episodeid": chosen_ep["episodeid"],
                        "season":    chosen_ep["season"],
                        "episode":   chosen_ep["episode"],
                        "title":     chosen_ep["title"],
                    }
                    log("[ChannelUI] Starting point {}: S{}E{}".format(
                        show_title,
                        chosen_ep["season"],
                        chosen_ep["episode"]))

        # ---- Step 5: Recycle ------------------------------------------------
        if existing:
            default_rec = existing.get("recycle", True)
        else:
            try:
                default_rec = self.addon.getSetting(
                    "default_recycle") != "false"
            except Exception:
                default_rec = True
        if channel_type == "movies":
            _rec_choice = d.select(
                self._s(32225),
                [self._s(32228),    # Recycle
                 self._s(32227),    # Stop
                 self._s(32569)],   # Cancel
                preselect=0 if default_rec else 1)
            if _rec_choice < 0 or _rec_choice == 2:
                return None
            recycle = (_rec_choice == 0)
        else:
            _rec_choice = d.select(
                self._s(32225),
                [self._s(32228),    # Recycle
                 self._s(32227),    # Stop
                 self._s(32569)],   # Cancel
                preselect=0 if default_rec else 1)
            if _rec_choice < 0 or _rec_choice == 2:
                return None
            recycle = (_rec_choice == 0)

        # ---- Step 5b: Movie exclusions ---------------------------------------
        # Always asks "Manage Exclusions? Yes/No" — never auto-enters, same
        # convention as the TV per-show exclusions step above.
        excluded_movies = existing.get("excluded_movies", []) if existing \
            else []
        if channel_type == "movies" and selected_movies:
            _do_ex_m = d.yesno(
                self._s(32561),
                self._s(32562),
                nolabel=self._s(32554),
                yeslabel=self._s(32555))
            if _do_ex_m:
                excluded_movies = self._build_movie_exclusions(
                    d, selected_movies, excluded_movies)

        # ---- Step 6: Queue size ---------------------------------------------
        try:
            _default_qs = max(10, int(
                self.addon.getSetting("default_queue_size") or "30"))
        except Exception:
            _default_qs = 30
        qs_str = d.input(
            self._s(32229),
            str(existing.get("queue_size", _default_qs)) if existing
            else str(_default_qs),
            type=xbmcgui.INPUT_NUMERIC)
        if not qs_str:
            return None
        try:
            queue_size = max(10, min(200, int(qs_str)))
        except ValueError:
            queue_size = _default_qs

        # ---- Step 7: Visibility ---------------------------------------------
        default_vis = existing.get("visible", True) if existing else True
        _vis_choice = d.select(
            self._s(32230),
            [self._s(32233),    # Show
             self._s(32232),    # Hide
             self._s(32569)],   # Cancel
            preselect=0 if default_vis else 1)
        if _vis_choice < 0 or _vis_choice == 2:
            return None
        visible = (_vis_choice == 0)

        # ---- Step 8: Carousel (TV and Movie channels only) ------------------
        carousel_enabled   = existing.get("carousel_enabled",   False) \
                             if existing else False
        carousel_interval  = existing.get("carousel_interval",  60) \
                             if existing else 60
        carousel_pop_count = existing.get("carousel_pop_count", 1) \
                             if existing else 1

        if channel_type in ("tv", "movies"):
            _car_choice = d.yesno(
                self._s(32575),         # "Carousel"
                self._s(32570),         # "Enable Carousel for this channel?"
                nolabel=self._s(32577), # "No"
                yeslabel=self._s(32576) # "Yes"
            )
            if _car_choice:
                carousel_enabled = True
                # Interval
                _interval_str = d.input(
                    self._s(32572),     # "Pop interval (minutes, minimum 30)"
                    str(carousel_interval),
                    type=xbmcgui.INPUT_NUMERIC)
                if not _interval_str:
                    return None
                try:
                    from resources.lib.carousel import CAROUSEL_MIN_INTERVAL
                    carousel_interval = max(CAROUSEL_MIN_INTERVAL,
                                           int(_interval_str))
                except ValueError:
                    carousel_interval = 60
                # Pop count
                _pop_str = d.input(
                    self._s(32573),     # "Items to remove per interval"
                    str(carousel_pop_count),
                    type=xbmcgui.INPUT_NUMERIC)
                if not _pop_str:
                    return None
                try:
                    carousel_pop_count = max(1, int(_pop_str))
                except ValueError:
                    carousel_pop_count = 1
                d.ok(self._s(32575),
                     self._s(32571) + "\n" +
                     self._s(32574))    # description + resume-disabled notice
            else:
                carousel_enabled = False

        return {
            "name":               name,
            "channel_type":       channel_type,
            "shows":              selected_shows,
            "movies":             selected_movies,
            "randomize":          randomize,
            "recycle":            recycle,
            "queue_size":         queue_size,
            "visible":            visible,
            "filters":            filters,
            "excluded_movies":    excluded_movies,
            "interleave":         existing.get("interleave") if existing else None,
            "starting_points":    starting_points,
            "carousel_enabled":   carousel_enabled,
            "carousel_interval":  carousel_interval,
            "carousel_pop_count": carousel_pop_count,
        }

    # -- Serial wizard ---------------------------------------------------------

    def _run_serial_wizard(self, d, existing, name):
        """Self-contained wizard for serial channels."""
        import random as _random

        existing_shows = existing.get("shows", []) if existing else []

        show_pool = self.manager.library.get_all_tvshows()
        if not show_pool:
            d.ok(self._s(32289), self._s(32217))
            return None

        show_labels = [s["title"] for s in show_pool]
        preselected = []
        if existing and existing_shows:
            ex_ids      = {s["tvshowid"] for s in existing_shows}
            preselected = [i for i, s in enumerate(show_pool)
                           if s["tvshowid"] in ex_ids]

        chosen = d.multiselect(
            self._s(32274),
            show_labels,
            preselect=preselected)
        if chosen is None:
            return None
        if not chosen:
            d.ok(self._s(32289), self._s(32215))
            return None

        selected_shows = [
            {"tvshowid": show_pool[i]["tvshowid"],
             "title":    show_pool[i]["title"]}
            for i in chosen
        ]

        if existing and existing_shows:
            _existing_order = {s["tvshowid"]: idx
                               for idx, s in enumerate(existing_shows)}
            _max_idx        = len(existing_shows)
            selected_shows.sort(
                key=lambda s: _existing_order.get(s["tvshowid"], _max_idx))

        if len(selected_shows) > 1:
            _order_choice = d.select(
                self._s(32276),
                [
                    self._s(32277),
                    self._s(32278),
                    self._s(32279),
                ])

            if _order_choice == 0 or _order_choice < 0:
                while True:
                    _remaining = list(selected_shows)
                    _ordered   = []
                    for _pos in range(len(selected_shows)):
                        _labels = [s["title"] for s in _remaining]
                        _pick   = d.select(
                            self._s(32247).format(_pos + 1),
                            _labels)
                        if _pick < 0:
                            _ordered = list(selected_shows)
                            break
                        _ordered.append(_remaining[_pick])
                        _remaining.pop(_pick)

                    _summary = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(_ordered))
                    # Display the chosen order before confirm/redo choice
                    d.ok(self._s(32249), _summary)
                    _confirm = d.select(
                        self._s(32249),
                        [
                            self._s(32246),
                            self._s(32250),
                        ])
                    if _confirm == 0:
                        selected_shows = _ordered
                        break
                    elif _confirm == 1:
                        continue
                    else:
                        break

            elif _order_choice == 2:
                while True:
                    _random.shuffle(selected_shows)
                    _new_order = "\n".join(
                        "{}. {}".format(i + 1, s["title"])
                        for i, s in enumerate(selected_shows))
                    # Display the shuffled result before the choice dialog
                    d.ok(self._s(32276), _new_order[:300])
                    _shuf_choice = d.select(
                        self._s(32276),
                        [self._s(32246),    # Accept
                         self._s(32245),    # Shuffle Again
                         self._s(32569)])   # Cancel
                    if _shuf_choice < 0 or _shuf_choice == 2:
                        return None
                    if _shuf_choice == 0:
                        break

        # ---- Episode exclusions (show-picker flow) ---------------------------
        # Same show-picker pattern as the TV wizard — one entry-point
        # Yes/No, then pick which show(s) to manage. Serial has no
        # episode_filters so get_filtered_episodes() is a straight
        # pass-through; exclusions are the only per-show pool restriction.
        _do_any_ser_ex = d.yesno(
            self._s(32552),
            self._s(32553),
            nolabel=self._s(32554),
            yeslabel=self._s(32555))
        if _do_any_ser_ex:
            while True:
                _ser_ex_labels = []
                for _ses in selected_shows:
                    _sec = len(_ses.get("excluded_episodes", []))
                    _ser_ex_labels.append("{} — {}".format(
                        _ses.get("title", ""),
                        self._s(32558).format(_sec) if _sec
                        else self._s(32559)))
                _ser_ex_labels.append(self._s(32466))  # Done
                _ser_pick = d.select(self._s(32564), _ser_ex_labels)
                if _ser_pick < 0 or _ser_pick == len(selected_shows):
                    break
                _ser_show  = selected_shows[_ser_pick]
                _ser_title = _ser_show.get("title", "")
                _ser_excl  = list(_ser_show.get("excluded_episodes", []))
                _new_ser_excl = self._build_episode_exclusions(
                    d, _ser_show, _ser_title, _ser_excl)
                if _new_ser_excl:
                    _ser_show["excluded_episodes"] = _new_ser_excl
                else:
                    _ser_show.pop("excluded_episodes", None)

        # ---- Recycle --------------------------------------------------------
        if existing:
            default_rec = existing.get("recycle", True)
        else:
            try:
                default_rec = self.addon.getSetting(
                    "default_recycle") != "false"
            except Exception:
                default_rec = True
        _rec_choice_s = d.select(
            self._s(32280),
            [self._s(32283),    # Repeat
             self._s(32282),    # Stop
             self._s(32569)],   # Cancel
            preselect=0 if default_rec else 1)
        if _rec_choice_s < 0 or _rec_choice_s == 2:
            return None
        recycle = (_rec_choice_s == 0)

        # ---- Queue size -----------------------------------------------------
        try:
            _default_qs = max(10, int(
                self.addon.getSetting("default_queue_size") or "30"))
        except Exception:
            _default_qs = 30
        qs_str = d.input(
            self._s(32284),
            str(existing.get("queue_size", _default_qs)) if existing
            else str(_default_qs),
            type=xbmcgui.INPUT_NUMERIC)
        if not qs_str:
            return None
        try:
            queue_size = max(10, min(200, int(qs_str)))
        except ValueError:
            queue_size = _default_qs

        # ---- Visibility -----------------------------------------------------
        default_vis = existing.get("visible", True) if existing else True
        _vis_choice_s = d.select(
            self._s(32285),
            [self._s(32288),    # Show
             self._s(32287),    # Hide
             self._s(32569)],   # Cancel
            preselect=0 if default_vis else 1)
        if _vis_choice_s < 0 or _vis_choice_s == 2:
            return None
        visible = (_vis_choice_s == 0)

        return {
            "name":            name,
            "channel_type":    "serial",
            "shows":           selected_shows,
            "movies":          [],
            "randomize":       False,
            "recycle":         recycle,
            "queue_size":      queue_size,
            "visible":         visible,
            "filters":         [],
            "interleave":      existing.get("interleave") if existing else None,
            "starting_points": {},
        }

    # -- Folder wizard ---------------------------------------------------------

    def _run_folder_wizard(self, d, existing, name):
        """
        Wizard for Folder (directory source) channels.
        Steps: folder path → playback order → recycle → queue size → visibility
        """
        from resources.lib.channels.folder import (
            _normalise_path, _accessible_path)
        import xbmcvfs as _xbmcvfs

        # ---- Step 1: Folder path --------------------------------------------
        existing_path = existing.get("folder_path", "") if existing else ""
        folder_path = d.browseSingle(
            0,
            self._s(32507),
            "files",
            defaultt=existing_path)
        if not folder_path:
            d.ok(self._s(32289), self._s(32508))
            return None

        folder_path = _normalise_path(folder_path)

        if not _accessible_path(folder_path):
            d.ok(self._s(32289), self._s(32509).format(folder_path))
            return None

        # ---- Step 2: Playback order -----------------------------------------
        if existing:
            default_rand = existing.get("randomize", False)
        else:
            try:
                default_rand = self.addon.getSetting(
                    "default_randomize") == "true"
            except Exception:
                default_rand = False
        _rand_choice_f = d.select(
            self._s(32511),
            [self._s(32384),    # Sequential
             self._s(32224),    # Random
             self._s(32569)],   # Cancel
            preselect=1 if default_rand else 0)
        if _rand_choice_f < 0 or _rand_choice_f == 2:
            return None
        randomize = (_rand_choice_f == 1)

        # ---- Step 3: Recycle ------------------------------------------------
        if existing:
            default_rec = existing.get("recycle", True)
        else:
            try:
                default_rec = self.addon.getSetting(
                    "default_recycle") != "false"
            except Exception:
                default_rec = True
        _rec_choice_f = d.select(
            self._s(32225),
            [self._s(32228),    # Recycle
             self._s(32227),    # Stop
             self._s(32569)],   # Cancel
            preselect=0 if default_rec else 1)
        if _rec_choice_f < 0 or _rec_choice_f == 2:
            return None
        recycle = (_rec_choice_f == 0)

        # ---- Step 4: Queue size ---------------------------------------------
        try:
            _default_qs = max(10, int(
                self.addon.getSetting("default_queue_size") or "30"))
        except Exception:
            _default_qs = 30
        qs_str = d.input(
            self._s(32229),
            str(existing.get("queue_size", _default_qs)) if existing
            else str(_default_qs),
            type=xbmcgui.INPUT_NUMERIC)
        if not qs_str:
            return None
        try:
            queue_size = max(10, min(200, int(qs_str)))
        except ValueError:
            queue_size = _default_qs

        # ---- Step 5: Visibility ---------------------------------------------
        default_vis = existing.get("visible", True) if existing else True
        _vis_choice_f = d.select(
            self._s(32230),
            [self._s(32233),    # Show
             self._s(32232),    # Hide
             self._s(32569)],   # Cancel
            preselect=0 if default_vis else 1)
        if _vis_choice_f < 0 or _vis_choice_f == 2:
            return None
        visible = (_vis_choice_f == 0)

        return {
            "name":             name,
            "channel_type":     "folder",
            "folder_path":      folder_path,
            "shows":            [],
            "movies":           [],
            "randomize":        randomize,
            "recycle":          recycle,
            "queue_size":       queue_size,
            "visible":          visible,
            "filters":          [],
            "interleave":       existing.get("interleave") if existing else None,
            "starting_points":  {},
        }

    # -- Filter builder --------------------------------------------------------

    def _build_episode_filters(self, d, show_title, existing_filters):
        """
        Interactive per-show episode filter builder.

        Always creates its own Dialog instance to prevent Kodi input-state
        bleed-through into subsequent wizard steps (e.g. date picker leaking
        into the queue-size numeric input).

        Season selection uses a list picker populated from the show's actual
        available seasons so the user can see what season numbers exist
        (important for shows like Looney Tunes where seasons are years).

        First Aired uses INPUT_ALPHANUM so the user types YYYY-MM-DD directly
        rather than Kodi's native date wheel (which shows DD/MM/YYYY and
        cannot be relabelled).
        """
        _d       = xbmcgui.Dialog()
        filters  = list(existing_filters) if existing_filters else []
        modified = False

        # Fetch the show's actual season list for the season picker.
        # Look up by title match from selected_shows (we only have title here).
        # Falls back to an empty list — user will see a "no seasons" notice.
        _season_list = []
        try:
            for _s in self.manager.library.get_all_tvshows():
                if _s.get("title", "").lower() == show_title.lower():
                    # get_episodes_for_show gives us season numbers
                    _eps = self.manager.library.get_episodes_for_show(
                        _s["tvshowid"])
                    _season_list = sorted(
                        set(e["season"] for e in _eps if e.get("season")))
                    break
        except Exception:
            _season_list = []

        while True:
            # Build summary line
            if filters:
                parts = []
                for i, f in enumerate(filters):
                    op       = f.get("operator", "and").upper()
                    prefix   = "" if i == 0 else "{} ".format(op)
                    ftype    = f.get("type", "")
                    fval     = f.get("value", "")
                    comp     = f.get("comparison", "")
                    comp_str = {
                        "greaterthan":      ">",
                        "lessthan":         "<",
                        "greaterthanequal": ">=",
                        "lessthanequal":    "<=",
                        "equals":           "=",
                    }.get(comp, "=")
                    parts.append("{}{}: {} {}".format(
                        prefix, ftype.capitalize(), comp_str, fval))
                summary = " | ".join(parts)
            else:
                summary = self._s(32547)  # "No episode filters set"

            # Build the dialog title with current filter summary embedded
            title = "{} — {}".format(
                self._s(32539).format(show_title), summary)

            options = [
                self._s(32546),           # [0] "Watched / Unwatched"
                self._s(32542),           # [1] "Season"
                self._s(32543),           # [2] "First Aired (YYYY-MM-DD)"
                self._s(32464),           # [3] "Remove last filter"
                self._s(32465),           # [4] "Clear all filters"
                self._s(32466),           # [5] "Done"
            ]
            action = _d.select(title, options)

            if action < 0 or action == 5:
                break

            elif action == 0:
                # Watched / Unwatched — simple two-option select
                wc = _d.select(
                    self._s(32546),
                    [self._s(32540),    # "Watched only"
                     self._s(32541)])   # "Unwatched only"
                if wc == 0:
                    filters = [f for f in filters if f.get("type") != "watched"]
                    filters.append({"type": "watched", "value": "watched",
                                    "operator": "and", "comparison": "equals"})
                    modified = True
                elif wc == 1:
                    filters = [f for f in filters if f.get("type") != "watched"]
                    filters.append({"type": "watched", "value": "unwatched",
                                    "operator": "and", "comparison": "equals"})
                    modified = True

            elif action == 1:
                # Season — pick comparison operator then pick from actual
                # season list so user sees real season numbers (e.g. 1940,
                # 1941... for Looney Tunes rather than 1, 2...).
                if not _season_list:
                    _d.ok(self._s(32289), self._s(32551))
                    continue
                comp_labels = ["=", ">=", "<=", ">", "<"]
                comp_values = ["equals", "greaterthanequal", "lessthanequal",
                               "greaterthan", "lessthan"]
                cc = _d.select(self._s(32542), comp_labels)
                if cc < 0:
                    continue
                comp_choice = comp_values[cc]
                # Show actual season numbers as list
                season_labels = [str(s) for s in _season_list]
                sc = _d.select(
                    self._s(32545),   # "Select season"
                    season_labels)
                if sc < 0:
                    continue
                sn_val = _season_list[sc]
                filters.append({"type": "season", "value": sn_val,
                                 "operator": "and",
                                 "comparison": comp_choice})
                modified = True

            elif action == 2:
                # First Aired — use INPUT_ALPHANUM so user types YYYY-MM-DD
                # directly. Kodi's INPUT_DATE shows a DD/MM/YYYY wheel that
                # cannot be relabelled and its format varies by region.
                comp_labels = ["after (>)", "before (<)", "on (=)"]
                comp_values = ["greaterthan", "lessthan", "equals"]
                cc = _d.select(self._s(32543), comp_labels)
                if cc < 0:
                    continue
                comp_choice = comp_values[cc]
                date_str = _d.input(
                    self._s(32544),        # "Enter date (YYYY-MM-DD)"
                    defaultt="2000-01-01",
                    type=xbmcgui.INPUT_ALPHANUM)
                if not date_str:
                    continue
                # Basic validation — must look like YYYY-MM-DD
                date_str = date_str.strip()
                import re as _re
                if not _re.match(r"^\d{4}-\d{2}-\d{2}$", date_str):
                    _d.ok(self._s(32289), self._s(32550))
                    continue
                filters.append({"type": "firstaired", "value": date_str,
                                 "operator": "and",
                                 "comparison": comp_choice})
                modified = True

            elif action == 3:
                if filters:
                    filters.pop()
                    modified = True

            elif action == 4:
                filters  = []
                modified = True

        return filters if modified else existing_filters

    # -- Exclusions builders -----------------------------------------------

    def _build_episode_exclusions(self, d, show_entry, show_title,
                                   existing_excluded):
        """
        Interactive per-show episode exclusion picker (TV and Serial).

        Reuses the season -> episode selection pattern from the manual
        starting-point picker, generalised into a repeatable loop with
        multiselect (toggle) instead of a single pick, since exclusions
        are a SET of episodes rather than one choice.

        Only offers episodes that pass the show's current episode_filters
        (get_filtered_episodes) — exclusions narrow what's already
        filtered in; there's no reason to offer excluding an episode the
        filters already remove from the pool.

        Always creates its own Dialog instance, matching
        _build_episode_filters, to avoid Kodi input-state bleed-through
        into subsequent wizard steps.
        """
        _d       = xbmcgui.Dialog()
        excluded = set(existing_excluded) if existing_excluded else set()

        eligible = self.manager.get_filtered_episodes(show_entry)
        if not eligible:
            _d.ok(self._s(32289), self._s(32551))
            return list(excluded)

        seasons = sorted(set(e["season"] for e in eligible
                             if e.get("season")))

        while True:
            summary = (self._s(32558).format(len(excluded)) if excluded
                       else self._s(32559))
            title = self._s(32556).format(show_title, summary)

            season_labels = [str(s) for s in seasons] + [self._s(32466)]
            choice = _d.select(title, season_labels)
            if choice < 0 or choice == len(seasons):
                break

            chosen_season = seasons[choice]
            season_eps    = sorted(
                [e for e in eligible if e["season"] == chosen_season],
                key=lambda e: e["episode"])

            # Intermediate choice: exclude the whole season at once or
            # pick individual episodes. Cancelling returns to the season
            # list without changing anything.
            _action = _d.select(
                self._s(32568).format(chosen_season),
                [
                    self._s(32565).format(chosen_season),
                    self._s(32566),
                ])
            if _action < 0:
                continue  # back to season list, no change

            if _action == 0:
                # Exclude entire season — replace any individual
                # selections for this season with the full set. This is
                # a deliberate "replace, not add" so any prior individual
                # picks within this season are superseded cleanly.
                season_ids = {e["episodeid"] for e in season_eps}
                excluded  -= season_ids   # clear individual first
                excluded  |= season_ids   # then add all
                continue  # back to season list

            # _action == 1: individual episode multiselect (existing flow)
            ep_labels = [
                "S{:02d}E{:02d} - {}".format(
                    e["season"], e["episode"], e["title"])
                for e in season_eps
            ]
            preselect = [i for i, e in enumerate(season_eps)
                        if e["episodeid"] in excluded]

            picked = _d.multiselect(
                self._s(32560).format(show_title, chosen_season),
                ep_labels,
                preselect=preselect)
            if picked is None:
                continue  # cancelled this season — keep looping, unchanged

            # Replace this season's exclusion membership with the new
            # picks: clear this season's ids from the set first, then add
            # back whatever is currently checked.
            season_ids = {e["episodeid"] for e in season_eps}
            excluded  -= season_ids
            for i in picked:
                excluded.add(season_eps[i]["episodeid"])

        return list(excluded)

    def _build_movie_exclusions(self, d, movies, existing_excluded):
        """
        Movie exclusion picker — single multiselect over the channel's
        own selected movie list. No season concept, unlike TV/Serial, so
        this is a single dialog rather than a season-picker loop.
        """
        _d       = xbmcgui.Dialog()
        excluded = set(existing_excluded) if existing_excluded else set()

        if not movies:
            return list(excluded)

        movie_labels = [m["title"] for m in movies]
        preselect    = [i for i, m in enumerate(movies)
                        if m["movieid"] in excluded]

        picked = _d.multiselect(
            self._s(32563), movie_labels, preselect=preselect)
        if picked is None:
            return list(excluded)  # cancelled — unchanged

        return [movies[i]["movieid"] for i in picked]

    def _build_filters(self, existing_filters, media_type="tv"):
        """Interactive filter rule builder."""
        d = xbmcgui.Dialog()

        filters  = list(existing_filters) if existing_filters else []
        modified = False

        while True:
            if filters:
                summary = []
                for i, f in enumerate(filters):
                    op = f.get("operator", "and").upper()
                    prefix = "" if i == 0 else "{} ".format(op)
                    comp   = f.get("comparison", "")
                    comp_str = {
                        "greaterthan":      ">",
                        "lessthan":         "<",
                        "greaterthanequal": ">=",
                        "lessthanequal":    "<=",
                        "equals":           "=",
                    }.get(comp, "")
                    summary.append("{}{}: {} {}".format(
                        prefix,
                        f.get("type", "").capitalize(),
                        comp_str,
                        f.get("value", "")))
                current = self._s(32460) + " | ".join(summary)
            else:
                current = self._s(32461)

            action = d.select(
                self._s(32462),
                [current,
                 self._s(32463),
                 self._s(32464),
                 self._s(32465),
                 self._s(32466)])

            if action < 0 or action == 4:
                break
            elif action == 0:
                pass
            elif action == 1:
                new_filter = self._add_filter_rule(d, filters, media_type)
                if new_filter:
                    filters.append(new_filter)
                    modified = True
            elif action == 2:
                if filters:
                    filters.pop()
                    modified = True
            elif action == 3:
                filters = []
                modified = True

        return filters

    def _add_filter_rule(self, d, existing_filters, media_type):
        """Add a single filter rule. Returns a filter dict or None."""
        if media_type == "movies":
            type_options = [
                ("genre",  self._s(32467)),
                ("year",   self._s(32468)),
                ("mpaa",   self._s(32469)),
                ("studio", self._s(32470)),
                ("rating", self._s(32471)),
            ]
        else:
            type_options = [
                ("genre",  self._s(32467)),
                ("year",   self._s(32472)),
                ("studio", self._s(32473)),
                ("rating", self._s(32471)),
            ]

        type_labels = [t[1] for t in type_options]
        type_choice = d.select(self._s(32474), type_labels)
        if type_choice < 0:
            return None

        ftype, flabel = type_options[type_choice]

        operator = "and"
        if existing_filters:
            op_choice = d.select(
                self._s(32475),
                [self._s(32476), self._s(32477)])
            if op_choice < 0:
                return None
            operator = "or" if op_choice == 1 else "and"

        if ftype == "genre":
            genres = self.manager.library.get_all_genres(
                "movie" if media_type == "movies" else "tvshow")
            if not genres:
                d.ok(self._s(32289), self._s(32478))
                return None
            choice = d.select(self._s(32427), genres)
            if choice < 0:
                return None
            return {"type": "genre", "value": genres[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "year":
            comp_choice = d.select(
                self._s(32483),
                [self._s(32484),
                 self._s(32485),
                 self._s(32486)])
            if comp_choice < 0:
                return None
            comp_map = {0: "greaterthan", 1: "lessthan", 2: "equals"}
            comp = comp_map[comp_choice]

            year_str = d.input(self._s(32487), "",
                               type=xbmcgui.INPUT_NUMERIC)
            if not year_str:
                return None
            try:
                year = int(year_str)
                if year < 1888 or year > 2100:
                    raise ValueError
            except ValueError:
                d.ok(self._s(32289), self._s(32488))
                return None
            return {"type": "year", "value": str(year),
                    "operator": operator, "comparison": comp}

        elif ftype == "mpaa":
            common = ["G", "PG", "PG-13", "R", "NC-17",
                      "NR", "TV-G", "TV-PG", "TV-14", "TV-MA"]
            lib_ratings = self.manager.library.get_mpaa_ratings("movie")
            all_ratings = sorted(set(common + lib_ratings))
            if not all_ratings:
                d.ok(self._s(32289), self._s(32479))
                return None
            choice = d.select(self._s(32480), all_ratings)
            if choice < 0:
                return None
            return {"type": "mpaa", "value": all_ratings[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "studio":
            studios = self.manager.library.get_studios(
                "movie" if media_type == "movies" else "tv")
            if not studios:
                d.ok(self._s(32289), self._s(32481))
                return None
            choice = d.select(self._s(32482), studios)
            if choice < 0:
                return None
            return {"type": "studio", "value": studios[choice],
                    "operator": operator, "comparison": "contains"}

        elif ftype == "rating":
            comp_choice = d.select(
                self._s(32489),
                [self._s(32490),
                 self._s(32491),
                 self._s(32492)])
            if comp_choice < 0:
                return None
            comp_map = {0: "greaterthanequal",
                        1: "lessthanequal", 2: "equals"}
            comp = comp_map[comp_choice]

            rating_str = d.input(self._s(32493), "7",
                                 type=xbmcgui.INPUT_NUMERIC)
            if not rating_str:
                return None
            try:
                rating = float(rating_str)
                if rating < 0 or rating > 10:
                    raise ValueError
            except ValueError:
                d.ok(self._s(32289), self._s(32494))
                return None
            return {"type": "rating", "value": str(rating),
                    "operator": operator, "comparison": comp}

        return None

    # -- Interleave ------------------------------------------------------------

    def manage_interleave_dialog(self, params):
        """Multi-source interleave configuration dialog.

        Replaces the old single-source dialog entirely.
        Uses channels/interleave.get_sources() to normalise config so both
        legacy single-dict and new list format are handled transparently.

        Flow:
          1. Show current sources as a select list (add / remove-all at bottom)
          2. Selecting a source -> edit (frequency/jitter/count_per/silent) or remove
          3. [Add Source] -> channel picker -> input dialog -> appended to list
          4. [Remove All] -> confirm -> strips interleave and regenerates queue
        """
        from resources.lib.channels.interleave import get_sources

        channel_id = params.get("channel_id")
        channel    = self.manager.get_channel(channel_id)
        if not channel:
            return

        d     = xbmcgui.Dialog()
        other = [c for c in self.manager.get_all_channels()
                 if c["id"] != channel_id]

        if not other:
            d.ok(self._s(32289), self._s(32182))
            return

        def _would_be_circular(foreign_id, origin_id, visited=None):
            """Follow ALL interleave sources recursively to detect A->B->A."""
            if visited is None:
                visited = set()
            if foreign_id in visited:
                return True
            visited.add(foreign_id)
            foreign_ch = self.manager.get_channel(foreign_id)
            if not foreign_ch:
                return False
            for src in get_sources(foreign_ch):
                next_id = src.get("channel_id", "")
                if next_id == origin_id:
                    return True
                if _would_be_circular(next_id, origin_id, visited):
                    return True
            return False

        def _source_input_dialog(existing=None):
            """Collect frequency / jitter / count_per / silent for one source.

            existing: dict with current values (or None for a new source).
            Returns a completed source dict, or None if the user cancelled.
            """
            ex = existing or {}

            # Jitter mode
            cur_jitter  = int(ex.get("jitter", 0))
            mode_choice = d.select(
                self._s(32192),
                [
                    self._s(32193) + ("  (current)" if cur_jitter == 0 else ""),
                    self._s(32194) + ("  (current)" if cur_jitter >  0 else ""),
                ])
            if mode_choice == -1:
                return None
            use_jitter = (mode_choice == 1)

            # Frequency
            cur_freq    = str(int(ex.get("frequency", 4)))
            freq_prompt = self._s(32195) if use_jitter else self._s(32196)
            freq_str    = d.input(freq_prompt, cur_freq,
                                  type=xbmcgui.INPUT_NUMERIC)
            if freq_str is None or freq_str == "":
                return None
            try:
                frequency = max(1, int(freq_str))
            except ValueError:
                frequency = 4

            # Jitter
            jitter = 0
            if use_jitter:
                max_jitter  = frequency - 1
                cur_jit_str = str(min(cur_jitter, max_jitter)
                                  if cur_jitter else min(2, max_jitter))
                jit_str = d.input(self._s(32197), cur_jit_str,
                                  type=xbmcgui.INPUT_NUMERIC)
                if jit_str is None or jit_str == "":
                    return None
                try:
                    jitter = max(0, min(max_jitter, int(jit_str)))
                except ValueError:
                    jitter = min(2, max_jitter)

            # Count per insertion
            cur_count = int(ex.get("count_per", 1))
            count_str = d.input(
                "{}\n{}\n({}: {})".format(
                    self._s(32198), self._s(32199),
                    self._s(32530), cur_count),
                defaultt=str(cur_count),
                type=xbmcgui.INPUT_NUMERIC)
            if count_str is None or count_str == "":
                return None
            try:
                count_per = max(1, int(count_str))
            except (ValueError, TypeError):
                count_per = cur_count

            # Silent toggle
            cur_silent    = bool(ex.get("silent", False))
            silent_choice = d.select(
                self._s(32527),
                [
                    self._s(32525) + ("  (current)" if not cur_silent else ""),
                    self._s(32524) + ("  (current)" if cur_silent     else ""),
                ])
            if silent_choice == -1:
                return None

            return {
                "frequency": frequency,
                "jitter":    jitter,
                "count_per": count_per,
                "silent":    (silent_choice == 1),
            }

        # ----------------------------------------------------------------
        # Main loop — show source list and handle actions
        # ----------------------------------------------------------------
        while True:
            sources = get_sources(channel)

            # Main dialog — actions only, no source listing here.
            # Rows layout:
            #   0 : [Add Source]
            #   1 : [Edit / Remove Sources]  (only when sources exist)
            #   1 or 2 : [Remove All Interleave]
            #   2 or 3 : [Done]
            rows = [self._s(32518)]   # [Add Source]
            if sources:
                rows.append(self._s(32531))  # [Edit / Remove Sources]
            rows += [self._s(32519), self._s(32499)]

            choice = d.select(self._s(32516), rows)
            if choice == -1:
                return

            add_idx        = 0
            edit_idx       = 1 if sources else None
            remove_all_idx = 2 if sources else 1
            done_idx       = 3 if sources else 2

            # Done
            if choice == done_idx:
                return

            # [Remove All Interleave]
            if choice == remove_all_idx:
                if not d.yesno(self._s(32289), self._s(32520)):
                    continue
                channel["interleave"] = None
                self.manager._save_channels()
                self.manager.regenerate_queue(channel_id)
                d.notification(self._s(32289), self._s(32521),
                               xbmcgui.NOTIFICATION_INFO, 2000)
                xbmc.sleep(300)
                xbmc.executebuiltin("Container.Refresh")
                return

            # [Edit / Remove Sources]
            if edit_idx is not None and choice == edit_idx:
                def _source_label(s):
                    ch   = self.manager.get_channel(s["channel_id"]) or {}
                    name = ch.get("name", s["channel_id"][:8])
                    badge  = " {}".format(self._s(32526)) if s["silent"] else ""
                    freq   = s["frequency"]
                    jit    = s["jitter"]
                    detail = ("every {}-{}".format(max(1, freq - jit), freq + jit)
                              if jit else "every {}".format(freq))
                    if s["count_per"] > 1:
                        detail += " x{}".format(s["count_per"])
                    return "{}{} — {}".format(name, badge, detail)

                src_choice = d.select(
                    self._s(32531),
                    [_source_label(s) for s in sources])
                if src_choice == -1:
                    continue
                src      = sources[src_choice]
                src_ch   = self.manager.get_channel(src["channel_id"]) or {}
                src_name = src_ch.get("name", src["channel_id"][:8])
                action   = d.select(
                    self._s(32522).format(src_name),
                    [
                        self._s(32193) if src["jitter"] == 0 else self._s(32194),
                        self._s(32523),
                    ])
                if action == -1:
                    continue
                # Remove this source
                if action == 1:
                    new_sources = [s for s in sources
                                   if s["channel_id"] != src["channel_id"]]
                    channel["interleave"] = new_sources if new_sources else None
                    self.manager._save_channels()
                    self.manager.regenerate_queue(channel_id)
                    d.notification(self._s(32289), self._s(32521),
                                   xbmcgui.NOTIFICATION_INFO, 2000)
                    continue
                # Edit this source
                result = _source_input_dialog(existing=src)
                if result is None:
                    continue
                result["channel_id"] = src["channel_id"]
                new_sources = [
                    result if s["channel_id"] == src["channel_id"] else s
                    for s in sources
                ]
                channel["interleave"] = new_sources
                self.manager._save_channels()
                self.manager.regenerate_queue(channel_id)
                d.notification(self._s(32289), self._s(32528),
                               xbmcgui.NOTIFICATION_INFO, 2000)
                continue

            # [Add Source]
            if choice == add_idx:
                existing_ids = {s["channel_id"] for s in sources}
                # Split candidates into two groups:
                # Group 1 — no interleave configured (clean sources)
                # Group 2 — already have interleave configured (still valid)
                eligible = [
                    c for c in other
                    if c["id"] not in existing_ids
                    and not _would_be_circular(c["id"], channel_id)
                ]
                if not eligible:
                    d.ok(self._s(32289), self._s(32529))
                    continue
                group1 = sorted([c for c in eligible
                                 if not get_sources(c)],
                                key=lambda c: c["name"])
                group2 = sorted([c for c in eligible
                                 if get_sources(c)],
                                key=lambda c: c["name"])
                # Build picker rows — separator is unselectable (handled by index)
                picker_rows      = [c["name"] for c in group1]
                picker_channels  = list(group1)
                separator_idx    = None
                if group2:
                    separator_idx = len(picker_rows)
                    picker_rows.append(self._s(32532))
                    picker_rows   += [c["name"] for c in group2]
                    picker_channels += [None] + list(group2)  # None = separator

                # Build picker title showing currently configured sources
                if sources:
                    cur_names = []
                    for s in sources:
                        sc = self.manager.get_channel(s["channel_id"]) or {}
                        cur_names.append(sc.get("name", s["channel_id"][:8]))
                    picker_title = "{} ({}:{})".format(
                        self._s(32530),
                        self._s(32516),
                        ", ".join(cur_names))
                else:
                    picker_title = self._s(32530)

                pick = d.select(picker_title, picker_rows)
                if pick == -1:
                    continue
                # Ignore if separator selected
                if separator_idx is not None and pick == separator_idx:
                    continue
                src_ch = picker_channels[pick]
                if src_ch is None:
                    continue
                result = _source_input_dialog()
                if result is None:
                    continue
                result["channel_id"] = src_ch["id"]
                new_sources = list(sources) + [result]
                channel["interleave"] = new_sources
                self.manager._save_channels()
                self.manager.regenerate_queue(channel_id)
                d.notification(self._s(32289), self._s(32528),
                               xbmcgui.NOTIFICATION_INFO, 2000)
                continue

