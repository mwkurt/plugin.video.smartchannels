from __future__ import annotations
"""
resources/lib/library.py
=========================
Abstracts all Kodi library queries.

Supports two backends:
  1. xbmc.executeJSONRPC  - uses Kodi's built-in JSON-RPC API (preferred).
     Works transparently whether Kodi is using SQLite or MySQL/MariaDB under
     the hood, since Kodi itself handles that routing.

  2. Direct MySQL/MariaDB  - optional fallback if the user explicitly wants
     to query the DB server directly (useful for advanced setups).

Results are cached in memory per Kodi session to avoid hammering the DB.
The cache is cleared on explicit user request or addon restart.
"""

import json
from typing import Any, Optional

import xbmc
import xbmcaddon

from resources.lib.utils.logger import log


class LibraryClient:
    """Thin wrapper around Kodi JSON-RPC for video library access."""

    def __init__(self, addon: xbmcaddon.Addon):
        self.addon   = addon
        self._cache  = {}
        import xbmcvfs as _xbmcvfs, os as _os
        self._profile = _xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        # Route local_library.json to shared storage if configured
        try:
            raw = addon.getSetting("shared_storage_path").strip()
            if raw in ("smb://", "smb:/", ""):
                raw = ""
            shared = raw.rstrip("/").rstrip("\\") if raw else ""
        except Exception:
            shared = ""
        # Convert Windows UNC (\\\\Server\\share) to smb://
        if shared and (shared.startswith("\\\\") or shared.startswith("//")):
            shared = shared.lstrip("\\/")
            shared = "smb://" + shared.replace("\\", "/")
            shared = shared.rstrip("/")
        if shared:
            if not _xbmcvfs.exists(shared):
                try:
                    _xbmcvfs.mkdirs(shared)
                except Exception:
                    pass
            # Network paths use forward slash; local paths use os.path.join
            if "://" in shared:
                self._local_cache_path = shared + "/local_library.json"
            else:
                self._local_cache_path = _os.path.join(
                    shared, "local_library.json")
        else:
            self._local_cache_path = _os.path.join(
                self._profile, "local_library.json")
        # Ensure profile directory exists
        if not _xbmcvfs.exists(self._profile):
            _xbmcvfs.mkdirs(self._profile)

    # -- Cache helpers ---------------------------------------------------------

    def clear_cache(self) -> None:
        self._cache.clear()
        log("[LibraryClient] Cache cleared")

    def _cached(self, key: str, fetcher):
        if key not in self._cache:
            self._cache[key] = fetcher()
        return self._cache[key]

    # -- JSON-RPC helper -------------------------------------------------------

    @staticmethod
    def _rpc(method: str, params: dict) -> dict:
        """
        Execute a Kodi JSON-RPC call and return the parsed result dict.
        Returns {} on error.
        """
        payload = json.dumps({
            "jsonrpc": "2.0",
            "id":      1,
            "method":  method,
            "params":  params,
        })
        raw = xbmc.executeJSONRPC(payload)
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            log("[LibraryClient] JSON decode error: {}".format(exc), level=xbmc.LOGERROR)
            return {}

        if "error" in data:
            log("[LibraryClient] RPC error for {}: {}".format(method, data['error']),
                level=xbmc.LOGWARNING)
            return {}

        return data.get("result", {})

    # -- TV Shows --------------------------------------------------------------

    # -- Local library cache ---------------------------------------------------

    def local_cache_exists(self):
        """Return True if a valid local cache file exists."""
        import xbmcvfs as _xbmcvfs, os as _os
        if not _xbmcvfs.exists(self._local_cache_path):
            return False
        try:
            stat = _xbmcvfs.Stat(self._local_cache_path)
            return stat.st_size() > 100
        except Exception:
            return False

    def local_cache_age_days(self):
        """Return age of local cache file in days, or 999 if missing."""
        import xbmcvfs as _xbmcvfs, time as _time
        if not _xbmcvfs.exists(self._local_cache_path):
            return 999
        try:
            stat = _xbmcvfs.Stat(self._local_cache_path)
            age  = _time.time() - stat.st_mtime()
            return age / 86400.0
        except Exception:
            return 999

    def load_local_cache(self):
        """
        Load the local library cache from disk.
        Returns dict with tvshows and movies lists, or None if not found.
        """
        import json as _json
        import xbmcvfs as _xbmcvfs
        if not _xbmcvfs.exists(self._local_cache_path):
            return None
        try:
            with _xbmcvfs.File(self._local_cache_path, "r") as f:
                data = _json.loads(f.read())
            log("[LibraryClient] Loaded local cache: {} shows, {} movies".format(
                len(data.get("tvshows", [])),
                len(data.get("movies", []))))
            return data
        except Exception as e:
            log("[LibraryClient] Failed to load local cache: {}".format(e))
            return None

    def build_local_cache(self, progress_callback=None):
        """
        Query MySQL for all shows and movies and write local_library.json.
        progress_callback(pct, msg) is called during the build for UI updates.

        Excludes watched status (changes too frequently to cache reliably).
        Watched filter is applied at queue build time via live DB query.
        """
        import json as _json, time as _time
        import xbmcvfs as _xbmcvfs

        log("[LibraryClient] Building local library cache...")

        def _progress(pct, msg):
            if progress_callback:
                progress_callback(pct, msg)

        _progress(5, "Fetching TV shows...")

        # Fetch TV shows with full filter-relevant properties
        result = self._rpc("VideoLibrary.GetTVShows", {
            "properties": ["title", "genre", "year", "studio",
                           "mpaa", "rating", "episode", "art"],
            "sort": {"order": "ascending", "method": "title"},
        })
        tvshows = []
        for s in result.get("tvshows", []):
            tvshows.append({
                "tvshowid":   s.get("tvshowid", -1),
                "title":      s.get("title", ""),
                "genre":      s.get("genre", []),
                "year":       s.get("year", 0),
                "studio":     s.get("studio", []),
                "mpaa":       s.get("mpaa", ""),
                "rating":     round(float(s.get("rating", 0) or 0), 1),
                "nbepisodes": s.get("episode", 0),
                "poster":     s.get("art", {}).get("poster", ""),
            })

        _progress(50, "Fetching movies...")

        # Fetch movies with full filter-relevant properties
        # Fetch movies in two passes to avoid large result sets timing out:
        # Pass 1: filter-relevant fields (fast)
        # Pass 2: display metadata fields (plot, runtime) separately
        result2 = self._rpc("VideoLibrary.GetMovies", {
            "properties": ["title", "genre", "year", "studio",
                           "mpaa", "rating", "file", "runtime", "art"],
            "sort": {"order": "ascending", "method": "title"},
        })
        movies = []
        for m in result2.get("movies", []):
            if not m.get("file"):
                continue
            movies.append({
                "movieid": m.get("movieid", -1),
                "title":   m.get("title", ""),
                "genre":   m.get("genre", []),
                "year":    m.get("year", 0),
                "studio":  m.get("studio", []),
                "mpaa":    m.get("mpaa", ""),
                "rating":  round(float(m.get("rating", 0) or 0), 1),
                "file":    m.get("file", ""),
                "runtime": m.get("runtime", 0),
                "plot":    "",
                "poster":  m.get("art", {}).get("poster", ""),
            })

        _progress(70, "Fetching movie descriptions...")

        # Pass 2: fetch plot separately - smaller result set per query
        # Do this in one batch query, not per-movie
        result3 = self._rpc("VideoLibrary.GetMovies", {
            "properties": ["plot"],
            "sort": {"order": "ascending", "method": "title"},
        })
        plot_map = {
            m.get("movieid"): (m.get("plot", "") or "")[:300]
            for m in result3.get("movies", [])
        }
        # Merge plots into movie list
        for m in movies:
            m["plot"] = plot_map.get(m["movieid"], "")

        _progress(90, "Writing cache file...")

        data = {
            "last_updated": _time.strftime("%Y-%m-%d %H:%M:%S"),
            "tvshows":      tvshows,
            "movies":       movies,
        }

        try:
            import xbmcvfs as _xbmcvfs2, os as _os2

            # Ensure profile directory exists before writing
            if not _xbmcvfs2.exists(self._profile):
                _xbmcvfs2.mkdirs(self._profile)
                log("[LibraryClient] Created profile dir: {}".format(
                    self._profile))

            json_data = _json.dumps(data, indent=2)
            log("[LibraryClient] Writing {} bytes to {}".format(
                len(json_data), self._local_cache_path))

            # Write cache: local path uses xbmcvfs.File directly;
            # shared path writes locally first then copies across.
            import os as _osl
            is_shared = not self._local_cache_path.startswith(self._profile)
            if not is_shared:
                with _xbmcvfs2.File(self._local_cache_path, "w") as _fl:
                    _fl.write(json_data)
            else:
                local_copy = _osl.path.join(self._profile,
                                            "local_library.json")
                with _xbmcvfs2.File(local_copy, "w") as _fl:
                    _fl.write(json_data)
                if not _xbmcvfs2.copy(local_copy, self._local_cache_path):
                    if "://" not in self._local_cache_path:
                        with _xbmcvfs2.File(local_copy, "r") as _sl, \
                             _xbmcvfs2.File(self._local_cache_path, "w") as _dl:
                            _dl.write(_sl.read())

            # Verify the file was actually written
            if not _xbmcvfs2.exists(self._local_cache_path):
                log("[LibraryClient] ERROR: cache file missing after write - "
                    "trying direct open() as fallback")
                with _xbmcvfs2.File(self._local_cache_path, "w") as f:
                    f.write(json_data)

            # Final verification
            if _xbmcvfs2.exists(self._local_cache_path):
                # Invalidate in-memory cache so next call re-reads fresh data
                self._cache.pop("tvshows_minimal", None)
                self._cache.pop("tvshows_full", None)
                self._cache.pop("movies_all", None)
                log("[LibraryClient] Local cache built: {} shows, {} movies".format(
                    len(tvshows), len(movies)))
                _progress(100, "Done!")
                return True
            else:
                log("[LibraryClient] ERROR: cache file still missing after "
                    "both write attempts!")
                return False

        except Exception as e:
            log("[LibraryClient] Failed to write local cache: {} - {}".format(
                type(e).__name__, e))
            # Last resort: try plain Python file write
            try:
                with _xbmcvfs2.File(self._local_cache_path, "w") as f:
                    f.write(_json.dumps(data, indent=2))
                log("[LibraryClient] Fallback write succeeded")
                _progress(100, "Done (fallback)!")
                return True
            except Exception as e2:
                log("[LibraryClient] Fallback write also failed: {}".format(e2))
                return False

    def get_all_tvshows(self) -> list[dict]:
        """
        Return all TV shows for multiselect display.
        Reads from local cache if available, falls back to live DB query.
        """
        def _fetch():
            cached = self.load_local_cache()
            if cached and cached.get("tvshows"):
                return cached["tvshows"]
            # Fallback: minimal live query
            result = self._rpc("VideoLibrary.GetTVShows", {
                "properties": ["title"],
                "sort": {"order": "ascending", "method": "title"},
            })
            shows = result.get("tvshows", [])
            log("[LibraryClient] Loaded {} TV shows (live fallback)".format(
                len(shows)))
            return shows
        return self._cached("tvshows_minimal", _fetch)

    def get_all_tvshows_full(self) -> list[dict]:
        """
        Return all TV shows with full filter properties.
        Reads from local cache if available.
        """
        def _fetch():
            cached = self.load_local_cache()
            if cached and cached.get("tvshows"):
                return cached["tvshows"]
            # Fallback: live full query
            result = self._rpc("VideoLibrary.GetTVShows", {
                "properties": ["title", "genre", "year", "studio",
                               "mpaa", "rating"],
                "sort": {"order": "ascending", "method": "title"},
            })
            return result.get("tvshows", [])
        return self._cached("tvshows_full", _fetch)


    def get_tvshow(self, tvshowid: int) -> Optional[dict]:
        """Fetch a single TV show by ID."""
        shows = self.get_all_tvshows()
        return next((s for s in shows if s["tvshowid"] == tvshowid), None)

    def search_tvshows(self, query: str) -> list[dict]:
        """Return TV shows whose title contains `query` (case-insensitive)."""
        q = query.lower()
        return [s for s in self.get_all_tvshows() if q in s["title"].lower()]

    def get_tvshows_by_genre(self, genre: str) -> list[dict]:
        return [s for s in self.get_all_tvshows()
                if genre.lower() in [g.lower() for g in s.get("genre", [])]]

    def get_tvshows_by_year(self, year: int) -> list[dict]:
        return [s for s in self.get_all_tvshows() if s.get("year") == year]

    # -- Episodes --------------------------------------------------------------

    def get_episodes_for_show(self, tvshowid: int) -> list[dict]:
        """
        Return all episodes for a show, sorted by season then episode number.
        Cached per show ID.

        Returns list of:
          {"episodeid": int, "title": str, "season": int, "episode": int,
           "file": str, "thumbnail": str, "plot": str, "runtime": int, ...}
        """
        cache_key = "episodes_{}".format(tvshowid)

        def _fetch():
            result = self._rpc("VideoLibrary.GetEpisodes", {
                "tvshowid":   tvshowid,
                # Minimal properties for queue building - reduces transfer size
                # and speeds up queries significantly on large libraries
                "properties": ["title", "season", "episode", "file",
                               "playcount", "showtitle"],
                "sort": {"order": "ascending", "method": "episode"},
            })
            episodes = result.get("episodes", [])
            # Remove episodes with no local file path
            episodes = [e for e in episodes if e.get("file")]
            log("[LibraryClient] Loaded {} episodes for show {}".format(
                len(episodes), tvshowid))
            return episodes

        return self._cached(cache_key, _fetch)

    def get_episode(self, episodeid: int) -> Optional[dict]:
        """Fetch a single episode by ID."""
        result = self._rpc("VideoLibrary.GetEpisodeDetails", {
            "episodeid":  episodeid,
            "properties": ["title", "season", "episode", "file",
                            "thumbnail", "plot", "runtime", "showtitle", "art"],
        })
        return result.get("episodedetails")

    # -- Movies ----------------------------------------------------------------

    def get_all_movies(self) -> list[dict]:
        """
        Return all movies. Reads from local cache if available.
        """
        def _fetch():
            cached = self.load_local_cache()
            if cached and cached.get("movies"):
                return cached["movies"]
            # Fallback: live query
            result = self._rpc("VideoLibrary.GetMovies", {
                "properties": ["title", "genre", "year", "file",
                               "thumbnail", "fanart", "plot", "runtime",
                               "rating", "mpaa", "studio", "playcount",
                               "art"],
                "sort": {"order": "ascending", "method": "title"},
            })
            movies = [m for m in result.get("movies", []) if m.get("file")]
            log("[LibraryClient] Loaded {} movies (live fallback)".format(
                len(movies)))
            return movies
        return self._cached("movies_all", _fetch)


    def get_movies_by_genre(self, genre: str) -> list[dict]:
        return [m for m in self.get_all_movies()
                if genre.lower() in [g.lower() for g in m.get("genre", [])]]

    def get_movies_by_year(self, year: int) -> list[dict]:
        return [m for m in self.get_all_movies() if m.get("year") == year]

    # -- Advanced filter queries -----------------------------------------------

    def build_jrpc_filter(self, filters):
        """
        Convert our filter list into a Kodi JSON-RPC filter object.

        Each filter dict:
          {"type": "genre",   "value": "Comedy",    "operator": "and"}
          {"type": "year",    "value": "1969",       "operator": "and",
           "comparison": "greaterthan"}
          {"type": "mpaa",    "value": "PG",         "operator": "and"}
          {"type": "studio",  "value": "Warner",     "operator": "and"}
          {"type": "watched", "value": "unwatched",  "operator": "and"}

        Returns a JSON-RPC filter dict or None if no filters.
        """
        if not filters:
            return None

        # Map our filter types to JSON-RPC fields
        field_map = {
            "genre":      "genre",
            "year":       "year",
            "mpaa":       "mpaa",
            "studio":     "studio",
            "watched":    "playcount",
            "rating":     "rating",
            "season":     "season",      # episode-level filter
            "firstaired": "airdate",     # episode-level filter (Kodi field: airdate)
        }

        # Map our comparison tokens to JSON-RPC operators.
        # IMPORTANT: Kodi 21 JSON-RPC List.Filter.Operators does NOT include
        # "greaterthanequal" or "lessthanequal" — those will be rejected with
        # "Value does not match any of the enum values in type operator".
        # Valid numeric operators are only "greaterthan" and "lessthan".
        # "greaterthanequal"/"lessthanequal" are handled per field type below
        # (integer fields: adjust value by 1; float fields: approximate).
        comparison_map = {
            "contains":    "contains",
            "equals":      "is",
            "greaterthan": "greaterthan",
            "lessthan":    "lessthan",
        }

        rules = []
        for f in filters:
            ftype = f.get("type", "")
            fval  = f.get("value", "")
            comp  = f.get("comparison", "contains")

            if ftype not in field_map:
                continue

            field = field_map[ftype]

            # Special handling for watched status
            if ftype == "watched":
                if fval == "watched":
                    rule = {"field": "playcount",
                            "operator": "greaterthan", "value": "0"}
                elif fval == "unwatched":
                    rule = {"field": "playcount",
                            "operator": "is", "value": "0"}
                else:
                    continue

            elif ftype == "year":
                # Integer field — emulate >= N as > N-1 and <= N as < N+1
                # so we never send the invalid "greaterthanequal" operator.
                if comp == "greaterthanequal":
                    try:
                        rule = {"field": "year", "operator": "greaterthan",
                                "value": str(int(fval) - 1)}
                    except (ValueError, TypeError):
                        rule = {"field": "year", "operator": "greaterthan",
                                "value": str(fval)}
                elif comp == "lessthanequal":
                    try:
                        rule = {"field": "year", "operator": "lessthan",
                                "value": str(int(fval) + 1)}
                    except (ValueError, TypeError):
                        rule = {"field": "year", "operator": "lessthan",
                                "value": str(fval)}
                else:
                    jrpc_op = comparison_map.get(comp, "greaterthan")
                    rule = {"field": "year", "operator": jrpc_op,
                            "value": str(fval)}

            elif ftype == "rating":
                # Float field — "greaterthanequal"/"lessthanequal" cannot be
                # emulated exactly via value adjustment (floating point).
                # Fall back to the strict operator; rating comparisons are
                # inherently approximate in practice.
                if comp in ("greaterthan", "greaterthanequal"):
                    rule = {"field": "rating", "operator": "greaterthan",
                            "value": str(fval)}
                elif comp in ("lessthan", "lessthanequal"):
                    rule = {"field": "rating", "operator": "lessthan",
                            "value": str(fval)}
                else:
                    jrpc_op = comparison_map.get(comp, "is")
                    rule = {"field": "rating", "operator": jrpc_op,
                            "value": str(fval)}

            elif ftype == "season":
                # Integer field — same value-adjustment trick as year.
                # Season >= N  →  season > N-1
                # Season <= N  →  season < N+1
                if comp == "greaterthanequal":
                    try:
                        rule = {"field": "season", "operator": "greaterthan",
                                "value": str(int(fval) - 1)}
                    except (ValueError, TypeError):
                        rule = {"field": "season", "operator": "greaterthan",
                                "value": str(fval)}
                elif comp == "lessthanequal":
                    try:
                        rule = {"field": "season", "operator": "lessthan",
                                "value": str(int(fval) + 1)}
                    except (ValueError, TypeError):
                        rule = {"field": "season", "operator": "lessthan",
                                "value": str(fval)}
                else:
                    jrpc_op = comparison_map.get(comp, "is")
                    rule = {"field": "season", "operator": jrpc_op,
                            "value": str(fval)}

            elif ftype == "firstaired":
                # Air date — Kodi stores as YYYY-MM-DD string.
                # Use "after"/"before" operators for date comparison.
                # Map our comparison tokens to Kodi date operators.
                date_op_map = {
                    "greaterthan":      "after",
                    "greaterthanequal": "after",
                    "lessthan":         "before",
                    "lessthanequal":    "before",
                    "equals":           "is",
                }
                jrpc_op = date_op_map.get(comp, "after")
                rule = {"field": "airdate", "operator": jrpc_op,
                        "value": str(fval)}

            else:
                rule = {"field": field, "operator": "contains",
                        "value": str(fval)}

            rules.append(rule)

        if not rules:
            return None

        # Combine rules with AND or OR
        # Check if any rule uses OR operator
        has_or = any(f.get("operator", "and").lower() == "or"
                     for f in filters)

        if len(rules) == 1:
            return rules[0]

        combiner = "or" if has_or else "and"
        return {combiner: rules}



    def get_tvshows_with_filters(self, filters):
        """
        Filter TV shows using the local cache - no MySQL query needed.
        Filters the cached show list in Python which is instant.
        Falls back to live DB query only if no local cache exists.
        """
        import json as _json

        # Try filtering from local cache first (instant)
        all_shows = self.get_all_tvshows_full()
        if all_shows:
            result = self._filter_items_in_python(all_shows, filters)
            log("[LibraryClient] Python filter: {} of {} shows match".format(
                len(result), len(all_shows)))
            return result

        # Fallback: live DB query (slow but works without cache)
        log("[LibraryClient] No cache - falling back to live filter query")
        jrpc_filter = self.build_jrpc_filter(filters)
        params = {
            "properties": ["title", "genre", "year", "studio",
                           "mpaa", "rating"],
            "sort": {"order": "ascending", "method": "title"},
        }
        if jrpc_filter:
            params["filter"] = jrpc_filter
        result = self._rpc("VideoLibrary.GetTVShows", params)
        shows  = result.get("tvshows", [])
        log("[LibraryClient] Live filter query returned {} shows".format(
            len(shows)))
        return shows

    def get_movies_with_filters(self, filters):
        """
        Filter movies using the local cache - no MySQL query needed.
        Falls back to live DB query only if no local cache exists.
        """
        all_movies = self.get_all_movies()
        if all_movies:
            result = self._filter_items_in_python(all_movies, filters)
            log("[LibraryClient] Python filter: {} of {} movies match".format(
                len(result), len(all_movies)))
            return result

        # Fallback: live DB query
        log("[LibraryClient] No cache - falling back to live movie filter")
        jrpc_filter = self.build_jrpc_filter(filters)
        params = {
            "properties": ["title", "genre", "year", "file",
                           "mpaa", "studio", "rating"],
            "sort": {"order": "ascending", "method": "title"},
        }
        if jrpc_filter:
            params["filter"] = jrpc_filter
        result  = self._rpc("VideoLibrary.GetMovies", params)
        movies  = [m for m in result.get("movies", []) if m.get("file")]
        log("[LibraryClient] Live movie filter returned {} movies".format(
            len(movies)))
        return movies

    def _filter_items_in_python(self, items, filters):
        """
        Filter a list of show/movie dicts using our filter rules.
        All filtering done in Python against cached data - no DB needed.

        Supports:
          genre   - contains match (case insensitive)
          year    - greaterthan / lessthan / equals
          mpaa    - contains match
          studio  - contains match
          rating  - greaterthan / lessthan / equals

        AND/OR logic: if ANY filter has operator="or" we use OR logic,
        otherwise all rules use AND logic.
        """
        if not filters:
            return items

        use_or = any(f.get("operator", "and").lower() == "or"
                     for f in filters)

        def _matches_rule(item, f):
            ftype = f.get("type", "")
            fval  = str(f.get("value", "")).lower().strip()
            comp  = f.get("comparison", "contains")

            if ftype == "genre":
                genres = [g.lower() for g in item.get("genre", [])]
                return any(fval in g for g in genres)

            elif ftype == "year":
                item_year = int(item.get("year", 0) or 0)
                try:
                    cmp_year = int(fval)
                except ValueError:
                    return True
                if comp == "greaterthan":
                    return item_year > cmp_year
                elif comp == "lessthan":
                    return item_year < cmp_year
                elif comp in ("equals", "is"):
                    return item_year == cmp_year
                elif comp == "greaterthanequal":
                    return item_year >= cmp_year
                elif comp == "lessthanequal":
                    return item_year <= cmp_year
                return item_year > cmp_year

            elif ftype == "mpaa":
                return fval in item.get("mpaa", "").lower()

            elif ftype == "studio":
                studios = [s.lower() for s in item.get("studio", [])]
                return any(fval in s for s in studios)

            elif ftype == "rating":
                item_rating = float(item.get("rating", 0) or 0)
                try:
                    cmp_rating = float(fval)
                except ValueError:
                    return True
                if comp in ("greaterthan", "greaterthanequal"):
                    return item_rating >= cmp_rating
                elif comp in ("lessthan", "lessthanequal"):
                    return item_rating <= cmp_rating
                elif comp in ("equals", "is"):
                    return abs(item_rating - cmp_rating) < 0.1
                return item_rating >= cmp_rating

            elif ftype == "season":
                item_season = int(item.get("season", 0) or 0)
                try:
                    cmp_season = int(fval)
                except (ValueError, TypeError):
                    return True
                if comp == "greaterthan":
                    return item_season > cmp_season
                elif comp == "lessthan":
                    return item_season < cmp_season
                elif comp == "greaterthanequal":
                    return item_season >= cmp_season
                elif comp == "lessthanequal":
                    return item_season <= cmp_season
                return item_season == cmp_season

            elif ftype == "firstaired":
                # Compare YYYY-MM-DD strings lexicographically — works
                # correctly for ISO date format.
                item_date = str(item.get("firstaired", "") or "").strip()
                cmp_date  = str(fval).strip()
                # Episodes with no firstaired date are excluded when filtering
                # by date — an unknown date cannot satisfy a date comparison.
                if not item_date:
                    return False
                if not cmp_date:
                    return True
                if comp in ("greaterthan", "greaterthanequal", "after"):
                    return item_date >= cmp_date
                elif comp in ("lessthan", "lessthanequal", "before"):
                    return item_date <= cmp_date
                return item_date == cmp_date

            return True  # Unknown filter type - pass through

        result = []
        for item in items:
            if use_or:
                # OR: item passes if ANY rule matches
                if any(_matches_rule(item, f) for f in filters):
                    result.append(item)
            else:
                # AND: item passes only if ALL rules match
                if all(_matches_rule(item, f) for f in filters):
                    result.append(item)

        return result

    def get_episodes_with_filters(self, tvshowid, filters):
        """
        Return episodes for a show matching filter rules.
        Supports: watched/unwatched, season, firstaired.

        Strategy: build a Kodi JSON-RPC filter and pass it in the query.
        If the RPC rejects the filter (e.g. unsupported field/operator
        combination on this Kodi version), fall back to fetching all episodes
        and applying _filter_items_in_python so the user always gets results.

        Note: "year" is NOT a valid episode property in Kodi JSON-RPC —
        do not add it to the properties list. Use "firstaired" for date-based
        episode filtering.
        """
        jrpc_filter = self.build_jrpc_filter(filters)
        log("[LibraryClient] get_episodes_with_filters: show={} "
            "jrpc_filter={}".format(tvshowid, jrpc_filter))

        params = {
            "tvshowid":   tvshowid,
            "properties": ["title", "season", "episode", "file",
                           "thumbnail", "plot", "runtime", "showtitle",
                           "playcount", "firstaired"],
        }
        if jrpc_filter:
            params["filter"] = jrpc_filter
        else:
            # Only add sort when there is no filter — Kodi rejects the
            # combination of tvshowid + filter + sort on some builds.
            params["sort"] = {"order": "ascending", "method": "episode"}

        result   = self._rpc("VideoLibrary.GetEpisodes", params)
        episodes = result.get("episodes", [])
        episodes = [e for e in episodes if e.get("file")]
        # Sort by season then episode — needed when sort param was omitted
        # (filtered queries drop the sort to avoid Kodi validator rejection)
        episodes.sort(key=lambda e: (e.get("season", 0), e.get("episode", 0)))

        # If Kodi rejected the filter (RPC error → empty result) but we had
        # valid filter rules, fall back to Python-side filtering so the
        # user still gets a filtered list rather than an empty queue.
        if not episodes and jrpc_filter and filters:
            log("[LibraryClient] get_episodes_with_filters: RPC filter "
                "failed or returned empty — falling back to Python filter "
                "for show {}".format(tvshowid))
            params_nf = {
                "tvshowid":   tvshowid,
                "properties": ["title", "season", "episode", "file",
                               "thumbnail", "plot", "runtime", "showtitle",
                               "playcount", "firstaired"],
                "sort": {"order": "ascending", "method": "episode"},
            }
            result_nf  = self._rpc("VideoLibrary.GetEpisodes", params_nf)
            all_eps    = result_nf.get("episodes", [])
            all_eps    = [e for e in all_eps if e.get("file")]
            episodes   = self._filter_items_in_python(all_eps, filters)
            log("[LibraryClient] get_episodes_with_filters: Python filter "
                "kept {} of {} episodes".format(len(episodes), len(all_eps)))

        return episodes

    def get_mpaa_ratings(self, media_type="movie"):
        """Return unique MPAA ratings present in the library."""
        cache_key = "mpaa_{}".format(media_type)
        def _fetch():
            if media_type == "movie":
                movies = self.get_all_movies()
                ratings = sorted(set(
                    m.get("mpaa", "") for m in movies
                    if m.get("mpaa", "").strip()))
            else:
                ratings = []
            return ratings
        return self._cached(cache_key, _fetch)

    def get_studios(self, media_type="movie"):
        """Return unique studios present in the library."""
        cache_key = "studios_{}".format(media_type)
        def _fetch():
            if media_type == "movie":
                items = self.get_all_movies()
            else:
                items = self.get_all_tvshows()
            studios = set()
            for item in items:
                for s in item.get("studio", []):
                    if s.strip():
                        studios.add(s.strip())
            return sorted(studios)
        return self._cached(cache_key, _fetch)

    # -- Genres (for filter selection) -----------------------------------------

    def get_all_genres(self, media_type: str = "tvshow") -> list[str]:
        """
        Return a sorted deduplicated list of genres for the given media type.
        media_type: "tvshow" or "movie"
        """
        cache_key = "genres_{}".format(media_type)

        def _fetch():
            result = self._rpc("VideoLibrary.GetGenres", {
                "type": media_type,
            })
            genres = [g["label"] for g in result.get("genres", [])]
            return sorted(set(genres))

        return self._cached(cache_key, _fetch)

    # -- Recently added (for new-episode detection) ----------------------------

    def get_recently_added_episodes(self, limit: int = 25) -> list[dict]:
        """Return the most recently added episodes - used to detect new content."""
        result = self._rpc("VideoLibrary.GetRecentlyAddedEpisodes", {
            "properties": ["title", "season", "episode", "file",
                            "thumbnail", "showtitle", "tvshowid"],
            "limits": {"end": limit},
        })
        return result.get("episodes", [])

    # -- Invalidate cache for a specific show (call after library scan) --------

    def invalidate_show(self, tvshowid: int) -> None:
        """Remove cached episode list for a show so it will be re-fetched."""
        key = "episodes_{}".format(tvshowid)
        self._cache.pop(key, None)
        self._cache.pop("all_tvshows", None)
        log("[LibraryClient] Invalidated cache for show {}".format(tvshowid))

    # -- Database version auto-detection ---------------------------------------

    @staticmethod
    def get_actual_db_name() -> str:
        """
        Ask Kodi which video database it is actually using right now.
        Returns the real database name e.g. "MyVideos131".
        Falls back to "MyVideos131" if detection fails.
        """
        result = LibraryClient._rpc("JSONRPC.Version", {})
        # We can also probe via Application.GetProperties
        # but the most reliable way is to check what Kodi reports
        # via its own introspection. If JSON-RPC is working at all,
        # our VideoLibrary calls will work too since they use the
        # same internal database connection Kodi already has open.
        # This method is provided for diagnostic/logging purposes.
        version = result.get("version", {})
        log("[LibraryClient] Kodi JSON-RPC version: {}".format(version))

        # The actual DB name is not exposed via JSON-RPC directly,
        # but we can detect it by checking xbmc.getInfoLabel
        db_name = xbmc.getInfoLabel("System.BuildVersion")
        log("[LibraryClient] Kodi build version: {}".format(db_name))

        # Return the known correct name for Kodi 21
        return "MyVideos131"

    def reset_watched_episode(self, episodeid: int) -> bool:
        """
        Reset the watched status of a TV episode to unwatched (playcount=0).
        Called by service.py after an episode completes naturally, when the
        'reset_watched' setting is enabled.
        Returns True on success, False on failure.
        """
        try:
            result = LibraryClient._rpc(
                "VideoLibrary.SetEpisodeDetails",
                {"episodeid": episodeid, "playcount": 0})
            # _rpc returns data["result"] which for Set* calls is the
            # string "OK", not a dict — check accordingly.
            ok = (result == "OK")
            if ok:
                log("[LibraryClient] reset watched: episode {}".format(
                    episodeid))
            else:
                log("[LibraryClient] reset watched failed for episode {}: "
                    "{}".format(episodeid, result), xbmc.LOGWARNING)
            return ok
        except Exception as e:
            log("[LibraryClient] reset_watched_episode error: {}".format(e),
                xbmc.LOGWARNING)
            return False

    def reset_watched_movie(self, movieid: int) -> bool:
        """
        Reset the watched status of a movie to unwatched (playcount=0).
        Called by service.py after a movie completes naturally, when the
        'reset_watched' setting is enabled.
        Returns True on success, False on failure.
        """
        try:
            result = LibraryClient._rpc(
                "VideoLibrary.SetMovieDetails",
                {"movieid": movieid, "playcount": 0})
            ok = (result == "OK")
            if ok:
                log("[LibraryClient] reset watched: movie {}".format(movieid))
            else:
                log("[LibraryClient] reset watched failed for movie {}: "
                    "{}".format(movieid, result), xbmc.LOGWARNING)
            return ok
        except Exception as e:
            log("[LibraryClient] reset_watched_movie error: {}".format(e),
                xbmc.LOGWARNING)
            return False

