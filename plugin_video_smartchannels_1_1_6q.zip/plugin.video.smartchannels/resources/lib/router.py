"""
resources/lib/router.py
========================
Dispatches URL actions to controllers.
The main_menu is gone - Open goes straight to the channel list.
Settings/Configure opens settings.xml via Kodi's built-in mechanism.
Channel management (create/edit/delete/interleave) is triggered via
context menus within the channel list, not a separate menu screen.

OWNS:   Parsing the Kodi addon URL and dispatching to the correct handler.
        UI list building (xbmcplugin calls) for the channel list.
        Calling channel_manager.py, player.py, and ui/channels.py.

NEVER:  Direct state.json reads/writes — always go through channel_manager.py.
        Direct queue file access.
        JSON-RPC calls (use library.py via channel_manager.py).
        Playback event handling (all in service.py).
        Hardcoded user-visible strings — all text via self._s().
"""

from __future__ import annotations

from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.channel_manager import ChannelManager
from resources.lib.player           import SmartPlayer
from resources.lib.ui.channels      import ChannelUI
from resources.lib.ui.auto_channels import AutoChannelUI
from resources.lib.utils.logger     import log
from resources.lib.utils.paths      import shared_root as _shared_root_fn


class Router:

    def __init__(self, handle: int, base_url: str, addon: xbmcaddon.Addon):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon
        self.manager  = ChannelManager(addon)
        self.ui       = ChannelUI(handle, base_url, addon, self.manager)

    def _s(self, id_: int) -> str:
        """Return localised string from strings.po. Never hardcode text."""
        return self.addon.getLocalizedString(id_)

    def _finish(self, succeeded: bool = True) -> None:
        xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded)

    def _get_shared_root(self):
        """Delegate to utils/paths.py — single source of truth."""
        return _shared_root_fn()

    # -- Viewer ----------------------------------------------------------------

    def list_channels(self, params: dict) -> None:
        """
        Default view when the addon is opened.
        When 'use_side_panel' is True, opens the custom WindowXML browser
        instead of the standard Kodi directory listing.
        Falls back to the standard listing when setting is False or on error.
        """
        log("[router] list_channels")

        use_panel = (xbmcaddon.Addon().getSetting(
            "use_side_panel") == "true")

        if use_panel:
            log("[router] list_channels: opening side panel")
            try:
                from resources.lib.ui.side_panel import open_side_panel
                # Signal Kodi we are not building a directory listing
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
                open_side_panel(self.addon, self.manager)
                return
            except Exception as e:
                log("[router] side panel error, falling back to list: "
                    "{}".format(e))
                # Fall through to standard listing below

        xbmcplugin.setPluginCategory(self.handle, self._s(32289))
        xbmcplugin.setContent(self.handle, "files")
        self.ui.list_channels(params)
        self._finish()

    def play_from_item(self, params: dict) -> None:
        """
        Reorder the channel queue so the selected item is at position 0,
        then start playback. Called from the side panel when the user
        selects a specific upcoming item rather than 'Play Channel'.

        queue_index is the 0-based position of the selected item in the
        queue file (not the panel list, which has the Play button at [0]).

        State advancement for bypassed items is handled by service.py's
        existing skip detection — no special handling needed here.
        """
        channel_id  = params.get("channel_id")
        queue_index = params.get("queue_index")
        log("[router] play_from_item channel={} index={}".format(
            channel_id, queue_index))

        if not channel_id or queue_index is None:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        try:
            queue_index = int(queue_index)
        except (ValueError, TypeError):
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        channel = self.manager.get_channel(channel_id)
        if not channel:
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32211),
                xbmcgui.NOTIFICATION_WARNING, 2000)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if queue_index > 0:
            ok = self.manager.reorder_queue_from_item(channel_id, queue_index)
            if not ok:
                log("[router] play_from_item: reorder failed, "
                    "playing from front instead")

        # Resolve the plugin handle before handing off to the player
        dummy = xbmcgui.ListItem(label=self._s(32289))
        dummy.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(self.handle, succeeded=False, listitem=dummy)

        player = SmartPlayer(self.addon, self.manager)
        result = player.start_channel(channel)

        if result is False:
            channel_name = channel.get("name", "")
            confirmed = xbmcgui.Dialog().yesno(
                self._s(32289),
                self._s(32290).format(channel_name))
            if confirmed:
                self.manager.delete_channel(channel["id"])
                xbmcgui.Dialog().notification(
                    self._s(32289),
                    self._s(32291).format(channel_name),
                    xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin("Container.Refresh")

    def open_channels(self, params: dict) -> None:
        """
        Open the addon channel browser from Settings.
        RunPlugin() fires the plugin but results render nowhere visible
        when called from a Settings context. ActivateWindow(Videos,url)
        opens the Videos window AND navigates into the plugin URL so
        the channel list (or side panel) is visible to the user.
        Dialog.Close(all,true) dismisses Settings first.
        """
        log("[router] open_channels")
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.sleep(300)
        xbmc.executebuiltin(
            "ActivateWindow(Videos,"
            "plugin://plugin.video.smartchannels/,return)")

    def open_channel(self, params: dict) -> None:
        """Show contents of a single channel - next episode per show + Play entry."""
        channel_id = params.get("channel_id")
        log(f"[router] open_channel id={channel_id}")
        if not channel_id:
            self._finish(False)
            return
        self.ui.open_channel(params)
        self._finish()

    def play_channel(self, params: dict) -> None:
        """Build queue and start playback."""
        channel_id = params.get("channel_id")
        log("[router] play_channel id={}".format(channel_id))
        channel = self.manager.get_channel(channel_id) if channel_id else None
        if not channel:
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32211),
                xbmcgui.NOTIFICATION_WARNING, 2000)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        # CRITICAL: Resolve the Kodi plugin handle BEFORE starting playback.
        # If we do not call endOfDirectory or setResolvedUrl, Kodi keeps
        # spinning waiting for the plugin to respond, freezing the UI.
        # We use setResolvedUrl with a dummy item to signal we are done
        # with the directory call, then hand off to the player.
        dummy = xbmcgui.ListItem(label=self._s(32289))
        dummy.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(self.handle, succeeded=False, listitem=dummy)

        player = SmartPlayer(self.addon, self.manager)
        result = player.start_channel(channel)

        # start_channel returns False when the queue is empty (channel
        # exhausted or no content).  Offer to delete it.
        if result is False:
            channel_name = channel.get("name", "")
            confirmed = xbmcgui.Dialog().yesno(
                self._s(32289),
                self._s(32290).format(channel_name))
            if confirmed:
                self.manager.delete_channel(channel["id"])
                xbmcgui.Dialog().notification(
                    self._s(32289),
                    self._s(32291).format(channel_name),
                    xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin("Container.Refresh")

    # -- Channel management ----------------------------------------------------

    def create_channel(self, params: dict) -> None:
        log("[router] create_channel")
        # Resolve the plugin handle immediately so Kodi doesn't treat
        # this as a directory listing that never completed. The wizard
        # uses xbmcgui.Dialog() calls only — no handle needed after this.
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        self.ui.create_channel_wizard(params)

    def auto_create_channels(self, params: dict) -> None:
        log("[router] auto_create_channels")
        # Same as create_channel — resolve handle first, then run wizard.
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        AutoChannelUI(
            self.handle, self.base_url, self.addon, self.manager).run()

    def edit_channel(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] edit_channel id={channel_id}")
        if channel_id:
            self.ui.edit_channel_wizard(params)

    def delete_channel(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] delete_channel id={channel_id}")
        if not channel_id:
            return
        confirmed = xbmcgui.Dialog().yesno(
            self._s(32289), self._s(32216))
        if confirmed:
            self.manager.delete_channel(channel_id)
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32210),
                xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin("Container.Refresh")

    def channel_info(self, params: dict) -> None:
        log("[router] channel_info id={}".format(params.get("channel_id")))
        self.ui.channel_info(params)

    def set_channel_icon(self, params: dict) -> None:
        """
        Let the user assign or clear a custom icon for a channel.

        Options presented:
          0 — Choose image file  (opens Kodi's browse dialog)
          1 — Clear icon         (removes manual assignment, reverts to
                                  auto-match or built-in fallback)

        Writes icon_path to channels.json via update_channel().
        Fires Container.Refresh so the channel list repaints immediately.
        """
        channel_id = params.get("channel_id")
        if not channel_id:
            return
        ch = self.manager.get_channel(channel_id)
        if not ch:
            return

        log("[router] set_channel_icon id={}".format(channel_id))

        options = [
            self._s(32665),   # "Set Channel Icon"  (browse for file)
            self._s(32666),   # "Clear Icon"
        ]
        choice = xbmcgui.Dialog().select(ch.get("name", ""), options)
        if choice < 0:
            return

        if choice == 0:
            # Browse for an image file — type 1 = file, shares = False,
            # heading from strings.po, mask restricts to image types.
            # Dialog().browse(type, heading, shares, mask, ...)
            #   type 1 = file browser (not folder)
            path = xbmcgui.Dialog().browse(
                1,
                self._s(32665),
                "files",
                ".png|.jpg|.jpeg",
                False,
                False,
                ch.get("icon_path", ""))
            if not path or path == ch.get("icon_path", ""):
                return
            self.manager.update_channel(channel_id, {"icon_path": path})

        elif choice == 1:
            self.manager.update_channel(channel_id, {"icon_path": ""})

        xbmc.executebuiltin("Container.Refresh")

    def view_exclusions(self, params: dict) -> None:
        log("[router] view_exclusions id={}".format(params.get("channel_id")))
        self.ui.view_exclusions(params)

    def toggle_channel_visibility(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] toggle_visibility id={channel_id}")
        if channel_id:
            self.manager.toggle_visibility(channel_id)
            xbmc.executebuiltin("Container.Refresh")

    def manage_interleave(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] manage_interleave id={channel_id}")
        if channel_id:
            self.ui.manage_interleave_dialog(params)

    # -- Misc ------------------------------------------------------------------

    def reset_channel(self, params: dict) -> None:
        """
        Reset ALL shows (and movie rotation) in a channel back to the
        very beginning. Every state key for the channel is wiped and the
        queue is rebuilt from scratch.
        """
        channel_id = params.get("channel_id")
        log("[router] reset_channel id={}".format(channel_id))
        channel = self.manager.get_channel(channel_id) if channel_id else None
        if not channel:
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32211),
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        confirmed = xbmcgui.Dialog().yesno(
            self._s(32331),
            self._s(32332).format(channel["name"]))
        if not confirmed:
            return

        self.manager.reset_channel(channel_id)
        xbmcgui.Dialog().notification(
            self._s(32289),
            self._s(32333).format(channel["name"]),
            xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")

    def reset_next_episode(self, params: dict) -> None:
        """
        Reset one show's playback pointer back to S01E01 within a channel.
        All other shows in the channel are unaffected.
        Movies interleaved into the channel are unaffected.
        """
        channel_id = params.get("channel_id")
        show_id    = params.get("show_id")
        log("[router] reset_next_episode channel={} show={}".format(
            channel_id, show_id))

        if not channel_id or not show_id:
            return

        try:
            show_id = int(show_id)
        except (ValueError, TypeError):
            return

        channel = self.manager.get_channel(channel_id)
        if not channel:
            return

        # Get show title from URL param (passed by channels.py when building
        # the context menu). Falls back to channel config lookup if absent
        # (e.g. called from an older queue file without the param).
        show_title = params.get("show_title", "")
        if not show_title:
            for s in channel.get("shows", []):
                if s.get("tvshowid") == show_id:
                    show_title = s.get("title", "")
                    break

        confirmed = xbmcgui.Dialog().yesno(
            self._s(32334),
            self._s(32335).format(show_title))
        if not confirmed:
            return

        show_entry = next(
            (s for s in channel.get("shows", [])
             if s.get("tvshowid") == show_id), {"tvshowid": show_id})
        episodes = self.manager.get_available_episodes(show_entry)
        if not episodes:
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32212),
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        ok = self.manager.reset_show_to_start(channel_id, show_id)
        if not ok:
            xbmcgui.Dialog().notification(
                self._s(32289), self._s(32212),
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        xbmcgui.Dialog().notification(
            self._s(32289),
            self._s(32336).format(show_title),
            xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")

    def refresh_library(self, params):
        log("[router] refresh_library - rebuilding local cache")

        progress = xbmcgui.DialogProgress()
        progress.create(self._s(32289), self._s(32337))
        progress.update(0, self._s(32338))

        cancelled = [False]

        def _on_progress(pct, msg):
            if progress.iscanceled():
                cancelled[0] = True
                return
            progress.update(pct, msg)

        try:
            success = self.manager.library.build_local_cache(
                progress_callback=_on_progress)
            progress.close()

            if cancelled[0]:
                xbmcgui.Dialog().notification(
                    self._s(32289), self._s(32339),
                    xbmcgui.NOTIFICATION_WARNING, 2000)
            elif success:
                self.manager.library.clear_cache()
                xbmcgui.Dialog().notification(
                    self._s(32289), self._s(32340),
                    xbmcgui.NOTIFICATION_INFO, 2000)
            else:
                xbmcgui.Dialog().notification(
                    self._s(32289), self._s(32341),
                    xbmcgui.NOTIFICATION_ERROR, 3000)
        except Exception as e:
            progress.close()
            log("[router] refresh_library error: {}".format(e))
            xbmcgui.Dialog().notification(
                self._s(32289),
                self._s(32342).format(str(e)[:50]),
                xbmcgui.NOTIFICATION_ERROR, 3000)

        xbmc.executebuiltin("Container.Refresh")

    def _get_backup_path(self):
        """
        Return configured backup folder path. Empty string if not set.
        Creates a fresh Addon() instance on every read to avoid stale
        settings cache from the instance created at Router init time.
        Retries up to 3 times with short sleeps to handle the async
        flush delay that occurs immediately after the settings dialog closes.
        """
        for attempt in range(3):
            try:
                raw = xbmcaddon.Addon().getSetting("backup_path").strip()
                log("[router] _get_backup_path attempt {}: raw={}".format(
                    attempt + 1, repr(raw)))
                if raw:
                    if raw.startswith("\\\\") or raw.startswith("//"):
                        raw = "smb://" + raw.lstrip("\\//").replace("\\", "/")
                    raw = raw.rstrip("/").rstrip("\\")
                    log("[router] _get_backup_path: result={}".format(
                        repr(raw)))
                    return raw
                if attempt < 2:
                    xbmc.sleep(750)
            except Exception as e:
                log("[router] _get_backup_path error: {}".format(e),
                    xbmc.LOGWARNING)
                break
        return ""

    def backup_data(self, params):
        import xbmcvfs, os, datetime, zipfile
        backup_root = self._get_backup_path()
        if not backup_root:
            # Offer to open settings so the user can enter a path
            # without having to exit and re-enter the addon
            open_now = xbmcgui.Dialog().yesno(
                self._s(32343), self._s(32344))
            if open_now:
                xbmcaddon.Addon().openSettings()
                backup_root = self._get_backup_path()
            if not backup_root:
                return
        profile = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        shared  = self._get_shared_root()

        file_specs = []
        data_files = [
            "channels.json", "state.json",
            "local_library.json", "now_playing.json",
        ]
        # Add queue files from both locations
        for root in set(p for p in [profile, shared] if p):
            try:
                _, files = xbmcvfs.listdir(root)
                for fn in files:
                    if fn.startswith("queue_") and fn.endswith(".json"):
                        data_files.append(fn)
            except Exception:
                pass
        data_files = list(dict.fromkeys(data_files))  # deduplicate, preserve order

        for fn in data_files:
            # Prefer shared path if configured, fall back to profile
            if shared:
                src_path = shared + "/" + fn
                if not xbmcvfs.exists(src_path):
                    src_path = os.path.join(profile, fn)
            else:
                src_path = os.path.join(profile, fn)
            file_specs.append((fn, src_path))

        file_data = {}
        for arc_name, src_path in file_specs:
            try:
                if xbmcvfs.exists(src_path):
                    with xbmcvfs.File(src_path, "r") as _f:
                        raw = _f.read()
                    if raw:
                        file_data[arc_name] = (
                            raw.encode("utf-8") if isinstance(raw, str) else raw)
                    else:
                        log("[router] backup_data: {} empty, skipping".format(
                            arc_name))
                else:
                    log("[router] backup_data: {} not found".format(src_path))
            except Exception as e:
                log("[router] backup_data: read error {}: {}".format(
                    arc_name, e), xbmc.LOGWARNING)

        if not file_data:
            xbmcgui.Dialog().ok(self._s(32345), self._s(32346))
            return

        ts       = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_name = "SmartChannels_Backup_" + ts + ".zip"
        tmp_zip  = os.path.join(
            xbmcvfs.translatePath("special://temp/"), zip_name)
        zip_path = backup_root + "/" + zip_name
        try:
            with zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
                for arc_name, data in file_data.items():
                    zf.writestr(arc_name, data)
            ok = xbmcvfs.copy(tmp_zip, zip_path)
            try:
                os.remove(tmp_zip)
            except Exception:
                pass
            if ok:
                log("[router] backup_data: wrote {} ({} files)".format(
                    zip_path, len(file_data)))
                xbmcgui.Dialog().ok(
                    self._s(32347),
                    self._s(32348).format(len(file_data), zip_name))
            else:
                xbmcgui.Dialog().ok(
                    self._s(32345),
                    self._s(32349).format(zip_path))
        except Exception as e:
            log("[router] backup_data: error: {}".format(e), xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                self._s(32345),
                self._s(32342).format(str(e)[:100]))

    def restore_data(self, params):
        import xbmcvfs, os, zipfile
        backup_root = self._get_backup_path()
        if not backup_root:
            open_now = xbmcgui.Dialog().yesno(
                self._s(32350), self._s(32344))
            if open_now:
                xbmcaddon.Addon().openSettings()
                backup_root = self._get_backup_path()
            if not backup_root:
                return
        try:
            _, dir_files = xbmcvfs.listdir(backup_root)
            zips = sorted(
                [f for f in dir_files
                 if f.startswith("SmartChannels_Backup_")
                 and f.endswith(".zip")],
                reverse=True)
        except Exception as e:
            xbmcgui.Dialog().ok(
                self._s(32351),
                self._s(32352).format(str(e)))
            return
        if not zips:
            xbmcgui.Dialog().ok(
                self._s(32350),
                self._s(32353).format(backup_root))
            return
        chosen_idx = xbmcgui.Dialog().select(self._s(32354), zips)
        if chosen_idx < 0:
            return
        zip_name = zips[chosen_idx]
        zip_path = backup_root + "/" + zip_name
        profile  = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        tmp_zip  = os.path.join(
            xbmcvfs.translatePath("special://temp/"), "_sc_restore_tmp.zip")
        try:
            if os.path.exists(tmp_zip):
                os.remove(tmp_zip)
            ok = xbmcvfs.copy(zip_path, tmp_zip)
            if not ok:
                xbmcgui.Dialog().ok(self._s(32351), self._s(32355))
                return
            zf        = zipfile.ZipFile(tmp_zip, "r")
            available = zf.namelist()
        except Exception as e:
            xbmcgui.Dialog().ok(
                self._s(32351),
                self._s(32342).format(str(e)[:100]))
            return
        if not available:
            xbmcgui.Dialog().ok(self._s(32351), self._s(32356))
            zf.close()
            return
        chosen = xbmcgui.Dialog().multiselect(
            self._s(32357),
            available,
            preselect=list(range(len(available))))
        if not chosen:
            zf.close()
            return
        files_to_restore = [available[i] for i in chosen]
        confirmed = xbmcgui.Dialog().yesno(
            self._s(32358),
            self._s(32359).format(len(files_to_restore)))
        if not confirmed:
            zf.close()
            return
        shared    = self._get_shared_root()
        data_root = (shared + "/") if shared else (profile.rstrip("/") + "/")
        needs_restart = False
        restored      = []
        failed        = []
        for fn in files_to_restore:
            dst = (profile.rstrip("/") + "/" + fn
                   if fn == "settings.xml" else data_root + fn)
            if fn == "settings.xml":
                needs_restart = True
            try:
                tmp_file = os.path.join(
                    xbmcvfs.translatePath("special://temp/"),
                    "_sc_restore_" + fn.replace("/", "_"))
                with xbmcvfs.File(tmp_file, "w") as out:
                    out.write(zf.read(fn).decode("latin-1"))
                if xbmcvfs.exists(dst):
                    xbmcvfs.delete(dst)
                ok = xbmcvfs.copy(tmp_file, dst)
                try:
                    os.remove(tmp_file)
                except Exception:
                    pass
                if ok:
                    restored.append(fn)
                    log("[router] restore_data: restored {}".format(fn))
                else:
                    failed.append(fn)
                    log("[router] restore_data: copy failed for {}".format(fn),
                        xbmc.LOGWARNING)
            except Exception as e:
                failed.append(fn)
                log("[router] restore_data: error {}: {}".format(fn, e),
                    xbmc.LOGWARNING)
        zf.close()
        try:
            os.remove(tmp_zip)
        except Exception:
            pass
        parts = []
        if restored:
            parts.append(self._s(32360).format(", ".join(restored)))
        if failed:
            parts.append(self._s(32361).format(", ".join(failed)))
        if needs_restart and "settings.xml" in restored:
            parts.append(self._s(32362))
        xbmcgui.Dialog().ok(self._s(32363), "\n".join(parts))
        if restored:
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")

    def delete_all_data(self, params):
        """
        Delete all addon data from both the local profile folder and
        the configured shared storage folder (if any).
        Prompts the user to confirm before deleting.
        """
        import xbmcvfs, os
        confirmed = xbmcgui.Dialog().yesno(
            self._s(32364), self._s(32365))
        if not confirmed:
            return

        data_files = [
            "channels.json", "state.json", "local_library.json",
            "now_playing.json",
        ]

        def _delete_from(folder, is_network):
            deleted = 0
            for fn in data_files:
                p = (folder + "/" + fn if is_network
                     else os.path.join(folder, fn))
                try:
                    if xbmcvfs.exists(p):
                        xbmcvfs.delete(p)
                        deleted += 1
                except Exception as e:
                    log("[router] delete_all_data: cannot delete {}: {}".format(
                        p, e))
            try:
                _, files = xbmcvfs.listdir(folder)
                for fn in files:
                    if fn.startswith("queue_") and fn.endswith(".json"):
                        p = (folder + "/" + fn if is_network
                             else os.path.join(folder, fn))
                        try:
                            if xbmcvfs.exists(p):
                                xbmcvfs.delete(p)
                                deleted += 1
                        except Exception:
                            pass
            except Exception:
                pass
            return deleted

        profile = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        total   = _delete_from(profile, False)

        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw in ("", "smb://", "smb:/"):
                raw = ""
            if raw and (raw.startswith("\\\\") or raw.startswith("//")):
                raw = "smb://" + raw.lstrip("\\/").replace("\\", "/")
            shared = raw.rstrip("/").rstrip("\\") if raw else ""
        except Exception:
            shared = ""

        if shared:
            is_net = "://" in shared
            total += _delete_from(shared, is_net)

        xbmcgui.Dialog().notification(
            self._s(32289),
            self._s(32366).format(total),
            xbmcgui.NOTIFICATION_INFO, 3000)
        log("[router] delete_all_data: deleted {} files".format(total))
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.Refresh")

    def clear_shared_path(self, params):
        """
        Clear the shared storage path and return to using Kodi's
        local addon data folder.  Offers to migrate files back.
        """
        import xbmcvfs, os
        log("[router] clear_shared_path")

        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw not in ("", "smb://", "smb:/"):
                if raw.startswith("\\\\") or raw.startswith("//"):
                    raw = raw.lstrip("\\/")
                    raw = "smb://" + raw.replace("\\", "/")
                shared = raw.rstrip("/").rstrip("\\")
            else:
                shared = ""
        except Exception:
            shared = ""

        self.addon.setSetting("shared_storage_path", "")
        log("[router] shared_storage_path cleared")

        if shared:
            profile = xbmcvfs.translatePath(
                self.addon.getAddonInfo("profile"))
            migrate_back = xbmcgui.Dialog().yesno(
                self._s(32289),
                self._s(32367).format(shared))
            if migrate_back:
                data_files = [
                    "channels.json", "state.json",
                    "local_library.json", "now_playing.json",
                ]
                def _path_join(root, fn):
                    if "://" in root:
                        return root + "/" + fn
                    return os.path.join(root, fn)
                try:
                    _, files = xbmcvfs.listdir(shared)
                    for fn in files:
                        if fn.startswith("queue_") and fn.endswith(".json"):
                            data_files.append(fn)
                except Exception:
                    pass
                migrated = []
                for fn in data_files:
                    src = _path_join(shared, fn)
                    dst = os.path.join(profile, fn)
                    if xbmcvfs.exists(src):
                        try:
                            xbmcvfs.copy(src, dst)
                            migrated.append(fn)
                        except Exception as e:
                            log("[router] migrate back {} failed: {}".format(
                                fn, e))
                if migrated:
                    log("[router] migrated back to local: {}".format(migrated))

        xbmcgui.Dialog().notification(
            self._s(32289), self._s(32368),
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.Refresh")

    def open_settings(self, params):
        """Open the addon settings dialog, then migrate files if shared
        path changed, then refresh the container."""
        import xbmcvfs, os
        log("[router] open_settings")

        def _get_shared():
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw in ("smb://", "smb:/", ""):
                return ""
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = raw.lstrip("\\/")
                raw = "smb://" + raw.replace("\\", "/")
            return raw.rstrip("/").rstrip("\\")

        def _path_join(root, filename):
            if "://" in root:
                return root + "/" + filename
            return os.path.join(root, filename)

        shared_before = _get_shared()
        self.addon.openSettings()
        shared_after = _get_shared()

        if shared_after and shared_after != shared_before:
            profile  = xbmcvfs.translatePath(
                self.addon.getAddonInfo("profile"))
            src_root = shared_before if shared_before else profile

            migrate_files = [
                "channels.json", "state.json",
                "local_library.json", "now_playing.json",
            ]
            try:
                _, files = xbmcvfs.listdir(src_root)
                for fn in files:
                    if fn.startswith("queue_") and fn.endswith(".json"):
                        migrate_files.append(fn)
            except Exception:
                pass

            migrated = []
            for fn in migrate_files:
                src = _path_join(src_root, fn)
                dst = _path_join(shared_after, fn)
                if xbmcvfs.exists(src) and not xbmcvfs.exists(dst):
                    try:
                        xbmcvfs.copy(src, dst)
                        migrated.append(fn)
                        log("[router] migrated: {} -> {}".format(src, dst))
                    except Exception as e:
                        log("[router] migrate {} failed: {}".format(fn, e))

            if migrated:
                xbmcgui.Dialog().notification(
                    self._s(32289),
                    self._s(32369).format(len(migrated)),
                    xbmcgui.NOTIFICATION_INFO, 3000)
                log("[router] Migrated to shared: {}".format(migrated))

                if shared_before:
                    clean = xbmcgui.Dialog().yesno(
                        self._s(32289),
                        self._s(32370).format(shared_before))
                    if clean:
                        for fn in migrated:
                            old_file = _path_join(shared_before, fn)
                            try:
                                if xbmcvfs.exists(old_file):
                                    xbmcvfs.delete(old_file)
                                    log("[router] deleted old: {}".format(
                                        old_file))
                            except Exception as e:
                                log("[router] delete old {} failed: {}".format(
                                    old_file, e))
            else:
                log("[router] No files to migrate (src={})".format(src_root))

        xbmc.sleep(300)
        xbmc.executebuiltin("Container.Refresh")
