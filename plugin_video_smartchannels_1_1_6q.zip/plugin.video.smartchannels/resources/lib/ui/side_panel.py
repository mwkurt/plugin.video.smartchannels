"""
resources/lib/ui/side_panel.py
================================
Two-pane channel browser using a custom WindowXML window.

Left pane  (control 100) : Channel list.
Right pane (control 200) : Upcoming queue items for the highlighted channel.

OWNS:   Window lifecycle, focus/navigation state machine, populating both
        panes, context menu, dispatching playback via router URL actions.

NEVER:  Direct state.json or queue file writes — all queue mutations go
        through channel_manager.reorder_queue_from_item().
        Playback event handling (service.py owns that).
        Hardcoded user-visible strings — all text via self._s().

Navigation contract:
  Up/Down in left pane   → moves channel selection, updates right pane.
  Right from left pane   → focus moves to right pane (control 200).
  Left from right pane   → focus returns to left pane (control 100).
  Enter on left pane     → plays channel from queue front.
  Enter on right pane[0] → plays channel from queue front.
  Enter on right pane[N] → reorders queue so item N is first, then plays.
  C / Menu key           → context menu for focused channel (left pane only).
  Back / Escape          → closes window, returns to Kodi Home.

Fixes in 1.1.6b:
  - ActivateWindow(Home) before open/play eliminates Videos screen flash.
  - After playback stops, Kodi returns to Home not Videos hub.
  - Context menu (action 117) shows full channel options in left pane.
  - Settings action "Open Smart Channels" re-launches the addon.

XML window ID: 9700  (unused by Kodi itself and all standard skins).
"""

from __future__ import annotations

import json
import os
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.utils.logger import log

# ---------------------------------------------------------------------------
# Kodi action IDs
# ---------------------------------------------------------------------------
ACTION_MOVE_LEFT        = 1
ACTION_MOVE_RIGHT       = 2
ACTION_MOVE_UP          = 3
ACTION_MOVE_DOWN        = 4
ACTION_SELECT_ITEM      = 7
ACTION_PREVIOUS_MENU    = 10    # Escape key
ACTION_CONTEXT_MENU     = 117   # C key / Menu button / long-press
ACTION_NAV_BACK         = 92    # Back button / Backspace

# ---------------------------------------------------------------------------
# Control IDs — must match SmartChannels_Main.xml exactly
# ---------------------------------------------------------------------------
CTRL_CHANNEL_LIST  = 100
CTRL_UPCOMING_LIST = 200
CTRL_UPCOMING_HDR  = 300
CTRL_RIGHT_GROUP   = 301

# ---------------------------------------------------------------------------
# String IDs
# ---------------------------------------------------------------------------
_S_PLAY_CHANNEL   = 32648   # "> Play"  (label2 = channel name at runtime)
_S_UPCOMING       = 32649   # "Upcoming"
_S_NO_ITEMS       = 32650   # "No items in queue"
_S_SEP_EP         = 32652   # "S{0}E{1} — {2}"
_S_MOVIE_YEAR     = 32653   # "{0} ({1})"

# Context menu string IDs — reuse existing strings from channels.py
_S_CTX_CHANNEL_INFO    = 32383
_S_CTX_PLAY            = 32204
_S_CTX_EDIT            = 32205
_S_CTX_RESET           = 32331
_S_CTX_DELETE          = 32206
_S_CTX_TOGGLE_VIS      = 32207
_S_CTX_INTERLEAVE      = 32208
_S_CTX_VIEW_EXCL       = 32578

# Reset confirmation strings (same as router.py uses)
_S_RESET_CONFIRM       = 32332   # "Reset {0}?"
_S_RESET_DONE          = 32333   # "{0} reset"
_S_ADDON_NAME          = 32289   # "Smart TV Channels"

# Plugin base URL
_PLUGIN_URL = "plugin://plugin.video.smartchannels/"


def _url(**kwargs):
    """Build a plugin:// URL for RunPlugin / RunAddon calls."""
    return "{}?{}".format(_PLUGIN_URL, urlencode(kwargs))


def _resolve_skin_xml(addon_path):
    """
    Return the path to SmartChannels_Main.xml for the active Kodi skin.

    Search order:
      1. resources/skins/<active_skin_id>/<res>/SmartChannels_Main.xml
      2. resources/skins/Default/1080i/SmartChannels_Main.xml  (fallback)

    <res> is 720p for Confluence, 1080i for everything else.
    """
    skin_id  = xbmc.getSkinDir()
    res      = "720p" if skin_id == "skin.confluence" else "1080i"
    specific = os.path.join(
        addon_path, "resources", "skins", skin_id, res,
        "SmartChannels_Main.xml")
    if xbmcvfs.exists(specific):
        log("[SidePanel] Using skin-specific XML: {}".format(specific))
        return specific

    fallback = os.path.join(
        addon_path, "resources", "skins", "Default", "1080i",
        "SmartChannels_Main.xml")
    log("[SidePanel] Using fallback XML: {}".format(fallback))
    return fallback


class SmartChannelsSidePanel(xbmcgui.WindowXML):
    """
    Two-pane channel browser.

    Instantiated and shown by open_side_panel() below.
    """

    def __new__(cls, xml_file, addon_path, addon, manager):
        return super().__new__(cls, xml_file, addon_path)

    def __init__(self, xml_file, addon_path, addon, manager):
        self._addon          = addon
        self._addon_path     = addon_path
        self._manager        = manager
        self._channels       = []    # visible channel dicts
        self._panel_data     = []    # items shown in right pane
        self._current_ch_idx = 0     # highlighted channel index
        self._panel_focused  = False # True when focus is in right pane

    # ── Kodi WindowXML lifecycle ───────────────────────────────────────────

    def onInit(self):
        """Called by Kodi when the window is ready to render."""
        log("[SidePanel] onInit")
        show_hidden = (self._addon.getSetting(
            "show_hidden_channels") == "true")
        self._channels = (self._manager.get_all_channels()
                          if show_hidden
                          else self._manager.get_visible_channels())
        self._populate_channel_list()
        if self._channels:
            self._populate_panel(self._channels[0])

    def onAction(self, action):
        """Handle navigation, back, and context menu."""
        action_id = action.getId()

        # Always sync _panel_focused from Kodi's actual focus state.
        # This corrects any de-sync from mouse clicks or skin focus
        # changes that don't fire onFocus reliably (issue 6).
        focused_ctrl = self.getFocusId()
        if focused_ctrl == CTRL_CHANNEL_LIST:
            self._panel_focused = False
        elif focused_ctrl == CTRL_UPCOMING_LIST:
            self._panel_focused = True

        # ── Back / Escape → close and go Home ─────────────────────────────
        if action_id in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            log("[SidePanel] Back/Escape — closing window")
            self.close()
            xbmc.executebuiltin("ActivateWindow(Home)")
            return

        # ── Context menu — left pane only ─────────────────────────────────
        if action_id == ACTION_CONTEXT_MENU and not self._panel_focused:
            self._show_context_menu()
            return

        # ── Right arrow: left pane → right pane ───────────────────────────
        if action_id == ACTION_MOVE_RIGHT and not self._panel_focused:
            if self._panel_data:
                self.setFocusId(CTRL_UPCOMING_LIST)
                self._panel_focused = True
            return

        # ── Left arrow: right pane → left pane ────────────────────────────
        if action_id == ACTION_MOVE_LEFT and self._panel_focused:
            self.setFocusId(CTRL_CHANNEL_LIST)
            self._panel_focused = False
            return

        # ── Up/Down in left pane — update right pane ──────────────────────
        if action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            if not self._panel_focused:
                xbmc.sleep(50)
                ctrl    = self.getControl(CTRL_CHANNEL_LIST)
                new_idx = ctrl.getSelectedPosition()
                if new_idx != self._current_ch_idx:
                    self._current_ch_idx = new_idx
                    if new_idx < len(self._channels):
                        self._populate_panel(self._channels[new_idx])

    def onFocus(self, control_id):
        """Track which pane is active."""
        if control_id == CTRL_CHANNEL_LIST:
            self._panel_focused = False
        elif control_id == CTRL_UPCOMING_LIST:
            self._panel_focused = True

    def onClick(self, control_id):
        """Handle Enter on either pane."""
        if control_id == CTRL_CHANNEL_LIST:
            ctrl = self.getControl(CTRL_CHANNEL_LIST)
            idx  = ctrl.getSelectedPosition()
            if idx < len(self._channels):
                ch = self._channels[idx]
                log("[SidePanel] onClick channel: playing '{}'".format(
                    ch.get("name")))
                self._play_channel(ch["id"])

        elif control_id == CTRL_UPCOMING_LIST:
            ctrl = self.getControl(CTRL_UPCOMING_LIST)
            idx  = ctrl.getSelectedPosition()
            if idx < 0 or idx >= len(self._panel_data):
                return

            item = self._panel_data[idx]

            if item.get("_is_play_button"):
                ch_idx = self._current_ch_idx
                if ch_idx < len(self._channels):
                    self._play_channel(self._channels[ch_idx]["id"])
            else:
                ch_idx = self._current_ch_idx
                if ch_idx < len(self._channels):
                    ch = self._channels[ch_idx]
                    log("[SidePanel] onClick upcoming[{}]: '{}' in '{}'".format(
                        idx, item.get("title", "?"), ch.get("name")))
                    # Use the raw queue file index stamped at populate time.
                    # This is correct even when silent items precede this
                    # item in the queue and shift panel vs raw positions apart.
                    raw_queue_index = item.get("_raw_queue_index", idx - 1)
                    self._play_from_item(ch["id"], item, raw_queue_index)

    # ── Context menu ──────────────────────────────────────────────────────

    def _show_context_menu(self):
        """
        Show a Dialog().select() with the same options as the standard
        channel list context menu.
        Only available when focus is in the left pane.

        Action handling strategy:
          play_channel       → _play_channel() directly (no RunPlugin)
          reset_channel      → manager.reset_channel() directly, then
                               refresh right pane immediately (synchronous,
                               no RunPlugin race condition)
          channel_info       → RunPlugin, keep panel open (shows a dialog,
                               no panel state change needed after)
          view_exclusions    → RunPlugin, keep panel open (same)
          delete_channel     → RunPlugin, relaunch addon after
          edit_channel       → RunPlugin, relaunch addon after
          manage_interleave  → RunPlugin, relaunch addon after
          toggle_visibility  → manager directly, refresh channel list
        """
        # Use getFocusId() as ground truth — corrects any _panel_focused
        # de-sync from mouse clicks or skin focus changes (issue 6).
        if self.getFocusId() != CTRL_CHANNEL_LIST:
            return

        ctrl = self.getControl(CTRL_CHANNEL_LIST)
        idx  = ctrl.getSelectedPosition()
        if idx < 0 or idx >= len(self._channels):
            return

        ch           = self._channels[idx]
        channel_id   = ch["id"]
        channel_type = ch.get("channel_type", "tv")

        options = [
            (self._s(_S_CTX_CHANNEL_INFO),  "channel_info"),
            (self._s(_S_CTX_PLAY),          "play_channel"),
            (self._s(_S_CTX_EDIT),          "edit_channel"),
            (self._s(_S_CTX_RESET),         "reset_channel"),
            (self._s(_S_CTX_DELETE),        "delete_channel"),
            (self._s(_S_CTX_TOGGLE_VIS),    "toggle_channel_visibility"),
            (self._s(32665),                "set_channel_icon"),
        ]
        if channel_type != "serial":
            options.append(
                (self._s(_S_CTX_INTERLEAVE), "manage_interleave"))
        if channel_type in ("tv", "serial", "movies"):
            options.append(
                (self._s(_S_CTX_VIEW_EXCL),  "view_exclusions"))

        labels = [o[0] for o in options]
        choice = xbmcgui.Dialog().select(ch.get("name", ""), labels)
        if choice < 0:
            return

        action_name = options[choice][1]
        log("[SidePanel] context menu: {}".format(action_name))

        # ── Play Channel ──────────────────────────────────────────────────
        if action_name == "play_channel":
            self._play_channel(channel_id)

        # ── Reset Channel — call manager directly, refresh right pane ────
        elif action_name == "reset_channel":
            confirmed = xbmcgui.Dialog().yesno(
                self._s(_S_CTX_RESET),
                self._s(32332).format(ch["name"]))
            if confirmed:
                self._manager.reset_channel(channel_id)
                xbmcgui.Dialog().notification(
                    self._s(_S_ADDON_NAME),
                    self._s(32333).format(ch["name"]),
                    xbmcgui.NOTIFICATION_INFO, 2000)
                # Queue is now rebuilt on disk — refresh right pane
                # immediately without closing the panel. No sleep needed
                # because reset_channel() is synchronous.
                self._refresh_panel(idx)

        # ── Toggle Visibility — call manager directly, refresh list ───────
        elif action_name == "toggle_channel_visibility":
            self._manager.toggle_visibility(channel_id)
            self._refresh_after_list_change(idx)

        # ── Channel Info / View Exclusions — RunPlugin, keep panel open ───
        elif action_name in ("channel_info", "view_exclusions",
                             "set_channel_icon"):
            plugin_url = _url(action=action_name, channel_id=channel_id)
            xbmc.executebuiltin("RunPlugin({})".format(plugin_url))
            # set_channel_icon updates channels.json — refresh icon in list
            if action_name == "set_channel_icon":
                self._manager.reload_channels()
                show_hidden = (self._addon.getSetting(
                    "show_hidden_channels") == "true")
                self._channels = (self._manager.get_all_channels()
                                  if show_hidden
                                  else self._manager.get_visible_channels())
                self._populate_channel_list()

        # ── Edit Channel / Manage Interleave — fire RunPlugin without
        # closing the panel. Wizard dialogs stack on top of the panel
        # (they use xbmcgui.Dialog(), not doModal()) and the panel
        # stays open underneath. After the wizard completes or is
        # ── Edit / Manage Interleave — call wizard directly on this thread
        # so changes are visible immediately without re-entering the addon.
        # RunPlugin is non-blocking; the wizard would complete in a separate
        # invoker and this manager instance would never see the disk changes.
        elif action_name in ("edit_channel", "manage_interleave"):
            from resources.lib.ui.channels import ChannelUI
            _ui = ChannelUI(
                handle=-1,
                base_url="plugin://plugin.video.smartchannels/",
                addon=self._addon,
                manager=self._manager)
            if action_name == "edit_channel":
                _ui.edit_channel_wizard({"channel_id": channel_id})
            else:
                _ui.manage_interleave_dialog({"channel_id": channel_id})
            # Wizard ran synchronously — reload disk state and repaint.
            self._manager.reload_channels()
            show_hidden = (self._addon.getSetting(
                "show_hidden_channels") == "true")
            self._channels = (self._manager.get_all_channels()
                              if show_hidden
                              else self._manager.get_visible_channels())
            self._populate_channel_list()
            safe_idx = min(idx, len(self._channels) - 1) \
                if self._channels else 0
            self._current_ch_idx = safe_idx
            if self._channels:
                self._populate_panel(self._channels[safe_idx])

        # ── Delete Channel — call manager directly so we can refresh
        # the channel list immediately without timing guesses.
        elif action_name == "delete_channel":
            confirmed = xbmcgui.Dialog().yesno(
                self._s(_S_ADDON_NAME),
                self._s(32216))
            if confirmed:
                self._manager.delete_channel(channel_id)
                xbmcgui.Dialog().notification(
                    self._s(_S_ADDON_NAME),
                    self._s(32210),
                    xbmcgui.NOTIFICATION_INFO, 2000)
                self._refresh_after_list_change(
                    max(0, idx - 1) if idx > 0 else 0)

        # ── Any other unhandled action — fire via RunPlugin ───────────────
        else:
            plugin_url = _url(action=action_name, channel_id=channel_id)
            xbmc.executebuiltin("RunPlugin({})".format(plugin_url))

    def _refresh_panel(self, ch_idx):
        """
        Refresh the right pane for the channel at ch_idx.
        Called after reset_channel — the queue is already rebuilt on disk.
        """
        if not self._channels or ch_idx >= len(self._channels):
            return
        self._current_ch_idx = ch_idx
        self._populate_panel(self._channels[ch_idx])

    def _refresh_after_list_change(self, prev_idx):
        """
        Refresh both panes after a visibility toggle.
        Handles the edge case where the channel list becomes empty (issue 5).
        """
        show_hidden = (self._addon.getSetting(
            "show_hidden_channels") == "true")
        self._channels = (self._manager.get_all_channels()
                          if show_hidden
                          else self._manager.get_visible_channels())
        self._populate_channel_list()

        if not self._channels:
            # List is empty — clear right pane
            self._current_ch_idx = 0
            self._panel_data     = []
            ctrl = self.getControl(CTRL_UPCOMING_LIST)
            ctrl.reset()
            hdr = self.getControl(CTRL_UPCOMING_HDR)
            hdr.setLabel(self._s(_S_UPCOMING))
            return

        safe_idx = min(prev_idx, len(self._channels) - 1)
        self._current_ch_idx = safe_idx
        self._populate_panel(self._channels[safe_idx])

    # ── Pane population ───────────────────────────────────────────────────

    def _populate_channel_list(self):
        """Fill the left pane with all visible (or all) channels."""
        ctrl = self.getControl(CTRL_CHANNEL_LIST)
        ctrl.reset()

        for ch in self._channels:
            # Prefix hidden channels with [H] when Show Hidden is on,
            # same as the standard channel list (issue 7).
            name = ch["name"]
            if not ch.get("visible", True):
                name = "[H] " + name

            li = xbmcgui.ListItem(label=name)
            li.setArt({"icon": self._manager.resolve_channel_icon(ch)})
            ctrl.addItem(li)

        log("[SidePanel] channel list: {} channels".format(
            len(self._channels)))

    def _populate_panel(self, channel):
        """Fill the right pane with upcoming items for the given channel."""
        ctrl     = self.getControl(CTRL_UPCOMING_LIST)
        hdr_ctrl = self.getControl(CTRL_UPCOMING_HDR)
        ctrl.reset()
        self._panel_data = []

        hdr_ctrl.setLabel(
            self._s(_S_UPCOMING) + "  —  " + channel.get("name", ""))

        # Load queue file
        q_path = self._manager._queue_file_path(channel["id"])
        queue  = []
        try:
            if xbmcvfs.exists(q_path):
                with xbmcvfs.File(q_path, "r") as f:
                    raw = f.read()
                if raw:
                    queue = json.loads(raw)
        except Exception as e:
            log("[SidePanel] _populate_panel read error: {}".format(e))

        # Number of items to show
        try:
            n = int(self._addon.getSetting("num_upcoming_programs") or "10")
            n = max(1, min(n, 30))
        except Exception:
            n = 10

        # ▶ Play Channel — always first
        _ch_icon = self._manager.resolve_channel_icon(channel)
        play_li = xbmcgui.ListItem(
            label=self._s(_S_PLAY_CHANNEL),
            label2=channel.get("name", ""))
        play_li.setArt({"icon": _ch_icon, "thumb": _ch_icon})
        ctrl.addItem(play_li)
        self._panel_data.append({"_is_play_button": True})

        if not queue:
            empty_li = xbmcgui.ListItem(
                label=self._s(_S_NO_ITEMS), label2="")
            ctrl.addItem(empty_li)
            self._panel_data.append({"_is_no_items": True})
            return

        ch_type  = channel.get("channel_type", "tv")
        visible  = 0

        # Build poster lookup from library cache — keyed by tvshowid/movieid.
        # Done once here (in-memory dict comprehension) so _format_queue_item
        # can resolve posters with a simple dict.get() — no RPC calls per item.
        try:
            _shows  = self._manager.library.get_all_tvshows()
            _movies = self._manager.library.get_all_movies()
            _show_poster  = {s["tvshowid"]: s.get("poster", "")
                             for s in _shows}
            _movie_poster = {m["movieid"]:  m.get("poster", "")
                             for m in _movies}
        except Exception:
            _show_poster  = {}
            _movie_poster = {}

        for raw_idx, item in enumerate(queue):
            if visible >= n:
                break
            # Silent interleave items are tagged _silent: True — they must
            # never appear in the upcoming list, same as Coming Up Next.
            if item.get("_silent"):
                continue
            label, label2, thumb = self._format_queue_item(
                item, ch_type, _show_poster, _movie_poster)
            li = xbmcgui.ListItem(label=label, label2=label2)
            if thumb:
                li.setArt({"thumb": thumb})
            ctrl.addItem(li)
            # Stamp the raw queue file index onto the item so onClick can
            # pass the correct position to reorder_queue_from_item regardless
            # of how many silent items were skipped before this one.
            item_copy = dict(item)
            item_copy["_raw_queue_index"] = raw_idx
            self._panel_data.append(item_copy)
            visible += 1

        log("[SidePanel] right pane: {} visible items for '{}'".format(
            visible, channel.get("name")))

    def _format_queue_item(self, item, ch_type,
                           show_poster=None, movie_poster=None):
        """Return (label, label2, thumb) for a single queue item.

        show_poster  — {tvshowid: poster_url} built once per _populate_panel
        movie_poster — {movieid:  poster_url} built once per _populate_panel
        Falls back to item thumbnail if no poster found in lookup.
        """
        show_poster  = show_poster  or {}
        movie_poster = movie_poster or {}

        is_movie = (item.get("is_movie")
                    or item.get("movieid", -1) > 0
                    or ch_type == "movies")
        is_folder = (ch_type == "folder"
                     and not is_movie
                     and not item.get("episodeid"))

        if is_movie:
            label  = item.get("title", "")
            year   = item.get("year", "")
            label2 = str(year) if year else ""
            thumb  = (movie_poster.get(item.get("movieid", -1), "")
                      or item.get("thumbnail") or item.get("thumb") or "")
        elif is_folder:
            raw   = item.get("file", item.get("label", ""))
            fname = raw.rstrip("/").rstrip("\\").rsplit("/", 1)[-1]
            fname = fname.rsplit("\\", 1)[-1]
            label  = os.path.splitext(fname)[0]
            label2 = ""
            thumb  = item.get("thumbnail") or item.get("thumb") or ""
        else:
            label  = item.get("tvshowtitle", "")
            label2 = self._s(_S_SEP_EP).format(
                item.get("season", 0),
                item.get("episode", 0),
                item.get("title", ""))
            thumb  = (show_poster.get(item.get("show_id") or item.get("_show_id", -1), "")
                      or item.get("thumbnail") or item.get("thumb") or "")

        return label, label2, thumb

    # ── Playback dispatch ─────────────────────────────────────────────────

    def _play_channel(self, channel_id):
        """
        Play channel from queue front.
        Move to Home first so Kodi returns to Home (not Videos hub)
        when playback stops.
        """
        log("[SidePanel] _play_channel id={}".format(channel_id))
        self.close()
        xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.sleep(200)
        xbmc.executebuiltin(
            "RunPlugin({})".format(_url(action="play_channel",
                                        channel_id=channel_id)))

    def _play_from_item(self, channel_id, item, queue_index):
        """
        Reorder queue so selected item is at position 0, then play.
        Items before it move to the tail — service.py skip detection
        advances their state naturally, identical to playlist skipping.
        """
        log("[SidePanel] _play_from_item channel={} queue_index={}".format(
            channel_id, queue_index))

        if queue_index <= 0:
            self._play_channel(channel_id)
            return

        try:
            ok = self._manager.reorder_queue_from_item(channel_id, queue_index)
            if not ok:
                log("[SidePanel] reorder failed — falling back to front")
        except Exception as e:
            log("[SidePanel] _play_from_item error: {}".format(e))

        self.close()
        xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.sleep(200)
        xbmc.executebuiltin(
            "RunPlugin({})".format(_url(action="play_channel",
                                        channel_id=channel_id)))

    # ── Helpers ───────────────────────────────────────────────────────────

    def _s(self, sid):
        """Return localised string. Never hardcode user-visible text."""
        return self._addon.getLocalizedString(sid)


# ── Public entry point ─────────────────────────────────────────────────────

def open_side_panel(addon, manager):
    """
    Move to Home first (eliminates Videos hub flash on open), then
    resolve the correct skin XML and open the side panel window.
    Called from router.py when use_side_panel setting is True.
    """
    # Move to Home before opening so Kodi has no Videos screen to
    # flash back to when endOfDirectory(succeeded=False) fires.
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(150)

    addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    xml_file   = _resolve_skin_xml(addon_path)
    xml_name   = os.path.basename(xml_file)

    log("[SidePanel] open_side_panel: xml={}".format(xml_file))

    try:
        panel = SmartChannelsSidePanel(xml_name, addon_path, addon, manager)
        panel.doModal()
        del panel
    except Exception as e:
        log("[SidePanel] open_side_panel error: {}".format(e))
        xbmcgui.Dialog().notification(
            addon.getLocalizedString(32289),
            "Side Panel error: {}".format(str(e)[:60]),
            xbmcgui.NOTIFICATION_ERROR, 4000)
