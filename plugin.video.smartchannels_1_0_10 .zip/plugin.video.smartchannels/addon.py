"""
plugin.video.smartchannels - Main Entry Point
=============================================
Kodi 21 (Omega) compatible plugin.

URL scheme:
  plugin://plugin.video.smartchannels/                    ? channel list (viewer)
  plugin://plugin.video.smartchannels/?action=open_channel&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=play_channel&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=create_channel
  plugin://plugin.video.smartchannels/?action=edit_channel&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=delete_channel&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=toggle_channel_visibility&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=manage_interleave&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=refresh_library
  plugin://plugin.video.smartchannels/?action=regenerate_queue&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=reset_channel&channel_id=<id>
  plugin://plugin.video.smartchannels/?action=reset_next_episode&channel_id=<id>&show_id=<id>
"""

import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon

from resources.lib.router import Router
from resources.lib.utils.logger import log

ADDON    = xbmcaddon.Addon()
HANDLE   = int(sys.argv[1])
BASE_URL = sys.argv[0]
PARAMS   = dict(parse_qsl(sys.argv[2][1:]))


def main():
    action = PARAMS.get("action", "list_channels")
    log(f"[addon.py] action='{action}' params={PARAMS}")

    router = Router(HANDLE, BASE_URL, ADDON)

    dispatch = {
        # -- Viewer ------------------------------------------------------------
        "list_channels":             router.list_channels,
        "open_channel":              router.open_channel,
        "play_channel":              router.play_channel,

        # -- Channel management (via context menus) ----------------------------
        "create_channel":            router.create_channel,
        "edit_channel":              router.edit_channel,
        "delete_channel":            router.delete_channel,
        "toggle_channel_visibility": router.toggle_channel_visibility,
        "manage_interleave":         router.manage_interleave,
        "channel_info":              router.channel_info,

        # -- Misc --------------------------------------------------------------
        "refresh_library":           router.refresh_library,
        "reset_channel":             router.reset_channel,
        "reset_next_episode":        router.reset_next_episode,
        "open_settings":             router.open_settings,
        "clear_shared_path":         router.clear_shared_path,
        "backup_data":               router.backup_data,
        "restore_data":              router.restore_data,
        "delete_all_data":           router.delete_all_data,
    }

    handler = dispatch.get(action)
    if handler:
        handler(PARAMS)
    else:
        log(f"[addon.py] Unknown action '{action}' - falling back to list_channels",
            level=xbmc.LOGWARNING)
        router.list_channels(PARAMS)


if __name__ == "__main__":
    main()
