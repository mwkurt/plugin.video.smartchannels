"""
resources/lib/router.py
========================
Dispatches URL actions to controllers.
The main_menu is gone - Open goes straight to the channel list.
Settings/Configure opens settings.xml via Kodi's built-in mechanism.
Channel management (create/edit/delete/interleave) is triggered via
context menus within the channel list, not a separate menu screen.
"""

from __future__ import annotations

from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.channel_manager import ChannelManager
from resources.lib.player           import SmartPlayer
from resources.lib.ui.channels      import ChannelUI
from resources.lib.utils.logger     import log


class Router:

    def __init__(self, handle: int, base_url: str, addon: xbmcaddon.Addon):
        self.handle   = handle
        self.base_url = base_url
        self.addon    = addon
        self.manager  = ChannelManager(addon)
        self.ui       = ChannelUI(handle, base_url, addon, self.manager)

    def _finish(self, succeeded: bool = True) -> None:
        xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded)

    def _get_shared_root(self):
        """Return the configured shared storage root path, or empty string."""
        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw in ("", "smb://", "smb:/"):
                return ""
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = "smb://" + raw.lstrip("\\//").replace("\\", "/")
            return raw.rstrip("/")
        except Exception:
            return ""

    # -- Viewer ----------------------------------------------------------------

    def list_channels(self, params: dict) -> None:
        """
        Default view when the addon is opened.
        Shows all visible channels plus a [Create New Channel] entry at bottom.
        """
        log("[router] list_channels")
        xbmcplugin.setPluginCategory(self.handle, "Smart TV Channels")
        xbmcplugin.setContent(self.handle, "files")
        self.ui.list_channels(params)
        self._finish()

    def open_channel(self, params: dict) -> None:
        """Show contents of a single channel - next episode per show + Play entry."""
        channel_id = params.get("channel_id")
        log(f"[router] open_channel id={channel_id}")
        if not channel_id:
            self._finish(False)
            return
        self.ui.open_channel(params)
        self._finish()

    def play_channel(self, params: dict) -> None:
        """Build queue and start playback."""
        channel_id = params.get("channel_id")
        log("[router] play_channel id={}".format(channel_id))
        channel = self.manager.get_channel(channel_id) if channel_id else None
        if not channel:
            xbmcgui.Dialog().notification(
                "Smart TV Channels", "Channel not found.",
                xbmcgui.NOTIFICATION_WARNING, 2000
            )
            # Must resolve the handle even on failure
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        # CRITICAL: Resolve the Kodi plugin handle BEFORE starting playback.
        # If we do not call endOfDirectory or setResolvedUrl, Kodi keeps
        # spinning waiting for the plugin to respond, freezing the UI.
        # We use setResolvedUrl with a dummy item to signal we are done
        # with the directory call, then hand off to the player.
        dummy = xbmcgui.ListItem(label="Smart TV Channels")
        dummy.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(self.handle, succeeded=False, listitem=dummy)

        player = SmartPlayer(self.addon, self.manager)
        result = player.start_channel(channel)

        # start_channel returns False when the queue is empty (channel
        # exhausted or no content).  Offer to delete it.
        if result is False:
            channel_name = channel.get("name", "")
            confirmed = xbmcgui.Dialog().yesno(
                self.addon.getLocalizedString(32289),
                self.addon.getLocalizedString(32290).format(channel_name))
            if confirmed:
                self.manager.delete_channel(channel["id"])
                xbmcgui.Dialog().notification(
                    self.addon.getLocalizedString(32289),
                    self.addon.getLocalizedString(32291).format(channel_name),
                    xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin("Container.Refresh")

    # -- Channel management ----------------------------------------------------

    def create_channel(self, params: dict) -> None:
        log("[router] create_channel")
        self.ui.create_channel_wizard(params)

    def edit_channel(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] edit_channel id={channel_id}")
        if channel_id:
            self.ui.edit_channel_wizard(params)

    def delete_channel(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] delete_channel id={channel_id}")
        if not channel_id:
            return
        confirmed = xbmcgui.Dialog().yesno(
            "Smart TV Channels",
            "Are you sure you want to delete this channel?"
        )
        if confirmed:
            self.manager.delete_channel(channel_id)
            xbmcgui.Dialog().notification(
                "Smart TV Channels", "Channel deleted.",
                xbmcgui.NOTIFICATION_INFO, 2000
            )
            xbmc.executebuiltin("Container.Refresh")

    def channel_info(self, params: dict) -> None:
        log("[router] channel_info id={}".format(params.get("channel_id")))
        self.ui.channel_info(params)

    def toggle_channel_visibility(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] toggle_visibility id={channel_id}")
        if channel_id:
            self.manager.toggle_visibility(channel_id)
            xbmc.executebuiltin("Container.Refresh")

    def manage_interleave(self, params: dict) -> None:
        channel_id = params.get("channel_id")
        log(f"[router] manage_interleave id={channel_id}")
        if channel_id:
            self.ui.manage_interleave_dialog(params)

    # -- Misc ------------------------------------------------------------------

    def reset_channel(self, params: dict) -> None:
        """
        Reset ALL shows (and movie rotation) in a channel back to the
        very beginning. Every state key for the channel is wiped and the
        queue is rebuilt from scratch.
        """
        channel_id = params.get("channel_id")
        log("[router] reset_channel id={}".format(channel_id))
        channel = self.manager.get_channel(channel_id) if channel_id else None
        if not channel:
            xbmcgui.Dialog().notification(
                "Smart TV Channels", "Channel not found.",
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        confirmed = xbmcgui.Dialog().yesno(
            "Reset Channel",
            "Reset \"{}\"\'s entire channel back to the beginning?\n"
            "All shows will restart from S01E01, movie rotation will "
            "restart from the first movie, and all saved resume points "
            "for this channel will be removed.".format(channel["name"]))
        if not confirmed:
            return

        self.manager.reset_channel(channel_id)
        xbmcgui.Dialog().notification(
            "Smart TV Channels",
            "\"{}\' reset to beginning.".format(channel["name"]),
            xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")

    def reset_next_episode(self, params: dict) -> None:
        """
        Reset one show\'s playback pointer back to S01E01 within a channel.
        All other shows in the channel are unaffected.
        Movies interleaved into the channel are unaffected.
        """
        channel_id = params.get("channel_id")
        show_id    = params.get("show_id")
        log("[router] reset_next_episode channel={} show={}".format(
            channel_id, show_id))

        if not channel_id or not show_id:
            return

        try:
            show_id = int(show_id)
        except (ValueError, TypeError):
            return

        channel = self.manager.get_channel(channel_id)
        if not channel:
            return

        show_title = "Show"
        for s in channel.get("shows", []):
            if s.get("tvshowid") == show_id:
                show_title = s.get("title", show_title)
                break

        confirmed = xbmcgui.Dialog().yesno(
            "Reset Show",
            "Reset \"{}\' back to S01E01 in this channel?\n"
            "Other shows and any interleaved movies are unaffected.".format(
                show_title))
        if not confirmed:
            return

        episodes = self.manager.library.get_episodes_for_show(show_id)
        if not episodes:
            xbmcgui.Dialog().notification(
                "Smart TV Channels", "No episodes found for show.",
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        first_ep = episodes[0]
        self.manager.save_show_state(channel_id, show_id, {
            "next_episode_id": first_ep["episodeid"],
            "season":          first_ep.get("season",  1),
            "episode":         first_ep.get("episode", 1),
            "played_ids":      [],
        })

        # Clear tail marker and queue file so the next build reflects the reset
        tail_key = self.manager._tail_key(channel_id)
        self.manager._state.pop(tail_key, None)
        self.manager._save_state()

        import xbmcvfs as _xbmcvfs
        queue_path = self.manager._queue_file_path(channel_id)
        if _xbmcvfs.exists(queue_path):
            _xbmcvfs.delete(queue_path)

        self.manager._pregenerate_queue(channel)

        xbmcgui.Dialog().notification(
            "Smart TV Channels",
            "\"{}\' reset to S01E01.".format(show_title),
            xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


    def refresh_library(self, params):
        log("[router] refresh_library - rebuilding local cache")

        progress = xbmcgui.DialogProgress()
        progress.create("Smart TV Channels", "Building library cache...")
        progress.update(0, "Starting...")

        cancelled = [False]

        def _on_progress(pct, msg):
            if progress.iscanceled():
                cancelled[0] = True
                return
            progress.update(pct, msg)

        try:
            success = self.manager.library.build_local_cache(
                progress_callback=_on_progress)
            progress.close()

            if cancelled[0]:
                xbmcgui.Dialog().notification(
                    "Smart TV Channels", "Cache rebuild cancelled.",
                    xbmcgui.NOTIFICATION_WARNING, 2000)
            elif success:
                # Also clear in-memory cache so next wizard reads fresh data
                self.manager.library.clear_cache()
                xbmcgui.Dialog().notification(
                    "Smart TV Channels", "Library cache rebuilt!",
                    xbmcgui.NOTIFICATION_INFO, 2000)
            else:
                xbmcgui.Dialog().notification(
                    "Smart TV Channels", "Cache rebuild failed - check logs.",
                    xbmcgui.NOTIFICATION_ERROR, 3000)
        except Exception as e:
            progress.close()
            log("[router] refresh_library error: {}".format(e))
            xbmcgui.Dialog().notification(
                "Smart TV Channels", "Error: {}".format(str(e)[:50]),
                xbmcgui.NOTIFICATION_ERROR, 3000)

        xbmc.executebuiltin("Container.Refresh")


    def _get_backup_path(self):
        """Return configured backup folder path. Empty string if not set."""
        try:
            # Re-read with fresh instance and retry once to handle
            # the case where Settings UI hasn't flushed to disk yet
            raw = xbmcaddon.Addon().getSetting("backup_path").strip()
            if not raw:
                xbmc.sleep(1000)
                raw = xbmcaddon.Addon().getSetting("backup_path").strip()
            log("[router] _get_backup_path: raw={}".format(repr(raw)))
            if not raw:
                return ""
            # UNC network path - convert to smb://
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = "smb://" + raw.lstrip("\\//").replace("\\", "/")
            # Strip trailing slashes/backslashes
            raw = raw.rstrip("/").rstrip("\\")
            log("[router] _get_backup_path: result={}".format(repr(raw)))
            return raw
        except Exception as e:
            log("[router] _get_backup_path error: {}".format(e), xbmc.LOGWARNING)
            return ""

    def backup_data(self, params):
        import xbmcvfs, os, datetime, zipfile
        backup_root = self._get_backup_path()
        if not backup_root:
            xbmcgui.Dialog().ok(
                "Backup",
                "No backup folder configured.\nPlease set a backup folder path in Settings > Backup & Restore.")
            return
        profile   = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        shared    = self._get_shared_root()
        data_root = (shared + "/") if shared else (profile.rstrip("/") + "/")
        files_to_backup = {
            "channels.json": data_root + "channels.json",
            "state.json":    data_root + "state.json",
            "settings.xml":  profile.rstrip("/") + "/settings.xml",
        }
        try:
            _, dir_files = xbmcvfs.listdir(data_root)
            for fn in dir_files:
                if fn.startswith("queue_") and fn.endswith(".json"):
                    files_to_backup[fn] = data_root + fn
        except Exception as e:
            log("[router] backup_data: could not list queue files: {}".format(e), xbmc.LOGWARNING)
        # Read all files via xbmcvfs into memory
        file_data = {}
        for arc_name, src_path in files_to_backup.items():
            try:
                if xbmcvfs.exists(src_path):
                    with xbmcvfs.File(src_path, "r") as _f:
                        raw = _f.read()
                    if raw:
                        file_data[arc_name] = raw.encode("utf-8") if isinstance(raw, str) else raw
                    else:
                        log("[router] backup_data: {} empty, skipping".format(arc_name))
                else:
                    log("[router] backup_data: {} not found".format(src_path))
            except Exception as e:
                log("[router] backup_data: read error {}: {}".format(arc_name, e), xbmc.LOGWARNING)
        if not file_data:
            xbmcgui.Dialog().ok("Backup Failed", "No files could be read.")
            return
        # Write zip to local temp then copy to backup destination
        ts       = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_name = "SmartChannels_Backup_" + ts + ".zip"
        tmp_zip  = os.path.join(xbmcvfs.translatePath("special://temp/"), zip_name)
        zip_path = backup_root + "/" + zip_name
        try:
            with zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED) as zf:
                for arc_name, data in file_data.items():
                    zf.writestr(arc_name, data)
            ok = xbmcvfs.copy(tmp_zip, zip_path)
            try:
                os.remove(tmp_zip)
            except Exception:
                pass
            if ok:
                log("[router] backup_data: wrote {} ({} files)".format(zip_path, len(file_data)))
                xbmcgui.Dialog().ok(
                    "Backup Complete",
                    "Backed up {} file(s).\nFile: {}".format(len(file_data), zip_name))
            else:
                xbmcgui.Dialog().ok(
                    "Backup Failed",
                    "Could not copy zip to:\n{}".format(zip_path))
        except Exception as e:
            log("[router] backup_data: error: {}".format(e), xbmc.LOGWARNING)
            xbmcgui.Dialog().ok("Backup Failed", str(e))

    def restore_data(self, params):
        import xbmcvfs, os, zipfile
        backup_root = self._get_backup_path()
        if not backup_root:
            xbmcgui.Dialog().ok(
                "Restore",
                "No backup folder configured.\nPlease set a backup folder path in Settings > Backup & Restore.")
            return
        # List zip files in backup folder
        try:
            _, dir_files = xbmcvfs.listdir(backup_root)
            zips = sorted([f for f in dir_files
                           if f.startswith("SmartChannels_Backup_") and f.endswith(".zip")],
                          reverse=True)
        except Exception as e:
            xbmcgui.Dialog().ok("Restore Failed", "Could not read backup folder:\n{}".format(str(e)))
            return
        if not zips:
            xbmcgui.Dialog().ok(
                "Restore",
                "No backup files found in:\n{}".format(backup_root))
            return
        # Let user pick which backup to restore
        chosen_idx = xbmcgui.Dialog().select("Select Backup to Restore", zips)
        if chosen_idx < 0:
            return
        zip_name = zips[chosen_idx]
        zip_path = backup_root + "/" + zip_name
        # Copy zip to local temp so zipfile module can read it natively
        profile  = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        tmp_zip  = os.path.join(xbmcvfs.translatePath("special://temp/"), "_sc_restore_tmp.zip")
        try:
            if os.path.exists(tmp_zip):
                os.remove(tmp_zip)
            ok = xbmcvfs.copy(zip_path, tmp_zip)
            if not ok:
                xbmcgui.Dialog().ok("Restore Failed", "Could not read the zip file.")
                return
            zf        = zipfile.ZipFile(tmp_zip, "r")
            available = zf.namelist()
        except Exception as e:
            xbmcgui.Dialog().ok("Restore Failed", str(e))
            return
        if not available:
            xbmcgui.Dialog().ok("Restore Failed", "Zip contains no files.")
            zf.close()
            return
        # Let user pick which files to restore
        chosen = xbmcgui.Dialog().multiselect(
            "Select Files to Restore from " + zip_name,
            available,
            preselect=list(range(len(available))))
        if not chosen:
            zf.close()
            return
        files_to_restore = [available[i] for i in chosen]
        confirmed = xbmcgui.Dialog().yesno(
            "Confirm Restore",
            "Overwrite {} file(s)? Current data will be replaced.".format(len(files_to_restore)))
        if not confirmed:
            zf.close()
            return
        shared    = self._get_shared_root()
        data_root = (shared + "/") if shared else (profile.rstrip("/") + "/")
        needs_restart = False
        restored      = []
        failed        = []
        for fn in files_to_restore:
            dst = profile.rstrip("/") + "/" + fn if fn == "settings.xml" else data_root + fn
            if fn == "settings.xml":
                needs_restart = True
            try:
                # Extract to local temp then copy to final destination
                tmp_file = os.path.join(xbmcvfs.translatePath("special://temp/"), "_sc_restore_" + fn.replace("/", "_"))
                with open(tmp_file, "wb") as out:
                    out.write(zf.read(fn))
                if xbmcvfs.exists(dst):
                    xbmcvfs.delete(dst)
                ok = xbmcvfs.copy(tmp_file, dst)
                try:
                    os.remove(tmp_file)
                except Exception:
                    pass
                if ok:
                    restored.append(fn)
                    log("[router] restore_data: restored {}".format(fn))
                else:
                    failed.append(fn)
                    log("[router] restore_data: copy failed for {}".format(fn), xbmc.LOGWARNING)
            except Exception as e:
                failed.append(fn)
                log("[router] restore_data: error {}: {}".format(fn, e), xbmc.LOGWARNING)
        zf.close()
        try:
            os.remove(tmp_zip)
        except Exception:
            pass
        parts = []
        if restored:
            parts.append("Restored: " + ", ".join(restored))
        if failed:
            parts.append("Failed: " + ", ".join(failed))
        if needs_restart and "settings.xml" in restored:
            parts.append("Kodi restart required for settings.")
        xbmcgui.Dialog().ok("Restore Complete", "\n".join(parts))
        if restored:
            xbmc.sleep(500)
            xbmc.executebuiltin("Container.Refresh")


    def delete_all_data(self, params):
        """
        Delete all addon data from both the local profile folder and
        the configured shared storage folder (if any).
        Prompts the user to confirm before deleting.
        """
        import xbmcvfs, os
        confirmed = xbmcgui.Dialog().yesno(
            "Delete All Addon Data",
            "This will permanently delete all channels, state, queues "
            "and library cache from both the local and shared folder.\n"
            "Are you sure?")
        if not confirmed:
            return

        data_files = [
            "channels.json", "state.json", "local_library.json",
            "now_playing.json"
        ]

        def _delete_from(folder, is_network):
            """Delete known files + all queue_*.json from folder."""
            deleted = 0
            for fn in data_files:
                if is_network:
                    p = folder + "/" + fn
                else:
                    p = os.path.join(folder, fn)
                try:
                    if xbmcvfs.exists(p):
                        xbmcvfs.delete(p)
                        deleted += 1
                except Exception as e:
                    log("[router] delete_all_data: cannot delete {}: {}".format(p, e))
            # Delete queue files
            try:
                _, files = xbmcvfs.listdir(folder)
                for fn in files:
                    if fn.startswith("queue_") and fn.endswith(".json"):
                        if is_network:
                            p = folder + "/" + fn
                        else:
                            p = os.path.join(folder, fn)
                        try:
                            xbmcvfs.delete(p)
                            deleted += 1
                        except Exception:
                            pass
            except Exception:
                pass
            return deleted

        profile = xbmcvfs.translatePath(self.addon.getAddonInfo("profile"))
        total = _delete_from(profile, False)

        # Also delete from shared folder if configured
        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw in ("", "smb://", "smb:/"):
                raw = ""
            # Normalize UNC paths to smb://
            if raw and (raw.startswith("\\\\") or raw.startswith("//")):
                raw = "smb://" + raw.lstrip("\\/").replace("\\", "/")
            shared = raw.rstrip("/").rstrip("\\") if raw else ""
        except Exception:
            shared = ""

        if shared:
            is_net = "://" in shared
            total += _delete_from(shared, is_net)

        xbmcgui.Dialog().notification(
            "Smart TV Channels",
            "Deleted {} file(s)".format(total),
            xbmcgui.NOTIFICATION_INFO, 3000)
        log("[router] delete_all_data: deleted {} files".format(total))
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.Refresh")

    def clear_shared_path(self, params):
        """
        Clear the shared storage path and return to using Kodi's
        local addon data folder.  Offers to migrate files back.
        """
        import xbmcvfs, os
        log("[router] clear_shared_path")

        try:
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw not in ("", "smb://", "smb:/"):
                if raw.startswith("\\\\") or raw.startswith("//"):
                    raw = raw.lstrip("\\/")
                    raw = "smb://" + raw.replace("\\", "/")
                shared = raw.rstrip("/").rstrip("\\")
            else:
                shared = ""
        except Exception:
            shared = ""

        # Clear the setting first
        self.addon.setSetting("shared_storage_path", "")
        log("[router] shared_storage_path cleared")

        # Offer to migrate files from shared back to local profile
        if shared:
            profile = xbmcvfs.translatePath(
                self.addon.getAddonInfo("profile"))
            migrate_back = xbmcgui.Dialog().yesno(
                "Smart TV Channels",
                "Copy files from shared folder back to Kodi addon data folder?\n"
                "[{}]".format(shared))
            if migrate_back:
                data_files = [
                    "channels.json", "state.json",
                    "local_library.json", "now_playing.json"
                ]
                def _path_join(root, fn):
                    if "://" in root:
                        return root + "/" + fn
                    return os.path.join(root, fn)
                # Add queue files
                try:
                    _, files = xbmcvfs.listdir(shared)
                    for fn in files:
                        if fn.startswith("queue_") and fn.endswith(".json"):
                            data_files.append(fn)
                except Exception:
                    pass
                migrated = []
                for fn in data_files:
                    src = _path_join(shared, fn)
                    dst = os.path.join(profile, fn)
                    if xbmcvfs.exists(src):
                        try:
                            xbmcvfs.copy(src, dst)
                            migrated.append(fn)
                        except Exception as e:
                            log("[router] migrate back {} failed: {}".format(fn, e))
                if migrated:
                    log("[router] migrated back to local: {}".format(migrated))

        xbmcgui.Dialog().notification(
            "Smart TV Channels",
            "Now using Kodi addon data folder",
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.sleep(500)
        xbmc.executebuiltin("Container.Refresh")

    def open_settings(self, params):
        """Open the addon settings dialog, then migrate files if shared
        path changed, then refresh the container."""
        import xbmcvfs, os
        log("[router] open_settings")

        def _get_shared():
            raw = self.addon.getSetting("shared_storage_path").strip()
            if raw in ("smb://", "smb:/", ""):
                return ""
            # Convert Windows UNC to smb:// so xbmcvfs handles it
            if raw.startswith("\\\\") or raw.startswith("//"):
                raw = raw.lstrip("\\/")
                raw = "smb://" + raw.replace("\\", "/")
            return raw.rstrip("/").rstrip("\\")

        def _path_join(root, filename):
            """Join root + filename correctly for local or network paths."""
            if "://" in root:
                return root + "/" + filename
            return os.path.join(root, filename)

        shared_before = _get_shared()
        self.addon.openSettings()
        shared_after = _get_shared()

        # Migrate files when the shared path is set or changed
        if shared_after and shared_after != shared_before:
            profile = xbmcvfs.translatePath(
                self.addon.getAddonInfo("profile"))

            # Source is the previous shared folder, or local profile if
            # there was no previous shared folder.
            src_root = shared_before if shared_before else profile

            migrate_files = [
                "channels.json", "state.json",
                "local_library.json", "now_playing.json"
            ]
            # Pick up any queue files from the source folder
            try:
                _, files = xbmcvfs.listdir(src_root)
                for fn in files:
                    if fn.startswith("queue_") and fn.endswith(".json"):
                        migrate_files.append(fn)
            except Exception:
                pass

            migrated = []
            for fn in migrate_files:
                src = _path_join(src_root, fn)
                dst = _path_join(shared_after, fn)
                if xbmcvfs.exists(src) and not xbmcvfs.exists(dst):
                    try:
                        xbmcvfs.copy(src, dst)
                        migrated.append(fn)
                        log("[router] migrated: {} -> {}".format(src, dst))
                    except Exception as e:
                        log("[router] migrate {} failed: {}".format(fn, e))

            if migrated:
                xbmcgui.Dialog().notification(
                    "Smart TV Channels",
                    "Migrated {} file(s) to shared folder".format(
                        len(migrated)),
                    xbmcgui.NOTIFICATION_INFO, 3000)
                log("[router] Migrated to shared: {}".format(migrated))

                # Offer to clean up the old shared folder if it was a
                # different shared path (not the local profile)
                if shared_before:
                    clean = xbmcgui.Dialog().yesno(
                        "Smart TV Channels",
                        "Delete the migrated files from the old "
                        "shared folder?\n[{}]".format(shared_before))
                    if clean:
                        for fn in migrated:
                            old_file = _path_join(shared_before, fn)
                            try:
                                if xbmcvfs.exists(old_file):
                                    xbmcvfs.delete(old_file)
                                    log("[router] deleted old: {}".format(
                                        old_file))
                            except Exception as e:
                                log("[router] delete old {} failed: {}".format(
                                    old_file, e))
            else:
                log("[router] No files to migrate (src={})".format(src_root))

        xbmc.sleep(300)
        xbmc.executebuiltin("Container.Refresh")
