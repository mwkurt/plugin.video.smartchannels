"""
resources/lib/serial.py
========================
Serial channel queue builder and state manager.

A serial channel plays every episode of Show A in full before moving to
Show B, then Show C, and so on.  When the last show finishes the channel
either loops back to Show A (recycle=True) or stops (recycle=False).

This module is fully self-contained.  It is the ONLY place that:
  - builds serial channel queues
  - reads / writes the __serial_show_idx__ state key
  - handles show-boundary state advancement for serial channels

channel_manager.py touches this module in exactly three places:
  1. build_queue()    — routes serial channels here
  2. refill_queue()   — routes serial top-ups here
  3. advance_show()   — delegates to SerialQueueBuilder.advance_show()
                        when channel_type == "serial"

service.py is NOT modified.  It calls channel_manager.advance_show() as
normal; the delegation above means serial logic never leaks into service.py.
"""

from __future__ import annotations

from resources.lib.utils.logger import log

# State key for the current show index within a serial channel.
# Written here and read here only.
_SERIAL_IDX_KEY = "{}:__serial_show_idx__"


class SerialQueueBuilder:
    """
    Builds and manages queues for serial channels.

    Receives a ChannelManager instance (_cm) so it can call its
    infrastructure methods (_normalize_ep, save_show_state, etc.)
    without duplicating that code.  It never modifies _cm's behaviour
    for any other channel type.
    """

    # How many episodes to look ahead into the NEXT show beyond the
    # current one.  Keeps the Kodi playlist populated across show
    # boundaries so playback never stalls waiting for a top-up.
    LOOKAHEAD = 3

    def __init__(self, channel_manager):
        self._cm = channel_manager

    # ------------------------------------------------------------------
    # Public: queue building
    # ------------------------------------------------------------------

    def build(self, channel, target_size, current_queue=None):
        """
        Build a queue for a serial channel.

        Reads __serial_show_idx__ from state to find the active show,
        then fills target_size slots starting from that show's current
        episode pointer.  Spills over into subsequent shows when the
        active show runs out, and adds LOOKAHEAD episodes from the next
        show so the Kodi playlist never hits a boundary stall.

        current_queue: when provided (top-up context), the episodes
        already in the live queue.  Used to skip past episodes already
        queued for each show so the top-up join is seamless.
        Without this, build() reads next_episode_id from state, which
        only advances after an episode FINISHES playing.  At top-up
        time shows may still have unplayed episodes ahead (including
        LOOKAHEAD items from the previous build), so state lags reality
        and build() duplicates those episodes at the join boundary.

        Returns a list of normalised episode dicts (same shape as
        _build_fresh_queue output) or [] if nothing can be queued.
        """
        channel_id = channel["id"]
        shows      = channel.get("shows", [])
        recycle    = channel.get("recycle", True)

        if not shows:
            log("[Serial] build: no shows in channel")
            return []

        # Read current show index from state
        show_idx = self._get_show_idx(channel_id, len(shows))
        log("[Serial] build: channel='{}' show_idx={} of {} shows "
            "recycle={}".format(channel["name"], show_idx,
                                len(shows), recycle))

        # Exhaustion guard for recycle=False:
        # _channel_exhausted() checks next_episode_id=None for all shows,
        # which is written by advance_show after the last episode plays.
        # But there is a timing window: if Play Channel is pressed while the
        # last episode is still playing, advance_show hasn't fired yet so
        # next_episode_id is not None.  We catch this with a secondary check:
        # if show_idx points at (or past) the last show AND the current
        # episode pointer for that show is at the last episode, treat the
        # channel as exhausted and return [] rather than replaying it.
        if not recycle:
            # Primary check: all shows marked exhausted via next_episode_id=None
            if self._cm._channel_exhausted(channel_id, channel):
                log("[Serial] build: channel exhausted (recycle=False) "
                    "— returning empty queue")
                return []
            # Secondary timing-window check
            if show_idx >= len(shows) - 1:
                last_show = shows[-1]
                last_sid  = last_show["tvshowid"]
                last_eps  = self._cm.library.get_episodes_for_show(last_sid)
                if last_eps:
                    last_state  = self._cm.get_show_state(channel_id, last_sid)
                    last_next   = last_state.get("next_episode_id")
                    last_ep_id  = last_eps[-1]["episodeid"]
                    # If the pointer is already on the very last episode of the
                    # last show, and all other shows are also at their last
                    # episode (or have next_episode_id=None), the channel is
                    # effectively done — don't replay the last episode.
                    if last_next == last_ep_id:
                        all_others_done = True
                        for _s in shows[:-1]:
                            _sid  = _s["tvshowid"]
                            _st   = self._cm.get_show_state(channel_id, _sid)
                            _nid  = _st.get("next_episode_id")
                            _eps  = self._cm.library.get_episodes_for_show(_sid)
                            if _nid is None:
                                continue  # already reset / exhausted
                            if _eps and _nid != _eps[0]["episodeid"]:
                                # Still has unseen episodes remaining
                                all_others_done = False
                                break
                        if all_others_done:
                            log("[Serial] build: timing-window exhaustion "
                                "detected — returning empty queue")
                            return []

        queue        = []
        visited      = 0          # guard against infinite loop
        max_visits   = len(shows) + 1

        while len(queue) < target_size + self.LOOKAHEAD:
            if visited > max_visits:
                break

            if show_idx >= len(shows):
                if not recycle:
                    log("[Serial] build: all shows played, recycle=False")
                    break
                show_idx = 0
                visited += 1

            show = shows[show_idx]
            sid  = show["tvshowid"]

            episodes = self._cm.library.get_episodes_for_show(sid)
            if not episodes:
                log("[Serial] build: no episodes for show '{}', "
                    "skipping".format(show.get("title", sid)))
                show_idx += 1
                visited  += 1
                continue

            # Find the episode pointer for this show.
            #
            # Normal path: read next_episode_id from state (written by
            # advance_show when an episode finishes playing).
            #
            # Top-up path (current_queue provided, first show only):
            # state may lag reality — advance_show only fires AFTER an
            # episode completes, but top-up fires while the last episode
            # of the starting show may still be queued ahead unplayed.
            # Scan current_queue instead: find the last episode of this
            # show already queued and start from the one AFTER it.
            # For subsequent shows (after the first) the state pointer is
            # reliable because advance_show has already reset them.
            state   = self._cm.get_show_state(channel_id, sid)
            next_id = state.get("next_episode_id")
            ep_ids  = [e["episodeid"] for e in episodes]

            if current_queue is not None:
                # Top-up path: scan current_queue for the last episode of
                # this show already queued so we start AFTER it.
                #
                # This must apply to EVERY show in the loop, not just the
                # first.  The LOOKAHEAD means multiple shows can already have
                # episodes in current_queue (e.g. the first show in the loop
                # may be fully queued AND the next show may have lookahead
                # items already there).  Clearing current_queue after the
                # first show caused subsequent shows to fall back to
                # next_episode_id state, which duplicated lookahead episodes.
                last_queued_id = None
                for item in reversed(current_queue):
                    item_sid = item.get("show_id") or item.get("_show_id")
                    if int(item_sid) == int(sid):
                        last_queued_id = item.get("episodeid")
                        break
                if last_queued_id is not None and last_queued_id in ep_ids:
                    queued_pos = ep_ids.index(last_queued_id)
                    start_idx  = queued_pos + 1   # start AFTER the last queued ep
                    log("[Serial] build: top-up start for '{}' after queued "
                        "ep {} (start_idx={})".format(
                            show.get("title", sid), last_queued_id, start_idx))
                    if start_idx >= len(episodes):
                        # This show is fully queued; move to next show
                        log("[Serial] build: '{}' fully queued, "
                            "skipping to next show".format(
                                show.get("title", sid)))
                        show_idx += 1
                        visited  += 1
                        continue
                else:
                    # No episodes of this show found in current_queue;
                    # fall back to state pointer
                    if next_id is None:
                        start_idx = 0
                    else:
                        try:
                            start_idx = ep_ids.index(next_id)
                        except ValueError:
                            start_idx = 0
            elif next_id is None:
                # Show was exhausted (or brand-new channel) — start from ep 0
                start_idx = 0
            else:
                try:
                    start_idx = ep_ids.index(next_id)
                except ValueError:
                    start_idx = 0

            # Append episodes from start_idx onward
            added_from_this_show = 0
            for ep in episodes[start_idx:]:
                if len(queue) >= target_size + self.LOOKAHEAD:
                    break
                queue.append(
                    self._cm._normalize_ep(ep, channel_id, sid))
                added_from_this_show += 1

            log("[Serial] build: added {} episodes from show '{}' "
                "(start_idx={})".format(
                    added_from_this_show, show.get("title", sid),
                    start_idx))

            # Move to next show for the next iteration
            show_idx += 1
            visited  += 1

        log("[Serial] build: queue has {} items for channel '{}'".format(
            len(queue), channel["name"]))

        # Persist the show index where this build's tail ended.
        #
        # build() advances show_idx locally as it fills the queue, but
        # never wrote it back to state.  The next build() call (top-up)
        # therefore re-reads the stale __serial_show_idx__ — which still
        # points to whichever show advance_show() last set — and restarts
        # from that show instead of continuing from the queue tail.  This
        # produces jumbled show order: shows repeat out of sequence and
        # episodes from the wrong show appear at the top-up join boundary.
        #
        # Fix: after building, normalise show_idx into the valid range and
        # save it.  recycle=True wraps modulo len(shows) so the index is
        # always a valid slot for the next build call.  recycle=False
        # clamps at len(shows) so the exhaustion check in the next build
        # fires correctly rather than wrapping.
        #
        # advance_show() continues to write its own value when a show
        # boundary is crossed during playback — that is correct and
        # unaffected by this change, because advance_show() always writes
        # finished_pos + 1 based on which show just ended, overriding
        # whatever tail index we saved here.
        if queue:
            n = len(shows)
            if recycle and n > 0:
                tail_idx = show_idx % n
            else:
                tail_idx = min(show_idx, n)
            self._set_show_idx(channel_id, tail_idx)
            log("[Serial] build: saved tail show_idx={}".format(tail_idx))

        return queue
    # ------------------------------------------------------------------
    # Public: state advancement
    # ------------------------------------------------------------------

    def advance_show(self, channel_id, show_id, played_episode_id,
                     channel):
        """
        Called by channel_manager.advance_show() when channel_type is
        'serial'.  Two scenarios reach this method:

        1. Show boundary crossing — the episode that just finished was
           the last one in show N; the next queue item belongs to show
           N+1.  service.py calls advance_show() on the FINISHED show
           so we reset it to S01E01 and increment __serial_show_idx__.

        2. Queue dry — the queue ran completely empty while playing the
           last episode of the last show (or the only show).  Same
           action: reset the finished show, advance the index.

        In both cases the queue builder will be called again immediately
        after this returns, so the updated __serial_show_idx__ and the
        S01E01 reset are picked up correctly.
        """
        shows   = channel.get("shows", [])
        recycle = channel.get("recycle", True)

        if not shows:
            return None

        # Reset the finished show back to S01E01 so it is ready for the
        # next cycle when recycle=True, or sits cleanly at start when
        # recycle=False.
        self._reset_show_to_start(channel_id, show_id)

        # Find the current show index and advance it
        show_idx    = self._get_show_idx(channel_id, len(shows))
        show_id_int = int(show_id)

        # Locate the finished show's position in the shows list
        finished_pos = next(
            (i for i, s in enumerate(shows)
             if int(s["tvshowid"]) == show_id_int), None)

        if finished_pos is not None:
            new_idx = finished_pos + 1
        else:
            # Fallback: just increment whatever index we have
            new_idx = show_idx + 1
            log("[Serial] advance_show: show {} not found in shows list, "
                "incrementing index".format(show_id))

        log("[Serial] advance_show: show_id={} finished_pos={} "
            "new_idx={}".format(show_id, finished_pos, new_idx))

        if new_idx >= len(shows):
            if not recycle:
                # All shows done and no recycle — mark channel exhausted
                # by writing next_episode_id=None for every show
                log("[Serial] advance_show: all shows done, "
                    "recycle=False — marking exhausted")
                for s in shows:
                    sid = s["tvshowid"]
                    st  = self._cm.get_show_state(channel_id, sid)
                    st["next_episode_id"] = None
                    st["played_ids"]      = []
                    self._cm.save_show_state(channel_id, sid, st)
                self._set_show_idx(channel_id, new_idx)
                return None
            else:
                # Wrap around — next cycle starts from show 0
                new_idx = 0

        self._set_show_idx(channel_id, new_idx)

        # Return the first episode of the next show as confirmation
        next_show = shows[new_idx]
        next_sid  = next_show["tvshowid"]
        episodes  = self._cm.library.get_episodes_for_show(next_sid)
        if episodes:
            return episodes[0]
        return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_show_idx(self, channel_id, num_shows):
        """
        Read __serial_show_idx__ from state.json.
        Returns 0 for a brand-new channel (key absent).
        Clamps to valid range in case shows were removed since last play.
        """
        key = _SERIAL_IDX_KEY.format(channel_id)
        # Read fresh from disk so we always see the latest value written
        # by advance_show (which runs in service.py context).
        try:
            fresh = self._cm._load_json(self._cm._state_path, {})
            idx   = int(fresh.get(key, 0))
        except (ValueError, TypeError):
            idx = 0
        # Clamp: if shows were removed the saved index may be out of range
        return max(0, min(idx, num_shows - 1)) if num_shows > 0 else 0

    def _set_show_idx(self, channel_id, idx):
        """Write __serial_show_idx__ to state.json."""
        key = _SERIAL_IDX_KEY.format(channel_id)
        # Remove from deleted-keys set first. reset_channel() adds this key
        # to _deleted_state_keys before calling _pregenerate_queue, which
        # calls build(), which calls _set_show_idx().  If the key stays in
        # _deleted_state_keys, _save_state()'s merge strips it out of the
        # result and it is never written to disk — so the next play_channel
        # call reads show_idx=0 (missing-key default) instead of the tail
        # index that build() just computed, causing show-order jumbling.
        self._cm._deleted_state_keys.discard(key)
        self._cm._state[key] = idx
        self._cm._save_state()
        log("[Serial] __serial_show_idx__ = {} for channel {}".format(
            idx, channel_id[:8]))

    def _reset_show_to_start(self, channel_id, show_id):
        """
        Reset a show's episode pointer back to S01E01 (episode index 0).
        Called when the show finishes in a serial channel so the next
        cycle starts cleanly from the beginning.
        """
        sid      = int(show_id)
        episodes = self._cm.library.get_episodes_for_show(sid)
        if not episodes:
            log("[Serial] _reset_show_to_start: no episodes for "
                "show {}".format(sid))
            return
        first = episodes[0]
        state = {
            "next_episode_id": first["episodeid"],
            "season":          first.get("season",  1),
            "episode":         first.get("episode", 1),
            "played_ids":      [],
        }
        self._cm.save_show_state(channel_id, sid, state)
        log("[Serial] Reset show {} to S{:02d}E{:02d}".format(
            sid, first.get("season", 1), first.get("episode", 1)))
