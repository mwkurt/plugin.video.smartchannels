# plugin.video.smartchannels — Project Handoff

## Overview

Custom Kodi 21/22 (Omega/Piers, Python 3) addon that creates smart TV-style
channels playing TV episodes, movies, folder media, serial content, audio, and
party mode music in configurable rotation with persistent queue/state management,
auto top-up, channel scheduling, and broadcast-style overlays.

- **Owner/Developer:** Mark
- **Home setup:** MySQL-backed shared Kodi library; NAS at 192.168.1.11;
  NVIDIA Shield as primary playback device; Windows 10 PC as primary test machine
- **Current build:** `1.2.3c`
- **Last built zip:** `plugin_video_smartchannels_1_2_3c.zip`
- **addon.xml version:** `1.2.3c`
- **Goal:** Submission to official Kodi addon repository
- **Working directory:** `/home/claude/plugin_work/build_out/plugin.video.smartchannels/`
- **Output zips:** `/mnt/user-data/outputs/` — uncompressed (`-0` flag),
  exclude `*.pyc` and `__pycache__`
- **strings.po last used ID:** `#32821`
- **strings.po next free ID:** `#32822`
- **addon.xml version must match zip filename on every build**

---

## Test Status (as of end of this session)

Tests run against 1.2.1u using the Playback Behavior Test Matrix.

| Test | Result |
|------|--------|
| Natural End — TV, RR, Recycle, Mid-queue | ✅ PASS |
| Skip handling (multiple skip counts) | ✅ PASS |
| Queue top-up at threshold | ✅ PASS |
| Audio CUN timing | ✅ PASS (confirmed working, removed from open bugs) |
| Carousel pop + silent sweep | ✅ PASS (confirmed in overnight log) |
| TV Round Robin sequential order (overnight) | ✅ PASS (full episode sequence verified) |
| Movie channel last-movie resume | ✅ PASS (fixed in 1.2.1u) |

**Next test to run:** Continue Playback Behavior Test Matrix from where left off.

---

## Open Bugs

None currently open.

---

## Changes This Session (1.2.2d → 1.2.3a)

### 1.2.3a — New Feature: Carousel Duration Mode
- Second carousel mode alongside existing Timed mode; chosen per channel
  in wizard
- Duration mode uses `item["duration"]` as the pop window; always pops
  exactly 1 real item per tick; `last_pop_time` advances by item duration
  not wall-clock elapsed
- Catch-up, safety floor, and top-up logic identical to Timed mode
- Wizard: Mode step (Timed/Duration) inserted after carousel enable;
  Interval/Pop Count steps only shown for Timed mode
- Channel Info: Duration mode shows "Duration mode — pops on item runtime"
  and next-pop estimate from current item duration
- Fully backwards-compatible: `carousel_mode` absent → "timed"
- Strings #32817–#32821 added; next free #32822
- Files changed: `carousel.py`, `ui/channels.py`, `strings.po`, `addon.xml`

---

## Changes Previous Session (1.2.1u → 1.2.2c)

### 1.2.2a — New feature: Interleave Source First
- Added `source_first` toggle to Unified Interleave per-source config
- When enabled, source channel item appears BEFORE the paired target item
  in each interleaved pair throughout the entire queue (default: target first)
- "Pair order" step added to interleave source dialog after Silent toggle
- `[src-first]` badge shown in Edit/Remove Sources list when enabled
- Fully backwards compatible — absent field defaults to False
- Strings #32811–#32814 added
- Files changed: `interleave.py`, `ui/channels.py`, `strings.po`

### 1.2.2b — Fix: hardcoded strings replaced with strings.po entries
- `player.py` lines 46-48: refill threshold warning notification title
  ("Smart TV Channels") and body ("Warning: Refill threshold...") were
  hardcoded English — repo submission blocker. Now uses
  `self.addon.getLocalizedString(32289)` for title and string #32815
  for the warning body.
- `side_panel.py` line 1179: Side Panel error notification body
  ("Side Panel error: {}") was hardcoded. Now uses string #32816.
- Full codebase audit confirmed these were the only two genuine
  hardcoded user-visible strings remaining.
- Strings #32815–#32816 added
- Files changed: `player.py`, `ui/side_panel.py`, `strings.po`

### 1.2.2c — Fix: folder.py private state access
- `folder.py` shuffle resume-pin logic was calling `self._cm._load_json`
  and `self._cm._state_path` directly (private methods) — same violation
  fixed in `audio.py` (1.2.1q)
- New public method `has_resume_for_file(channel_id, file_path)` added
  to `channel_manager.py`; `folder.py` now calls this instead
- No functional change, no strings changes, no state format changes
- Files changed: `channel_manager.py`, `channels/folder.py`

---

## Repo Submission Status

All known repo blockers are resolved:

| Item | Status |
|------|--------|
| Hardcoded user-visible strings | ✅ Fixed in 1.2.2b |
| `icon.png` (256×256 PNG) | ✅ Present |
| `fanart.jpg` (1280×720 JPEG) | ✅ Present |
| `addon.xml` — all required fields | ✅ Complete (summary, description, platform, license, forum_url, website, source, news, assets) |
| Bare `open()` calls | ✅ None found |
| No malicious code / external network calls | ✅ Confirmed |

**Remaining architectural items (not repo blockers):**
- `serial.py` — 3 instances of private `_load_json` / `_state_path` / `_state` / `_save_state` access for serial channel index tracking
- `channels.py` — several `_queue_file_path` and one `_load_json` / `_state_path` access in UI layer
- `side_panel.py` — `_queue_file_path` calls for queue display
- `schedule_wizard.py` — `_queue_file_path`, `_load_json`, `_save_json` for conflict checking

These are self-imposed architectural standards, not Kodi repo requirements.
Fix before repo submission for code quality, but not blocking.

---

## Completed Features (all confirmed stable)

- TV/Movie/Serial/Folder channel types
- Persistent queue, state management, auto top-up
- Unified Interleave (multi-source with silent flag, source_first option)
- Episode/Movie/Serial Exclusions
- Round Robin rotation
- Carousel / Pseudo Live
- Coming Up Next overlay (video + audio)
- Channel Logo Overlay (timed, 5s default)
- Side Panel (two-pane WindowXML) — song/track selection plays selected item
- Lower Third Ticker (with schedule-aware upcoming programming promos)
- Duration Cache
- Channel Scheduling (fire blocks, soft-start, Once with date targeting)
- Audio Channels (artist/album/genre/all filters, balanced shuffle, song
  exclusions, no-repeat mode)
- Party Mode (local and NAS folder audio, no-repeat mode)
- Songs Cache (26,362 songs, ~2.5 min to build, instant read after)
- Channel Sort (A-Z, Move Up/Down in Side Panel)
- Channel Info shows schedule relationships (target/source)
- Auto-Create Channels
- Backup & Restore

---

## On The Horizon

Specs written and approved — build in this order:

### 1. ~~Carousel Duration Mode~~ — ✅ DONE (1.2.3a)

### 2. Schedule Hard Start with Resume (1.2.3b or 1.2.4a) — NEXT BUILD
Spec: `SPEC_ScheduleHardStart.md`
Adds Hard Start fire mode to Channel Scheduling — block fires at exactly
the scheduled time, interrupting whatever is playing. Interrupted item is
saved and resumes after the block finishes. Per-schedule setting alongside
existing Soft Start.
Next free string ID: #32822 (spec uses #32805–#32810 — renumber from #32822 at build time).

### 3. Audio Now Playing Overlay
Spec: `SPEC_1_2_2a_AudioNowPlaying.md`
Persistent overlay during audio channel playback showing current song
metadata and upcoming tracks. Driven by service poll timer.
Build after Hard Start so service.py is stable.

### 4. ffprobe Batch NFO Scanner
Spec: `SPEC_ffprobe_batch_scanner.md`
Windows-only utility to pre-scan folder library files with ffprobe and
write companion NFOs in bulk before first playback. Low risk, no
interaction with playback or queue logic.

### 5. EPG / Live Clock (1.3.0a) — LARGEST, BUILD LAST
Spec: `SPEC_1_3_0a_LiveClock_EPG.md`
Two parts: Live Clock Channels (wall-clock timeline, tune in mid-programme)
and Multi-Channel EPG Grid (full-screen programme guide). Largest scope
of any feature in the project.

**Note on version numbers:** 1.2.2a–1.2.2c consumed by this session's
fixes. Next feature build starts at 1.2.3a.

**Note on string IDs:** Carousel Duration Mode consumed #32817–#32821.
Next free is #32822.

---

## Audio Channel Architecture Notes

### no_repeat tracking
- **Audio channels:** tracked by `songid` in `state.json` key
  `ch_<id>:audio_no_repeat_played` (list of int songid values)
- **Party channels:** tracked by file path in `state.json` key
  `ch_<id>:party_no_repeat_played` (list of file path strings)
- State I/O via public channel_manager methods only (not private _load/_save_json)
- Tracking fires in skip loop (primary path on this platform) AND in
  `_handle_end` (for platforms where `onPlayBackEnded` fires reliably)
- Requires channel created after 1.2.1o for songid/file to be present in queue items
- Full cycle reset (played list cleared) when all songs/files have been heard

### Queue items for audio/party
- Written by dedicated branch in `player.py` `_write_now_playing()`
- Fields preserved: `is_audio`, `songid`, `artist`, `album`, `genre`, `year`,
  `track`, `thumbnail`, plus all standard fields
- Party items also get `is_party_item=True`

### Recycle/Stop
- Audio channels: always recycle=True, no exhaustion tracking, Stop removed from wizard
- Party channels: always recycle=True, no exhaustion tracking, Stop removed from wizard
- Folder channels: Recycle/Stop meaningful and working — keep as-is
- TV/Movie/Serial channels: Recycle/Stop meaningful and working — keep as-is

---

## Architecture Rules (NEVER VIOLATE)

1. `service.py` owns ALL playback callbacks, state advancement, resume,
   top-up, playlist management
2. `player.py` owns ONLY `start_channel()` and `_write_now_playing()`
3. `channel_manager.py` owns queue building, state read/write, library access
4. NO duplicate code between files
5. NO playback event handlers outside `service.py`
6. No hardcoded dialog text — all user-visible strings through `strings.po`
7. All code written for Kodi official repo submission standard
8. MANDATORY strings audit before and after every change touching strings
9. One feature or fix at a time
10. Never break working functionality
11. **FAILED FIX PROTOCOL:** One "Build On Top" permitted when root cause is
    confirmed and only implementation detail was wrong. After two failed
    attempts on same bug, always Roll Back to last confirmed-working zip.
12. CHANGELOG entry written BEFORE packaging
13. **PRE-CODING CHECKLIST** (mandatory before any new function):
    - What does this function do? (one sentence)
    - Which module owns it per the boundary map?
    - Does it already exist anywhere in the codebase?
    - If yes: import it. If no: write it in the correct module only.
14. **PRIVATE ACCESS RULE:** Never call private methods (prefixed with `_`)
    on another module's class. Specifically, never call
    `channel_manager._load_json`, `._save_json`, `._state_path`,
    `._state`, `._save_state`, `._deleted_state_keys`,
    `._queue_file_path`, or `._write_queue_file` from outside
    `channel_manager.py`.
    - If you need data that requires one of these, add a public method
      to `channel_manager.py` first, then call that.
    - Pre-coding checklist addition: "Does this code call any private
      method on another class? If yes, stop and add a public method instead."

---

## Packaging Command

```bash
cd /home/claude/plugin_work/build_out && zip -0 -r \
  /mnt/user-data/outputs/plugin_video_smartchannels_VERSION.zip \
  plugin.video.smartchannels \
  --exclude "*.pyc" --exclude "*/__pycache__/*" --exclude "*/__pycache__"
```

## Rollback Command

```bash
cd /home/claude/plugin_work/build_out && rm -rf plugin.video.smartchannels && \
  unzip -q /mnt/user-data/outputs/plugin_video_smartchannels_VERSION.zip
```

## Strings Audit Script

```python
import re, glob
from collections import Counter
base = "/home/claude/plugin_work/build_out/plugin.video.smartchannels"
with open(base + "/resources/language/resource.language.en_gb/strings.po") as f:
    po = f.read()
all_ids = re.findall(r'msgctxt "#(\d+)"', po)
defined = set(int(x) for x in all_ids)
dupes = {k: v for k, v in Counter(all_ids).items() if v > 1}
code_ids = set()
for fpath in glob.glob(base + "/**/*.py", recursive=True):
    with open(fpath) as f: src = f.read()
    for m in re.findall(r'(?:getLocalizedString|_s)\s*\(\s*(\d{5})\b', src):
        code_ids.add(int(m))
with open(base + "/resources/settings.xml") as f: xml = f.read()
xml_ids = set(int(x) for x in re.findall(r'label="(\d+)"', xml))
broken = sorted((code_ids | xml_ids) - defined)
print("Duplicates:", dupes or "NONE")
print("Broken:", broken or "NONE")
print("Highest ID: #{}".format(max(defined)))
```

---

## Log Filtering

For playback events, queue operations, overlay lifecycle, carousel, scheduling,
and errors: filtered smartchannels-only log is sufficient.

For input/focus/window issues: full unfiltered log required.

Standard filter:
```bash
grep -i "smartchannel\|fire_block\|block.*item\|onPlayBack\|carousel\|scheduler\|advance_show\|no_repeat\|audio.*complet\|party.*complet" kodi.log \
  | grep -v "CAddonSettings\|playlists/video\|playlists/inprogress\|xsp\|LOCAL STORAGE"
```
