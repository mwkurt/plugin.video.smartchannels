"""
resources/lib/ui/side_panel.py
================================
Two-pane channel browser using a custom WindowXML window.

Left pane  (control 100) : Channel list.
Right pane (control 200) : Upcoming queue items for the highlighted channel.

OWNS:   Window lifecycle, focus/navigation state machine, populating both
        panes, context menu, dispatching playback via router URL actions.

NEVER:  Direct state.json or queue file writes — all queue mutations go
        through channel_manager.reorder_queue_from_item().
        Playback event handling (service.py owns that).
        Hardcoded user-visible strings — all text via self._s().

Navigation contract:
  Up/Down in left pane   → moves channel selection, updates right pane.
  Right from left pane   → focus moves to right pane (control 200).
  Left from right pane   → focus returns to left pane (control 100).
  Enter on left pane     → plays channel from queue front.
  Enter on right pane[0] → plays channel from queue front.
  Enter on right pane[N] → reorders queue so item N is first, then plays.
  C / Menu key           → context menu for focused channel (left pane only).
  Back / Escape          → closes window, returns to Kodi Home.

Fixes in 1.1.6b:
  - ActivateWindow(Home) before open/play eliminates Videos screen flash.
  - After playback stops, Kodi returns to Home not Videos hub.
  - Context menu (action 117) shows full channel options in left pane.
  - Settings action "Open Smart Channels" re-launches the addon.

XML window ID: 9700  (unused by Kodi itself and all standard skins).
"""

from __future__ import annotations

import json
import os
from urllib.parse import urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.utils.logger import log

# ---------------------------------------------------------------------------
# Kodi action IDs
# ---------------------------------------------------------------------------
ACTION_MOVE_LEFT        = 1
ACTION_MOVE_RIGHT       = 2
ACTION_MOVE_UP          = 3
ACTION_MOVE_DOWN        = 4
ACTION_SELECT_ITEM      = 7
ACTION_PREVIOUS_MENU    = 10    # Escape key
ACTION_CONTEXT_MENU     = 117   # C key / Menu button / long-press
ACTION_NAV_BACK         = 92    # Back button / Backspace

# ---------------------------------------------------------------------------
# Control IDs — must match SmartChannels_Main.xml exactly
# ---------------------------------------------------------------------------
CTRL_CHANNEL_LIST  = 100
CTRL_UPCOMING_LIST = 200
CTRL_UPCOMING_HDR  = 300
CTRL_RIGHT_GROUP   = 301
CTRL_TICKER_GROUP  = 400
CTRL_TICKER_ICON   = 401
CTRL_TICKER_PHRASE = 402
CTRL_TICKER_TITLE  = 403
CTRL_TICKER_CHAN   = 404

# ---------------------------------------------------------------------------
# String IDs
# ---------------------------------------------------------------------------
_S_PLAY_CHANNEL   = 32648   # "> Play"  (label2 = channel name at runtime)
_S_UPCOMING       = 32649   # "Upcoming"
_S_NO_ITEMS       = 32650   # "No items in queue"
_S_SEP_EP         = 32652   # "S{0}E{1} — {2}"
_S_MOVIE_YEAR     = 32653   # "{0} ({1})"

# Ticker string IDs
_S_NOW_PLAYING_ON  = 32673   # "Now Playing on"

# Context menu string IDs — reuse existing strings from channels.py
_S_CTX_CHANNEL_INFO    = 32383
_S_CTX_PLAY            = 32204
_S_CTX_EDIT            = 32205
_S_CTX_RESET           = 32331
_S_CTX_DELETE          = 32206
_S_CTX_INTERLEAVE      = 32208
_S_CTX_VIEW_EXCL       = 32578
_S_CTX_ADD_SCHEDULE    = 32686   # "Add Schedule" (1.1.9a)
_S_CTX_MOVE_UP         = 32738   # "Move Up"
_S_CTX_MOVE_DOWN       = 32739   # "Move Down"

# Reset confirmation strings (same as router.py uses)
_S_RESET_CONFIRM       = 32332   # "Reset {0}?"
_S_RESET_DONE          = 32333   # "{0} reset"
_S_ADDON_NAME          = 32289   # "Smart TV Channels"

# Plugin base URL
_PLUGIN_URL = "plugin://plugin.video.smartchannels/"


def _url(**kwargs):
    """Build a plugin:// URL for RunPlugin / RunAddon calls."""
    return "{}?{}".format(_PLUGIN_URL, urlencode(kwargs))


def _resolve_skin_xml(addon_path):
    """
    Return the path to SmartChannels_Main.xml for the active Kodi skin.

    Search order:
      1. resources/skins/<active_skin_id>/<res>/SmartChannels_Main.xml
      2. resources/skins/Default/1080i/SmartChannels_Main.xml  (fallback)

    <res> is 720p for Confluence, 1080i for everything else.
    """
    skin_id  = xbmc.getSkinDir()
    res      = "720p" if skin_id == "skin.confluence" else "1080i"
    specific = os.path.join(
        addon_path, "resources", "skins", skin_id, res,
        "SmartChannels_Main.xml")
    if xbmcvfs.exists(specific):
        log("[SidePanel] Using skin-specific XML: {}".format(specific))
        return specific

    fallback = os.path.join(
        addon_path, "resources", "skins", "Default", "1080i",
        "SmartChannels_Main.xml")
    log("[SidePanel] Using fallback XML: {}".format(fallback))
    return fallback


class SmartChannelsSidePanel(xbmcgui.WindowXML):
    """
    Two-pane channel browser.

    Instantiated and shown by open_side_panel() below.
    """

    def __new__(cls, xml_file, addon_path, addon, manager):
        return super().__new__(cls, xml_file, addon_path)

    def __init__(self, xml_file, addon_path, addon, manager):
        self._addon          = addon
        self._addon_path     = addon_path
        self._manager        = manager
        self._channels       = []    # visible channel dicts
        self._panel_data     = []    # items shown in right pane
        self._current_ch_idx = 0     # highlighted channel index
        self._panel_focused  = False # True when focus is in right pane

        # Ticker state
        self._ticker_items   = []    # list of (phrase_line, title, icon)
        self._ticker_idx     = 0     # current rotation position
        self._ticker_thread  = None  # background rotation thread
        self._ticker_stop    = None  # threading.Event to signal stop
        self._ticker_enabled = False # set from setting in onInit

    # ── Kodi WindowXML lifecycle ───────────────────────────────────────────

    def onInit(self):
        """Called by Kodi when the window is ready to render."""
        log("[SidePanel] onInit")
        self._channels = self._manager.get_visible_channels()
        self._populate_channel_list()
        if self._channels:
            self._populate_panel(self._channels[0])

        # Ticker — only when side panel is enabled AND show_ticker is on
        self._ticker_enabled = (
            self._addon.getSetting("use_side_panel") == "true"
            and self._addon.getSetting("show_ticker") == "true"
        )
        if self._ticker_enabled:
            self._ticker_items = self._build_ticker_items()
            if self._ticker_items:
                self._show_ticker_item(0)
                self._start_ticker_thread()
            else:
                # No items — hide the ticker group
                try:
                    self.getControl(CTRL_TICKER_GROUP).setVisible(False)
                except Exception:
                    pass
        else:
            try:
                self.getControl(CTRL_TICKER_GROUP).setVisible(False)
            except Exception:
                pass

    def onAction(self, action):
        """Handle navigation, back, and context menu."""
        action_id = action.getId()

        # Always sync _panel_focused from Kodi's actual focus state.
        # This corrects any de-sync from mouse clicks or skin focus
        # changes that don't fire onFocus reliably (issue 6).
        focused_ctrl = self.getFocusId()
        if focused_ctrl == CTRL_CHANNEL_LIST:
            self._panel_focused = False
        elif focused_ctrl == CTRL_UPCOMING_LIST:
            self._panel_focused = True

        # ── Back / Escape → close and go Home ─────────────────────────────
        if action_id in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            log("[SidePanel] Back/Escape — closing window")
            self._stop_ticker_thread()
            self.close()
            xbmc.executebuiltin("ActivateWindow(Home)")
            return

        # ── Context menu — left pane only ─────────────────────────────────
        if action_id == ACTION_CONTEXT_MENU and not self._panel_focused:
            self._show_context_menu()
            return

        # ── Right arrow: left pane → right pane ───────────────────────────
        if action_id == ACTION_MOVE_RIGHT and not self._panel_focused:
            if self._panel_data:
                self.setFocusId(CTRL_UPCOMING_LIST)
                self._panel_focused = True
            return

        # ── Left arrow: right pane → left pane ────────────────────────────
        if action_id == ACTION_MOVE_LEFT and self._panel_focused:
            self.setFocusId(CTRL_CHANNEL_LIST)
            self._panel_focused = False
            return

        # ── Up/Down in left pane — update right pane ──────────────────────
        if action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN):
            if not self._panel_focused:
                xbmc.sleep(50)
                ctrl    = self.getControl(CTRL_CHANNEL_LIST)
                new_idx = ctrl.getSelectedPosition()
                if new_idx != self._current_ch_idx:
                    self._current_ch_idx = new_idx
                    if new_idx < len(self._channels):
                        self._populate_panel(self._channels[new_idx])

    def onFocus(self, control_id):
        """Track which pane is active."""
        if control_id == CTRL_CHANNEL_LIST:
            self._panel_focused = False
        elif control_id == CTRL_UPCOMING_LIST:
            self._panel_focused = True

    def onClick(self, control_id):
        """Handle Enter on either pane."""
        if control_id == CTRL_CHANNEL_LIST:
            ctrl = self.getControl(CTRL_CHANNEL_LIST)
            idx  = ctrl.getSelectedPosition()
            if idx < len(self._channels):
                ch = self._channels[idx]
                log("[SidePanel] onClick channel: playing '{}'".format(
                    ch.get("name")))
                self._play_channel(ch["id"])

        elif control_id == CTRL_UPCOMING_LIST:
            ctrl = self.getControl(CTRL_UPCOMING_LIST)
            idx  = ctrl.getSelectedPosition()
            if idx < 0 or idx >= len(self._panel_data):
                return

            item = self._panel_data[idx]

            if item.get("_is_play_button"):
                ch_idx = self._current_ch_idx
                if ch_idx < len(self._channels):
                    self._play_channel(self._channels[ch_idx]["id"])
            else:
                ch_idx = self._current_ch_idx
                if ch_idx < len(self._channels):
                    ch = self._channels[ch_idx]
                    log("[SidePanel] onClick upcoming[{}]: '{}' in '{}'".format(
                        idx, item.get("title", "?"), ch.get("name")))
                    # Use the raw queue file index stamped at populate time.
                    # This is correct even when silent items precede this
                    # item in the queue and shift panel vs raw positions apart.
                    raw_queue_index = item.get("_raw_queue_index", idx - 1)
                    self._play_from_item(ch["id"], item, raw_queue_index)

    # ── Context menu ──────────────────────────────────────────────────────

    def _show_context_menu(self):
        """
        Show a Dialog().select() with the same options as the standard
        channel list context menu.
        Only available when focus is in the left pane.

        Action handling strategy:
          play_channel       → _play_channel() directly (no RunPlugin)
          reset_channel      → manager.reset_channel() directly, then
                               refresh right pane immediately (synchronous,
                               no RunPlugin race condition)
          channel_info       → RunPlugin, keep panel open (shows a dialog,
                               no panel state change needed after)
          view_exclusions    → RunPlugin, keep panel open (same)
          delete_channel     → RunPlugin, relaunch addon after
          edit_channel       → RunPlugin, relaunch addon after
          manage_interleave  → RunPlugin, relaunch addon after
        """
        # Use getFocusId() as ground truth — corrects any _panel_focused
        # de-sync from mouse clicks or skin focus changes (issue 6).
        if self.getFocusId() != CTRL_CHANNEL_LIST:
            return

        ctrl = self.getControl(CTRL_CHANNEL_LIST)
        idx  = ctrl.getSelectedPosition()
        if idx < 0 or idx >= len(self._channels):
            return

        ch           = self._channels[idx]
        channel_id   = ch["id"]
        channel_type = ch.get("channel_type", "tv")

        options = [
            (self._s(_S_CTX_CHANNEL_INFO),  "channel_info"),
            (self._s(_S_CTX_PLAY),          "play_channel"),
            (self._s(_S_CTX_EDIT),          "edit_channel"),
            (self._s(_S_CTX_RESET),         "reset_channel"),
            (self._s(_S_CTX_DELETE),        "delete_channel"),
            (self._s(32665),                "set_channel_icon"),
            (self._s(_S_CTX_MOVE_UP),       "move_channel_up"),
            (self._s(_S_CTX_MOVE_DOWN),     "move_channel_down"),
        ]
        if channel_type not in ("audio", "party"):
            options.append(
                (self._s(_S_CTX_ADD_SCHEDULE), "add_schedule"))
        if channel_type not in ("audio", "party", "serial"):
            options.append(
                (self._s(_S_CTX_INTERLEAVE), "manage_interleave"))
        if channel_type in ("tv", "serial", "movies"):
            options.append(
                (self._s(_S_CTX_VIEW_EXCL),  "view_exclusions"))
        # Missing Durations — only shown when entries exist
        _missing = self._manager.get_missing_durations(channel_id)
        if _missing:
            options.append(
                (self._s(32668).format(len(_missing)),
                 "view_missing_durations"))

        labels = [o[0] for o in options]
        choice = xbmcgui.Dialog().select(ch.get("name", ""), labels)
        if choice < 0:
            return

        action_name = options[choice][1]
        log("[SidePanel] context menu: {}".format(action_name))

        # ── Play Channel ──────────────────────────────────────────────────
        if action_name == "play_channel":
            self._play_channel(channel_id)

        # ── Reset Channel — call manager directly, refresh right pane ────
        elif action_name == "reset_channel":
            confirmed = xbmcgui.Dialog().yesno(
                self._s(_S_CTX_RESET),
                self._s(32332).format(ch["name"]))
            if confirmed:
                self._manager.reset_channel(channel_id)
                xbmcgui.Dialog().notification(
                    self._s(_S_ADDON_NAME),
                    self._s(32333).format(ch["name"]),
                    xbmcgui.NOTIFICATION_INFO, 2000)
                # Queue is now rebuilt on disk — refresh right pane
                # immediately without closing the panel. No sleep needed
                # because reset_channel() is synchronous.
                self._refresh_panel(idx)

        # ── Move Up / Move Down — reorder channel list in place ───────────
        elif action_name in ("move_channel_up", "move_channel_down"):
            if action_name == "move_channel_up":
                self._manager.move_channel_up(channel_id)
                new_idx = max(0, idx - 1)
            else:
                self._manager.move_channel_down(channel_id)
                new_idx = min(len(self._channels) - 1, idx + 1)
            self._refresh_after_list_change(new_idx)

        # ── Channel Info / View Exclusions — RunPlugin, keep panel open ───
        elif action_name in ("channel_info", "view_exclusions",
                             "set_channel_icon"):
            plugin_url = _url(action=action_name, channel_id=channel_id)
            xbmc.executebuiltin("RunPlugin({})".format(plugin_url))
            # set_channel_icon updates channels.json — refresh icon in list
            if action_name == "set_channel_icon":
                self._manager.reload_channels()
                self._channels = self._manager.get_visible_channels()
                self._populate_channel_list()

        elif action_name == "view_missing_durations":
            self._show_missing_durations_dialog(channel_id, ch)

        # ── Edit Channel / Manage Interleave — fire RunPlugin without
        # closing the panel. Wizard dialogs stack on top of the panel
        # (they use xbmcgui.Dialog(), not doModal()) and the panel
        # stays open underneath. After the wizard completes or is
        # ── Edit / Manage Interleave — call wizard directly on this thread
        # so changes are visible immediately without re-entering the addon.
        # RunPlugin is non-blocking; the wizard would complete in a separate
        # invoker and this manager instance would never see the disk changes.
        elif action_name in ("edit_channel", "manage_interleave"):
            from resources.lib.ui.channels import ChannelUI
            _ui = ChannelUI(
                handle=-1,
                base_url="plugin://plugin.video.smartchannels/",
                addon=self._addon,
                manager=self._manager)
            if action_name == "edit_channel":
                _ui.edit_channel_wizard({"channel_id": channel_id})
            else:
                _ui.manage_interleave_dialog({"channel_id": channel_id})
            # Wizard ran synchronously — reload disk state and repaint.
            self._manager.reload_channels()
            self._channels = self._manager.get_visible_channels()
            self._populate_channel_list()
            safe_idx = min(idx, len(self._channels) - 1) \
                if self._channels else 0
            self._current_ch_idx = safe_idx
            if self._channels:
                self._populate_panel(self._channels[safe_idx])

        # ── Add Schedule — run wizard directly on this thread ─────────────
        elif action_name == "add_schedule":
            from resources.lib.ui.schedule_wizard import ScheduleWizard
            _wizard = ScheduleWizard(
                self._addon, self._manager,
                existing=None,
                target_channel_id=channel_id)
            result = _wizard.run()
            if result:
                self._manager.add_schedule(result)
                xbmcgui.Dialog().notification(
                    self._s(_S_ADDON_NAME),
                    self._s(32696),   # "Schedule saved."
                    xbmcgui.NOTIFICATION_INFO, 2000)

        # ── Delete Channel — call manager directly so we can refresh
        # the channel list immediately without timing guesses.
        elif action_name == "delete_channel":
            confirmed = xbmcgui.Dialog().yesno(
                self._s(_S_ADDON_NAME),
                self._s(32216))
            if confirmed:
                self._manager.delete_channel(channel_id)
                xbmcgui.Dialog().notification(
                    self._s(_S_ADDON_NAME),
                    self._s(32210),
                    xbmcgui.NOTIFICATION_INFO, 2000)
                self._refresh_after_list_change(
                    max(0, idx - 1) if idx > 0 else 0)

        # ── Any other unhandled action — fire via RunPlugin ───────────────
        else:
            plugin_url = _url(action=action_name, channel_id=channel_id)
            xbmc.executebuiltin("RunPlugin({})".format(plugin_url))

    def _refresh_panel(self, ch_idx):
        """
        Refresh the right pane for the channel at ch_idx.
        Called after reset_channel — the queue is already rebuilt on disk.
        """
        if not self._channels or ch_idx >= len(self._channels):
            return
        self._current_ch_idx = ch_idx
        self._populate_panel(self._channels[ch_idx])

    def _refresh_after_list_change(self, prev_idx):
        """
        Refresh both panes after a visibility toggle.
        Handles the edge case where the channel list becomes empty (issue 5).
        """
        self._channels = self._manager.get_visible_channels()
        self._populate_channel_list()

        if not self._channels:
            # List is empty — clear right pane
            self._current_ch_idx = 0
            self._panel_data     = []
            ctrl = self.getControl(CTRL_UPCOMING_LIST)
            ctrl.reset()
            hdr = self.getControl(CTRL_UPCOMING_HDR)
            hdr.setLabel(self._s(_S_UPCOMING))
            return

        safe_idx = min(prev_idx, len(self._channels) - 1)
        self._current_ch_idx = safe_idx
        self._populate_panel(self._channels[safe_idx])

    # ── Pane population ───────────────────────────────────────────────────

    def _populate_channel_list(self):
        """Fill the left pane with all visible (or all) channels."""
        ctrl = self.getControl(CTRL_CHANNEL_LIST)
        ctrl.reset()

        for ch in self._channels:
            name = ch["name"]

            li = xbmcgui.ListItem(label=name)
            li.setArt({"icon": self._manager.resolve_channel_icon(ch)})
            ctrl.addItem(li)

        log("[SidePanel] channel list: {} channels".format(
            len(self._channels)))

    def _populate_panel(self, channel):
        """Fill the right pane with upcoming items for the given channel."""
        ctrl     = self.getControl(CTRL_UPCOMING_LIST)
        hdr_ctrl = self.getControl(CTRL_UPCOMING_HDR)
        ctrl.reset()
        self._panel_data = []

        hdr_ctrl.setLabel(
            self._s(_S_UPCOMING) + "  —  " + channel.get("name", ""))

        # Load queue file
        q_path = self._manager._queue_file_path(channel["id"])
        queue  = []
        try:
            if xbmcvfs.exists(q_path):
                with xbmcvfs.File(q_path, "r") as f:
                    raw = f.read()
                if raw:
                    queue = json.loads(raw)
        except Exception as e:
            log("[SidePanel] _populate_panel read error: {}".format(e))

        # Number of items to show
        try:
            n = int(self._addon.getSetting("num_upcoming_programs") or "10")
            n = max(1, min(n, 30))
        except Exception:
            n = 10

        # ▶ Play Channel — always first
        _ch_icon = self._manager.resolve_channel_icon(channel)
        play_li = xbmcgui.ListItem(
            label=self._s(_S_PLAY_CHANNEL),
            label2=channel.get("name", ""))
        play_li.setArt({"icon": _ch_icon, "thumb": _ch_icon})
        ctrl.addItem(play_li)
        self._panel_data.append({"_is_play_button": True})

        if not queue:
            empty_li = xbmcgui.ListItem(
                label=self._s(_S_NO_ITEMS), label2="")
            ctrl.addItem(empty_li)
            self._panel_data.append({"_is_no_items": True})
            return

        ch_type  = channel.get("channel_type", "tv")
        visible  = 0

        # Build poster lookup from library cache — keyed by tvshowid/movieid.
        # Done once here (in-memory dict comprehension) so _format_queue_item
        # can resolve posters with a simple dict.get() — no RPC calls per item.
        try:
            _shows  = self._manager.library.get_all_tvshows()
            _movies = self._manager.library.get_all_movies()
            _show_poster  = {s["tvshowid"]: s.get("poster", "")
                             for s in _shows}
            _movie_poster = {m["movieid"]:  m.get("poster", "")
                             for m in _movies}
        except Exception:
            _show_poster  = {}
            _movie_poster = {}

        for raw_idx, item in enumerate(queue):
            if visible >= n:
                break
            # Silent interleave items are tagged _silent: True — they must
            # never appear in the upcoming list, same as Coming Up Next.
            if item.get("_silent"):
                continue
            label, label2, thumb = self._format_queue_item(
                item, ch_type, _show_poster, _movie_poster)
            li = xbmcgui.ListItem(label=label, label2=label2)
            if thumb:
                li.setArt({"thumb": thumb})
            ctrl.addItem(li)
            # Stamp the raw queue file index onto the item so onClick can
            # pass the correct position to reorder_queue_from_item regardless
            # of how many silent items were skipped before this one.
            item_copy = dict(item)
            item_copy["_raw_queue_index"] = raw_idx
            self._panel_data.append(item_copy)
            visible += 1

        log("[SidePanel] right pane: {} visible items for '{}'".format(
            visible, channel.get("name")))

    def _format_queue_item(self, item, ch_type,
                           show_poster=None, movie_poster=None):
        """Return (label, label2, thumb) for a single queue item.

        show_poster  — {tvshowid: poster_url} built once per _populate_panel
        movie_poster — {movieid:  poster_url} built once per _populate_panel
        Falls back to item thumbnail if no poster found in lookup.
        """
        from resources.lib.utils.duration_cache import format_duration as _fmt_dur

        show_poster  = show_poster  or {}
        movie_poster = movie_poster or {}

        duration_str = _fmt_dur(int(item.get("duration", 0) or 0))

        is_movie = (item.get("is_movie")
                    or item.get("movieid", -1) > 0
                    or ch_type == "movies")
        is_folder = (ch_type == "folder"
                     and not is_movie
                     and not item.get("episodeid"))

        if is_movie:
            label  = item.get("title", "")
            year   = item.get("year", "")
            parts  = [str(year)] if year else []
            if duration_str:
                parts.append(duration_str)
            label2 = " · ".join(parts)
            thumb  = (movie_poster.get(item.get("movieid", -1), "")
                      or item.get("thumbnail") or item.get("thumb") or "")
        elif is_folder:
            raw   = item.get("file", item.get("label", ""))
            fname = raw.rstrip("/").rstrip("\\").rsplit("/", 1)[-1]
            fname = fname.rsplit("\\", 1)[-1]
            label  = os.path.splitext(fname)[0]
            label2 = duration_str
            thumb  = item.get("thumbnail") or item.get("thumb") or ""
        else:
            label  = item.get("tvshowtitle", "")
            ep_str = self._s(_S_SEP_EP).format(
                item.get("season", 0),
                item.get("episode", 0),
                item.get("title", ""))
            label2 = "{} · {}".format(ep_str, duration_str) \
                     if duration_str else ep_str
            thumb  = (show_poster.get(item.get("show_id") or item.get("_show_id", -1), "")
                      or item.get("thumbnail") or item.get("thumb") or "")

        return label, label2, thumb

    # ── Missing Durations dialog ───────────────────────────────────────────

    def _show_missing_durations_dialog(self, channel_id: str,
                                       channel: dict) -> None:
        """
        Show a scrollable list of items skipped due to missing NFO duration.
        Bottom option is Clear List (with yesno confirmation).
        Only shown when the list is non-empty — caller already checked.
        """
        missing = self._manager.get_missing_durations(channel_id)
        if not missing:
            return

        # Build display labels
        items = []
        for m in missing:
            show  = m.get("show", "")
            title = m.get("title", "")
            ep    = m.get("episode", "")
            label = " — ".join(filter(None, [show, ep, title])) or \
                    m.get("file", "")
            file_ = m.get("file", "")
            items.append((label, file_))

        # Append Clear List option
        clear_label = self._s(32669)
        labels      = [i[0] for i in items] + [clear_label]

        choice = xbmcgui.Dialog().select(
            self._s(32668).format(len(missing)), labels)

        if choice < 0:
            return

        if choice == len(items):
            # Clear List
            confirmed = xbmcgui.Dialog().yesno(
                self._s(32668).format(len(missing)),
                self._s(32670))
            if confirmed:
                self._manager.clear_missing_durations(channel_id)
                xbmcgui.Dialog().notification(
                    channel.get("name", ""),
                    self._s(32671),
                    xbmcgui.NOTIFICATION_INFO, 3000)

    # ── Playback dispatch ─────────────────────────────────────────────────

    def _play_channel(self, channel_id):
        """
        Play channel from queue front.
        Move to Home first so Kodi returns to Home (not Videos hub)
        when playback stops.
        """
        log("[SidePanel] _play_channel id={}".format(channel_id))
        self._stop_ticker_thread()
        self.close()
        xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.sleep(200)
        xbmc.executebuiltin(
            "RunPlugin({})".format(_url(action="play_channel",
                                        channel_id=channel_id)))

    def _play_from_item(self, channel_id, item, queue_index):
        """
        Reorder queue so selected item is at position 0, then play.
        Items before it move to the tail — service.py skip detection
        advances their state naturally, identical to playlist skipping.
        """
        log("[SidePanel] _play_from_item channel={} queue_index={}".format(
            channel_id, queue_index))

        if queue_index <= 0:
            self._play_channel(channel_id)
            return

        try:
            ok = self._manager.reorder_queue_from_item(channel_id, queue_index)
            if not ok:
                log("[SidePanel] reorder failed — falling back to front")
        except Exception as e:
            log("[SidePanel] _play_from_item error: {}".format(e))

        self.close()
        xbmc.executebuiltin("ActivateWindow(Home)")
        xbmc.sleep(200)
        xbmc.executebuiltin(
            "RunPlugin({})".format(_url(action="play_channel",
                                        channel_id=channel_id)))

    # ── Lower Third Ticker ────────────────────────────────────────────────

    # Default phrase sets written to ticker_phrases.txt on first open.
    _DEFAULT_NEXT_PHRASES = [
        "Up Next on",
        "Coming up on",
        "Stay tuned for",
        "Next on",
        "Catch it on",
        "Don't miss",
    ]
    _DEFAULT_PROMO_PHRASES = [
        "Catch {show} on",
        "Don't miss {show} on",
        "Watch {show} on",
        "{show} — now on",
        "{channel} presents {show}",
        "Coming up on {channel}:",
    ]

    def _ticker_phrases_path(self):
        """Return the path to ticker_phrases.txt in the resolved storage root."""
        return self._manager._resolve_path("ticker_phrases.txt")

    def _load_ticker_phrases(self):
        """
        Load next/promo phrases from ticker_phrases.txt.
        Creates the file with defaults if absent.
        Returns (next_phrases, promo_phrases) — both are non-empty lists.
        """
        path = self._ticker_phrases_path()
        next_phrases  = []
        promo_phrases = []

        if xbmcvfs.exists(path):
            try:
                with xbmcvfs.File(path, "r") as f:
                    content = f.read()
                section = None
                for raw_line in content.splitlines():
                    line = raw_line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if line.lower() == "[next]":
                        section = "next"
                    elif line.lower() == "[promo]":
                        section = "promo"
                    elif section == "next":
                        next_phrases.append(line)
                    elif section == "promo":
                        promo_phrases.append(line)
                log("[SidePanel] Ticker phrases loaded: {} next, {} promo".format(
                    len(next_phrases), len(promo_phrases)))
            except Exception as e:
                log("[SidePanel] ticker_phrases.txt read error: {}".format(e))

        # Fall back to defaults for any empty section
        if not next_phrases:
            next_phrases = list(self._DEFAULT_NEXT_PHRASES)
        if not promo_phrases:
            promo_phrases = list(self._DEFAULT_PROMO_PHRASES)

        # Write file if it didn't exist (first open)
        if not xbmcvfs.exists(path):
            self._write_default_phrases(path)

        return next_phrases, promo_phrases

    def _write_default_phrases(self, path):
        """Write the default ticker_phrases.txt to disk."""
        lines = [
            "# Smart TV Channels — Ticker Phrases",
            "# One phrase per line. Lines starting with # are comments.",
            "# {show} = show/movie title  {channel} = channel name",
            "#",
            "# Next-item phrases: shown with the next queued item on a channel.",
            "",
            "[next]",
        ] + self._DEFAULT_NEXT_PHRASES + [
            "",
            "# Show/movie promo phrases: shown with a random title from the channel.",
            "# Use {show} and {channel} tokens — both are substituted at runtime.",
            "",
            "[promo]",
        ] + self._DEFAULT_PROMO_PHRASES + [""]
        try:
            with xbmcvfs.File(path, "w") as f:
                f.write("\n".join(lines))
            log("[SidePanel] ticker_phrases.txt created at {}".format(path))
        except Exception as e:
            log("[SidePanel] ticker_phrases.txt write error: {}".format(e))

    def _build_ticker_items(self):
        """
        Build the list of ticker entries to rotate through.

        For each visible channel produces two candidate entries:
          1. Next-item  — item[0] from queue file + random next phrase
          2. Show promo — random show/movie from channel config + random
                          promo phrase with {show}/{channel} substituted

        Currently-playing channel always gets "Now Playing on" for its
        next-item entry (factually accurate — item[0] is in progress).

        Returns list of (phrase_line, title, icon).
          phrase_line — gold label text: phrase + " — " + channel name, or
                        phrase with {channel} substituted if template had it.
                        Never contains the show/movie title.
          title       — white label text: show/movie title only. Never
                        contains the channel name or phrase text.
          icon        — channel icon path (may be empty string).
        Control 404 is always set to empty — channel lives in phrase_line.
        """
        import random as _random

        next_phrases, promo_phrases = self._load_ticker_phrases()

        # Detect currently-playing channel from now_playing.json
        playing_channel_id = ""
        try:
            np_path = self._manager._resolve_path("now_playing.json")
            if xbmcvfs.exists(np_path):
                with xbmcvfs.File(np_path, "r") as f:
                    np_data = json.loads(f.read())
                playing_channel_id = np_data.get("active_channel_id", "")
        except Exception:
            pass

        # Build per-channel next-item and promo buckets.
        next_items  = {}   # ch_id -> (phrase, title, ch_name, icon)
        promo_items = {}   # ch_id -> (phrase, title, ch_name, icon)

        for ch in self._channels:
            ch_id   = ch["id"]
            ch_name = ch.get("name", "")
            ch_type = ch.get("channel_type", "tv")
            icon    = self._manager.resolve_channel_icon(ch)
            is_playing = (ch_id == playing_channel_id)

            # ── Next-item ────────────────────────────────────────────────
            q_path = self._manager._queue_file_path(ch_id)
            next_title = ""
            try:
                if xbmcvfs.exists(q_path):
                    with xbmcvfs.File(q_path, "r") as f:
                        raw = f.read()
                    if raw:
                        queue = json.loads(raw)
                        for q_item in queue:
                            if not q_item.get("_silent"):
                                if q_item.get("is_movie") or q_item.get("movieid", -1) > 0:
                                    next_title = q_item.get("title", "")
                                elif q_item.get("is_audio"):
                                    artist = q_item.get("artist", "")
                                    title  = q_item.get("title", "")
                                    next_title = "{} \u2014 {}".format(artist, title) if artist else title
                                else:
                                    show  = q_item.get("tvshowtitle", "")
                                    title = q_item.get("title", "")
                                    next_title = show if show else title
                                break
            except Exception as e:
                log("[SidePanel] ticker queue read error for {}: {}".format(ch_id, e))

            if next_title:
                if is_playing:
                    raw_phrase = self._s(_S_NOW_PLAYING_ON)
                else:
                    raw_phrase = _random.choice(next_phrases)
                # Channel name always on the phrase line, never in 404
                phrase_line = "{} \u2014 {}".format(raw_phrase, ch_name)
                next_items[ch_id] = (phrase_line, next_title, icon)

            # ── Show promo ───────────────────────────────────────────────
            promo_title = ""
            if ch_type in ("tv", "serial"):
                shows = ch.get("shows", [])
                if shows:
                    show_entry = _random.choice(shows)
                    try:
                        sid = show_entry.get("tvshowid", -1)
                        all_shows = self._manager.library.get_all_tvshows()
                        match = next(
                            (s for s in all_shows if s.get("tvshowid") == sid), None)
                        if match:
                            promo_title = match.get("title", "")
                    except Exception:
                        pass
            elif ch_type == "movies":
                movies = ch.get("movies", [])
                if movies:
                    movie_entry = _random.choice(movies)
                    try:
                        mid = movie_entry.get("movieid", -1)
                        all_movies = self._manager.library.get_all_movies()
                        match = next(
                            (m for m in all_movies if m.get("movieid") == mid), None)
                        if match:
                            promo_title = match.get("title", "")
                    except Exception:
                        pass
            elif ch_type == "folder":
                folder_path = ch.get("folder_path", "")
                if folder_path:
                    name = folder_path.rstrip("/").rstrip("\\").rsplit("/", 1)[-1]
                    name = name.rsplit("\\", 1)[-1].replace("%20", " ")
                    promo_title = name

            if promo_title:
                raw_phrase = _random.choice(promo_phrases)
                # If template contains {show}, strip it — title lives in 403 only.
                # If template contains {channel}, substitute it — channel is already
                # in the phrase line, don't append again.
                # If template contains neither, append " — ch_name" to phrase line.
                has_channel = "{channel}" in raw_phrase
                # Always remove {show} from phrase — title is always in 403
                phrase_line = raw_phrase.replace("{show}", "").strip(" :—-")
                if has_channel:
                    phrase_line = phrase_line.replace("{channel}", ch_name)
                else:
                    phrase_line = "{} \u2014 {}".format(phrase_line, ch_name)
                promo_items[ch_id] = (phrase_line, promo_title, icon)

        # Build interleaved pairs: [next, promo] per channel, shuffle pairs,
        # then flatten so no two entries for the same channel are adjacent.
        all_ch_ids = list(set(list(next_items.keys()) + list(promo_items.keys())))
        _random.shuffle(all_ch_ids)

        flat = []
        for ch_id in all_ch_ids:
            n = next_items.get(ch_id)
            p = promo_items.get(ch_id)
            if n:
                flat.append(n)
            if p:
                flat.append(p)

        # ── Schedule promos ──────────────────────────────────────────────
        # For each active schedule firing within the next 24 hours, add a
        # ticker entry on the TARGET channel: e.g.
        #   phrase_line: "Tonight at 8:00 PM — Comedy TV"
        #   title:       "Til Death (4 episodes)"
        # Only fires if the target channel is visible and the schedule is
        # active and not already fired today.
        try:
            import datetime as _dt
            _now        = _dt.datetime.now()
            _today_dow  = _now.weekday()   # 0=Mon
            _dow_names  = ["monday","tuesday","wednesday","thursday",
                           "friday","saturday","sunday"]
            _weekdays   = {"monday","tuesday","wednesday","thursday","friday"}
            _weekends   = {"saturday","sunday"}
            _schedules  = self._manager.get_all_schedules()

            # Build ch_id → name map for visible channels
            _ch_map = {c["id"]: c for c in self._channels}

            for _sch_id, _sch in _schedules.items():
                if not _sch.get("active", False):
                    continue
                _target_id = _sch.get("target_channel", "")
                if _target_id not in _ch_map:
                    continue

                # Check if schedule fires today or tomorrow within 24 hours
                _day_str    = _sch.get("day", "").lower()
                _time_str   = _sch.get("time", "00:00")
                _today_name = _dow_names[_today_dow]
                _tom_name   = _dow_names[(_today_dow + 1) % 7]
                _fires_today = (
                    _day_str == "daily"
                    or (_day_str == "weekdays" and _today_name in _weekdays)
                    or (_day_str == "weekends" and _today_name in _weekends)
                    or _day_str == _today_name
                )
                _fires_tomorrow = (
                    _day_str == "daily"
                    or (_day_str == "weekdays" and _tom_name in _weekdays)
                    or (_day_str == "weekends" and _tom_name in _weekends)
                    or _day_str == _tom_name
                )

                # Skip if already fired today
                _last = _sch.get("last_fired", 0)
                if _last:
                    _last_dt = _dt.datetime.fromtimestamp(_last)
                    if _last_dt.date() == _now.date():
                        continue

                # Parse fire time for display
                try:
                    _h, _m = (int(x) for x in _time_str.split(":"))
                    _fire_dt = _now.replace(
                        hour=_h, minute=_m, second=0, microsecond=0)
                    _ampm = "AM" if _h < 12 else "PM"
                    _h12  = _h % 12 or 12
                    _time_label = "{:d}:{:02d} {}".format(_h12, _m, _ampm)
                except Exception:
                    _time_label = _time_str

                if _fires_today and _fire_dt > _now:
                    # Fires later today
                    _phrase_line = "{} \u2014 {}".format(
                        self._s(32789).format(_time_label),
                        _ch_map[_target_id].get("name", ""))
                elif _fires_tomorrow:
                    # Fires tomorrow
                    _phrase_line = "{} \u2014 {}".format(
                        self._s(32790).format(_time_label),
                        _ch_map[_target_id].get("name", ""))
                else:
                    # Fires on a named day in the future
                    _day_labels = {
                        "monday": self._s(32718), "tuesday": self._s(32719),
                        "wednesday": self._s(32720), "thursday": self._s(32721),
                        "friday": self._s(32722), "saturday": self._s(32723),
                        "sunday": self._s(32724), "weekdays": self._s(32725),
                        "weekends": self._s(32726), "daily": "Daily",
                    }
                    _day_label = _day_labels.get(_day_str, _day_str.capitalize())
                    _phrase_line = "{} \u2014 {}".format(
                        self._s(32791).format(_day_label, _time_label),
                        _ch_map[_target_id].get("name", ""))

                # Title: schedule name + item count
                _src_id   = _sch.get("source_channel", "")
                _src_ch   = self._manager.get_channel(_src_id)
                _src_name = _src_ch.get("name", "") if _src_ch else ""
                _count    = int(_sch.get("item_count", 0))
                _sch_name = _sch.get("name", "")
                _title    = "{} ({} ep{}{})".format(
                    _sch_name,
                    _count,
                    "s" if _count != 1 else "",
                    " from {}".format(_src_name) if _src_name else "")
                _icon = self._manager.resolve_channel_icon(
                    _ch_map[_target_id])
                flat.append((_phrase_line, _title, _icon))

        except Exception as _se:
            log("[SidePanel] Ticker schedule promo error: {}".format(_se))

        # Log each item for diagnostics
        for i, (phrase_line, title, _icon) in enumerate(flat):
            log("[SidePanel][Ticker] #{} | {} | {}".format(i + 1, phrase_line, title))

        log("[SidePanel] Ticker built {} items".format(len(flat)))
        return flat

    def _show_ticker_item(self, idx):
        """
        Update the ticker controls to display items[idx].
        Safe to call from the background thread — uses setLabel/setImage
        which are thread-safe in Kodi.

        Tuple format: (phrase_line, title, icon)
          phrase_line — gold label (402): phrase + channel name, e.g.
                        "Up Next on — Comedy TV" or "Comedy TV presents"
          title       — white label (403): show/movie title only
          icon        — channel icon path for control 401
        Control 404 is always cleared — channel name lives in 402.
        """
        if not self._ticker_items:
            return
        idx = idx % len(self._ticker_items)
        phrase_line, title, icon = self._ticker_items[idx]
        try:
            self.getControl(CTRL_TICKER_PHRASE).setLabel(phrase_line)
            self.getControl(CTRL_TICKER_TITLE).setLabel(title)
            self.getControl(CTRL_TICKER_CHAN).setLabel("")
            icon_ctrl = self.getControl(CTRL_TICKER_ICON)
            if icon:
                icon_ctrl.setImage(icon)
        except Exception as e:
            log("[SidePanel] _show_ticker_item error: {}".format(e))

    def _start_ticker_thread(self):
        """Start the background rotation thread (8-second interval)."""
        import threading
        self._ticker_stop   = threading.Event()
        self._ticker_idx    = 0
        stop_event          = self._ticker_stop

        def _rotate():
            idx = 0
            while not stop_event.wait(timeout=8):
                idx += 1
                self._ticker_idx = idx
                self._show_ticker_item(idx)

        self._ticker_thread = threading.Thread(
            target=_rotate, name="SmartChannelsTicker", daemon=True)
        self._ticker_thread.start()
        log("[SidePanel] Ticker thread started ({} items)".format(
            len(self._ticker_items)))

    def _stop_ticker_thread(self):
        """Signal the ticker thread to stop and wait for it to exit."""
        if self._ticker_stop is not None:
            self._ticker_stop.set()
        if self._ticker_thread is not None:
            self._ticker_thread.join(timeout=2)
            self._ticker_thread = None
        log("[SidePanel] Ticker thread stopped")

    # ── Helpers ───────────────────────────────────────────────────────────

    def _s(self, sid):
        """Return localised string. Never hardcode user-visible text."""
        return self._addon.getLocalizedString(sid)


# ── Public entry point ─────────────────────────────────────────────────────

def open_side_panel(addon, manager):
    """
    Move to Home first (eliminates Videos hub flash on open), then
    resolve the correct skin XML and open the side panel window.
    Called from router.py when use_side_panel setting is True.
    """
    # Move to Home before opening so Kodi has no Videos screen to
    # flash back to when endOfDirectory(succeeded=False) fires.
    xbmc.executebuiltin("ActivateWindow(Home)")
    xbmc.sleep(150)

    addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))
    xml_file   = _resolve_skin_xml(addon_path)
    xml_name   = os.path.basename(xml_file)

    log("[SidePanel] open_side_panel: xml={}".format(xml_file))

    try:
        panel = SmartChannelsSidePanel(xml_name, addon_path, addon, manager)
        panel.doModal()
        del panel
    except Exception as e:
        log("[SidePanel] open_side_panel error: {}".format(e))
        xbmcgui.Dialog().notification(
            addon.getLocalizedString(32289),
            addon.getLocalizedString(32816).format(str(e)[:60]),
            xbmcgui.NOTIFICATION_ERROR, 4000)
