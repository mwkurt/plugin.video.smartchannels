# channels/combo.py
#
# OWNS:   Queue building logic for Combo Block channels.
#         Per-slot item fetching (TV, Movie, Folder).
#         Per-slot state read/write via channel_manager public methods only.
#
# NEVER:  UI rendering. Playback control.
#         Private channel_manager methods (Rule 14).
#         Direct state.json or queue file access.
#
# CALLERS: channel_manager.py only, via build_queue() dispatch and
#          _load_foreign_items combo branch.
#
# STATUS 1.2.4a: Initial implementation.

from __future__ import annotations

import uuid

import xbmc

from resources.lib.channels.base import BaseQueueBuilder
from resources.lib.utils.logger  import log

# State key templates — all scoped to combo channel + slot
_TV_NEXT_EP_KEY    = "combo:{}:slot:{}:tv_next_ep"
_TV_EP_INDEX_KEY   = "combo:{}:slot:{}:tv_ep_index"
_MOVIE_STATE_KEY   = "combo:{}:slot:{}:movie_state"
_FOLDER_PLAYED_KEY = "combo:{}:slot:{}:folder_played"


class ComboQueueBuilder(BaseQueueBuilder):
    """
    Queue builder for Combo Block channels.

    A Combo Block defines an ordered list of slots.  Each slot is one
    content source (TV show, Movie pool, or Folder).  One item fires
    per slot per unit.  The queue is a flat list of interleaved slot
    items:  [slot1[0], slot2[0], slot1[1], slot2[1], ...].

    All state is scoped to the Combo Block channel ID + slot ID so that
    a TV show used in a Combo Block slot never shares its playback
    position with the same show configured as a standalone channel.
    """

    def build(self, channel: dict, target_size: int,
              current_queue=None) -> list:
        """
        Build a Combo Block queue of up to target_size items.

        current_queue is accepted for API compatibility but ignored —
        Combo Blocks always build fresh (top-up is handled by the caller
        in _load_foreign_items via a separate topup call).
        """
        channel_id = channel["id"]
        slots      = channel.get("slots", [])

        if not slots:
            log("[ComboQueueBuilder] '{}': no slots configured — "
                "returning empty queue".format(channel.get("name", channel_id)))
            return []

        num_slots    = len(slots)
        units_needed = max(1, target_size // num_slots)

        log("[ComboQueueBuilder] '{}': {} slot(s), {} units, "
            "target={} items".format(
            channel.get("name", channel_id),
            num_slots, units_needed, target_size))

        # Fetch items per slot.
        # TV slots honour episodes_per_slot; Movie slots honour movies_per_slot.
        # Folder slots always contribute 1 item per unit.
        per_slot = []
        for slot in slots:
            src = slot.get("source_type", "")
            if src == "tv":
                # Sum per-show episodes_per_slot for this slot
                slot_count = max(1, sum(
                    max(1, int(sh.get("episodes_per_slot", 1)))
                    for sh in slot.get("shows", [{"episodes_per_slot": 1}])))
            elif src == "movies":
                slot_count = max(1, int(slot.get("movies_per_slot", 1)))
            else:
                slot_count = max(1, int(slot.get("episodes_per_slot", 1)))
            items = self._fetch_slot_items(
                channel_id, slot, units_needed * slot_count)
            per_slot.append((slot, items, slot_count))
            log("[ComboQueueBuilder] slot {} ({}) count={}: {} items fetched"
                .format(slot.get("slot_id", "?")[:8],
                        src, slot_count, len(items)))

        # Interleave into units.
        # Each unit: for each slot, take slot_count consecutive items.
        # e.g. slots=[CC(1), LT(2), 1950s(1)] →
        #      unit: [CC[0], LT[0], LT[1], 1950s[0]]
        queue = []
        for unit_idx in range(units_needed):
            for slot, items, slot_count in per_slot:
                base = unit_idx * slot_count
                for k in range(slot_count):
                    item_idx = base + k
                    if item_idx < len(items):
                        item = dict(items[item_idx])
                        # TV slots stamp _silent per-show in build_combo_tv_slot;
                        # Movie/Folder slots carry silent at slot level.
                        if "_silent" not in item:
                            item["_silent"] = slot.get("silent", False)
                        item["_combo_slot"]  = slot.get("slot_id", "")
                        item["_interleaved"] = True
                        queue.append(item)
                    # If a slot is exhausted, skip silently.

        log("[ComboQueueBuilder] '{}': built {} items ({} complete "
            "units of {})".format(
            channel.get("name", channel_id),
            len(queue), units_needed, num_slots))
        return queue

    def build_one_unit(self, channel: dict) -> list:
        """Build exactly one complete combo unit.

        Each slot contributes episodes_per_slot (TV) or movies_per_slot
        (Movie) items, defaulting to 1.  Folder slots always contribute 1.
        Called by service.py _handle_combo_slot for 1-for-1 replacement.
        """
        slots = channel.get("slots", [])
        if not slots:
            return []
        # target_size = total items across all slots for one unit.
        # TV slots: sum episodes_per_slot across all shows in the slot
        # (each show can have a different count).
        # Movie slots: use movies_per_slot on the slot itself.
        # Folder slots: always 1.
        def _slot_count(s):
            src = s.get("source_type", "")
            if src == "tv":
                return max(1, sum(
                    max(1, int(sh.get("episodes_per_slot", 1)))
                    for sh in s.get("shows", [{"episodes_per_slot": 1}])))
            if src == "movies":
                return max(1, int(s.get("movies_per_slot", 1)))
            return max(1, int(s.get("episodes_per_slot", 1)))
        target_size = sum(_slot_count(s) for s in slots)
        return self.build(channel, target_size)

    def build_one_slot(self, channel: dict, slot_index: int) -> list:
        """Build one replacement item for a single slot by index.

        Used for strict 1-for-1 replacement: when slot N is consumed,
        immediately append the next item for slot N — no waiting for
        the full unit to complete.  Returns a list of 0 or 1 items.
        """
        slots = channel.get("slots", [])
        if not slots or slot_index >= len(slots):
            return []
        channel_id = channel["id"]
        slot       = slots[slot_index]
        items      = self._fetch_slot_items(channel_id, slot, 1)
        if not items:
            return []
        item = dict(items[0])
        if "_silent" not in item:
            item["_silent"] = slot.get("silent", False)
        item["_combo_slot"]  = slot.get("slot_id", "")
        item["_interleaved"] = True
        item["_channel_id"]  = channel_id   # needed for next carousel pop
        log("[ComboQueueBuilder] build_one_slot: slot_index={} slot={} "
            "built '{}'".format(
            slot_index, slot.get("slot_id","?")[:8],
            item.get("title","?")))
        return [item]

    # ------------------------------------------------------------------
    # Per-slot item fetching
    # ------------------------------------------------------------------

    def _fetch_slot_items(self, combo_id: str, slot: dict,
                          count: int) -> list:
        """Dispatch to the correct fetcher based on slot source_type."""
        src = slot.get("source_type", "")
        if src == "tv":
            return self._fetch_tv_items(combo_id, slot, count)
        if src == "movies":
            return self._fetch_movie_items(combo_id, slot, count)
        if src == "folder":
            return self._fetch_folder_items(combo_id, slot, count)
        log("[ComboQueueBuilder] Unknown source_type '{}' in slot "
            "{}".format(src, slot.get("slot_id", "?")),
            xbmc.LOGWARNING)
        return []

    def _fetch_tv_items(self, combo_id: str, slot: dict,
                        count: int) -> list:
        """
        Fetch `count` TV episodes for one TV slot.
        Delegates to channel_manager.build_combo_tv_slot which owns
        all state I/O for combo TV slots.
        """
        return self._cm.build_combo_tv_slot(combo_id, slot, count)

    def _fetch_movie_items(self, combo_id: str, slot: dict,
                           count: int) -> list:
        """
        Fetch `count` movies for one Movie slot.
        Delegates to channel_manager.build_combo_movie_slot.
        """
        return self._cm.build_combo_movie_slot(combo_id, slot, count)

    def _fetch_folder_items(self, combo_id: str, slot: dict,
                             count: int) -> list:
        """
        Fetch `count` folder items for one Folder slot.
        Builds a synthetic channel dict from the slot config and delegates
        to FolderQueueBuilder.  State is scoped to the combo+slot key.
        """
        from resources.lib.channels.folder import FolderQueueBuilder

        slot_id     = slot.get("slot_id", "")
        folder_path = slot.get("folder_path", "")

        if not folder_path:
            log("[ComboQueueBuilder] Folder slot {} has no "
                "folder_path".format(slot_id[:8]), xbmc.LOGWARNING)
            return []

        # Build a synthetic channel dict so FolderQueueBuilder can work
        # with its standard interface.  The id is the combo+slot scoped
        # key so played_files state is isolated from any standalone channel.
        synthetic_ch = {
            "id":          "combo:{}:slot:{}".format(combo_id, slot_id),
            "name":        "combo_slot_{}".format(slot_id[:8]),
            "folder_path": folder_path,
            "randomize":   slot.get("randomize", True),
            "recycle":     slot.get("recycle",   True),
            "no_repeat":   slot.get("no_repeat", False),
        }

        items = FolderQueueBuilder(self._cm).build(
            synthetic_ch, count)
        if not items:
            return []

        # Overwrite _channel_id with the real combo channel ID so that
        # service.py's is_combo_channel() correctly identifies these items
        # as belonging to the combo block.  FolderQueueBuilder sets it to
        # the synthetic "combo:{id}:slot:{id}" key (used for state isolation)
        # which has no entry in channels.json, causing is_combo_channel to
        # return False and misroute the item in _do_replacement_inner.
        # Preserve the synthetic id as _folder_state_id so service.py can
        # record played files against the correct scoped state key for
        # no_repeat / recycle=False tracking.
        synthetic_id = synthetic_ch["id"]
        for item in items:
            item["_channel_id"]      = combo_id
            item["channel_id"]       = combo_id
            item["_folder_state_id"] = synthetic_id

        # If this slot is silent, replace each item's title with the
        # folder's leaf name so the OSD and playlist show a clean label
        # (e.g. "1950s" or "Cartoon College") rather than individual
        # file names like "1950s CAPTAIN KANGAROO".
        if slot.get("silent", False):
            import re as _re
            _leaf = _re.split(r"[/\\]",
                              folder_path.rstrip("/").rstrip("\\"))
            folder_label = _leaf[-1] if _leaf else folder_path
            for item in items:
                item["title"] = folder_label

        return items
