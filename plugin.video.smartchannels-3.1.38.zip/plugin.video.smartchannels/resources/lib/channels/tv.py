# plugin.video.smartchannels
# channels/tv.py
#
# OWNS:   Queue building entry point for TV channels (round_robin and serial).
#         TV / Serial queue logic lives in channel_manager._build_tv_items().
#         This module is a thin dispatch shim — it calls channel_manager's
#         public API and does nothing else.
#
# NEVER:  State reads/writes (request via channel_manager.py).
#         Direct library access (request via channel_manager.py).
#         Playback control, UI rendering, routing.
#         Logic belonging to a different channel type.
#         Private method calls on ChannelManager (Architecture Rule 14/15).
#
# CALLERS: channel_manager.py only — via build_channel_queue() dispatch.
#
# Version: 3.0.0
# Spec ref: §8, §26 Phase 1

from __future__ import annotations

from resources.lib.channels.base import BaseQueueBuilder
from resources.lib.utils.logger  import log


class TVQueueBuilder(BaseQueueBuilder):
    """Queue builder for TV (round-robin / random) and Serial channels.

    Both channel subtypes (round_robin and serial) are handled here;
    the playback_mode field on the channel dict selects the behaviour
    inside channel_manager._build_tv_items().

    This class is intentionally minimal.  All episode selection logic,
    cursor management, and interleave weaving live in channel_manager.py
    so that they remain reachable from service.py's 1-for-1 replacement
    path without going through this class.
    """

    def build(self, channel: dict, target_size: int,
              start_show_index: int | None = None) -> list:
        """Build a fresh TV queue of exactly target_size items.

        Args:
            channel:          Channel definition dict.
            target_size:      Number of items to build.
            start_show_index: If provided, seeds the rotation so the queue
                              starts from this show index rather than 0.
                              Used when rebuilding mid-playback so the active
                              show's position is preserved.

        Returns:
            List of normalised queue item dicts.
        """
        log("[channels/tv] build: fresh build, target={}".format(target_size))
        return self._cm._build_fresh_tv_queue(
            channel, target_size,
            start_show_index=start_show_index)
