# plugin.video.smartchannels
# resources/lib/channel_manager.py
#
# OWNS:   Channel definitions (channels.json), queue files, state (state.json),
#         cursor API, 1-for-1 replacement, combo unit tracker, library access.
#
# NEVER:  Playback callbacks (service.py), playlist management (service.py),
#         start_channel / now_playing (player.py), UI rendering (ui/*),
#         direct executeJSONRPC calls (library.py only).
#
# Architecture rules enforced here:
#   - No private method calls from outside this class.
#   - No duplicate logic from channels/base.py or library.py.
#   - All user-visible strings must come from strings.po (not hardcoded here).
#   - All queue file I/O goes through write_channel_queue / get_channel_queue.
#
# Version: 3.0.0
# Spec ref: §4, §7, §8, §11

from __future__ import annotations

import copy
import json
import os
import random
import uuid
from typing import Any, Optional

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.library      import LibraryClient
from resources.lib.utils.logger import log
from resources.lib.utils.paths  import (load_json, save_json, resolve_path,
                                        shared_root, path_join)
from resources.lib.channels.base import (
    normalize_ep        as _normalize_ep_fn,
    normalize_movie     as _normalize_movie_fn,
    get_available_episodes as _get_available_episodes_fn,
    get_filtered_episodes  as _get_filtered_episodes_fn,
)

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
ChannelDef  = dict
EpisodeInfo = dict


class ChannelManager:
    """Central brain: channel CRUD, queue building, state, cursor, replacement."""

    CHANNELS_FILE  = "channels.json"
    STATE_FILE     = "state.json"
    SCHEDULES_FILE = "schedules.json"

    # Zero cursor — used for fresh builds and as a safe default.
    # Keys: show_slot (int), ep_pos (dict), ep_played (dict), slot_owed (dict).
    # spec §4.3
    _ZERO_CURSOR = {
        "show_slot": 0,
        "ep_pos":    {},
        "ep_played": {},
        "slot_owed": {},
    }

    def __init__(self, addon: xbmcaddon.Addon):
        self.addon   = addon
        self.profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        self._ensure_profile_dir()

        self._channels_path  = self._resolve_path(self.CHANNELS_FILE)
        self._state_path     = self._resolve_path(self.STATE_FILE)
        self._schedules_path = self._resolve_path(self.SCHEDULES_FILE)

        shared = self._shared_root()
        if shared:
            log("[ChannelManager] SHARED STORAGE ACTIVE: {}".format(shared))
        else:
            log("[ChannelManager] LOCAL STORAGE: {}".format(self.profile))

        self._channels = self._load_json(self._channels_path, [])
        self._state    = self._load_json(self._state_path,    {})
        log("[ChannelManager] Loaded {} channel(s)".format(len(self._channels)))

        # Keys explicitly deleted this session; stripped from merge on save.
        self._deleted_state_keys: set = set()

        self.library = LibraryClient(addon)

    # =========================================================================
    # Settings helpers
    # =========================================================================

    def _default_queue_size(self) -> int:
        try:
            return max(10, int(
                self.addon.getSetting("default_queue_size") or "30"))
        except (ValueError, TypeError):
            return 30

    # =========================================================================
    # Path / IO helpers (private — no callers outside this file)
    # =========================================================================

    def _ensure_profile_dir(self) -> None:
        if not xbmcvfs.exists(self.profile):
            xbmcvfs.mkdirs(self.profile)

    def _shared_root(self) -> str:
        return shared_root()

    def _resolve_path(self, filename: str) -> str:
        return resolve_path(filename)

    def _load_json(self, path: str, default: Any) -> Any:
        return load_json(path, default)

    def _save_json(self, path: str, data: Any) -> None:
        save_json(path, data)

    def _save_channels(self) -> None:
        self._save_json(self._channels_path, self._channels)

    def _save_state(self) -> None:
        """Read-before-write merge for state.json.

        Reads current file from disk, merges our in-memory changes on top,
        strips explicitly deleted keys, strips orphan keys (channels that no
        longer exist), then writes. Keeps in-memory copy consistent.
        """
        try:
            on_disk = self._load_json(self._state_path, {})
            merged  = {**on_disk, **self._state}
            for k in self._deleted_state_keys:
                merged.pop(k, None)
            # Orphan-key pruning: drop keys for deleted channels.
            # Exemptions: keys starting with "resume:" or "combo:" are managed
            # independently and must not be pruned here.
            # Read live channel IDs directly from disk so channels created by
            # other processes (e.g. addon.py) are not falsely treated as orphans
            # by the long-running service process.
            try:
                disk_channels = self._load_json(self._channels_path, [])
                live_ids = {c["id"] for c in disk_channels}
                # Keep in-memory channels in sync
                self._channels = disk_channels
            except Exception:
                live_ids = {c["id"] for c in self._channels}
            orphans  = [
                k for k in list(merged.keys())
                if ":" in k
                and not k.startswith("resume:")
                and not k.startswith("combo:")
                and not k.startswith("pending_seek:")
                and not k.startswith("sch_")   # schedule active_block keys
                and k.split(":", 1)[0] not in live_ids
            ]
            for k in orphans:
                del merged[k]
            self._save_json(self._state_path, merged)
            self._state = merged
        except Exception as exc:
            log("[ChannelManager] _save_state error: {}".format(exc),
                level=xbmc.LOGWARNING)

    def _is_network_path(self, path: str) -> bool:
        """Return True if path is a network protocol URL (smb://, nfs://, etc.).
        Ported from 2.x channel_manager.py.
        """
        return "://" in (path or "")

    def _normalise_icon_folder(self, folder: str) -> str:
        """Convert Windows UNC paths to Kodi SMB VFS format.

        \\\\Server\\share\\path  →  smb://Server/share/path
        Leaves smb://, nfs://, special://, and local paths unchanged.
        Ported from 2.x channel_manager.py.
        """
        if not folder:
            return folder
        if "://" in folder:
            return folder
        stripped = folder.replace("\\", "/")
        if stripped.startswith("//"):
            result = "smb://" + stripped.lstrip("/")
            log("[ChannelManager] icon folder UNC->SMB: {} -> {}".format(
                folder, result))
            return result
        return folder

    def _queue_file_path(self, channel_id: str) -> str:
        return self._resolve_path("queue_{}.json".format(channel_id))

    def _write_queue_file(self, channel_id: str, queue: list) -> None:
        self._save_json(self._queue_file_path(channel_id), queue)

    # =========================================================================
    # Queue file public API
    # Called by: player.py, service.py, ui/*, scheduler.py
    # =========================================================================

    def get_channel_queue(self, channel_id: str) -> list:
        """Read and return the queue list for any channel type.
        Returns [] if the queue file does not exist or cannot be read.
        """
        return self._load_json(self._queue_file_path(channel_id), [])

    def write_channel_queue(self, channel_id: str, queue: list) -> None:
        """Write the queue list for any channel type."""
        self._write_queue_file(channel_id, queue)

    def get_channel_queue_path(self, channel_id: str) -> str:
        """Return the filesystem path to the queue file.
        Public wrapper for use by UI components that monitor the file
        (e.g. side panel queue watcher thread).
        """
        return self._queue_file_path(channel_id)

    # =========================================================================
    # Cursor public API  (spec §8.1)
    # Called by: service.py, player.py, channels/tv.py
    # =========================================================================

    def get_cursor(self, channel_id: str) -> dict:
        """Read the TV cursor for channel_id from state.
        Returns a zero cursor if no cursor exists yet.
        """
        key    = "{}:cursor".format(channel_id)
        stored = self._state.get(key)
        if stored and isinstance(stored, dict):
            c = dict(self._ZERO_CURSOR)
            c.update(stored)
            # Ensure sub-dicts are always present (forward-compat)
            for k in ("ep_pos", "ep_played", "slot_owed"):
                if not isinstance(c.get(k), dict):
                    c[k] = {}
            return c
        return dict(self._ZERO_CURSOR)

    def set_cursor(self, channel_id: str, cursor: dict) -> None:
        """Write cursor to state for channel_id."""
        key = "{}:cursor".format(channel_id)
        self._deleted_state_keys.discard(key)
        self._state[key] = cursor
        self._save_state()

    def clear_cursor(self, channel_id: str) -> None:
        """Delete the cursor for channel_id.
        The next queue build will use a zero cursor (fresh start).
        """
        key = "{}:cursor".format(channel_id)
        self._state.pop(key, None)
        self._deleted_state_keys.add(key)
        self._save_state()

    def update_cursor_for_edit(self, channel_id: str,
                               added_show_ids: list,
                               removed_show_ids: list,
                               invalidate: bool) -> None:
        """Adjust the cursor after a channel edit.

        invalidate=True  → clear the cursor entirely (recycle/randomize changed).
        invalidate=False → preserve cursor but add/drop show entries.
        """
        if invalidate:
            self.clear_cursor(channel_id)
            log("[ChannelManager] update_cursor_for_edit: invalidated cursor "
                "for '{}'".format(channel_id))
            return

        cursor  = self.get_cursor(channel_id)
        changed = False

        for sid in removed_show_ids:
            sid_str = str(sid)
            cursor["ep_pos"].pop(sid_str,    None)
            cursor["ep_played"].pop(sid_str, None)
            cursor["slot_owed"].pop(sid_str, None)
            changed = True

        if removed_show_ids:
            cursor["show_slot"] = max(
                0, cursor["show_slot"] - len(removed_show_ids))

        if added_show_ids:
            # No cursor entry created for new shows — _fill_slot seeds
            # ep_pos from show state on first access.
            changed = True

        if changed:
            self.set_cursor(channel_id, cursor)
            log("[ChannelManager] update_cursor_for_edit: updated cursor for "
                "'{}' removed={} added={}".format(
                    channel_id, removed_show_ids, added_show_ids))

    # =========================================================================
    # 1-for-1 replacement  (spec §7.3, §8.1)
    # Called by: service.py only
    # =========================================================================

    def get_one_replacement(self, channel_id: str,
                            consumed_item: dict,
                            current_queue: Optional[list] = None) -> Optional[dict]:
        """Return one replacement item for consumed_item and update cursor.

        Called by service.py after every item completion (natural end, skip,
        or carousel pop) for non-combo items.  The returned item should be
        appended to the queue tail by the caller.

        current_queue: the in-memory queue AFTER the consumed item has been
        removed.  Serial replacement uses this to find the true tail of the
        queue without reading a potentially stale disk copy.

        Returns None if the channel is exhausted (recycle=False, pool empty).
        """
        # Interleaved items must be replaced from their source channel, not the
        # host channel.  Without this, a movie interleaved into a TV channel
        # would be replaced with a TV episode (wrong source, wrong type).
        # The replacement must also carry the same interleave tags as the
        # consumed item so that when IT is later skipped or consumed, the
        # correct replacement path is taken again.
        if consumed_item.get("_interleaved"):
            source_cid = consumed_item.get("_channel_id", "")
            if source_cid and source_cid != channel_id:
                source_ch = self.get_channel(source_cid)
                if source_ch:
                    sctype = source_ch.get("channel_type", "tv")
                    result = None
                    if sctype == "movies":
                        result = self._replacement_movie(
                            source_cid, source_ch, consumed_item)
                    elif sctype == "folder":
                        result = self._replacement_folder(
                            source_cid, source_ch, consumed_item)
                    elif sctype == "tv":
                        result = self._replacement_tv(
                            source_cid, source_ch, consumed_item)
                    if result is not None:
                        result = dict(result)
                        result["_interleaved"]  = True
                        result["_channel_id"]   = source_cid
                        if consumed_item.get("_silent"):
                            result["_silent"]       = True
                        if consumed_item.get("_channel_name"):
                            result["_channel_name"] = consumed_item["_channel_name"]
                    return result
                log("[ChannelManager] get_one_replacement: interleaved item "
                    "source channel {} not found — falling through to host"
                    .format(source_cid))

        channel = self.get_channel(channel_id)
        if not channel:
            log("[ChannelManager] get_one_replacement: channel {} not "
                "found".format(channel_id))
            return None

        ctype = channel.get("channel_type", "tv")

        if ctype == "tv":
            return self._replacement_tv(channel_id, channel, consumed_item,
                                        current_queue=current_queue)
        if ctype == "movies":
            return self._replacement_movie(channel_id, channel, consumed_item)
        if ctype == "folder":
            return self._replacement_folder(channel_id, channel, consumed_item)

        log("[ChannelManager] get_one_replacement: unhandled type '{}' for "
            "channel {}".format(ctype, channel_id))
        return None

    def get_carousel_replacement(self, channel_id: str,
                                 popped_show_id: int) -> Optional[dict]:
        """Get next episode of the SAME show that was carousel-popped.

        Does NOT advance show_slot — only the per-show ep_pos advances.
        spec §8.5, §9.2
        """
        channel = self.get_channel(channel_id)
        if not channel:
            return None

        cursor = self.get_cursor(channel_id)
        shows  = channel.get("shows", [])
        show   = next(
            (s for s in shows if s["tvshowid"] == popped_show_id), None)
        if not show:
            log("[ChannelManager] get_carousel_replacement: show_id {} not "
                "found in channel {}".format(popped_show_id, channel_id))
            return None

        episodes = self.get_available_episodes(show)
        if not episodes:
            return None

        sid_str = str(popped_show_id)
        ep      = self._pick_one_ep_no_slot_advance(
            show, sid_str, episodes, cursor,
            channel.get("randomize", False), channel.get("recycle", True),
            channel_id=channel_id)
        self.set_cursor(channel_id, cursor)
        return ep

    def _replacement_tv(self, channel_id: str, channel: dict,
                        consumed_item: dict,
                        current_queue: Optional[list] = None) -> Optional[dict]:
        """Return one TV replacement.

        Round-robin: next episode of the same consumed show.
        Serial: advance to the next show in serial sequence.
        """
        # Serial channels: stay on the current show until it is fully
        # exhausted, then advance to the next show. This handles the case
        # where the queue size cut the show off before all episodes were
        # queued — we must continue appending that show's episodes until
        # ep_pos reaches the end before moving to the next show.
        if channel.get("playback_mode") == "serial":
            return self._replacement_serial(channel_id, channel,
                                            consumed_item,
                                            current_queue=current_queue)

        show_id  = consumed_item.get("show_id") or consumed_item.get("_show_id")
        shows    = channel.get("shows", [])
        show     = next((s for s in shows if s["tvshowid"] == show_id), None)
        if not show:
            # show no longer in channel — advance rotation to next show
            return self._replacement_tv_next_show(channel_id, channel)

        episodes = self.get_available_episodes(show)
        if not episodes:
            return None

        cursor  = self.get_cursor(channel_id)
        sid_str = str(show_id)
        ep      = self._pick_one_ep_no_slot_advance(
            show, sid_str, episodes, cursor,
            channel.get("randomize", False), channel.get("recycle", True),
            channel_id=channel_id)
        self.set_cursor(channel_id, cursor)
        return ep

    def _replacement_serial(self, channel_id: str, channel: dict,
                            consumed_item: dict,
                            current_queue: Optional[list] = None) -> Optional[dict]:
        """Serial replacement: continue from wherever the queue tail currently is.

        For serial channels the rule is simple: always append the successor of
        whatever is last in the queue. The consumed item's show is irrelevant —
        what matters is the tail, because the tail represents what has already
        been scheduled. This is correct for both natural play (one item at a
        time) and skip (N items at a time) because each call sees the growing
        queue including all replacements appended by previous calls in the loop.

        If the tail show is exhausted (last episode already queued), advance to
        the next show. If no queue exists yet, fall back to consumed item's show.
        """
        shows = channel.get("shows", [])
        if not shows:
            return None

        queue = current_queue if current_queue is not None \
            else self.get_channel_queue(channel_id)

        # Find the last item in the queue and what show it belongs to.
        # That determines what comes next in serial order.
        if queue:
            tail_item   = queue[-1]
            tail_show_id = tail_item.get("show_id") or tail_item.get("_show_id")
        else:
            tail_show_id = None

        if tail_show_id:
            tail_show = next(
                (s for s in shows if s["tvshowid"] == tail_show_id), None)

            if tail_show:
                episodes = self.get_available_episodes(tail_show)
                if episodes:
                    tail_ep_id = tail_item.get("episodeid")
                    tail_idx   = next(
                        (i for i, ep in enumerate(episodes)
                         if ep["episodeid"] == tail_ep_id), None)

                    if tail_idx is not None and tail_idx + 1 < len(episodes):
                        # More episodes of the tail show remain — continue it.
                        next_idx = tail_idx + 1
                        cursor   = self.get_cursor(channel_id)
                        sid_str  = str(tail_show_id)
                        cursor["ep_pos"][sid_str] = next_idx
                        log("[ChannelManager] _replacement_serial: show {} "
                            "continuing from idx {} (ep {})".format(
                            tail_show_id, next_idx,
                            episodes[next_idx].get("episode", "?")))
                        ep = self._pick_one_ep_no_slot_advance(
                            tail_show, sid_str, episodes, cursor,
                            channel.get("randomize", False),
                            channel.get("recycle", True),
                            channel_id=channel_id)
                        self.set_cursor(channel_id, cursor)
                        return ep

        # Tail show is exhausted (or queue is empty) — advance to next show.
        # Use the tail show id (not the consumed show id) as skip_show_id so
        # we don't immediately re-pick the show that was just exhausted.
        skip_id = tail_show_id or 0
        log("[ChannelManager] _replacement_serial: show {} exhausted in "
            "queue, advancing to next show".format(skip_id))
        return self._replacement_tv_next_show(channel_id, channel,
                                              skip_show_id=skip_id)

    def _replacement_tv_next_show(self, channel_id: str,
                                  channel: dict,
                                  skip_show_id: int = 0) -> Optional[dict]:
        """Return one episode from the next show after the exhausted one.

        For serial channels: find skip_show_id in the show list and pick
        the show at (index + 1) % len(shows). This is deterministic and
        never drifts — it doesn't rely on show_slot which can become
        misaligned after multiple boundary crossings and skips.

        For round-robin channels: use show_slot % len(shows) as before.
        """
        shows  = channel.get("shows", [])
        cursor = self.get_cursor(channel_id)

        is_serial = (channel.get("playback_mode") == "serial")

        if is_serial and skip_show_id:
            # Find the exhausted show's index and pick the next one.
            exhausted_idx = next(
                (i for i, s in enumerate(shows)
                 if s["tvshowid"] == skip_show_id), None)
            if exhausted_idx is not None:
                for attempt in range(len(shows)):
                    next_idx  = (exhausted_idx + 1 + attempt) % len(shows)
                    show      = shows[next_idx]
                    episodes  = self.get_available_episodes(show)
                    if not episodes:
                        continue
                    sid_str = str(show["tvshowid"])
                    ep = self._pick_one_ep_no_slot_advance(
                        show, sid_str, episodes, cursor,
                        channel.get("randomize", False),
                        channel.get("recycle", True),
                        channel_id=channel_id)
                    if ep:
                        # Keep show_slot in sync so round-robin path stays
                        # consistent if the channel mode ever changes.
                        cursor["show_slot"] = next_idx + 1
                        self.set_cursor(channel_id, cursor)
                        return ep
            return None

        # Round-robin path: use show_slot as before.
        for _ in range(len(shows)):
            show_slot = cursor["show_slot"]
            show_idx  = show_slot % len(shows)
            show      = shows[show_idx]
            cursor["show_slot"] = show_slot + 1
            if skip_show_id and show["tvshowid"] == skip_show_id:
                continue
            episodes  = self.get_available_episodes(show)
            if not episodes:
                continue
            sid_str = str(show["tvshowid"])
            ep = self._pick_one_ep_no_slot_advance(
                show, sid_str, episodes, cursor,
                channel.get("randomize", False), channel.get("recycle", True),
                channel_id=channel_id)
            if ep:
                self.set_cursor(channel_id, cursor)
                return ep
        return None

    def _replacement_movie(self, channel_id: str, channel: dict,
                           consumed_item: dict) -> Optional[dict]:
        """Return one movie replacement from the channel's movie pool."""
        from resources.lib.channels.movies import MovieQueueBuilder
        items = MovieQueueBuilder(self).build_one(channel)
        return items[0] if items else None

    def _replacement_folder(self, channel_id: str, channel: dict,
                            consumed_item: dict) -> Optional[dict]:
        """Return one folder replacement from the channel's folder."""
        from resources.lib.channels.folder import FolderQueueBuilder
        current_queue = self.get_channel_queue(channel_id)
        queued_files  = [i.get("file", "") for i in current_queue
                         if i.get("file")]
        items = FolderQueueBuilder(self).build(channel, 1,
                                               queued_files=queued_files)
        return items[0] if items else None

    def _pick_one_ep_no_slot_advance(self, show: dict, sid_str: str,
                                     episodes: list, cursor: dict,
                                     randomize: bool,
                                     recycle: bool,
                                     channel_id: str = "") -> Optional[dict]:
        """Pick exactly one episode and advance cursor for that show only.

        Used by both carousel replacement and TV 1-for-1 replacement.
        Does NOT advance show_slot.
        """
        show_randomize = show.get("randomize", randomize)
        ep_ids         = [e["episodeid"] for e in episodes]

        if show_randomize:
            played_set = set(cursor["ep_played"].get(sid_str, []))
            unplayed   = [eid for eid in ep_ids if eid not in played_set]
            if not unplayed:
                if not recycle:
                    return None
                # Reset cycle
                cursor["ep_played"][sid_str] = []
                unplayed = list(ep_ids)
            chosen_id = random.choice(unplayed)
            ep = next((e for e in episodes if e["episodeid"] == chosen_id),
                      None)
            if ep is None:
                return None
            played_list = cursor["ep_played"].setdefault(sid_str, [])
            if chosen_id not in played_list:
                played_list.append(chosen_id)
        else:
            # Seed ep_pos from state if first access
            if sid_str not in cursor["ep_pos"]:
                cursor["ep_pos"][sid_str] = 0

            idx = cursor["ep_pos"].get(sid_str, 0)
            if idx >= len(episodes):
                if not recycle:
                    return None
                cursor["ep_pos"][sid_str] = 0
                idx = 0
            ep = episodes[idx]
            # Advance by span
            from resources.lib.utils.multi_episode import count_episode_span
            span = count_episode_span(ep)
            cursor["ep_pos"][sid_str] = idx + span

        norm = _normalize_ep_fn(ep, channel_id or show.get("tvshowid", 0),
                                 int(sid_str),
                                 all_episodes_for_show=episodes)
        return norm

    # =========================================================================
    # Combo unit tracker public API  (spec §4.5, §7.3, §11)
    # Called by: service.py only
    # =========================================================================

    def is_combo_channel(self, channel_id: str) -> bool:
        """Return True if channel_id is a Combo Block channel.
        Gate for all combo-aware decisions in service.py.  spec §11.1
        """
        ch = self.get_channel(channel_id)
        return bool(ch and ch.get("channel_type") == "combo")

    # =========================================================================
    # Queue building public API
    # Called by: player.py (initial build), service.py (1-for-1 append)
    # =========================================================================

    def build_queue(self, channel: dict,
                    start_show_index: Optional[int] = None) -> list:
        """2.x compatibility alias for build_channel_queue.
        player.py calls this name; removed once player.py is rewritten in
        Phase 4.
        """
        return self.build_channel_queue(channel,
                                        start_show_index=start_show_index)

    def build_channel_queue(self, channel: dict,
                            start_show_index: Optional[int] = None) -> list:
        """Build a fresh queue of exactly queue_size items for any channel type.

        Called on channel create, reset, or edit requiring rebuild.
        Writes the cursor and returns the queue list (caller writes to disk).

        spec §7.2
        """
        channel_id  = channel["id"]
        target_size = int(channel.get("queue_size",
                                      self._default_queue_size()))
        ctype       = channel.get("channel_type", "tv")

        if ctype == "tv":
            return self._build_fresh_tv_queue(channel, target_size,
                                              start_show_index)
        if ctype == "movies":
            from resources.lib.channels.movies import MovieQueueBuilder
            return MovieQueueBuilder(self).build(channel, target_size)
        if ctype == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            return FolderQueueBuilder(self).build(channel, target_size)
        if ctype == "audio":
            from resources.lib.channels.audio import AudioQueueBuilder
            return AudioQueueBuilder(self).build(channel, target_size)
        if ctype == "party":
            from resources.lib.channels.party import PartyQueueBuilder
            return PartyQueueBuilder(self).build(channel, target_size)
        if ctype == "combo":
            from resources.lib.channels.combo import ComboQueueBuilder
            return ComboQueueBuilder(self).build(channel, target_size)

        log("[ChannelManager] build_channel_queue: unknown type '{}' for "
            "channel '{}'".format(ctype, channel.get("name", channel_id)))
        return []

    def _apply_starting_points(self, channel: dict,
                               cursor: dict) -> None:
        """Translate starting_points from channel definition into cursor ep_pos.

        For each show with a starting_point, finds the episode's index in the
        available episode list and sets cursor ep_pos[sid_str] to that index.
        Called before _build_tv_items so the queue builds from the correct
        episode.  Matches the intent of 2.x _apply_starting_points.
        """
        starting_points = channel.get("starting_points", {})
        if not starting_points:
            return

        for sid_str, ep_info in starting_points.items():
            try:
                sid = int(sid_str)
            except (ValueError, TypeError):
                continue

            show = next(
                (s for s in channel.get("shows", [])
                 if s["tvshowid"] == sid), None)
            if not show:
                continue

            episodes = self.get_available_episodes(show)
            if not episodes:
                continue

            chosen_id = ep_info.get("episodeid")
            idx = next(
                (i for i, ep in enumerate(episodes)
                 if ep["episodeid"] == chosen_id), None)

            if idx is not None:
                cursor["ep_pos"][str(sid)] = idx
                log("[ChannelManager] _apply_starting_points: show {} "
                    "starting at index {} (S{}E{} '{}')".format(
                    sid, idx,
                    ep_info.get("season", "?"),
                    ep_info.get("episode", "?"),
                    ep_info.get("title", "")))
            else:
                log("[ChannelManager] _apply_starting_points: episodeid {} "
                    "not found for show {} — starting from beginning".format(
                    chosen_id, sid))

    def _build_fresh_tv_queue(self, channel: dict,
                               target_size: int,
                               start_show_index: Optional[int] = None) -> list:
        """Build a fresh TV queue using a zero cursor.

        Applies interleave if configured.  Writes the cursor to state.
        """
        from resources.lib.channels.tv import TVQueueBuilder
        channel_id = channel["id"]
        shows      = channel.get("shows", [])

        zero = dict(self._ZERO_CURSOR)
        zero["ep_pos"]    = {}
        zero["ep_played"] = {}
        zero["slot_owed"] = {}

        if (start_show_index is not None
                and isinstance(start_show_index, int)
                and 0 < start_show_index < len(shows)):
            zero["show_slot"] = start_show_index
            log("[ChannelManager] _build_fresh_tv_queue: seeding "
                "show_slot={}".format(start_show_index))
        else:
            zero["show_slot"] = 0

        # Apply starting points — translates starting_points from the
        # channel definition into ep_pos entries in the cursor so the
        # queue builds from the user's chosen starting episodes.
        self._apply_starting_points(channel, zero)

        items, cursor = self._build_tv_items(channel, target_size, zero)
        self.set_cursor(channel_id, cursor)

        interleave_cfg = channel.get("interleave")
        if interleave_cfg and items:
            from resources.lib.channels.interleave import apply_interleave_list
            items = apply_interleave_list(
                items, channel,
                self._load_foreign_items,
                self.get_channel)
            # Sync combo slot tv_next_ep to the episode after the last one
            # actually woven into the queue (not all fetched items).
            self._sync_combo_state_from_queue(items, channel)

        log("[ChannelManager] _build_fresh_tv_queue: built {} items for '{}'"
            .format(len(items), channel.get("name", channel_id)))
        return items

    # =========================================================================
    # _build_tv_items  (spec §8.2–8.4)
    # Pure function: reads library + cursor, returns (items, cursor), no I/O.
    # =========================================================================

    def _build_tv_items(self, channel: dict, n_requested: int,
                        cursor: dict) -> tuple:
        """Build TV episode queue items using the cursor.

        Returns (items, updated_cursor).  No file I/O performed.

        For round_robin channels the builder completes a full rotation cycle
        before stopping (may slightly overshoot n_requested to avoid mid-cycle
        truncation).  For serial channels it stops exactly at n_requested and
        records slot_owed for continuation.

        spec §8.2–8.4
        """
        channel_id = channel["id"]
        shows      = channel.get("shows", [])
        mode       = channel.get("playback_mode", "round_robin")
        randomize  = channel.get("randomize", False)
        recycle    = channel.get("recycle",   True)

        if not shows:
            log("[ChannelManager] _build_tv_items: no shows in '{}'"
                .format(channel.get("name", channel_id)))
            return [], cursor

        cursor = copy.deepcopy(cursor)

        # Pre-load episode pools (filters + exclusions applied)
        all_episodes: dict[str, list] = {}
        for show in shows:
            sid_str = str(show["tvshowid"])
            eps     = self.get_available_episodes(show)
            if eps:
                all_episodes[sid_str] = eps

        if not all_episodes:
            log("[ChannelManager] _build_tv_items: no episodes for '{}'"
                .format(channel.get("name", channel_id)))
            return [], cursor

        items:    list = []
        exhausted: set = set()

        # --- Phase 1: complete any in-progress slots (slot_owed > 0) ---------
        for sid_str, owed in list(cursor.get("slot_owed", {}).items()):
            if owed <= 0:
                cursor["slot_owed"].pop(sid_str, None)
                continue
            show     = next((s for s in shows
                             if str(s["tvshowid"]) == sid_str), None)
            episodes = all_episodes.get(sid_str, [])
            if not show or not episodes:
                cursor["slot_owed"].pop(sid_str, None)
                continue
            placed = self._fill_slot(show, sid_str, owed, episodes, cursor,
                                     randomize, recycle, channel_id, items,
                                     all_episodes, mode)
            if placed >= owed:
                cursor["slot_owed"].pop(sid_str, None)
            else:
                cursor["slot_owed"][sid_str] = owed - placed
                if not recycle:
                    exhausted.add(sid_str)

        # --- Phase 2: rotation loop ------------------------------------------
        cycle_start_slot   = cursor.get("show_slot", 0)
        stall_count        = 0  # consecutive shows that placed 0 items

        while True:
            if len(exhausted) >= len(shows):
                break

            show_slot = cursor.get("show_slot", 0)
            show_idx  = show_slot % len(shows)
            show      = shows[show_idx]
            sid_str   = str(show["tvshowid"])

            # Round-robin stop: n_requested met AND back to cycle start.
            # Must complete the full cycle so every show has an episode in
            # the initial queue — otherwise shows beyond n_requested would
            # never appear until the cursor cycles back to them via 1-for-1
            # replacement, breaking uniform rotation.
            if len(items) >= n_requested and mode != "serial":
                if show_slot % len(shows) == cycle_start_slot % len(shows):
                    break

            # Serial stop: n_requested met
            if len(items) >= n_requested and mode == "serial":
                break

            episodes = all_episodes.get(sid_str, [])
            if not episodes:
                cursor["show_slot"] = show_slot + 1
                exhausted.add(sid_str)
                continue

            eps_per_slot = self._eps_per_slot(show, mode, episodes)

            # Pool-empty pre-check
            if self._is_pool_empty(sid_str, episodes, cursor, show, randomize):
                if not recycle:
                    cursor["show_slot"] = show_slot + 1
                    exhausted.add(sid_str)
                    continue
                self._reset_pool(sid_str, cursor, randomize)
                stall_count = 0
                continue  # show_slot NOT incremented — retry same show

            cursor["show_slot"] = show_slot + 1
            # Cap to prevent unbounded growth
            if cursor["show_slot"] >= len(shows) * 1000:
                cursor["show_slot"] = cursor["show_slot"] % len(shows)

            prev_count = len(items)
            placed     = self._fill_slot(show, sid_str, eps_per_slot,
                                         episodes, cursor,
                                         randomize, recycle, channel_id,
                                         items, all_episodes, mode)

            if len(items) == prev_count:
                stall_count += 1
            else:
                stall_count = 0

            if stall_count >= len(shows):
                log("[ChannelManager] _build_tv_items: full rotation stalled "
                    "— stopping at {} items".format(len(items)))
                break

            if placed < eps_per_slot:
                if mode == "serial":
                    remaining = eps_per_slot - placed
                    if remaining > 0:
                        cursor["slot_owed"][sid_str] = remaining
                if not recycle and placed == 0:
                    exhausted.add(sid_str)

        log("[ChannelManager] _build_tv_items: built {} items for '{}' "
            "(mode={} requested={})".format(
                len(items), channel.get("name", channel_id),
                mode, n_requested))
        return items, cursor

    def _fill_slot(self, show: dict, sid_str: str, count: int,
                   episodes: list, cursor: dict,
                   randomize: bool, recycle: bool,
                   channel_id: str, items: list,
                   all_episodes: dict,
                   mode: str = "round_robin") -> int:
        """Place up to count episodes from show into items.

        Handles sequential (ep_pos) and random (ep_played) placement.
        Advances cursor by multi-episode span when applicable.
        Skips items with missing duration (logs via record_missing_duration).

        Returns the number of episodes actually placed.
        """
        from resources.lib.utils.multi_episode import (
            count_episode_span as _count_span,
            span_episode_ids   as _span_ids_fn,
        )

        show_randomize = show.get("randomize", randomize)
        ep_ids         = [e["episodeid"] for e in episodes]
        placed         = 0
        queued_files   = {item.get("file", "") for item in items
                          if item.get("file")}

        # Seed ep_pos from show state on first access (sequential mode)
        if not show_randomize and sid_str not in cursor["ep_pos"]:
            cursor["ep_pos"][sid_str] = 0

        max_attempts = len(episodes) * 2 + count + 10
        attempts     = 0

        while placed < count and attempts < max_attempts:
            attempts += 1

            if show_randomize:
                played_set = set(cursor["ep_played"].get(sid_str, []))
                unplayed   = [eid for eid in ep_ids if eid not in played_set]
                if not unplayed:
                    break  # caller handles recycle
                chosen_id = random.choice(unplayed)
                ep = next((e for e in episodes
                           if e["episodeid"] == chosen_id), None)
                if ep is None:
                    break
            else:
                idx = cursor["ep_pos"].get(sid_str, 0)
                if idx >= len(episodes):
                    break  # caller handles recycle
                ep = episodes[idx]

            # Skip duplicate files (sequential round_robin only)
            ep_file = ep.get("file", "")
            if (ep_file and ep_file in queued_files
                    and not show_randomize and mode != "serial"):
                cursor["ep_pos"][sid_str] = \
                    cursor["ep_pos"].get(sid_str, 0) + 1
                continue

            # Multi-episode span detection
            span     = _count_span(ep)
            span_ids = _span_ids_fn(ep, episodes) if span > 1 else [ep["episodeid"]]

            # Normalise (reads duration)
            norm = _normalize_ep_fn(ep, channel_id, int(sid_str),
                                    all_episodes_for_show=episodes)
            if norm is None:
                # Missing duration — skip, advance cursor past it
                self.record_missing_duration(channel_id, ep, "no_nfo")
                if not show_randomize:
                    cursor["ep_pos"][sid_str] = \
                        cursor["ep_pos"].get(sid_str, 0) + 1
                else:
                    played_list = cursor["ep_played"].setdefault(sid_str, [])
                    if ep["episodeid"] not in played_list:
                        played_list.append(ep["episodeid"])
                continue

            # Advance cursor by span
            if not show_randomize:
                cursor["ep_pos"][sid_str] = \
                    cursor["ep_pos"].get(sid_str, 0) + span
            else:
                played_list = cursor["ep_played"].setdefault(sid_str, [])
                for eid in span_ids:
                    if eid not in played_list:
                        played_list.append(eid)

            # Track queued files to avoid duplicates
            if ep_file:
                queued_files.add(ep_file)
                for eid in span_ids:
                    s_ep = next((e for e in episodes
                                 if e["episodeid"] == eid), None)
                    if s_ep and s_ep.get("file"):
                        queued_files.add(s_ep["file"])

            items.append(norm)
            placed += span  # multi-episode files count as span slots

        return placed

    @staticmethod
    def _eps_per_slot(show: dict, mode: str, episodes: list) -> int:
        if mode == "serial":
            return len(episodes)
        return max(1, int(show.get("episodes_per_slot", 1)))

    def _is_pool_empty(self, sid_str: str, episodes: list, cursor: dict,
                       show: dict, randomize: bool) -> bool:
        show_randomize = show.get("randomize", randomize)
        if show_randomize:
            played_set = set(cursor["ep_played"].get(sid_str, []))
            return all(e["episodeid"] in played_set for e in episodes)
        idx = cursor["ep_pos"].get(sid_str, 0)
        return idx >= len(episodes)

    @staticmethod
    def _reset_pool(sid_str: str, cursor: dict, randomize: bool) -> None:
        cursor["ep_played"].pop(sid_str, None)
        cursor["ep_pos"][sid_str] = 0

    # =========================================================================
    # Episode pool public API
    # Called by: channels/*.py, ui/*.py, service.py
    # =========================================================================

    def get_available_episodes(self, show_entry: dict) -> list:
        """Return a show's PLAYABLE episode pool: filters + exclusions applied.
        Delegates to channels/base.py — single source of truth.
        """
        return _get_available_episodes_fn(show_entry, self.library)

    def get_filtered_episodes(self, show_entry: dict) -> list:
        """Return a show's episode pool with filters applied only (no exclusions).
        Used by the exclusions picker UI.
        Delegates to channels/base.py — single source of truth.
        """
        return _get_filtered_episodes_fn(show_entry, self.library)

    # =========================================================================
    # Multi-episode span public API
    # Called by: service.py, ui/channels.py
    # =========================================================================

    def get_episode_span(self, episode_dict: dict) -> int:
        from resources.lib.utils.multi_episode import count_episode_span
        return count_episode_span(episode_dict)

    def get_span_episode_ids(self, episode_dict: dict,
                             all_episodes_for_show: list) -> list:
        from resources.lib.utils.multi_episode import span_episode_ids
        return span_episode_ids(episode_dict, all_episodes_for_show)

    # =========================================================================
    # Missing duration logging  (spec §7.5)
    # Called by: _fill_slot, channels/folder.py
    # =========================================================================

    def record_missing_duration(self, channel_id: str, item: dict,
                                reason: str) -> None:
        """Record a skipped item (zero/missing duration) in two places:

        1. Per-channel list in state.json — what context menus read.
        2. missing_durations.txt in the addon profile — permanent human log.

        spec §7.5
        """
        import datetime as _dt

        file_path = item.get("file", "")
        show      = item.get("tvshowtitle", item.get("title", ""))
        title     = item.get("title", "")
        season    = int(item.get("season",  0) or 0)
        episode   = int(item.get("episode", 0) or 0)
        ep_label  = ("S{:02d}E{:02d}".format(season, episode)
                     if season else "")

        # 1. Per-channel state list
        state_key = "{}:missing_durations".format(channel_id)
        try:
            state    = self._load_json(self._state_path, {})
            existing = state.get(state_key, [])
            known    = {e.get("file", "") for e in existing}
            if file_path not in known:
                existing.append({
                    "show":    show,
                    "title":   title,
                    "episode": ep_label,
                    "file":    file_path,
                    "reason":  reason,
                    "ts":      int(_dt.datetime.utcnow().timestamp()),
                })
                if len(existing) > 200:
                    existing = existing[-200:]
                state[state_key] = existing
                self._save_json(self._state_path, state)
        except Exception as exc:
            log("[ChannelManager] record_missing_duration state error: "
                "{}".format(exc))

        # 2. Global missing_durations.txt
        try:
            txt_path = self._resolve_path("missing_durations.txt")
            ts_str   = _dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            ch_obj   = self.get_channel(channel_id)
            ch_name  = (ch_obj.get("name", channel_id)
                        if ch_obj else channel_id)
            line     = "{}\t{}\t{}\t{}\t{}\t{}\n".format(
                ts_str, ch_name, show, ep_label, file_path, reason)
            existing_txt = ""
            if xbmcvfs.exists(txt_path):
                try:
                    rf = xbmcvfs.File(txt_path, "r")
                    existing_txt = rf.read()
                    rf.close()
                except Exception:
                    existing_txt = ""
            wf = xbmcvfs.File(txt_path, "w")
            wf.write(existing_txt + line)
            wf.close()
        except Exception as exc:
            log("[ChannelManager] record_missing_duration txt error: "
                "{}".format(exc))

    def get_missing_durations(self, channel_id: str) -> list:
        """Return the per-channel missing_durations list from state.json."""
        state_key = "{}:missing_durations".format(channel_id)
        try:
            state = self._load_json(self._state_path, {})
            return state.get(state_key, [])
        except Exception:
            return []

    # =========================================================================
    # Carousel state  (spec §4.4, §9.3)
    # Called by: carousel.py, service.py
    # =========================================================================

    def get_carousel_state(self, channel_id: str) -> dict:
        key = "{}:carousel".format(channel_id)
        return self._state.get(key, {})

    def set_carousel_state(self, channel_id: str, value: dict) -> None:
        key = "{}:carousel".format(channel_id)
        self._deleted_state_keys.discard(key)
        self._state[key] = value
        self._save_state()

    def get_carousel_elapsed(self, channel_id: str):
        """Return seconds elapsed since the last carousel pop for channel_id.

        Returns None if last_pop_time is absent (carousel has never fired).
        Used by channel info display.  Ported from 2.x channel_manager.py.
        """
        import time as _time
        try:
            state    = self.get_carousel_state(channel_id)
            last_pop = state.get("last_pop_time")
            if last_pop is None:
                return None
            return max(0.0, _time.time() - float(last_pop))
        except Exception as exc:
            log("[ChannelManager] get_carousel_elapsed error: {}".format(exc))
            return None

    # =========================================================================
    # State key generic public API
    # Called by: scheduler.py, service.py, channels/serial.py
    # =========================================================================

    def read_state_key(self, key: str, default=None):
        """Read a single key from state.json (always fresh from disk)."""
        try:
            fresh = self._load_json(self._state_path, {})
            return fresh.get(key, default)
        except Exception as exc:
            log("[ChannelManager] read_state_key '{}' error: {}".format(
                key, exc))
            return default

    def write_state_key(self, key: str, value) -> None:
        """Write a single key/value to state.json."""
        try:
            self._deleted_state_keys.discard(key)
            self._state[key] = value
            self._save_state()
        except Exception as exc:
            log("[ChannelManager] write_state_key '{}' error: {}".format(
                key, exc))

    # =========================================================================
    # Channel CRUD
    # =========================================================================

    def get_all_channels(self) -> list:
        return self._channels

    def get_visible_channels(self) -> list:
        return [c for c in self._channels if c.get("visible", True)]

    def get_channel(self, channel_id: str) -> Optional[ChannelDef]:
        for ch in self._channels:
            if ch["id"] == channel_id:
                return ch
        return None

    def reload_channels(self) -> None:
        self._channels = self._load_json(self._channels_path, [])

    def create_channel(self, definition: dict) -> ChannelDef:
        """Create a new channel and persist to channels.json.
        Pre-generates the queue immediately after creation.
        """
        channel = {
            "id":                 str(uuid.uuid4()),
            "name":               definition.get("name",             "Unnamed Channel"),
            "channel_type":       definition.get("channel_type",     "tv"),
            "playback_mode":      definition.get("playback_mode",    "round_robin"),
            "visible":            definition.get("visible",          True),
            "queue_size":         int(definition.get("queue_size",   self._default_queue_size())),
            "recycle":            definition.get("recycle",          True),
            "randomize":          definition.get("randomize",        False),
            "icon_path":          definition.get("icon_path",        ""),
            "interleave":         definition.get("interleave",       None),
            "carousel_enabled":   definition.get("carousel_enabled", False),
            "carousel_mode":      definition.get("carousel_mode",    "timed"),
            "carousel_interval":  definition.get("carousel_interval",  60),
            "carousel_pop_count": definition.get("carousel_pop_count", 1),
            "starting_points":    definition.get("starting_points",  {}),
            "owner":              definition.get("owner",            None),
            "sc_version":         "3.0.0",
            # TV
            "shows":              definition.get("shows",            []),
            "filters":            definition.get("filters",          []),
            # Movies
            "movies":             definition.get("movies",           []),
            "excluded_movies":    definition.get("excluded_movies",  []),
            # Folder
            "folder_path":        definition.get("folder_path",      ""),
            "no_repeat":          definition.get("no_repeat",         False),
            # NOTE: queue_size is not used for combo block channels in 3.x.
            # Combo blocks do not write queue files — items are built on-demand
            # via build_one_slot (1-for-1). The combo wizard no longer asks for
            # or returns queue_size. Existing stored values in channels.json are
            # harmless and left in place; new combo channels will use the default.
            # Audio
            "audio_order":        definition.get("audio_order",      "random"),
            "audio_filters":      definition.get("audio_filters",    []),
            "included_albums":    definition.get("included_albums",  {}),
            "excluded_songs":     definition.get("excluded_songs",   []),
            # Combo Block
            "slots":              definition.get("slots",            []),
        }
        self._channels.append(channel)
        self._save_channels()
        log("[ChannelManager] Created channel '{}' id={}".format(
            channel["name"], channel["id"]))
        # Initialise carousel last_pop_time to now so the first tick does NOT
        # fire immediately.  Without this, last_pop_time defaults to 0 and the
        # very first carousel tick sees elapsed >> any reasonable duration,
        # popping the queue front before the user has finished configuring the
        # channel (e.g. adding interleave sources).
        if channel.get("carousel_enabled", False):
            import time as _time
            self.set_carousel_state(channel["id"], {
                "last_pop_time":    _time.time(),
                "last_popped_show": None,
            })
            log("[ChannelManager] Carousel initialised last_pop_time=now "
                "for new channel '{}'".format(channel["name"]))
        self._pregenerate_queue_safe(channel)
        return channel

    def update_channel(self, channel_id: str,
                       definition: dict) -> Optional[ChannelDef]:
        """Update an existing channel and rebuild queue if needed."""
        channel = self.get_channel(channel_id)
        if not channel:
            return None

        old_shows      = list(channel.get("shows",        []))
        old_queue_size = channel.get("queue_size",        30)
        old_randomize  = channel.get("randomize",         False)
        old_recycle    = channel.get("recycle",           True)
        old_no_repeat  = channel.get("no_repeat",         False)
        old_type       = channel.get("channel_type",      "tv")
        old_interleave = channel.get("interleave",        None)
        old_slots      = list(channel.get("slots",        []))

        channel.update({k: definition.get(k, channel.get(k))
                        for k in definition})
        channel["sc_version"] = "3.0.0"
        self._save_channels()

        mode_changed = (
            old_randomize  != channel.get("randomize",  False)
            or old_recycle    != channel.get("recycle",    True)
            or old_no_repeat  != channel.get("no_repeat",  False)
            or old_type       != channel.get("channel_type", "tv")
        )

        new_show_ids = {s["tvshowid"] for s in channel.get("shows", [])}
        old_show_ids = {s["tvshowid"] for s in old_shows}
        removed      = old_show_ids - new_show_ids

        if mode_changed:
            cursor_key = "{}:cursor".format(channel_id)
            keys_to_del = [k for k in self._state
                           if k.startswith("{}:".format(channel_id))]
            for k in keys_to_del:
                del self._state[k]
            self._deleted_state_keys.update(keys_to_del)
            self._save_state()
        else:
            self.update_cursor_for_edit(
                channel_id,
                added_show_ids=list(new_show_ids - old_show_ids),
                removed_show_ids=list(removed),
                invalidate=False)

        no_queue_change = (
            not mode_changed
            and not removed
            and definition.get("shows",      old_shows)      == old_shows
            and definition.get("queue_size", old_queue_size) == old_queue_size
            and definition.get("interleave", old_interleave) == old_interleave
            and definition.get("slots",      old_slots)      == old_slots
        )

        if not no_queue_change:
            self._pregenerate_queue_safe(channel)

        # If carousel is enabled and last_pop_time is not yet set, initialise it
        # to now so the first tick does not fire immediately.
        cs = self.get_carousel_state(channel_id)
        if channel.get("carousel_enabled", False) and not cs.get("last_pop_time"):
            import time as _time
            self.set_carousel_state(channel_id, {
                "last_pop_time":    _time.time(),
                "last_popped_show": cs.get("last_popped_show"),
            })
            log("[ChannelManager] Carousel initialised last_pop_time=now "
                "for updated channel '{}'".format(channel.get("name", channel_id)))

        log("[ChannelManager] Updated channel id={}".format(channel_id))
        return channel

    def delete_channel(self, channel_id: str) -> bool:
        """Delete a channel and ALL associated data.

        Handles (regardless of deletion order):
        1.  Own state keys: "{channel_id}:*" and "resume:{channel_id}:*"
        2.  Combo slot state keys: "combo:{channel_id}:*" (tv_next_ep,
            show_slot, movie_state, folder_played, missing_durations)
        3.  Combo owner field: clear owner on any combo this channel owned
            so it becomes available as a source for other channels.
        4.  Interleave back-references: remove this channel from every other
            channel's interleave source list.
        5.  Schedules: delete any schedule where this channel is the source
            or the target.
        6.  Auto-companion channels: recursively delete any __auto__ companion
            channel that is only referenced by this channel's interleave
            config.  (Ported from 2.x — applies once auto_channels is active.)
        7.  Queue file(s): delete queue_{channel_id}.json and any .tmp copy.
        """
        from resources.lib.channels.interleave import get_sources

        channel = self.get_channel(channel_id)
        if not channel:
            return False

        # ── Step 1: Cross-channel pre-cleanup (before removing from list) ──

        # Clear combo owner and delete auto-companions in interleave sources.
        for source in get_sources(channel):
            src_id  = source.get("channel_id", "")
            src_ch  = self.get_channel(src_id)
            if not src_ch:
                continue
            # Clear owner field so the combo becomes available elsewhere.
            if src_ch.get("channel_type") == "combo":
                self.clear_combo_owner(src_id)
                log("[ChannelManager] delete_channel: cleared combo owner "                    "for '{}'".format(src_ch.get("name", src_id)))
            # Recursively delete __auto__ companion channels.
            if (src_ch.get("name", "").startswith("__auto__")
                    and not src_ch.get("visible", True)):
                self.delete_channel(src_id)
                log("[ChannelManager] delete_channel: deleted auto-companion "                    "'{}'".format(src_ch.get("name", src_id)))

        # Remove this channel from every other channel's interleave config.
        channels_changed = False
        for ch in self._channels:
            if ch["id"] == channel_id:
                continue
            raw = ch.get("interleave")
            if not raw:
                continue
            sources_list = raw if isinstance(raw, list) else [raw]
            filtered     = [s for s in sources_list
                            if s.get("channel_id") != channel_id]
            if len(filtered) != len(sources_list):
                ch["interleave"] = filtered if filtered else None
                channels_changed = True
                log("[ChannelManager] delete_channel: removed interleave "                    "ref from '{}'".format(ch.get("name", ch["id"])))

        # Delete schedules where this channel is source or target.
        schedules = self.get_all_schedules()
        sched_ids_to_del = [
            sid for sid, sch in schedules.items()
            if sch.get("target_channel_id") == channel_id
            or sch.get("target_channel")    == channel_id
            or sch.get("source_channel_id") == channel_id
            or sch.get("source_channel")    == channel_id
        ]
        if sched_ids_to_del:
            for sid in sched_ids_to_del:
                del schedules[sid]
                log("[ChannelManager] delete_channel: deleted schedule "                    "{}".format(sid))
            self.save_schedules_data(schedules)

        # ── Step 2: Remove channel from list ──
        before = len(self._channels)
        self._channels = [c for c in self._channels if c["id"] != channel_id]
        if len(self._channels) >= before:
            return False

        # ── Step 3: State key cleanup ──
        # Standard keys:   "{channel_id}:*"
        # Resume keys:     "resume:{channel_id}:*"
        # Combo slot keys: "combo:{channel_id}:*" (show_slot, tv_next_ep,
        #                   movie_state, folder_played, missing_durations)
        prefixes = (
            "{}:".format(channel_id),
            "resume:{}:".format(channel_id),
            "combo:{}:".format(channel_id),
        )
        keys_to_del = [k for k in self._state
                       if any(k.startswith(p) for p in prefixes)]
        for k in keys_to_del:
            del self._state[k]
        self._deleted_state_keys.update(keys_to_del)

        # ── Step 4: Persist all changes ──
        self._save_channels()
        self._save_state()

        # ── Step 5: Delete queue file ──
        queue_path = self._queue_file_path(channel_id)
        for p in (queue_path, queue_path + ".tmp"):
            try:
                if xbmcvfs.exists(p):
                    xbmcvfs.delete(p)
            except Exception:
                pass

        log("[ChannelManager] Deleted channel id={} — removed {} state "            "key(s), {} schedule(s)".format(
                channel_id, len(keys_to_del), len(sched_ids_to_del)))
        return True

    def toggle_visibility(self, channel_id: str) -> None:
        channel = self.get_channel(channel_id)
        if channel:
            channel["visible"] = not channel.get("visible", True)
            self._save_channels()

    def save_channel_list(self) -> None:
        """Flush the in-memory channel list to channels.json.
        Public alias for callers outside channel_manager.py.
        """
        self._save_channels()

    # =========================================================================
    # Channel ordering
    # =========================================================================

    def _find_channel_index(self, channel_id: str) -> int:
        for i, ch in enumerate(self._channels):
            if ch["id"] == channel_id:
                return i
        return -1

    def move_channel_up(self, channel_id: str) -> bool:
        idx = self._find_channel_index(channel_id)
        if idx <= 0:
            return False
        self._channels[idx], self._channels[idx - 1] = \
            self._channels[idx - 1], self._channels[idx]
        self._save_channels()
        return True

    def move_channel_down(self, channel_id: str) -> bool:
        idx = self._find_channel_index(channel_id)
        if idx < 0 or idx >= len(self._channels) - 1:
            return False
        self._channels[idx], self._channels[idx + 1] = \
            self._channels[idx + 1], self._channels[idx]
        self._save_channels()
        return True

    def sort_channels_alpha(self) -> None:
        import re as _re
        def _natural_key(c):
            parts = _re.split(r'(\d+)', c.get("name", "").lower())
            return [int(p) if p.isdigit() else p for p in parts]
        self._channels.sort(key=_natural_key)
        self._save_channels()

    # =========================================================================
    # Schedule CRUD  (unchanged from 2.x — spec §12)
    # =========================================================================

    def get_all_schedules(self) -> dict:
        return self._load_json(self._schedules_path, {})

    def get_schedule(self, schedule_id: str) -> Optional[dict]:
        return self.get_all_schedules().get(schedule_id)

    def add_schedule(self, definition: dict) -> dict:
        schedules = self.get_all_schedules()
        sch_id    = "sch_" + str(uuid.uuid4())
        definition["id"] = sch_id
        schedules[sch_id] = definition
        self._save_json(self._schedules_path, schedules)
        return definition

    def update_schedule(self, schedule_id: str,
                        definition: dict) -> Optional[dict]:
        schedules = self.get_all_schedules()
        if schedule_id not in schedules:
            return None
        definition["id"]        = schedule_id
        schedules[schedule_id]  = definition
        self._save_json(self._schedules_path, schedules)
        return definition

    def delete_schedule(self, schedule_id: str) -> None:
        schedules = self.get_all_schedules()
        if schedule_id in schedules:
            del schedules[schedule_id]
            self._save_json(self._schedules_path, schedules)
        block_key = "{}:active_block".format(schedule_id)
        try:
            state = self._load_json(self._state_path, {})
            if block_key in state:
                del state[block_key]
                self._save_json(self._state_path, state)
        except Exception:
            pass

    def save_schedules_data(self, schedules: dict) -> None:
        self._save_json(self._schedules_path, schedules)

    def get_active_block(self, schedule_id: str) -> Optional[dict]:
        key = "{}:active_block".format(schedule_id)
        return self._load_json(self._state_path, {}).get(key)

    def set_active_block(self, schedule_id: str, block: dict) -> None:
        key   = "{}:active_block".format(schedule_id)
        state = self._load_json(self._state_path, {})
        state[key] = block
        self._save_json(self._state_path, state)

    def clear_active_block(self, schedule_id: str) -> None:
        key   = "{}:active_block".format(schedule_id)
        state = self._load_json(self._state_path, {})
        if key in state:
            del state[key]
            self._save_json(self._state_path, state)

    # =========================================================================
    # Combo Block public API  (spec §11)
    # =========================================================================

    def set_combo_owner(self, combo_id: str, target_id: str,
                        target_name: str, relationship: str) -> None:
        ch = self.get_channel(combo_id)
        if not ch:
            return
        ch["owner"] = {
            "channel_id":   target_id,
            "channel_name": target_name,
            "relationship": relationship,
        }
        self._save_channels()

    def clear_combo_owner(self, combo_id: str) -> None:
        ch = self.get_channel(combo_id)
        if ch and ch.get("owner") is not None:
            ch["owner"] = None
            self._save_channels()

    def get_interleave_source_owner(self, source_id: str,
                                    exclude_channel_id: str = "") -> Optional[dict]:
        """Return the channel that uses source_id as an interleave source, or None.

        Scans all channels' interleave source lists.  Used by the interleave
        source picker to enforce the one-owner rule for regular (non-combo)
        channels.

        exclude_channel_id: the channel currently being edited — its own
        sources are not counted as foreign ownership.
        """
        from resources.lib.channels.interleave import get_sources
        for ch in self.get_all_channels():
            if ch["id"] == exclude_channel_id:
                continue
            for src in get_sources(ch):
                if src.get("channel_id") == source_id:
                    return ch
        return None

    def get_combo_owner(self, combo_id: str) -> Optional[dict]:
        ch = self.get_channel(combo_id)
        return (ch.get("owner") or None) if ch else None

    # =========================================================================
    # Resume position  (spec §1.6)
    # Called by: service.py, player.py
    # =========================================================================

    def save_resume_position(self, channel_id: str, item_file: str,
                             position_seconds: float) -> None:
        """Save resume position for item_file on channel_id."""
        if not item_file:
            return
        key = "resume:{}:{}".format(channel_id, item_file)
        self._deleted_state_keys.discard(key)
        self._state[key] = round(position_seconds, 2)
        self._save_state()
        log("[ChannelManager] save_resume_position: {} @ {:.0f}s".format(
            key, position_seconds))

    def get_resume_position(self, channel_id: str,
                            item_file: str) -> Optional[dict]:
        """Return saved resume entry for item_file, or None.
        Returns None if position <= 10s (treat as not started).
        """
        if not item_file:
            return None
        key      = "resume:{}:{}".format(channel_id, item_file)
        position = self._state.get(key)
        if position is None:
            return None
        if float(position) <= 10:
            return None
        return {"position": float(position)}

    def clear_resume_position(self, channel_id: str, item_file: str) -> None:
        """Remove resume entry for item_file on channel_id."""
        if not item_file:
            return
        key = "resume:{}:{}".format(channel_id, item_file)
        self._state.pop(key, None)
        self._deleted_state_keys.add(key)
        self._save_state()

    def set_pending_seek(self, channel_id: str, position: float) -> None:
        """Store a seek position for service.py to execute in onAVStarted.

        Called by player.py start_channel() after the user accepts a resume
        dialog.  service.py reads and clears it via pop_pending_seek() once
        the file is open and seekTime() is safe (onAVStarted).
        """
        key = "pending_seek:{}".format(channel_id)
        self._state[key] = round(position, 2)
        self._deleted_state_keys.discard(key)
        self._save_state()

    def pop_pending_seek(self, channel_id: str) -> Optional[float]:
        """Return and remove any pending seek position for channel_id.

        Returns None if no seek is pending.  Clears the entry so it fires
        exactly once even if onAVStarted is called more than once.
        """
        key = "pending_seek:{}".format(channel_id)
        position = self._state.pop(key, None)
        if position is not None:
            self._deleted_state_keys.add(key)
            self._save_state()
            return float(position)
        return None

    # =========================================================================
    # Channel exhaustion  (spec §1.2)
    # =========================================================================

    def is_channel_exhausted(self, channel_id: str, channel: dict) -> bool:
        """Return True when a recycle=False channel has nothing left to play."""
        if channel.get("recycle", True):
            return False
        ctype = channel.get("channel_type", "tv")
        if ctype == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            return FolderQueueBuilder(self).is_exhausted(channel)
        if ctype == "movies":
            state_key = "{}:__movie_state__".format(channel_id)
            mstate    = self._load_json(self._state_path, {}).get(state_key)
            if mstate is None:
                return False
            return (len(mstate.get("unplayed_ids", [1])) == 0
                    and len(mstate.get("played_ids", [])) > 0)
        # TV channels: all shows exhausted
        shows = channel.get("shows", [])
        if not shows:
            return False
        for show in shows:
            cursor = self.get_cursor(channel_id)
            sid    = str(show["tvshowid"])
            eps    = self.get_available_episodes(show)
            if not eps:
                continue
            if not self._is_pool_empty(sid, eps, cursor, show,
                                        channel.get("randomize", False)):
                return False
        return True

    # =========================================================================
    # Channel icon resolution
    # =========================================================================

    def resolve_channel_icon(self, ch: dict) -> str:
        """Resolve the display icon path for a channel.

        Priority: manual icon_path → channel_icon_folder auto-match → default.
        """
        ch_name   = ch.get("name", "")
        icon_path = ch.get("icon_path", "")
        if icon_path and xbmcvfs.exists(icon_path):
            return icon_path

        folder = self.addon.getSetting("channel_icon_folder").strip()
        if folder:
            folder_base = folder.rstrip("/\\")
            ch_name_lower = ch_name.strip().lower()
            for ext in (".png", ".jpg", ".jpeg"):
                candidate = xbmcvfs.translatePath(
                    "{}/{}{}".format(folder_base, ch_name, ext))
                if xbmcvfs.exists(candidate):
                    return candidate
            try:
                _dirs, files = xbmcvfs.listdir(folder)
                for fname in files:
                    if "." not in fname:
                        continue
                    base, fext = fname.rsplit(".", 1)
                    if ("." + fext.lower()) in (".png", ".jpg", ".jpeg"):
                        if base.lower() == ch_name_lower:
                            return xbmcvfs.translatePath(
                                "{}/{}".format(folder_base, fname))
            except Exception:
                pass

        return "DefaultVideoPlaylists.png"

    # =========================================================================
    # EPG stub  (spec §24)
    # =========================================================================

    def get_epg_data(self, channel_id: str, hours: int = 2) -> list:
        """EPG data — stub, returns [] until Phase 6+ implements full EPG."""
        return []

    # =========================================================================
    # Movie queue building  (used by channels/movies.py and _replacement_movie)
    # =========================================================================

    def build_fresh_movie_queue(self, channel: dict, size: int) -> list:
        """Build a fresh movie queue. Called by MovieQueueBuilder and
        get_one_replacement. Delegates to _build_movie_queue."""
        return self._build_movie_queue(channel, size)

    def _build_movie_queue(self, channel: dict, target_size: int) -> list:
        """Build a queue of movies for a movie channel.

        Uses the channel's movies list, applies filters and exclusions,
        respects randomize/recycle, tracks played_ids in state.json.

        target_size is a hard ceiling — the queue is filled by recycling
        through the movie pool as many times as needed until the queue
        reaches target_size (or the pool is exhausted for recycle=False).
        Matches 2.x behaviour exactly.
        """
        import random as _random

        channel_id = channel["id"]
        movies     = channel.get("movies", [])
        randomize  = channel.get("randomize", True)
        recycle    = channel.get("recycle",   True)

        if not movies:
            log("[ChannelManager] _build_movie_queue: no movies in channel")
            return []

        excluded     = set(channel.get("excluded_movies", []))
        filters      = channel.get("filters", [])
        movie_ids    = [m["movieid"] for m in movies
                        if m["movieid"] not in excluded]
        movie_id_set = set(movie_ids)

        # Load details from local cache — always read from file so we
        # see fresh data including plots, bypassing any stale in-memory copy.
        cached = self.library.load_local_cache()
        if cached and cached.get("movies"):
            all_movies = [m for m in cached["movies"]
                          if m.get("movieid") in movie_id_set]
        else:
            all_movies = [m for m in self.library.get_all_movies()
                          if m.get("movieid") in movie_id_set]

        if filters and all_movies:
            all_movies = self.library._filter_items_in_python(all_movies, filters)

        movie_lookup = {m["movieid"]: m for m in all_movies}
        if not movie_lookup:
            log("[ChannelManager] _build_movie_queue: no movies in library")
            return []

        # Dedup channel movie list preserving order
        seen_ids = set()
        all_available = []
        for mid in movie_ids:
            if mid not in seen_ids and mid in movie_lookup:
                seen_ids.add(mid)
                all_available.append(mid)

        if not all_available:
            return []

        # Load state fresh from disk so we always see the latest played_ids.
        state_key  = "{}:__movie_state__".format(channel_id)
        fresh      = self._load_json(self._state_path, {})
        mstate     = fresh.get(state_key, {"played_ids": [], "next_index": 0})
        played_ids = list(mstate.get("played_ids", []))
        next_index = mstate.get("next_index", 0)

        # Reconstruct unplayed pool, honouring any stored order and
        # appending movies added to the channel since the last build.
        stored_unplayed = mstate.get("unplayed_ids")
        valid_id_set    = set(all_available)
        if stored_unplayed is not None:
            unplayed_ids = [mid for mid in stored_unplayed if mid in valid_id_set]
            stored_set   = set(stored_unplayed) | set(played_ids)
            for mid in all_available:
                if mid not in stored_set:
                    unplayed_ids.append(mid)
        else:
            unplayed_ids = [mid for mid in all_available if mid not in played_ids]

        queue = []

        if randomize:
            # Draw from unplayed pool, recycling through all_available as
            # needed until target_size is reached.  Matches 2.x exactly:
            # every movie plays once per cycle before any repeats; the cycle
            # boundary falls wherever target_size lands (no padding to a full
            # cycle).  A back-to-back repeat guard is applied at each cycle
            # reset so the last movie of one cycle never immediately precedes
            # the first movie of the next.
            if not recycle and not unplayed_ids:
                pass  # pool exhausted and recycle=False — return empty
            else:
                working_unplayed = list(unplayed_ids)
                working_played   = list(played_ids)
                while len(queue) < target_size:
                    if not working_unplayed:
                        if not recycle:
                            break
                        log("[ChannelManager] _build_movie_queue: "
                            "cycle complete — resetting for next cycle")
                        working_played   = []
                        working_unplayed = list(all_available)
                        if not working_unplayed:
                            break
                    # Shuffle the remaining pool each draw pass.
                    draw_pool = list(working_unplayed)
                    _random.shuffle(draw_pool)
                    # Back-to-back repeat guard at cycle boundary.
                    if (queue and len(draw_pool) > 1 and
                            draw_pool[0] == queue[-1].get("movieid")):
                        draw_pool = draw_pool[1:] + draw_pool[:1]
                    slots_needed = target_size - len(queue)
                    for mid in draw_pool[:slots_needed]:
                        movie = movie_lookup.get(mid)
                        if movie:
                            norm = _normalize_movie_fn(
                                movie, channel_id, library=self.library)
                            if not norm or not norm.get("duration"):
                                self.record_missing_duration(
                                    channel_id, movie, "no_runtime")
                            else:
                                queue.append(norm)
                        working_unplayed.remove(mid)
                        working_played.append(mid)
                unplayed_ids = working_unplayed
                played_ids   = working_played
        else:
            # Sequential — walk all_available from next_index, wrapping
            # when recycle=True, stopping when recycle=False.
            for _ in range(target_size):
                if not all_available:
                    break
                if next_index >= len(all_available):
                    if not recycle:
                        break
                    next_index = 0
                chosen_id = all_available[next_index]
                movie     = movie_lookup.get(chosen_id)
                if movie:
                    norm = _normalize_movie_fn(
                        movie, channel_id, library=self.library)
                    if not norm or not norm.get("duration"):
                        self.record_missing_duration(
                            channel_id, movie, "no_runtime")
                    else:
                        queue.append(norm)
                next_index += 1

        # Persist updated cycle state.
        self.write_state_key(state_key, {
            "played_ids":   played_ids,
            "unplayed_ids": unplayed_ids,
            "next_index":   next_index,
        })

        log("[ChannelManager] _build_movie_queue: built {} items for '{}'".format(
            len(queue), channel.get("name", channel_id)))
        return queue

    # =========================================================================
    # Combo Block queue building  (used by channels/combo.py)
    # =========================================================================

    def build_combo_tv_slot(self, combo_channel_id: str,
                            slot: dict, count: int) -> list:
        """Build `count` TV episodes for one Combo Block TV slot.

        When multiple shows are configured on the slot they rotate in
        round-robin order — one episode per show per unit — matching 2.x
        exactly.  Result order: [show0_ep0, show1_ep0, show0_ep1, ...].

        State is isolated to combo_channel_id:slot_id and never touches
        any standalone channel's state.
        """
        import random as _random

        slot_id = slot.get("slot_id", "")
        shows   = slot.get("shows")
        if not shows:
            legacy_id = slot.get("tvshowid")
            if not legacy_id:
                return []
            shows = [{
                "tvshowid":          legacy_id,
                "title":             slot.get("title", str(legacy_id)),
                "episode_filters":   slot.get("episode_filters",   []),
                "excluded_episodes": slot.get("excluded_episodes", []),
                "randomize":         slot.get("randomize", True),
                "recycle":           slot.get("recycle",   True),
                "silent":            slot.get("silent",    False),
            }]

        num_shows = len(shows)
        log("[ChannelManager] build_combo_tv_slot: slot {} — {} show(s), "
            "count={}".format(slot_id[:8], num_shows, count))

        # show_slot tracks position within the per-unit episode sequence.
        # The sequence repeats the show index eps_per_slot times, e.g. for
        # Show A (eps=2) and Show B (eps=1): sequence = [0, 0, 1] (length 3).
        # Each 1-for-1 replacement call (count=1) advances show_slot by 1
        # through this sequence so the correct show is always picked.
        show_slot_key = "combo:{}:slot:{}:show_slot".format(
            combo_channel_id, slot_id)
        try:
            show_slot = int(self.read_state_key(show_slot_key, 0))
        except (TypeError, ValueError):
            show_slot = 0

        # Build the repeating show sequence from eps_per_slot values.
        # sequence[i] = show_pools index for the i-th episode in one unit.
        unit_sequence = []
        for pool_idx, show_entry in enumerate(shows):
            eps = max(1, int(show_entry.get("episodes_per_slot", 1)))
            unit_sequence.extend([pool_idx] * eps)
        unit_cycle = len(unit_sequence) if unit_sequence else num_shows

        # Silent is a slot-level setting — all shows in a TV slot share
        # the same silent flag (they rotate as a unit).
        slot_silent = slot.get("silent", False)

        # Build per-show episode pools once.
        show_pools = []
        for show_entry in shows:
            show_id   = show_entry.get("tvshowid")
            randomize = show_entry.get("randomize", True)
            recycle   = show_entry.get("recycle",   True)
            # Per-show silent is kept for backward-compat with existing
            # channel data that stored it per-show; slot level takes
            # precedence when set, otherwise fall back to per-show value.
            silent    = slot_silent or show_entry.get("silent", False)

            available = self.get_available_episodes(show_entry)
            if not available:
                log("[ChannelManager] build_combo_tv_slot: no episodes for "
                    "show {} (slot {})".format(show_id, slot_id[:8]))
                show_pools.append(None)
                continue

            avail_ids   = [e["episodeid"] for e in available]
            next_ep_key = "combo:{}:slot:{}:show:{}:tv_next_ep".format(
                combo_channel_id, slot_id, show_id)

            stored_next = self.read_state_key(next_ep_key, None)
            if stored_next is not None:
                try:
                    start_idx = avail_ids.index(int(stored_next))
                except ValueError:
                    start_idx = 0
            else:
                start_idx = 0

            if randomize:
                pool = available[:]
                _random.shuffle(pool)
            else:
                pool = available[start_idx:] + available[:start_idx]

            show_pools.append({
                "show_id":      show_id,
                "randomize":    randomize,
                "recycle":      recycle,
                "silent":       silent,
                "available":    available,
                "avail_ids":    avail_ids,
                "pool":         pool,
                "pool_offset":  0,
                "exhausted":    False,
                "next_ep_key":  next_ep_key,
                "eps_per_slot": max(1, int(
                    show_entry.get("episodes_per_slot", 1))),
            })

        # Round-robin: one full turn per show per unit.
        # Each turn fetches eps_per_slot consecutive episodes from that show
        # before advancing to the next show, giving correct grouping:
        # [A_ep1, A_ep2, B_ep1] for eps_per_slot(A)=2, eps_per_slot(B)=1.
        #
        # `count` passed in = units_needed * sum(eps_per_slot).
        # Recover units_needed so we iterate the right number of rounds.
        def _fetch_one_ep(sp):
            """Pop the next valid episode from a show pool.
            Handles recycle and no-duration skipping.
            Returns a normalised item dict or None.
            """
            pool = sp["pool"]
            ep   = None

            if sp["pool_offset"] < len(pool):
                ep                = pool[sp["pool_offset"]]
                sp["pool_offset"] += 1
            elif sp["recycle"]:
                if sp["randomize"]:
                    _random.shuffle(pool)
                sp["pool_offset"] = 1
                ep = pool[0] if pool else None
                if ep is None:
                    sp["exhausted"] = True
                    return None
            else:
                sp["exhausted"] = True
                return None

            # Try episodes until one has a valid duration.
            attempts = len(pool)
            while attempts > 0:
                norm = _normalize_ep_fn(ep, combo_channel_id,
                                        sp["show_id"],
                                        all_episodes_for_show=sp["available"])
                if norm is not None:
                    norm["channel_id"]  = combo_channel_id
                    norm["_channel_id"] = combo_channel_id
                    norm["show_id"]     = sp["show_id"]
                    norm["_show_id"]    = sp["show_id"]
                    norm["_silent"]     = sp["silent"]
                    return norm
                self.record_missing_duration(combo_channel_id, ep, "no_nfo")
                attempts -= 1
                if sp["pool_offset"] < len(pool):
                    ep                = pool[sp["pool_offset"]]
                    sp["pool_offset"] += 1
                elif sp["recycle"]:
                    if sp["randomize"]:
                        _random.shuffle(pool)
                    sp["pool_offset"] = 1
                    ep = pool[0] if pool else None
                    if ep is None:
                        break
                else:
                    break
            return None

        # Build exactly `count` episodes, selecting shows via unit_sequence.
        # show_slot is the position within unit_sequence, persisted across
        # calls so the 1-for-1 replacement path (count=1) always picks the
        # correct show for the current position in the repeating pattern.
        #
        # Example: A(eps=2), B(eps=1) → unit_sequence=[0,0,1], cycle=3
        #   call 1 (count=1, show_slot=0): seq[0]=Show A → A_ep1, show_slot→1
        #   call 2 (count=1, show_slot=1): seq[1]=Show A → A_ep2, show_slot→2
        #   call 3 (count=1, show_slot=2): seq[2]=Show B → B_ep1, show_slot→3
        #   call 4 (count=1, show_slot=3%3=0): seq[0]=Show A → A_ep3 ...
        result = []
        episodes_needed = count
        while episodes_needed > 0:
            seq_idx  = show_slot % unit_cycle if unit_cycle else 0
            pool_idx = unit_sequence[seq_idx] if unit_sequence else 0
            sp       = show_pools[pool_idx] if pool_idx < len(show_pools) else None

            if sp is None or sp["exhausted"]:
                # This show is exhausted — advance and try next position.
                show_slot += 1
                if all(sp is None or sp["exhausted"] for sp in show_pools):
                    break
                continue

            norm = _fetch_one_ep(sp)
            if norm is not None:
                result.append(norm)
                episodes_needed -= 1
            show_slot += 1

        # Persist per-show next-episode pointers.
        for sp in show_pools:
            if sp is None:
                continue
            last_ep_id = None
            for item in reversed(result):
                if item.get("show_id") == sp["show_id"]:
                    last_ep_id = item.get("episodeid", -1)
                    break
            if last_ep_id is not None:
                avail_ids = sp["avail_ids"]
                available = sp["available"]
                try:
                    last_idx = avail_ids.index(last_ep_id)
                    next_idx = (last_idx + 1) % len(available)
                    next_id  = avail_ids[next_idx]
                except (ValueError, ZeroDivisionError):
                    next_id  = avail_ids[0] if avail_ids else None
                if next_id is not None:
                    self.write_state_key(sp["next_ep_key"], next_id)

        # Persist show_slot — already advanced in the loop above.
        self.write_state_key(show_slot_key, show_slot)

        log("[ChannelManager] build_combo_tv_slot: slot {} built {} "
            "items".format(slot_id[:8], len(result)))
        return result

    def build_combo_movie_slot(self, combo_channel_id: str,
                               slot: dict, count: int) -> list:
        """Build count movies for one Combo Block Movie slot."""
        import random as _random

        slot_id   = slot.get("slot_id", "")
        randomize = slot.get("randomize", True)
        recycle   = slot.get("recycle",   True)
        excluded  = set(slot.get("excluded_movies", []))
        filters   = slot.get("filters", [])
        state_key = "combo:{}:slot:{}:movie_state".format(
            combo_channel_id, slot_id)

        explicit_movies = slot.get("movies", [])
        if explicit_movies:
            # User picked specific movies — build pool from those IDs only.
            explicit_ids = {m["movieid"] for m in explicit_movies
                            if "movieid" in m}
            all_movies = [m for m in self.library.get_all_movies()
                          if m.get("movieid") in explicit_ids]
        else:
            if filters:
                all_movies = self.library.get_movies_with_filters(filters)
            else:
                all_movies = self.library.get_all_movies()
        all_movies = [m for m in all_movies
                      if m.get("movieid", -1) not in excluded]
        if not all_movies:
            return []

        all_ids    = [m["movieid"] for m in all_movies]
        mstate     = self.read_state_key(state_key, None) or {}
        played     = set(mstate.get("played_ids", []))
        unplayed   = [m for m in all_movies if m.get("movieid", -1) not in played]

        if not unplayed:
            if not recycle:
                return []
            played   = set()
            unplayed = all_movies[:]
            self.write_state_key(state_key, {"played_ids": [], "unplayed_ids": all_ids})

        if randomize:
            pool = unplayed[:]
            _random.shuffle(pool)
        else:
            pool = unplayed

        result = []
        for movie in pool[:count]:
            norm = _normalize_movie_fn(movie, combo_channel_id, library=self.library)
            if not norm or not norm.get("duration"):
                self.record_missing_duration(combo_channel_id, movie, "no_runtime")
                continue
            norm["channel_id"]  = combo_channel_id
            norm["_channel_id"] = combo_channel_id
            result.append(norm)
            played.add(movie.get("movieid", -1))

        remaining = [m["movieid"] for m in all_movies
                     if m.get("movieid", -1) not in played]
        self.write_state_key(state_key, {
            "played_ids":   list(played),
            "unplayed_ids": remaining,
        })
        return result

    def get_interleave_items(self, source_channel_id: str, count: int) -> list:
        """Fetch count items from source_channel_id for interleave insertion.
        Called by carousel.py.
        """
        foreign_ch = self.get_channel(source_channel_id)
        if not foreign_ch:
            return []
        try:
            return self._load_foreign_items(source_channel_id, foreign_ch, count) or []
        except Exception as exc:
            log("[ChannelManager] get_interleave_items error: {}".format(exc))
            return []

    def _load_foreign_items(self, foreign_id: str, foreign_ch: dict,
                            needed: int) -> list:
        """Load needed items from a foreign channel for interleave weaving.

        For TV channel sources: builds from a FRESH cursor (ep_pos all zeroes)
        so the interleave always starts from S01E01 regardless of where the
        TV channel's own queue build left the cursor.  The fresh cursor is
        written back so subsequent calls continue from where this one left off,
        but the TV channel's own standalone cursor is not touched — we save it
        first and restore it after so the TV channel's own queue is unaffected.
        """
        ctype = foreign_ch.get("channel_type", "tv")
        if ctype == "tv":
            # Save the TV channel's own cursor so we can restore it.
            own_cursor = self.get_cursor(foreign_id)
            # Build a fresh interleave cursor starting from episode 1.
            fresh_cursor = {
                "show_slot": 0,
                "ep_pos":    {},
                "ep_played": {},
                "slot_owed": {},
            }
            items, interleave_cursor = self._build_tv_items(
                foreign_ch, needed, fresh_cursor)
            # Restore the TV channel's own cursor — the channel's standalone
            # queue must not be affected by the interleave build.
            self.set_cursor(foreign_id, own_cursor)
            return items
        if ctype == "movies":
            return self._build_movie_queue(foreign_ch, needed)
        if ctype == "folder":
            from resources.lib.channels.folder import FolderQueueBuilder
            return FolderQueueBuilder(self).build(foreign_ch, needed) or []
        if ctype == "combo":
            from resources.lib.channels.combo import ComboQueueBuilder
            return ComboQueueBuilder(self).build(foreign_ch, needed)
        return []

    # =========================================================================
    # Show state public API  (used by folder.py, party.py, service.py)
    # =========================================================================

    def get_show_state(self, channel_id: str, show_id: int) -> dict:
        """Return the playback state dict for show_id within channel_id."""
        key = "{}:{}".format(channel_id, show_id)
        return self._state.get(key, {
            "next_episode_id": None,
            "season":          1,
            "episode":         1,
            "played_ids":      [],
        })

    def save_show_state(self, channel_id: str, show_id: int,
                        state: dict) -> None:
        """Persist show state for show_id within channel_id."""
        key = "{}:{}".format(channel_id, show_id)
        self._state[key] = state
        self._save_state()

    def record_folder_file_played(self, channel_id: str,
                                   file_path: Optional[str]) -> None:
        """Record a folder/party file as played for recycle=False / no_repeat tracking.

        When file_path is None, clears the entire played list — used by
        FolderQueueBuilder when a no_repeat cycle completes and the slot
        should start over from the full file set.
        """
        state = self.get_show_state(channel_id, 0)
        if file_path is None:
            # Clear played list — no_repeat cycle reset.
            if "played_files" in state:
                state["played_files"] = []
                self.save_show_state(channel_id, 0, state)
            return
        played = state.get("played_files", [])
        if file_path not in played:
            played.append(file_path)
            state["played_files"] = played
            self.save_show_state(channel_id, 0, state)

    # =========================================================================
    # Audio no-repeat state  (used by channels/audio.py)
    # =========================================================================

    def get_audio_no_repeat_played(self, channel_id: str) -> list:
        state_key = "{}:audio_no_repeat_played".format(channel_id)
        return list(self._load_json(self._state_path, {}).get(state_key, []))

    def set_audio_no_repeat_played(self, channel_id: str,
                                    played: list) -> None:
        state_key = "{}:audio_no_repeat_played".format(channel_id)
        self.write_state_key(state_key, played)

    # =========================================================================
    # Party no-repeat state  (used by channels/party.py)
    # =========================================================================

    def get_party_no_repeat_played(self, channel_id: str) -> list:
        state_key = "{}:party_no_repeat_played".format(channel_id)
        return list(self._load_json(self._state_path, {}).get(state_key, []))

    def set_party_no_repeat_played(self, channel_id: str,
                                    played: list) -> None:
        state_key = "{}:party_no_repeat_played".format(channel_id)
        self.write_state_key(state_key, played)

    # =========================================================================
    # has_resume_for_file  (used by channels/folder.py)
    # =========================================================================

    def has_resume_for_file(self, channel_id: str, file_path: str) -> bool:
        """Return True if a resume position exists for file_path on channel."""
        import hashlib
        if not file_path:
            return False
        md5 = hashlib.md5(file_path.encode("utf-8")).hexdigest()[:16]
        key = "resume:{}:file:{}".format(channel_id, md5)
        return key in self._load_json(self._state_path, {})

    # =========================================================================
    # folder_default_duration setting helper
    # =========================================================================

    def get_folder_default_duration(self) -> int:
        """Return the configured folder default duration in seconds."""
        try:
            return max(1, int(
                self.addon.getSetting("folder_default_duration") or "120"))
        except (ValueError, TypeError):
            return 120

    # =========================================================================
    # Queue pre-generation helper (called after create / edit)
    # =========================================================================

    def _apply_combo_slot_starting_points(self, channel: dict) -> None:
        """Write tv_next_ep state for any combo TV slots that have starting_points.

        Called when a combo channel is created or updated so that the first
        episode fetched by build_combo_tv_slot starts from the user's chosen
        episode rather than the beginning of the show.
        """
        channel_id = channel["id"]
        for slot in channel.get("slots", []):
            if slot.get("source_type") != "tv":
                continue
            slot_id         = slot.get("slot_id", "")
            starting_points = slot.get("starting_points", {})
            if not starting_points:
                continue
            for show in slot.get("shows", []):
                sid    = show["tvshowid"]
                sp     = starting_points.get(str(sid)) or starting_points.get(sid)
                if not sp:
                    continue
                ep_id  = sp.get("episodeid")
                if ep_id is None:
                    continue
                key = "combo:{}:slot:{}:show:{}:tv_next_ep".format(
                    channel_id, slot_id, sid)
                self.write_state_key(key, ep_id)
                log("[ChannelManager] combo slot starting point: "
                    "show {} → episodeid {} (S{}E{} '{}')".format(
                    sid, ep_id,
                    sp.get("season", "?"), sp.get("episode", "?"),
                    sp.get("title", "")))

    def _sync_combo_state_from_queue(self, woven_queue: list,
                                     channel: dict) -> None:
        """After weaving, set tv_next_ep for each combo TV slot to the episode
        that follows the last one actually inserted into the woven queue.

        The interleave weaver may fetch more items from a combo source than it
        inserts (e.g. ComboQueueBuilder.build fetches N items but the weaver
        only inserts a subset).  Without this, tv_next_ep points past all
        fetched items, causing the first 1-for-1 replacement to skip episodes.

        Called after apply_interleave_list returns in both regenerate_queue
        and _build_fresh_tv_queue.
        """
        from resources.lib.channels.interleave import get_sources
        for source in get_sources(channel):
            src_ch = self.get_channel(source["channel_id"])
            if not src_ch or src_ch.get("channel_type") != "combo":
                continue
            combo_id = src_ch["id"]
            for slot in src_ch.get("slots", []):
                if slot.get("source_type") != "tv":
                    continue
                slot_id = slot.get("slot_id", "")
                for show in slot.get("shows", []):
                    show_id = show.get("tvshowid")
                    if not show_id:
                        continue
                    # Find the last episode from this show/slot in the queue.
                    last_ep_id = None
                    for item in reversed(woven_queue):
                        if (item.get("_combo_slot") == slot_id
                                and item.get("show_id") == show_id):
                            last_ep_id = item.get("episodeid")
                            break
                    if last_ep_id is None:
                        continue
                    # Set tv_next_ep to the episode after the last one used.
                    available  = self.get_available_episodes(show)
                    avail_ids  = [e["episodeid"] for e in available]
                    try:
                        last_idx = avail_ids.index(last_ep_id)
                        next_id  = avail_ids[(last_idx + 1) % len(avail_ids)]
                    except (ValueError, ZeroDivisionError):
                        next_id  = avail_ids[0] if avail_ids else None
                    if next_id is not None:
                        key = "combo:{}:slot:{}:show:{}:tv_next_ep".format(
                            combo_id, slot_id, show_id)
                        self.write_state_key(key, next_id)
                        log("[ChannelManager] _sync_combo_state_from_queue: "
                            "slot {} show {} → next episodeid {}".format(
                                slot_id[:8], show_id, next_id))
        self._save_state()

    def _reset_combo_interleave_sources(self, channel: dict) -> list:
        """Clear episode-position state for every combo block that is an
        interleave source of *channel*, then return those combo channels.

        Called before building a TV channel queue so that both the interleave
        weave inside that build AND the subsequent standalone combo queue
        rebuild start from episode 1 rather than from wherever the pointer
        was left by a previous build.

        The state keys cleared per combo TV slot are:
            combo:{combo_id}:slot:{slot_id}:show_slot
            combo:{combo_id}:slot:{slot_id}:show:{show_id}:tv_next_ep

        Returns the list of combo channel dicts that were reset, so the
        caller can rebuild their standalone queues afterwards.
        """
        from resources.lib.channels.interleave import get_sources
        reset_combos = []
        for source in get_sources(channel):
            src_ch = self.get_channel(source["channel_id"])
            if not src_ch or src_ch.get("channel_type") != "combo":
                continue
            combo_id = src_ch["id"]
            # Clear show_slot and tv_next_ep for every TV slot in this combo.
            keys_to_clear = []
            for slot in src_ch.get("slots", []):
                if slot.get("source_type") != "tv":
                    continue
                slot_id = slot.get("slot_id", "")
                keys_to_clear.append(
                    "combo:{}:slot:{}:show_slot".format(combo_id, slot_id))
                for show in slot.get("shows", []):
                    keys_to_clear.append(
                        "combo:{}:slot:{}:show:{}:tv_next_ep".format(
                            combo_id, slot_id, show["tvshowid"]))
            for k in keys_to_clear:
                self._state.pop(k, None)
                self._deleted_state_keys.add(k)
            if keys_to_clear:
                self._save_state()
                log("[ChannelManager] _reset_combo_interleave_sources: "
                    "cleared {} state key(s) for combo '{}' so next "
                    "build starts from episode 1".format(
                        len(keys_to_clear), src_ch.get("name", combo_id)))
            reset_combos.append(src_ch)
        return reset_combos

    def _pregenerate_queue_safe(self, channel: dict,
                                start_show_index: Optional[int] = None) -> None:
        """Build a fresh queue for channel and write it to disk.
        Catches and logs all exceptions so a builder failure never crashes
        the wizard.
        """
        channel_id = channel["id"]
        try:
            # Combo block channels do not use a standalone queue file.
            # Their items are built on-demand via build_one_slot (1-for-1
            # replacement) or woven into the owning TV channel queue during
            # build_channel_queue.  Writing a queue file here would produce
            # a file that is never read and would advance state (show_slot,
            # tv_next_ep) before the TV channel interleave build runs,
            # causing the TV channel to start at the wrong episode.
            # Only apply_combo_slot_starting_points is needed here — it
            # initialises the state keys so the first build_one_slot call
            # starts at the chosen episode.
            if channel.get("channel_type") == "combo":
                self._apply_combo_slot_starting_points(channel)
                log("[ChannelManager] _pregenerate_queue_safe: skipping "
                    "queue file for combo '{}' (not used in 3.x)".format(
                        channel.get("name", channel_id)))
                return

            # For TV channels with combo interleave sources: reset the combo
            # episode pointers to the beginning before building the TV queue.
            # This ensures the interleave weave inside build_channel_queue
            # starts from episode 1, not from wherever the pointer was left
            # by a previous standalone combo build.  After the TV queue is
            # written, rebuild each combo's standalone queue so it picks up
            # from the episode immediately after those used by the TV queue.
            reset_combos = []
            if channel.get("channel_type") == "tv":
                reset_combos = self._reset_combo_interleave_sources(channel)

            queue = self.build_channel_queue(channel,
                                             start_show_index=start_show_index)
            if queue:
                self._write_queue_file(channel_id, queue)
                log("[ChannelManager] Pre-generated {} items for '{}'".format(
                    len(queue), channel.get("name", channel_id)))
            else:
                log("[ChannelManager] Pre-generate: empty queue for '{}' "
                    "(library may be empty or all durations missing)".format(
                        channel.get("name", channel_id)))

            # Combo queue files are not written in 3.x — their state
            # (show_slot, tv_next_ep) is the authoritative source and was
            # already reset by _reset_combo_interleave_sources above.
            # apply_combo_slot_starting_points ensures state is initialised.
            for combo_ch in reset_combos:
                try:
                    self._apply_combo_slot_starting_points(combo_ch)
                    log("[ChannelManager] _pregenerate_queue_safe: "
                        "combo state initialised for '{}'".format(
                            combo_ch.get("name", combo_ch["id"])))
                except Exception as combo_exc:
                    log("[ChannelManager] _pregenerate_queue_safe: combo "
                        "state init error for '{}': {}".format(
                            combo_ch.get("name", combo_ch["id"]), combo_exc))

        except Exception as exc:
            log("[ChannelManager] _pregenerate_queue_safe error for '{}': "
                "{}".format(channel.get("name", channel_id), exc))

    # -------------------------------------------------------------------------
    # Phase 5 public API additions
    # -------------------------------------------------------------------------

    def get_interleave_sources(self, channel: dict) -> list:
        """Return the normalised list of interleave source configs for channel.

        Delegates to channels/interleave.py — single source of truth.
        Ported from 2.x channel_manager.py.
        """
        from resources.lib.channels.interleave import get_sources
        return get_sources(channel)

    def clear_missing_durations(self, channel_id: str) -> None:
        """Clear the per-channel missing_durations list from state.json.

        Does NOT touch missing_durations.txt — that is the permanent record.
        Ported from 2.x channel_manager.py.
        """
        state_key = "{}:missing_durations".format(channel_id)
        try:
            if state_key in self._state:
                del self._state[state_key]
                self._deleted_state_keys.add(state_key)
                self._save_state()
        except Exception as exc:
            log("[ChannelManager] clear_missing_durations error: {}".format(exc),
                level=xbmc.LOGWARNING)

    def get_missing_durations_txt_path(self) -> str:
        """Return the absolute path to the global missing_durations.txt file.

        Routes through the profile path so shared storage is respected.
        Ported from 2.x channel_manager.py.
        """
        import xbmcvfs as _xbmcvfs
        profile = _xbmcvfs.translatePath(
            self._addon.getAddonInfo("profile"))
        import os
        return os.path.join(profile, "missing_durations.txt")

    def capture_folder_duration(self, channel_id: str,
                                 file_path: str,
                                 duration_seconds: int) -> None:
        """Write a companion NFO for a folder item and update its queue entry.

        Called by service.py after a folder item finishes playing so that
        subsequent queue builds use the real duration instead of the default.
        1. Writes companion NFO via duration_cache.
        2. Updates the matching item in the channel queue file in place.
        Ported from 2.x channel_manager.py.
        """
        from resources.lib.utils.duration_cache import (
            write_companion_nfo as _write_nfo)

        if not file_path or duration_seconds <= 0:
            return

        log("[ChannelManager] capture_folder_duration: {}s for {}".format(
            duration_seconds, file_path))

        _write_nfo(file_path, duration_seconds)

        try:
            queue = self.get_channel_queue(channel_id)
            if not queue:
                return
            changed = False
            for item in queue:
                if item.get("file") == file_path and item.get("duration_is_default"):
                    item["duration"]          = duration_seconds
                    item["duration_is_default"] = False
                    changed = True
            if changed:
                self.write_channel_queue(channel_id, queue)
                log("[ChannelManager] capture_folder_duration: "
                    "updated queue entry for {}".format(file_path))
        except Exception as exc:
            log("[ChannelManager] capture_folder_duration queue update "
                "error: {}".format(exc), level=xbmc.LOGWARNING)

    def save_resume_position_local(self, item: dict,
                                    position: float,
                                    total: float) -> None:
        """Save resume position — alias for save_resume_position.

        In 2.x this wrote to a separate local file to avoid SMB writes
        during playback.  In 3.x save_resume_position already writes to
        state.json (which may be on shared storage).  The alias is kept
        so any callers ported from 2.x work without change.
        Ported from 2.x channel_manager.py.
        """
        self.save_resume_position(item, position, total)

    def clear_channel_resume_points(self, channel_id: str) -> None:
        """Remove all resume-position entries for a channel from state.json.
        Called when recycle/randomize/type changes make saved positions invalid.
        spec §21 (service.py onPlayBackStopped USER path)
        """
        try:
            prefix   = "resume:{}:".format(channel_id)
            mem_keys = [k for k in self._state if k.startswith(prefix)]
            for k in mem_keys:
                del self._state[k]
            self._deleted_state_keys.update(mem_keys)
            # Flush so disk stays clean
            if mem_keys:
                self._save_state()
                log("[ChannelManager] Cleared {} resume point(s) "
                    "for channel {}".format(len(mem_keys), channel_id[:8]))
        except Exception as e:
            log("[ChannelManager] clear_channel_resume_points error: "
                "{}".format(e))

    def reset_show_to_start(self, channel_id: str, show_id: int) -> bool:
        """Reset one show's episode pointer to the first episode.
        Rebuilds the queue so the channel view reflects the reset immediately.
        Returns True if episodes were found, False otherwise.
        spec TC-30.17
        """
        import xbmcvfs as _xbmcvfs

        channel    = self.get_channel(channel_id)
        show_entry = None
        if channel:
            show_entry = next(
                (s for s in channel.get("shows", [])
                 if int(s.get("tvshowid", -1)) == int(show_id)), None)

        episodes = (self.get_available_episodes(show_entry) if show_entry
                    else self.library.get_episodes_for_show(show_id))
        if not episodes:
            return False

        first_ep = episodes[0]
        self.save_show_state(channel_id, show_id, {
            "next_episode_id": first_ep["episodeid"],
            "season":          first_ep.get("season",  1),
            "episode":         first_ep.get("episode", 1),
            "played_ids":      [],
        })

        # Reset the cursor ep_pos for this show so the next build starts fresh
        cursor = self.get_cursor(channel_id)
        sid    = str(show_id)
        cursor.get("ep_pos", {}).pop(sid, None)
        cursor.get("ep_played", {}).pop(sid, None)
        cursor.get("slot_owed", {}).pop(sid, None)
        self.set_cursor(channel_id, cursor)

        # Delete the stale queue file and rebuild
        q_path = self._queue_file_path(channel_id)
        if _xbmcvfs.exists(q_path):
            _xbmcvfs.delete(q_path)
        if channel:
            self._pregenerate_queue_safe(channel)
        return True

    def regenerate_queue(self, channel_id: str) -> None:
        """Rebuild the queue after an interleave change.
        Strips existing interleaved items from the current queue and
        re-weaves with the updated interleave config. Falls back to a
        full rebuild if no usable queue exists.
        spec §10.2
        """
        import xbmcvfs as _xbmcvfs

        channel = self.get_channel(channel_id)
        if not channel:
            return

        log("[ChannelManager] regenerate_queue for '{}'".format(
            channel.get("name", channel_id)))

        existing_queue = self.get_channel_queue(channel_id)
        interleave_cfg = channel.get("interleave")

        if existing_queue:
            # Strip previously-interleaved items, keep primary items
            primary = [item for item in existing_queue
                       if not item.get("_interleaved")]
            if primary:
                if interleave_cfg:
                    from resources.lib.channels.interleave import (
                        apply_interleave_list)
                    # Reset combo episode pointers before weaving so the
                    # interleave starts from episode 1, not wherever a
                    # previous build left the pointer.
                    reset_combos = self._reset_combo_interleave_sources(channel)
                    new_queue = apply_interleave_list(
                        primary, channel,
                        self._load_foreign_items,
                        self.get_channel)
                    log("[ChannelManager] regenerate_queue: wove {} primary "
                        "+ interleave → {} total".format(
                            len(primary), len(new_queue)))
                    self.write_channel_queue(channel_id, new_queue)
                    # Sync combo slot tv_next_ep to the episode after the last
                    # one actually woven into the queue (not all fetched items).
                    self._sync_combo_state_from_queue(new_queue, channel)
                    # Combo queue files are not written in 3.x.
                    # State (show_slot, tv_next_ep) was reset by
                    # _reset_combo_interleave_sources; just initialise
                    # starting points so the next build_one_slot call
                    # starts at the correct episode.
                    for combo_ch in reset_combos:
                        try:
                            self._apply_combo_slot_starting_points(combo_ch)
                        except Exception as combo_exc:
                            log("[ChannelManager] regenerate_queue: combo "
                                "state init error for '{}': {}".format(
                                    combo_ch.get("name", combo_ch["id"]),
                                    combo_exc))
                else:
                    new_queue = primary
                    log("[ChannelManager] regenerate_queue: interleave "
                        "removed, {} primary items".format(len(new_queue)))
                    self.write_channel_queue(channel_id, new_queue)
                return

        # No usable queue — full rebuild
        log("[ChannelManager] regenerate_queue: no existing queue, "
            "full rebuild")
        self.clear_cursor(channel_id)
        q_path = self._queue_file_path(channel_id)
        if _xbmcvfs.exists(q_path):
            _xbmcvfs.delete(q_path)
        self._pregenerate_queue_safe(channel)

    def reorder_queue_from_item(self, channel_id: str,
                                queue_index: int) -> bool:
        """Rotate the queue so the item at queue_index becomes position 0.
        Items before it move to the tail in their original order.
        Called by play_from_item (side panel click).
        Returns True on success.
        spec §16.1 (side panel Enter on right pane[N])
        """
        queue = self.get_channel_queue(channel_id)
        if not queue:
            return False
        if queue_index <= 0 or queue_index >= len(queue):
            return False

        reordered = queue[queue_index:] + queue[:queue_index]
        self.write_channel_queue(channel_id, reordered)
        log("[ChannelManager] reorder_queue_from_item: channel={} "
            "rotated to index {}".format(channel_id, queue_index))
        return True

    def update_now_playing(self, channel: dict, item: dict) -> None:
        """Update now_playing.json with the currently playing item.

        Called by service.py on every new episode start so the file stays
        current throughout playback — not just at channel start.
        Writes to local profile first, then copies to shared storage if
        configured.  spec §21, §24.
        """
        import time as _time
        import os   as _os

        channel_id = channel.get("id", "")
        profile    = xbmcvfs.translatePath(
            self.addon.getAddonInfo("profile"))

        data = {
            "active_channel_id": channel_id,
            "channel_name":      channel.get("name", ""),
            "title":             item.get("title",       ""),
            "tvshowtitle":       item.get("tvshowtitle", ""),
            "season":            item.get("season",      0),
            "episode":           item.get("episode",     0),
            "duration":          item.get("duration",    0),
            "start_time":        _time.time(),
        }

        import json as _json
        local_path = _os.path.join(profile, "now_playing.json")
        try:
            with xbmcvfs.File(local_path, "w") as f:
                f.write(_json.dumps(data, indent=2))
            log("[ChannelManager] update_now_playing: '{}' on '{}'".format(
                item.get("title", "?"), channel.get("name", "?")))
        except Exception as exc:
            log("[ChannelManager] update_now_playing error: {}".format(exc))
            return

        shared_path = self._resolve_path("now_playing.json")
        if shared_path != local_path:
            try:
                xbmcvfs.copy(local_path, shared_path)
            except Exception as exc:
                log("[ChannelManager] update_now_playing: shared copy "
                    "failed: {}".format(exc))
