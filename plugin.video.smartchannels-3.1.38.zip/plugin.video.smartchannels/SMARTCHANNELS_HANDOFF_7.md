# SmartChannels 3.x — Session Handoff Document
## Version: 3.1.35 (current)
## Date: September 2026

---

## Environment

| Item | Value |
|---|---|
| Working dir | `/home/claude/plugin_work/3.0.0/plugin.video.smartchannels/` |
| Output zips | `/mnt/user-data/outputs/` |
| 2.x reference | `/tmp/sc2x/plugin.video.smartchannels/` |
| Kodi target | 21/22 (Omega), Python 3 |
| Developer OS | Windows 10 |
| Current version | 3.1.35 |

---

## Packaging Procedure

```bash
cd /home/claude/plugin_work/3.0.0/plugin.video.smartchannels
sed -i 's/version="3.1.XX"/version="3.1.YY"/' addon.xml
# Add CHANGELOG.md entry first
find . -name "*.py" | sort | while read f; do python3 -m py_compile "$f" 2>&1; done | grep -v "^$"
cd /home/claude/plugin_work/3.0.0
rm -f /mnt/user-data/outputs/smartchannels_3_1_XX.zip
zip -0 -r /mnt/user-data/outputs/smartchannels_3_1_YY.zip \
  plugin.video.smartchannels \
  --exclude "*.pyc" --exclude "*/__pycache__/*"
```

**Rules:** `zip -0 -r` always. One fix per version. CHANGELOG entry before packaging.
Mark assigns all strings.po IDs — never add IDs without Mark providing them.

---

## Architecture Rules (Never Violate)

- `service.py` owns ALL playback callbacks, state advancement, resume, queue top-up, playlist management
- `player.py` owns ONLY `start_channel()` and `_write_now_playing()`
- `channel_manager.py` owns queue building, state read/write, library access
- NO duplicate code between files
- NO playback event handlers outside `service.py`
- No hardcoded dialog text — all via `strings.po` (#32000+)
- Fresh `ChannelManager` per access in `service.py` via `_get_manager()`
- Any new field added to wizard return dict must be added to both `add_channel` and `update_channel` whitelists in `channel_manager.py`
- Failed fix protocol: explicitly state "Roll Back" or "Build On Top" and why before touching any code after a failed fix
- NEVER report things that are working correctly — only report problems

---

## Key Architecture Decisions (Locked)

### 1-for-1 Pop/Append
Every consumed item immediately appends exactly one replacement. No batch top-up. No threshold.
This applies to ALL item types including interleaved items — an interleaved movie replaced by a movie, an interleaved combo slot replaced by the next item from the same slot. The interleave pattern is self-maintaining because every slot in the queue is always replaced by the same type.

### Interleaved Item Replacement
- `get_one_replacement()` in `channel_manager.py` checks `consumed_item.get("_interleaved")` first
- If True: routes to the SOURCE channel (`consumed_item["_channel_id"]`) for replacement, not the host channel
- Replacement item has `_interleaved=True`, `_channel_id`, `_silent`, `_channel_name` copied from consumed item
- This ensures every interleaved item in the queue carries correct tags throughout its lifetime

### Combo Block Slot Replacement
- `build_one_slot(combo_ch, slot_index)` fetches exactly 1 item for the specific slot consumed
- `build_one_slot` MUST set `_combo_slot`, `_interleaved=True`, AND `_channel_id` on the returned item
- `_channel_id` is critical — without it, the next carousel pop cannot identify the combo source
- No combo queue files ever written — state keys are the authority
- `_handle_combo_slot` in `service.py` calls `build_one_slot`
- `_handle_skip` uses `build_one_slot` per skipped combo item
- `carousel.py` `_handle_combo_slot_pop` also uses `build_one_slot`

### Combo Block as Interleave Source — State Sync
- `_sync_combo_state_from_queue()` in `channel_manager.py` called after `apply_interleave_list()` in both `regenerate_queue` and `_build_fresh_tv_queue`
- Scans the woven queue for the last episode actually inserted per combo TV slot/show
- Sets `tv_next_ep` to the episode after that one
- Prevents the interleave build from advancing `tv_next_ep` past what was actually inserted (the weaver fetches more items than it inserts)

### TV Channel Queue Size
- `queue_size` is a MINIMUM for TV channels — not a hard cap
- Initial build always completes a full show cycle so every show has an episode in the queue
- `queue_size` setting labelled "Default Minimum Queue Size" (#32014)

### Scheduled Block Items
- Tagged with `_schedule_id` in queue
- Carousel pops them WITHOUT replacement (queue shrinks by block count, then resumes normal 1-for-1)
- `on_block_item_complete()` called via `ScheduleManager` on each carousel pop
- Interleaved items (`_interleaved=True`) are NOT block items — always get normal 1-for-1 replacement
- Block reload requires channel to be playing — `_pending_block_channel` set by `_tick_scheduler`

### Block Reload False Skip Prevention
- `_block_reload_pending = True` set in `_maybe_start_block_reload` before launching thread
- `onAVStarted` checks flag when skip detected — if set, suppresses skip detection and clears flag

### Shared Storage Migration
- `onSettingsChanged` in `service.py` detects changes to `shared_storage_path`
- `_last_shared_root` on `SmartChannelsMonitor` tracks previous value; None on first call (no dialog)
- On change: verifies new path accessible, prompts user, calls `migrate_storage_path()` from `paths.py`
- Covers local→shared, shared→local, shared→shared transitions
- On shared→shared or local→shared: optionally deletes old files after successful copy
- Helpers in `paths.py`: `migrate_storage_path()`, `delete_files_in_root()`, `_list_files_in_root()`

### Kodi Playlist
- `kodi_playlist.remove()` NEVER called during skip or natural playback
- Skip replacements appended to Kodi playlist tail
- Natural replacements appended to Kodi playlist tail

---

## Module Map

```
service.py              SmartChannelsPlayer(xbmc.Player)
                        _handle_combo_slot — 1-for-1 via build_one_slot
                        _handle_skip — 1-for-1 per skipped item
                        _do_replacement — pops queue[0], appends 1 replacement
                        _block_reload_pending — suppresses false skip on block reload
                        _get_next_episode() — skips block/silent items for CUN
                        _tick_scheduler — fires schedules, sets _pending_block_channel
                        SmartChannelsMonitor.onSettingsChanged — shared storage migration

player.py               start_channel() — builds Kodi playlist, starts playback
                        _write_now_playing()

channel_manager.py      build_combo_tv_slot — unit_sequence + show_slot for eps_per_slot
                        build_combo_movie_slot — handles explicit movies list
                        _pregenerate_queue_safe — skips combo channels (no queue files)
                        _sync_combo_state_from_queue — sets tv_next_ep after interleave weave
                        get_one_replacement — routes interleaved items to source channel

channels/combo.py       ComboQueueBuilder.build() — full initial queue build
                        ComboQueueBuilder.build_one_unit() — one unit for initial build
                        ComboQueueBuilder.build_one_slot() — 1-for-1 replacement
                        build_one_slot sets: _combo_slot, _interleaved=True, _channel_id

carousel.py             Pop loop detects _schedule_id — no replacement for block items
                        _handle_combo_slot_pop — uses build_one_slot (1-for-1)
                        Duplicate episode check before appending carousel replacement
                        Container.Refresh: not implemented (getCondVisibility unreliable
                        from background thread in Kodi 21)

scheduler.py            fire_block() — combo sources use build_one_slot directly
                        unit_size multiplier for combo sources (item_count × unit_size)

utils/paths.py          resolve_path, load_json, save_json, shared_root
                        migrate_storage_path() — copies data files between roots
                        delete_files_in_root() — cleans up old location after migration
                        _list_files_in_root() — discovers all data files in a root

resources/lib/overlays/ coming_up_next.py — CUN overlay, audio-aware
                        logo_overlay.py — channel logo during playback
resources/lib/ui/side_panel.py  — Two-pane WindowXML browser, ticker code removed
resources/lib/ui/auto_channels.py — Auto-create channels wizard
resources/lib/ui/ffprobe_wizard.py — ffprobe batch NFO scanner wizard
resources/lib/utils/ffprobe_scanner.py — ffprobe scanner (explicit path, no PATH fallback)
resources/lib/scheduler.py — scheduler unchanged from 2.x logic
```

---

## Strings.po

- **Highest ID in use:** #32912 (`"Tools"`) in sequence; also #32228, #32229, #32390, #32391, #32392
- **Next free:** #32913 (verify: `grep "msgctxt" strings.po | tail -5`)
- Mark assigns all IDs — Claude only uses IDs Mark provides
- **Key strings added this session:**
  - #32386: `"Copy files from shared folder back to Kodi addon data folder? [{0}]"`
  - #32387: `"Now using Kodi addon data folder."`
  - #32388: `"Migrated {0} file(s) to shared folder."`
  - #32389: `"Delete the migrated files from the old shared folder? [{0}]"`
  - #32390: `"Copy existing data to new shared folder? [{0}]"`
  - #32391: `"New storage path is not accessible. No files were transferred."`
  - #32392: `"Transfer incomplete. {0} of {1} file(s) copied. Check the log for details."`
  - #32639: changed from "Minimum items per channel" to "Minimum episodes per channel (0 = show all)"

---

## Bugs Fixed This Session (3.1.23 → 3.1.35)

| Version | Fix |
|---|---|
| 3.1.23 | Interleaved items replaced from host channel instead of source channel |
| 3.1.24 | Replacement for interleaved items missing _interleaved/_channel_id tags — caused skip path to treat them as primary |
| 3.1.25–3.1.29 | Carousel live refresh attempted and reverted — getInfoLabel/getCondVisibility unreliable from background thread |
| 3.1.30 | First attempt at combo interleave episode skip fix (wrong location — reverted in 3.1.31) |
| 3.1.31 | Combo block interleave episode skip: _sync_combo_state_from_queue() sets tv_next_ep after weave |
| 3.1.32 | Combo block side panel context menu incorrectly showed Set Channel Icon |
| 3.1.33 | Combo block side panel context menu incorrectly showed Move Up/Down; interleave wizard frequency prompt used same string as count_per prompt |
| 3.1.34 | build_one_slot missing _channel_id tag — carousel broke interleave pattern after first combo slot pop |
| 3.1.35 | Shared storage path migration — data not transferred when user changes shared_storage_path setting |

---

## What Was Confirmed Working

- 1-for-1 queue replacement — confirmed overnight across multiple days
- Carousel channels with combo block interleave sources — confirmed 3-hour and overnight runs
- Interleave pattern self-maintaining through carousel pops (all slot types: TV, movie, folder)
- Scheduled blocks (regular + combo source) — 3 schedules × 3 days clean
- False skip suppression on block reload — confirmed in log
- Queue position tracking — clean incrementing across full overnight runs
- Coming Up Next overlay — working
- Logo overlay — working (must enable in settings)
- ffprobe scanner — explicit path validated
- Auto-create channels — working
- Side panel — Edit/Reset/context menu working
- Missing Durations global log — View + Clear working

---

## Known Issues / Open Items

1. **SMB write failure during carousel pop** can cause queue file loss → fresh build on next play. Needs retry logic in `save_json`. Low frequency, deferred.

2. **Carousel live list refresh** — `Container.Refresh` from `service.py` background thread is not reliable. `getInfoLabel("Container.FolderPath")` and `getCondVisibility()` both return empty/unreliable from service thread in Kodi 21. Deferred — list updates correctly on navigate away/back.

3. **Auto-create minimum filter** — currently filters on total episodes. Open question: should it filter on show count instead? Not yet decided.

4. **#32344** `"Interleave configured"` incorrectly used as jitter amount input heading in interleave wizard. Minor string bug — needs a correct string ID from Mark.

5. **Side panel testing** — TC-20 partially tested. Add Schedule, View Exclusions, Missing Durations from side panel not yet verified.

---

## Feature Queue Status

| Item | Status |
|---|---|
| A — Combo queue skip in _pregenerate | ✅ Done |
| B — Interleave source one-owner rule | ✅ Done |
| C — Coming Up Next overlay | ✅ Done |
| D — Side Panel | ✅ Done (partial testing) |
| E — Logo overlay | ✅ Done |
| F — Auto-create channels | ✅ Done |
| H — ffprobe scanner | ✅ Done |
| I — OSD cursor fix | ✅ Works same as 2.x |
| J — Shuffle each cycle | 🔲 PENDING |
| K — New Lower-Third Ticker | 🔲 PENDING |
| M — EPG overlay | 🔲 Deferred |

---

## Test Sections Status

| Section | Status |
|---|---|
| 1 — TV Channel Creation (TC-P5-01 to TC-P5-10) | ✅ PASS |
| 2 — Serial Channel (TC-P5-11) | ✅ PASS |
| 3 — Movie Channel (TC-P5-12, TC-P5-13) | ✅ PASS |
| 4 — Folder Channel (TC-P5-14) | ✅ PASS |
| 5 — Audio Channel (TC-P5-15) | ✅ PASS |
| 6 — Party Channel (TC-P5-16) | ✅ PASS |
| 7 — Combo Block (TC-P5-17 to TC-P5-19) | ✅ PASS |
| 8 — Context Menu (TC-P5-20 to TC-P5-22) | ✅ PASS |
| 9 — Playing / Queue (TC-P5-23 to TC-P5-26) | ✅ PASS |
| 10 — Carousel (TC-P5-27, TC-P5-28) | ✅ PASS |
| 11 — Interleave (TC-P5-29, TC-P5-30) | ✅ PASS |
| 12 — Scheduling (TC-P5-31, TC-P5-32) | ✅ PASS |
| 13 — Channel Info (TC-P5-33, TC-P5-34) | 🔲 In progress |
| 14 — Operational (TC-P5-35 to TC-P5-38) | 🔲 In progress |
| 15 — Phase 1–4 Regression | ✅ PASS |
| Carousel + Combo Interleave overnight | ✅ PASS (3.1.34+) |

---

## State.json Key Reference

```
{channel_id}:cursor                          — show_slot, ep_pos, ep_played, slot_owed
{channel_id}:carousel                        — last_pop_time, last_popped_show
resume:{channel_id}:{file}                   — resume position seconds
combo:{combo_id}:slot:{slot_id}:show:{show_id}:tv_next_ep
combo:{combo_id}:slot:{slot_id}:show_slot
combo:{combo_id}:slot:{slot_id}:missing_durations
{channel_id}:missing_durations
{schedule_id}:active_block                   — active block state (sch_ prefix exempt from pruning)
sch_ prefix keys exempt from orphan pruning in _save_state()
```

---

## Test Channels (Current)

| Channel | ID | Type | Notes |
|---|---|---|---|
| Test TV Channel | 6a6e2432 | TV (3rd Rock, Alfred Hitchcock, 8 Simple Rules) + TC-17 combo interleave every 3, carousel 10min | Primary carousel+interleave test |
| Test TV Channel 2 | 4e3cfc4c | TV ('Til Death ×2, 2BG, 3BP) + TC-15-2 combo interleave every 3, carousel 10min | Second carousel+interleave test |
| Test TC-13 | 1917b82d | Combo ('Til Death TV slot) | Single TV slot combo |
| Test TC-14 | f5a54846 | Combo (2BG TV slot, eps_per_slot=2) | TV slot with eps_per_slot |
| Test TC-15 | 3852e21c | Combo (Drama movie slot, randomize=True) | Single movie slot, owner=Test TV Channel |
| Test TC-15-2 | fdef43cb | Combo (Drama movie slot ×2, randomize=True) | Movie slot movies_per_slot=2 |
| Test TC-16 | cf84dc79 | Combo (1960s folder silent, eps_per_slot=2) | Folder slot with eps_per_slot |
| Test TC-17 | f6290ca6 | Combo (1950s silent, 'Til Death, Comedy movies, Cartoon College silent, Looney Tunes) | 5-slot combo, owner=Test TV Channel |

## Active Schedules (Test TV Channel target)

| Schedule | Time | Source | Items | Recurrence |
|---|---|---|---|---|
| Test Schedule 10pm | 21:30 | 8 Simple Rules | 3 | Daily |
| Test Schedule 2 | 01:30 | 3rd Rock | 3 | Daily |
| Test Schedule 3 | 03:30 | Combo Block | 1 unit (4 slots) | Daily |

