# SmartChannels 3.0.0 — Test Matrix
**Version:** 3.0.75
**Date:** 2026-09-10
**Tester:** Mark
**Build:** smartchannels_3_0_75.zip

---

## How to Use This Document

Each test case includes:
- **Setup** — what you need before testing
- **Steps** — exactly what to do, in order
- **Expected Result** — what correct behaviour looks like
- **Pass / Fail** — mark after testing

**Before any test:** Install the zip via Kodi → Add-ons → Install from zip.
**Profile path (Windows):** `C:\Users\PC\AppData\Roaming\Kodi\userdata\addon_data\plugin.video.smartchannels\`

**Not tested in this matrix (not yet implemented):**
- Side Panel (item D)
- Coming Up Next overlay (item C)
- Logo overlay (item E)
- Auto-create channels (item F)
- Scheduler execution / firing (item G)
- ffprobe scanner (item H)
- Ticker overlay (item K)

---

## SECTION 1 — TV Channel Creation

---

### TC-01 — Create a basic TV channel (full wizard flow)

**Setup:** At least 2 TV shows in Kodi library.

**Steps:**
1. Open Smart Channels → right-click → **Create New Channel**
2. Channel Type → **TV Shows (episodes in rotation)**
3. Playback Order → **Round-Robin**
4. Enter a channel name
5. If library > 20 shows: Show Selection dialog appears — select **Show All**
6. Select 2+ shows → OK
7. Show Rotation Order → **Keep Selection Order**
8. Set Episodes Per Slot? → **No, keep 1 each**
9. Per-Show Playback Order? → **No, all sequential**
10. Set episode filters? → **No, skip filters**
11. Exclude Episodes? → **No, skip exclusions**
12. Starting Point → **Start from S01E01 (default)**
13. Queue size — accept default
14. Visibility → **Show**
15. Carousel → **No**
16. Notification appears: Channel created

**Expected Result:** Channel in list. All dialog headings and labels match strings.po. No wrong text anywhere.

**Pass / Fail:** ___________

---

### TC-02 — TV wizard: filter first (library > 20 shows)

**Setup:** More than 20 TV shows in library.

**Steps:**
1. Create New Channel → TV Shows → Round-Robin → enter name
2. Show Selection dialog appears automatically
3. Verify: Heading = **Show Selection**, Yes = **Filter First**, No = **Show All**
4. Select **Filter First** → Manage Filters → Add Filter Rule → **Genre**
5. Select a genre → Filter Results dialog shows count → OK
6. Filtered show list appears in multiselect
7. Select shows and complete wizard

**Expected Result:** Correct dialog text throughout. Filtered list contains only matching shows.

**Pass / Fail:** ___________

---

### TC-03 — TV wizard: episodes per slot (multi-show)

**Setup:** TV channel creation in progress, 2+ shows selected, sequential order.

**Steps:**
1. Proceed to **Items Per Slot?** dialog
2. Verify: Heading = **Items Per Slot?**
3. Verify body = **This slot currently plays 1 item(s) per turn. Set a custom count?**
4. Select **Yes, Customise**
5. Numeric input appears: verify heading = **Items per slot (current: 1):**
6. Enter 2 for first show, 1 for second
7. Complete wizard

**Expected Result:** Both strings are generic (no "movie" or "episode" wording). Values are saved.

**Pass / Fail:** ___________

---

### TC-04 — TV wizard: episode exclusions

**Setup:** TV channel creation in progress, shows selected.

**Steps:**
1. Proceed to **Exclude Episodes?** dialog
2. Verify heading, message, Yes/No labels match schematic
3. Select **Yes, set exclusions**
4. Show picker loop → select a show → pick a season → **Select individual episodes**
5. Multiselect shows episodes as S01E01 — Episode Title format
6. Select some episodes → OK
7. Show returns to picker with **N episode(s) excluded**
8. Select **Done**

**Expected Result:** Exclusion count updates. Format of episode labels correct.

**Pass / Fail:** ___________

---

### TC-05 — TV wizard: Surprise Me starting point

**Setup:** TV channel with sequential shows.

**Steps:**
1. Proceed to Starting Point → **Surprise Me!**
2. Preview dialog shows random episodes for each show
3. Select **Try Again** — episodes reshuffle
4. Select **Accept** — wizard continues
5. Play channel — verify first episode matches the accepted starting point

**Expected Result:** Random preview rerandomises. Accepted start point used in queue.

**Pass / Fail:** ___________

---

### TC-06 — TV wizard: carousel enabled (timed mode)

**Setup:** TV channel reaching carousel step (visible, not schedule/interleave source).

**Steps:**
1. Complete wizard through Visibility → **Show**
2. Carousel dialog: Heading = **Carousel**, Yes/No labels correct
3. Select **Yes** → Carousel mode → **Timed**
4. Pop interval input (minimum 20) → enter 20
5. Items per interval → enter 1
6. Informational dialog appears → OK
7. Channel created

**Expected Result:** Carousel enabled, mode=timed, interval=20, pop_count=1. Visible in channel info.

**Pass / Fail:** ___________

---

### TC-07 — TV wizard: hidden channel skips carousel

**Steps:**
1. Complete TV wizard through Visibility → **Hide**
2. Verify: Carousel dialog does NOT appear
3. Channel created immediately

**Expected Result:** No carousel dialog for hidden channels.

**Pass / Fail:** ___________

---

## SECTION 2 — Serial Channel

---

### TC-08 — Create a Serial channel

**Setup:** 2+ TV shows in library.

**Steps:**
1. Create New Channel → TV Shows → **Serial**
2. Enter name → multiselect shows
3. Show Play Order → **Set Order Manually** → assign positions → Accept
4. Exclude Episodes? → **No, skip exclusions**
5. Queue size → Visibility → **Show**
6. Verify: NO carousel dialog appears after Visibility
7. Channel created

**Expected Result:** Serial channel created. No carousel step. Channel info shows "Serial" type.

**Pass / Fail:** ___________

---

## SECTION 3 — Movie Channel

---

### TC-09 — Create a Movie channel (All Movies + filter)

**Steps:**
1. Create New Channel → **Movies** → enter name
2. Movie Selection Method → **All Movies (N total)**
3. Movie Filters → **Add Filters** → Genre → select genre
4. Filter Results shows count → Done
5. Movie Order → **Random**
6. Exclude Movies? → **No, skip exclusions**
7. Queue size → Visibility → **Show** → Carousel → **No**

**Expected Result:** Channel created. Queue contains only movies matching genre.

**Pass / Fail:** ___________

---

## SECTION 4 — Folder Channel

---

### TC-10 — Create a Folder channel

**Setup:** A media folder accessible from Kodi.

**Steps:**
1. Create New Channel → **Folder** → enter name
2. Browse to folder → select
3. Playback Order: Yes = **Sequential**, No = **Random** — select Sequential
4. Queue size → Visibility → **Show**
5. Verify: NO carousel dialog
6. Channel created

**Expected Result:** Folder channel created. No carousel step.

**Pass / Fail:** ___________

---

## SECTION 5 — Audio Channel

---

### TC-11 — Create an Audio channel (Filter by Artist)

**Setup:** Music in Kodi library.

**Steps:**
1. Create New Channel → **Audio Channel** → enter name
2. Playback Order → **Random**
3. Music Source → **Filter by Artist**
4. Select Artists multiselect: verify **nothing pre-selected**
5. Select one artist → OK
6. Select Albums: verify **nothing pre-selected**, first item = **Select All Albums**
7. Select **Select All Albums**
8. Exclude Songs? → **No**
9. Queue size only — verify NO Visibility or Carousel dialogs
10. Channel created

**Expected Result:** Nothing pre-selected in artists or albums. Select All works. No Visibility/Carousel step.

**Pass / Fail:** ___________

---

## SECTION 6 — Party Channel

---

### TC-12 — Create a Party channel

**Setup:** A folder of music files.

**Steps:**
1. Create New Channel → **Party Mode Channel** → enter name
2. Browse to music folder → select
3. Playback Order → **Random**
4. Queue size — verify NO Visibility or Carousel dialogs
5. Channel created

**Expected Result:** No Visibility/Carousel step. Channel created.

**Pass / Fail:** ___________

---

## SECTION 7 — Combo Block Channel

---

### TC-13 — Create a Combo Block: TV slot

**Setup:** TV shows in library.

**Steps:**
1. Create New Channel → **Combo Block** → enter name
2. Manage Slots → **Add Slot** → Source type → **TV Shows**
3. Select one show → OK
4. Exclude Episodes? Message says: **Exclude specific episodes from "{Show}" on this slot.**
5. Select **No, skip exclusions**
6. Playback Order → **Sequential**
7. **When all episodes have played...** → **Recycle**
8. Silent dialog: Heading = **Silent**, message correct → select **Not Silent**
9. Slot appears in list → **Done**
10. Queue size → verify NO Visibility dialog
11. Channel created (always hidden)

**Expected Result:** Correct dialog text throughout. Recycle heading is "When all episodes have played...". No Visibility dialog.

**Pass / Fail:** ___________

---

### TC-14 — Combo Block: items per slot (TV slot, 1 show)

**Setup:** Creating a TV slot in a Combo Block with 1 show.

**Steps:**
1. In TV slot wizard after show selection
2. **Items Per Slot?** dialog appears:
   - Heading: **Items Per Slot?**
   - Body: **This slot currently plays 1 item(s) per turn. Set a custom count?**
3. Select **Yes, Customise**
4. Input heading: **Items per slot (current: 1):**
5. Enter 2 → OK

**Expected Result:** Generic wording throughout. No "movie" or "episode" in any of the three strings.

**Pass / Fail:** ___________

---

### TC-15 — Combo Block: items per slot (Movie slot)

**Steps:**
1. Add a Movie slot to a Combo Block
2. Movie Filters? → **No Filters**
3. Exclude Movies? → **No, skip exclusions**
4. Playback Order → **Random**
5. **Items Per Slot?** dialog:
   - Heading: **Items Per Slot?**
   - Body: **This slot currently plays 1 item(s) per turn. Set a custom count?**
6. Select **Yes, Customise**
7. Input heading: **Items per slot (current: 1):**
8. Enter 2 → OK
9. **When all movies have played...** → **Recycle**
10. Silent → **Not Silent**

**Expected Result:** All three per-slot strings are generic. Recycle heading is "When all movies have played...".

**Pass / Fail:** ___________

---

### TC-16 — Combo Block: items per slot (Folder slot)

**Steps:**
1. Add a Folder slot to a Combo Block → browse to folder
2. Playback Order → **Sequential**
3. No Repeat → **No Repeat**
4. **Items Per Slot?** dialog:
   - Heading: **Items Per Slot?**
   - Body: **This slot currently plays 1 item(s) per turn. Set a custom count?**
5. Select **Yes, Customise**
6. Input heading: **Items per slot (current: 1):**
7. Enter 2 → OK
8. **When all files have played...** → **Stop**
9. Silent → **Silent**

**Expected Result:** All three strings generic. Recycle heading is "When all files have played...".

**Pass / Fail:** ___________

---

### TC-17 — Combo Block: slot management (move, remove)

**Setup:** Combo Block with 2+ slots.

**Steps:**
1. Right-click Combo Block → **Edit Channel** → OK on warning
2. Manage Slots shows existing slots + Add Slot + Done
3. Select a slot → **Move Slot Up** → slot moves
4. Select a slot → **Remove Slot** → confirm shows slot name → **Yes** → slot removed
5. **Done**

**Expected Result:** Move works. Remove confirm shows slot name. Done exits cleanly.

**Pass / Fail:** ___________

---

## SECTION 8 — Context Menu

---

### TC-18 — Context menu text verification

**Steps:**
1. Right-click a TV channel — verify all items:
   - Channel Info, Play Channel, Edit Channel, Reset Channel, Delete Channel
   - Set Channel Icon, Toggle Visibility, Add Schedule, Manage Interleave
   - View Exclusions, Move Up, Move Down
2. Right-click a Combo Block (with Show Hidden Channels enabled) — verify:
   - Channel Info, Edit Channel, Delete Channel, Set Channel Icon, Move Up, Move Down
   - No Play, No Reset, No Toggle Visibility, No Add Schedule, No Manage Interleave

**Expected Result:** All labels correct. Combo Block correctly omits non-applicable options.

**Pass / Fail:** ___________

---

### TC-19 — Delete channel confirmation

**Steps:**
1. Right-click a channel → **Delete Channel**
2. yesno dialog: Heading = **Smart TV Channels**, message asks confirmation
3. Select **No** — nothing happens
4. Delete again → **Yes** — channel removed

**Expected Result:** Heading correct. Deletion confirmed and executed.

**Pass / Fail:** ___________

---

### TC-20 — Reset channel confirmation

**Steps:**
1. Right-click a TV channel → **Reset Channel**
2. yesno dialog: Heading = **Reset Channel**, message contains channel name
3. Select **Yes**
4. Open channel — queue starts from S01E01

**Expected Result:** Correct heading. Queue rebuilt from episode 1 after reset.

**Pass / Fail:** ___________

---

## SECTION 9 — Queue and Playback

---

### TC-21 — 1-for-1 queue replacement (basic)

**Setup:** TV channel, queue size 10.

**Steps:**
1. Play channel
2. Open `queue_{channel_id}.json` — count items (should be 10)
3. Let episode play to natural end
4. Reopen queue file — count still 10
5. Verify tail item is next episode in correct show rotation

**Expected Result:** Queue depth stays exactly 10 throughout. Correct show rotation at tail.

**Pass / Fail:** ___________

---

### TC-22 — Correct show rotation with episodes_per_slot

**Setup:** TV channel with Til Death (eps=2), 2BG (eps=1), 3rd Rock (eps=1).

**Steps:**
1. Open queue file
2. Verify the first 4 primary items are: Til Death ep1, Til Death ep2, 2BG ep1, 3rd Rock ep1
3. Verify next 4: Til Death ep3, Til Death ep4, 2BG ep2, 3rd Rock ep2
4. Play through several episodes — verify tail items follow same pattern

**Expected Result:** Til Death always gets 2 consecutive episodes per rotation. 2BG and 3rd Rock get 1 each.

**Pass / Fail:** ___________

---

### TC-23 — Resume on stop

**Setup:** Any channel.

**Steps:**
1. Play a channel — let it play 30+ seconds
2. Stop playback
3. Right-click channel → **Play Channel**
4. Resume dialog appears: Heading = **Smart TV Channels**, message = **{channel} — resume from {time}?**
5. Select **Yes** — playback resumes from saved position (verify seek to correct time)
6. Stop and replay → select **No** — playback starts from beginning

**Expected Result:** Resume dialog correct. Yes seeks accurately. No starts from beginning.

**Pass / Fail:** ___________

---

### TC-24 — Resume poll interval setting

**Steps:**
1. Settings → Resume → **Background Polling Interval** — note default is 60
2. Change to 30 → while playing a channel verify position saves every ~30s (check state.json resume key updates)
3. Change back to 60

**Expected Result:** Poll interval is user-configurable. Default is 60 s. Changes take effect without restart.

**Pass / Fail:** ___________

---

### TC-25 — Skip detection

**Setup:** TV channel with 5+ items in queue.

**Steps:**
1. Play channel — skip forward 3 items in Kodi playlist (press Next 3 times)
2. 4th item starts playing
3. Stop — open queue file
4. Verify queue count unchanged (3 replacements appended to tail)
5. Verify tail items are correct next episodes in rotation

**Expected Result:** Queue count stable. 3 replacements appended. No false double-replacement.

**Pass / Fail:** ___________

---

### TC-26 — Reset Watched if enabled

**Setup:** Settings → Playback → **Reset Watched Status on Queue Build** = true.

**Steps:**
1. Play a TV episode to natural completion
2. Check Kodi library — episode watched count should be reset to 0 (unwatched)
3. Disable the setting — play another episode to completion
4. Verify watched count increments normally

**Expected Result:** Reset fires only when setting is on. Off = normal Kodi watched behaviour.

**Pass / Fail:** ___________

---

## SECTION 10 — Carousel

---

### TC-27 — Carousel: no immediate pop on channel creation

**Setup:** Create a new carousel-enabled TV channel (duration mode).

**Steps:**
1. Create channel with carousel enabled
2. Immediately open queue file — note item at position [0]
3. Wait 60 seconds
4. Reopen queue file — position [0] should be the same item (not yet popped)
5. Wait for the item's full duration to elapse
6. Queue front should now have changed (pop fired)

**Expected Result:** No pop fires immediately after creation. First pop fires after item duration elapses.

**Pass / Fail:** ___________

---

### TC-28 — Carousel: correct same-show replacement

**Setup:** TV carousel channel with 3rd Rock and 8 Simple Rules.

**Steps:**
1. Wait for carousel pop to fire (check log: "[carousel] popping item")
2. Note which show was popped (check log: show_id)
3. Check queue tail — replacement item should be the NEXT episode of the SAME show
4. Verify last_popped_show in state.json matches popped show's tvshowid

**Expected Result:** Replacement is always next episode of same show. last_popped_show updated.

**Pass / Fail:** ___________

---

### TC-29 — Carousel: skips currently-playing channel

**Setup:** A carousel channel currently being played.

**Steps:**
1. Play a carousel channel
2. Wait for carousel tick (60s)
3. Check log — should see: "[carousel] skipping '...' — currently playing"
4. Verify queue file unchanged (no pop fired while playing)

**Expected Result:** Carousel does not pop the channel that is actively playing.

**Pass / Fail:** ___________

---

### TC-30 — Carousel: catch-up after Kodi restart (timed mode)

**Setup:** A timed carousel channel (interval=20 min). Stop Kodi, wait 45 minutes, restart.

**Steps:**
1. After restart, check log for carousel catch-up
2. Should see: "2 interval(s) due, popping 2 item(s)" (or appropriate count)
3. Queue front should have advanced by the correct number of items

**Expected Result:** Catch-up fires multiple pops for missed intervals. Queue advances correctly.

**Pass / Fail:** ___________

---

### TC-31 — Carousel timed: no pop on first tick (state manually cleared)

**Steps:**
1. Manually delete the `{channel_id}:carousel` key from state.json for a timed carousel channel
2. Wait for next carousel tick (60s)
3. Check log — should see: "[carousel] timed first run — initialising clock"
4. No pop should fire on that tick
5. Wait for full interval — pop fires normally

**Expected Result:** First-run guard prevents immediate pop when carousel state is absent.

**Pass / Fail:** ___________

---

### TC-32 — Carousel: abort pop when library unavailable

**Setup:** Requires temporarily blocking library access (disconnect NAS or stop MySQL).

**Steps:**
1. Disconnect shared library
2. Wait for carousel pop tick
3. Check log — should see: "replacement returned nothing — aborting pop, queue unchanged"
4. Verify queue file on disk is unchanged (not shortened)
5. Reconnect library — next tick should pop and replace successfully

**Expected Result:** Queue not shortened when library is down. No data loss. Retry succeeds.

**Pass / Fail:** ___________

---

## SECTION 11 — Combo Block + Interleave

---

### TC-33 — Combo block: correct episode sequence in TV channel queue

**Setup:** TV channel with combo block interleaved (freq=3).

**Steps:**
1. Open queue file for the TV channel
2. Count primary items between each combo block insertion — should all be 3
3. Verify combo block units have the correct slot order and correct eps_per_slot count
4. e.g. with CC(eps=2), LT(eps=2): each unit = CC,CC,LT,LT

**Expected Result:** Interleave fires every 3 primary items. Unit structure matches slot configuration.

**Pass / Fail:** ___________

---

### TC-34 — Combo block: correct starting episode after channel creation

**Setup:** TV channel with combo block interleave — freshly created.

**Steps:**
1. Open `queue_{tv_channel_id}.json`
2. Find first combo block unit — TV-slot show should start at S01E01
3. Open `queue_{combo_block_id}.json`
4. Same show should start at the episode AFTER the last one used by the TV channel queue
5. No episode appears in BOTH queues

**Expected Result:** TV channel interleave starts from S01E01. Standalone combo queue continues from where TV left off. No overlap.

**Pass / Fail:** ___________

---

### TC-35 — Combo block: 1-for-1 slot replacement

**Setup:** TV channel with combo block interleaved, playing.

**Steps:**
1. Note the current queue depth
2. Play through one full combo block unit (all slots)
3. After each slot: verify no replacement yet (queue depth unchanged for combo items)

Wait — **Note:** In 3.x, combo slots replace 1-for-1 immediately per slot, not per unit. Verify:

1. Let one combo slot play to completion
2. Check queue file — one new slot item should be at the tail
3. Repeat for each slot in the unit
4. Queue depth stays stable throughout

**Expected Result:** Each slot immediately gets a 1-for-1 replacement at the queue tail. Queue depth never drops.

**Pass / Fail:** ___________

---

### TC-36 — Combo block: episode never repeats immediately after 3.0.71 fix

**Setup:** TV channel with combo block interleave running for 1+ hour.

**Steps:**
1. Let channel run (carousel or playing)
2. After 1+ hour, check `queue_{tv_channel_id}.json`
3. Find the TV-slot show items in the combo block positions
4. Verify episodes are different from each other (not all the same episode repeating)
5. Check state.json — `show_slot` and `tv_next_ep` should have advanced significantly

**Expected Result:** No episode repeats forever. State advances correctly on each replacement.

**Pass / Fail:** ___________

---

## SECTION 12 — Interleave

---

### TC-37 — Add an interleave source

**Setup:** Two visible TV or Movie channels. Neither carousel-enabled.

**Steps:**
1. Right-click target channel → **Manage Interleave**
2. Select **[Add Source]** → select source channel
3. Interleave mode → **Fixed - every N items**
4. Frequency → enter 4
5. Count per insertion → enter 1
6. Visible/Silent → **Visible**
7. Notification: **Source saved.**
8. Done
9. Play channel — interleaved items appear approximately every 4 primary items

**Expected Result:** Interleave source saved. Items appear at correct frequency.

**Pass / Fail:** ___________

---

### TC-38 — Carousel guard on interleave source picker

**Setup:** One carousel-enabled channel, one non-carousel channel.

**Steps:**
1. Right-click non-carousel channel → **Manage Interleave** → Add Source
2. Verify carousel-enabled channel does NOT appear in the source picker
3. An informational note may appear explaining why carousel channels are excluded

**Expected Result:** Carousel channels excluded from interleave source picker.

**Pass / Fail:** ___________

---

## SECTION 13 — Scheduling

---

### TC-39 — Create a schedule

**Setup:** Two TV channels — neither carousel-enabled.

**Steps:**
1. Right-click target channel → **Add Schedule**
2. Enter schedule name
3. Target channel pre-selected
4. Select source channel
5. Day → **Daily**
6. Start time → a future time
7. Item count → 3
8. Summary dialog → **Yes**
9. Notification: **Schedule saved.**

**Expected Result:** Schedule created and appears in Manage Schedules. No errors.

**Pass / Fail:** ___________

---

### TC-40 — Manage schedules (activate/deactivate/delete)

**Steps:**
1. Settings → **Manage Schedules** (or context menu)
2. Schedule list shows [ACTIVE] or [OFF] prefix for each schedule
3. Select a schedule → **Deactivate** — prefix changes to [OFF]
4. Select again → **Activate** — prefix changes to [ACTIVE]
5. Select again → **Delete** → confirm → notification → schedule removed

**Expected Result:** Toggle and delete work. Prefix updates correctly.

**Pass / Fail:** ___________

---

## SECTION 14 — Channel Info

---

### TC-41 — TV channel info

**Steps:**
1. Right-click TV channel → **Channel Info**
2. Textviewer: heading = **{Channel Name} — Channel Info**
3. Verify presence of: Type, Rotation, Shows list, Interleave section (if configured), Carousel section (if enabled), Schedules section (if any)
4. Carousel section shows correct remaining time (not 60 min default)

**Expected Result:** All labels use correct string IDs. Carousel remaining time is accurate.

**Pass / Fail:** ___________

---

### TC-42 — Combo Block channel info

**Steps:**
1. Enable **Show Hidden Channels** (Settings → Advanced)
2. Right-click Combo Block → **Channel Info**
3. Verify: slot count, each slot's source type, queue depth in items AND units, owner channel name

**Expected Result:** Slot details and unit count correct. Owner channel shown.

**Pass / Fail:** ___________

---

## SECTION 15 — Operational

---

### TC-43 — Refresh library cache

**Steps:**
1. Settings → Cache → **Refresh Library Cache**
2. Progress dialog appears
3. Completes — notification appears
4. `cache_age_display` setting updates to "0 days old"

**Expected Result:** Cache rebuilds silently. Notification correct. Age display updates.

**Pass / Fail:** ___________

---

### TC-44 — Library cache auto-rebuild after Kodi scan

**Steps:**
1. Run a Kodi library scan (Videos → Update Library)
2. After scan completes, check log for: **VideoLibrary.OnScanFinished — rebuilding cache**
3. Library cache rebuilds in background

**Expected Result:** onNotification fires on scan completion. Cache rebuilds automatically. No manual refresh needed.

**Pass / Fail:** ___________

---

### TC-45 — Backup and Restore

**Setup:** Backup folder path configured in Settings → Backup & Restore.

**Steps:**
1. Settings → Backup & Restore → **Backup Addon Data**
2. Success dialog shows filename and file count
3. Settings → Backup & Restore → **Restore Addon Data**
4. Select the zip just created
5. File multiselect — all pre-selected → OK
6. Confirm → restore completes
7. Success dialog lists restored files

**Expected Result:** Backup creates valid zip. Restore successfully overwrites files.

**Pass / Fail:** ___________

---

### TC-46 — View Exclusions

**Setup:** A TV channel with at least one excluded episode.

**Steps:**
1. Right-click channel → **View Exclusions**
2. Textviewer shows excluded episodes in S01E01 — Title format
3. Right-click a channel with NO exclusions → **View Exclusions**
4. ok dialog: no exclusions message

**Expected Result:** Exclusion list correct. Empty message correct.

**Pass / Fail:** ___________

---

### TC-47 — View Missing Durations

**Setup:** A folder channel where some items had no NFO duration.

**Steps:**
1. Right-click folder channel → **Missing Durations (N)** (visible only when entries exist)
2. Textviewer lists each item: show name, episode label, file path, reason
3. A channel with NO missing durations → menu item not shown

**Expected Result:** Missing durations listed. Item absent when no entries exist.

**Pass / Fail:** ___________

---

## SECTION 16 — Settings

---

### TC-48 — Settings → Resume poll interval

**Steps:**
1. Settings → Resume → **Background Polling Interval** — verify default = 60
2. Change to 120 — while playing, resume save interval changes to ~120s
3. Set to 0 — verify this disables polling (no position saves)
4. Restore to 60

**Expected Result:** Setting is respected. No hard floor enforced by code (other than 1s minimum).

**Pass / Fail:** ___________

---

### TC-49 — Settings → Show Hidden Channels

**Steps:**
1. Create a hidden TV channel (Visibility → Hide)
2. Settings → Advanced → **Show Hidden Channels** = false — channel not in list
3. Set to true — hidden channel appears in list
4. Verify Combo Blocks (always hidden) obey this setting too

**Expected Result:** Hidden channels toggle correctly. Combo Blocks only visible when Show Hidden Channels = true.

**Pass / Fail:** ___________

---

## SECTION 17 — Regression (confirmed working in earlier builds)

These were confirmed in earlier sessions. Re-run if any related area changed.

| TC | Area | What to verify |
|----|------|----------------|
| TC-R01 | 1-for-1 basic | Queue stays exactly at queue_size during all playback |
| TC-R02 | Carousel same-show | Pop of Show A → replacement is Show A next ep, not Show B |
| TC-R03 | Silent at queue front | Silent bumper at position [0] plays first — no reordering |
| TC-R04 | Hard Start (StopReason) | HARD_START stop: no resume save, no queue advance |
| TC-R05 | StopReason paths | USER=save resume, NATURAL=advance queue, UNKNOWN=USER |
| TC-R06 | No carousel live join | Playback starts at item beginning, not mid-item |
| TC-R07 | Audio album picker | Nothing pre-selected. Select All button works. |
| TC-R08 | Serial channel | Each show plays fully before the next begins |
| TC-R09 | Reset Show | Context menu Reset Show: only that show's position resets |
| TC-R10 | Skip detection | Skip 3 items → 3 replacements at tail, queue size unchanged |

---

## Test Summary

| Section | TCs | Pass | Fail | Notes |
|---------|-----|------|------|-------|
| 1 — TV Channel Creation | 7 | | | |
| 2 — Serial Channel | 1 | | | |
| 3 — Movie Channel | 1 | | | |
| 4 — Folder Channel | 1 | | | |
| 5 — Audio Channel | 1 | | | |
| 6 — Party Channel | 1 | | | |
| 7 — Combo Block | 5 | | | |
| 8 — Context Menu | 3 | | | |
| 9 — Queue and Playback | 6 | | | |
| 10 — Carousel | 6 | | | |
| 11 — Combo + Interleave | 4 | | | |
| 12 — Interleave | 2 | | | |
| 13 — Scheduling | 2 | | | |
| 14 — Channel Info | 2 | | | |
| 15 — Operational | 5 | | | |
| 16 — Settings | 2 | | | |
| 17 — Regression | 10 | | | |
| **TOTAL** | **60** | | | |

---

*Generated: 2026-09-10 | SmartChannels 3.0.75*
